' Motmot photo sorter - starts the program window without a black console (ASCII only).
' The desktop shortcut points here. It finds Node by itself (node-path.txt, then the usual places),
' so the .cmd is only needed once when Node is not installed at all.
' Watchdog: if the program stops abnormally (crash, out of memory), it is started again (--restarted).
' A normal close (window closed) exits with code 0 and ends this script.
Option Explicit
Dim fso, sh, here, np, node, f, arg, cands, c, code, tries, started
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
here = fso.GetParentFolderName(WScript.ScriptFullName)
np = here & "\node-path.txt"
node = ""
If fso.FileExists(np) Then
  If fso.GetFile(np).Size > 0 Then node = Trim(fso.OpenTextFile(np, 1).ReadLine)
  If Not fso.FileExists(node) Then node = ""
End If
If node = "" Then
  cands = Array(sh.ExpandEnvironmentStrings("%ProgramFiles%\nodejs\node.exe"), _
    sh.ExpandEnvironmentStrings("%LOCALAPPDATA%\motmot-photo\node\node.exe"), _
    sh.ExpandEnvironmentStrings("%ProgramFiles(x86)%\nodejs\node.exe"), _
    sh.ExpandEnvironmentStrings("%LOCALAPPDATA%\Programs\nodejs\node.exe"), _
    sh.ExpandEnvironmentStrings("%ProgramFiles%\Adobe\Adobe Creative Cloud Experience\libs\node.exe"))
  For Each c In cands
    If node = "" Then
      If fso.FileExists(c) Then node = c
    End If
  Next
  If node <> "" Then fso.CreateTextFile(np, True).WriteLine node
End If
If node = "" Then
  ' No Node anywhere: run the .cmd once (it downloads portable Node and comes back here)
  For Each f In fso.GetFolder(here).Files
    If LCase(fso.GetExtensionName(f.Name)) = "cmd" Then sh.Run """" & f.Path & """", 1, False : WScript.Quit
  Next
  WScript.Quit
End If
arg = ""
If WScript.Arguments.Count > 0 Then arg = " """ & WScript.Arguments(0) & """"
sh.CurrentDirectory = here
tries = 0
code = sh.Run("""" & node & """ --max-old-space-size=4096 """ & here & "\main.mjs""" & arg, 0, True)
Do While code <> 0 And tries < 5
  tries = tries + 1
  started = Timer
  code = sh.Run("""" & node & """ --max-old-space-size=4096 """ & here & "\main.mjs"" --restarted", 0, True)
  ' ran for more than 10 minutes before stopping again: count it as a fresh start
  If Abs(Timer - started) > 600 Then tries = 0
Loop
