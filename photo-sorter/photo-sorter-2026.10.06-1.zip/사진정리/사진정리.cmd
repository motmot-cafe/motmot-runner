@echo off
rem Motmot photo sorter launcher (ASCII only - cmd.exe misreads UTF-8 text).
rem First run: double-click this once. It finds Node, makes the desktop icon, and opens the program window.
rem After that, use the desktop icon. You can also drag a .zip / folder onto this file.
setlocal
set "HERE=%~dp0"
set "NODE="
for /f "delims=" %%i in ('where node 2^>nul') do if not defined NODE set "NODE=%%i"
if not defined NODE if exist "%ProgramFiles%\nodejs\node.exe" set "NODE=%ProgramFiles%\nodejs\node.exe"
if not defined NODE if exist "%LOCALAPPDATA%\motmot-photo\node\node.exe" set "NODE=%LOCALAPPDATA%\motmot-photo\node\node.exe"
if not defined NODE if exist "%ProgramFiles%\Adobe\Adobe Creative Cloud Experience\libs\node.exe" set "NODE=%ProgramFiles%\Adobe\Adobe Creative Cloud Experience\libs\node.exe"
if not defined NODE (
  echo Node.js not found. Downloading portable Node.js 22 from nodejs.org ^(about 30MB, once^)...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $b='https://nodejs.org/dist/latest-v22.x/'; $sums=(Invoke-WebRequest -UseBasicParsing ($b+'SHASUMS256.txt')).Content; $line=($sums -split \"`n\" | Where-Object { $_ -match 'win-x64\.zip$' })[0]; $hash,$name=$line -split '\s+'; $dst=Join-Path $env:LOCALAPPDATA 'motmot-photo'; New-Item -ItemType Directory -Force $dst | Out-Null; $zip=Join-Path $dst $name; Invoke-WebRequest -UseBasicParsing ($b+$name) -OutFile $zip; if ((Get-FileHash $zip -Algorithm SHA256).Hash.ToLower() -ne $hash.ToLower()) { throw 'checksum mismatch' }; Expand-Archive $zip $dst -Force; Remove-Item $zip; $d=Get-ChildItem $dst -Directory | Where-Object Name -like 'node-v*-win-x64' | Select-Object -First 1; if (Test-Path (Join-Path $dst 'node')) { Remove-Item (Join-Path $dst 'node') -Recurse -Force }; Rename-Item $d.FullName 'node'"
  if exist "%LOCALAPPDATA%\motmot-photo\node\node.exe" set "NODE=%LOCALAPPDATA%\motmot-photo\node\node.exe"
)
if not defined NODE (
  echo Could not get Node.js. Install it from https://nodejs.org and run this again.
  pause
  exit /b 1
)
rem Remember node for the no-console launcher, make the desktop icon once, then start without a console.
> "%HERE%node-path.txt" echo %NODE%
if not exist "%HERE%.shortcut-made" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%HERE%make-shortcut.ps1" && echo done> "%HERE%.shortcut-made"
)
if exist "%WINDIR%\System32\wscript.exe" (
  start "" "%WINDIR%\System32\wscript.exe" "%HERE%photo-sorter.vbs" %*
  exit /b 0
)
"%NODE%" --max-old-space-size=4096 "%HERE%main.mjs" %*
if errorlevel 1 pause
