/* 사진정리 새 판 올리기 — 개발자용(사장님 PC 에서는 안 씀).
   node tools/photo-sorter/publish.mjs <motmot-runner 폴더> "바뀐 점(줄은 \n)"
   → <runner>/photo-sorter/photo-sorter-<VERSION>.zip(안에 「사진정리/…」) · latest.json(판 · 안내 · zip 주소 · sha256 · 크기)
   바로 앞 판 zip 하나는 남기고(되돌릴 때) 그보다 옛것은 지운다. 그다음 runner 를 커밋 · push.
   VERSION 을 먼저 올리고(2026.MM.DD-N) 이 저장소에 머지한 뒤에 돌린다 — zip 은 git 이 아는 파일만(git ls-files) 담는다. */
import { execFileSync } from "node:child_process";
import { readFileSync, writeFileSync, mkdirSync, readdirSync, rmSync, statSync } from "node:fs";
import { join, dirname, resolve } from "node:path";
import { createHash } from "node:crypto";
import { fileURLToPath } from "node:url";
import { writeZip } from "./lib/zip.mjs";
import { PREFIX } from "./lib/update.mjs";

const HERE = dirname(fileURLToPath(import.meta.url));
const [runner, notes = ""] = process.argv.slice(2);
if (!runner) { console.error('쓰는 법: node tools/photo-sorter/publish.mjs <motmot-runner 폴더> "바뀐 점"'); process.exit(1); }
const ver = readFileSync(join(HERE, "VERSION"), "utf8").trim();
const files = execFileSync("git", ["ls-files", "-z", "."], { cwd: HERE }).toString("utf8").split("\0").filter(Boolean);
const out = join(resolve(runner), "photo-sorter");
mkdirSync(out, { recursive: true });
const name = `photo-sorter-${ver}.zip`;
await writeZip(join(out, name), files.map((f) => ({ name: PREFIX + f, path: join(HERE, f) })), { deflate: true });
const buf = readFileSync(join(out, name));
const latest = {
  version: ver, notes: notes.replace(/\\n/g, "\n"),
  zip: `https://raw.githubusercontent.com/motmot-cafe/motmot-runner/main/photo-sorter/${name}`,
  sha256: createHash("sha256").update(buf).digest("hex"), size: buf.length,
};
writeFileSync(join(out, "latest.json"), JSON.stringify(latest, null, 2) + "\n");
// 지금 판 + 바로 앞 판만 남긴다
const zips = readdirSync(out).filter((f) => /^photo-sorter-.*\.zip$/.test(f)).sort((a, b) => statSync(join(out, b)).mtimeMs - statSync(join(out, a)).mtimeMs);
for (const z of zips.slice(2)) rmSync(join(out, z));
console.log(`올릴 준비: ${join(out, name)} (${Math.round(buf.length / 1024)}KB · ${files.length}개 파일) — runner 를 커밋 · push 하세요`);
