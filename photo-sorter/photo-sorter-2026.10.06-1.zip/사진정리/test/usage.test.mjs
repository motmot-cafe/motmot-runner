import test from "node:test";
import assert from "node:assert/strict";
import { mkdirSync, writeFileSync, existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { readUsage } from "../lib/usage.mjs";
import { Job } from "../lib/job.mjs";
import { writeZip } from "../lib/zip.mjs";
import { tmp, fakeJpeg } from "./_helpers.mjs";

function fakeAppdata() {
  const d = tmp();
  const rec = join(d, "모토모토-블로그원고", "원고기록");
  mkdirSync(rec, { recursive: true });
  mkdirSync(join(d, "모토모토-사진정리"), { recursive: true });
  return { d, rec, env: { APPDATA: d } };
}

test("원고기 기록 — 모양에 기대지 않고 어느 칸이든 정리된 사진 이름 · 공간목록 열쇠를 찾는다 · 약속 파일도 읽는다", () => {
  const { d, rec, env } = fakeAppdata();
  writeFileSync(join(rec, "job-1.json"), JSON.stringify({ keyword: "춘천 카페", created_at: "2026-10-01T01:00:00Z",
    blocks: [{ photos: [{ what: "글래스룸 — cafe-glass-room-003.jpg", tip: "" }] }, { photos: [{ file: "ai작업/사진/카페/카페 외부/cafe-cafe-outside-001.jpg" }] }] }));
  writeFileSync(join(rec, "_피할말학습.json"), JSON.stringify({ x: "cafe-glass-room-009.jpg" })); // 원고가 아닌 파일은 안 읽는다
  writeFileSync(join(rec, "깨짐.json"), "{");
  writeFileSync(join(d, "모토모토-사진정리", "사용한사진.jsonl"), '{"파일":"PENSION-BBQ-002.JPG","원고":"바베큐 글","날짜":"2026-10-02"}\n깨진 줄\n');
  const u = readUsage(env);
  assert.deepEqual(u.map((x) => [x.파일 || x.열쇠, x.원고, x.날짜]), [
    ["cafe-glass-room-003.jpg", "춘천 카페", "2026-10-01"],
    ["ai작업/사진/카페/카페 외부/cafe-cafe-outside-001.jpg", "춘천 카페", "2026-10-01"],
    ["cafe-cafe-outside-001.jpg", "춘천 카페", "2026-10-01"],
    ["pension-bbq-002.jpg", "바베큐 글", "2026-10-02"],
  ]);
});

test("정리한 뒤 원고기가 쓴 사진이 저절로 「사용한 원고사진」 으로 — 사장님이 푼 것은 다시 안 묶는다", async () => {
  const { rec, env } = fakeAppdata();
  const d = tmp();
  const z = join(d, "s.zip");
  await writeZip(z, [{ name: "a.jpg", data: fakeJpeg(1) }, { name: "b.jpg", data: fakeJpeg(2) }]);
  const j = new Job(z);
  const [a, b] = j.photos;
  j.edit([a.id, b.id], { 공간: "글래스룸" });
  await j.organize();
  assert.ok(existsSync(join(j.dir, "원본/카페/글래스룸/cafe-glass-room-002.jpg")));
  writeFileSync(join(rec, "job-7.json"), JSON.stringify({ title: "글래스룸 대관 후기", text: "[사진] cafe-glass-room-002.jpg" }));
  assert.equal(j.applyUsage(readUsage(env)), 1);
  assert.equal(b.사용.원고, "글래스룸 대관 후기"); assert.equal(b.사용.자동, "원고기");
  await j.organize();
  assert.ok(existsSync(join(j.dir, "사용한 원고사진/글래스룸 대관 후기/원본/cafe-glass-room-002.jpg")));
  assert.ok(!existsSync(join(j.dir, "원본/카페/글래스룸/cafe-glass-room-002.jpg")));
  const list = JSON.parse(readFileSync(join(j.dir, "공간목록.json"), "utf8"));
  assert.equal(Object.keys(list.사진).length, 1);
  // 다시 읽어도 두 번 묶지 않는다 · 옮긴 뒤의 이름으로도 같은 사진
  assert.equal(j.applyUsage(readUsage(env)), 0);
  // 사장님이 풀면 원고기 기록이 남아 있어도 그대로
  j.edit([b.id], { 사용: null });
  assert.equal(j.applyUsage(readUsage(env)), 0);
  assert.equal(b.사용, undefined);
});
