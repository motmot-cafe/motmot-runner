/* 원고기와 함께 · 새 사진 자동 정리(블로그 원고기 판 2026.10.02-4 — 사장님 2026-10-02 「사진정리 프로그램이랑 블로그 원고프로그램이 통합운영 되었으면 좋겠음」 ·
   「폴더링 되어있으니까, 그거 알아서 새로 업로드 된 사진들 찾아서 추가 폴더링 작업하고, 원고 프로그램에서는 그 사진들을 카테고리별로 필요한거 찾아서 이용하고」) */
import test from "node:test";
import assert from "node:assert/strict";
import { existsSync, readFileSync, writeFileSync, mkdirSync, utimesSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";
import { Job } from "../lib/job.mjs";
import { tmp, fakeJpeg } from "./_helpers.mjs";

const HERE = dirname(fileURLToPath(import.meta.url));
const 폴더 = () => { const d = tmp(); const src = join(d, "사진"); mkdirSync(src); return { d, src }; };
const 옛날 = (f) => { const t = new Date(Date.now() - 10 * 60 * 1000); utimesSync(f, t, t); };

test("새 사진 찾기(rescan) — 새 파일만 더함(번호 이어서) · 방금 복사 중인 파일은 다음 번 · 지문은 크기 · 바뀐 때가 같으면 그대로 · zip 은 그대로", () => {
  const { src } = 폴더();
  for (const [n, s] of [["a.jpg", 1], ["b.jpg", 2]]) { writeFileSync(join(src, n), fakeJpeg(s)); 옛날(join(src, n)); }
  const j = new Job(src);
  assert.deepEqual(j.photos.map((p) => [p.rel, p.id]), [["a.jpg", "p00001"], ["b.jpg", "p00002"]]);
  assert.deepEqual(j.rescan({ settleMs: 60000 }), { 새: 0, 사라짐: 0, 기다림: 0 });
  writeFileSync(join(src, "c.jpg"), fakeJpeg(3));   // 방금 — 아직 복사 중일 수 있다
  assert.deepEqual(j.rescan({ settleMs: 60000 }), { 새: 0, 사라짐: 0, 기다림: 1 });
  옛날(join(src, "c.jpg"));
  assert.deepEqual(j.rescan({ settleMs: 60000 }), { 새: 1, 사라짐: 0, 기다림: 0 });
  assert.equal(j.photos.find((p) => p.rel === "c.jpg").id, "p00003");
  assert.equal(j.pendingPrep(), 3);
  /* 같은 사진을 앞 이름으로 또 넣어도 먼저 있던 것이 남는다(중복은 새 것) */
  writeFileSync(join(src, "0-copy.jpg"), fakeJpeg(1)); 옛날(join(src, "0-copy.jpg"));
  j.rescan({ settleMs: 60000 });
  const by = Object.fromEntries(j.photos.map((p) => [p.rel, p]));
  assert.equal(by["0-copy.jpg"].중복of, by["a.jpg"].id, "★이미 있던 사진이 중복으로 바뀌었다");
  assert.ok(!by["a.jpg"].중복of);
  /* 다시 읽어도 상태가 남는다(새 Job) */
  assert.equal(new Job(src).photos.length, 4);
});

test("폴더로 정리 번호는 그대로 — 날짜가 이른 새 사진은 뒤 번호(이미 풀어 둔 파일 이름 · 원고기 후보가 안 바뀐다)", async () => {
  const { src } = 폴더();
  for (const [n, s] of [["a.jpg", 1], ["b.jpg", 2]]) { writeFileSync(join(src, n), fakeJpeg(s)); 옛날(join(src, n)); }
  const j = new Job(src);
  const [a, b] = j.photos;
  j.setInfo(a.id, { 찍은날: "2025-07-01 10:00:00" }); j.setInfo(b.id, { 찍은날: "2025-07-02 10:00:00" });
  j.edit([a.id, b.id], { 공간: "객실 침실" });
  assert.deepEqual((await j.organize()).오류, []);
  const P = (x) => join(j.dir, "원본/펜션&풀빌라/객실 침실", x);
  assert.ok(readFileSync(P("pension-room-bedroom-001.jpg")).equals(fakeJpeg(1)) && readFileSync(P("pension-room-bedroom-002.jpg")).equals(fakeJpeg(2)));
  writeFileSync(join(src, "c.jpg"), fakeJpeg(3)); 옛날(join(src, "c.jpg"));
  assert.equal(j.rescan().새, 1);
  const c = j.photos.find((p) => p.rel === "c.jpg");
  j.setInfo(c.id, { 찍은날: "2025-06-01 10:00:00" });   // 가장 이른 날
  j.edit([c.id], { 공간: "객실 침실" });
  assert.deepEqual((await j.organize()).오류, []);
  assert.ok(readFileSync(P("pension-room-bedroom-001.jpg")).equals(fakeJpeg(1)), "★001 이 바뀌었다");
  assert.ok(readFileSync(P("pension-room-bedroom-002.jpg")).equals(fakeJpeg(2)), "★002 가 바뀌었다");
  assert.ok(readFileSync(P("pension-room-bedroom-003.jpg")).equals(fakeJpeg(3)), "새 사진은 003");
  /* 하나를 빼고 다시 — 빈 번호를 다시 쓰지 않는다(빠진 파일을 치우다 새 파일을 지우지 않게) */
  j.edit([a.id], { 제외: true });
  writeFileSync(join(src, "d.jpg"), fakeJpeg(4)); 옛날(join(src, "d.jpg"));
  j.rescan(); const d = j.photos.find((p) => p.rel === "d.jpg"); j.edit([d.id], { 공간: "객실 침실" });
  assert.deepEqual((await j.organize()).오류, []);
  assert.ok(!existsSync(P("pension-room-bedroom-001.jpg")), "뺀 사진은 치운다");
  assert.ok(readFileSync(P("pension-room-bedroom-004.jpg")).equals(fakeJpeg(4)));
});

test("장면 후보 — 장면 글에 공간이 없으면 원고기가 준 공간으로(옛 이름도) · 카테고리가 맞는(또는 공통) 사진만", () => {
  const { src } = 폴더();
  for (const [n, s] of [["a.jpg", 1], ["b.jpg", 2], ["c.jpg", 3]]) { writeFileSync(join(src, n), fakeJpeg(s)); 옛날(join(src, n)); }
  const j = new Job(src);
  const [a, b, c] = j.photos;
  for (const p of [a, b, c]) j.setInfo(p.id, {});
  j.edit([a.id], { 공간: "카페 외부" });
  j.edit([b.id], { 공간: "세미나실" });
  j.edit([c.id], { 공간: "카페 외부" });
  j.edit([c.id], { 카테고리: ["단체"] });
  assert.deepEqual(j.sceneCandidates("정원 모습", "카페", 3).후보, [], "공간 낱말이 없으면 예전처럼 빈 목록");
  const r = j.sceneCandidates("정원 모습", "카페", 3, "카페 외부");
  assert.deepEqual(r.공간, ["카페 외부"]);
  assert.deepEqual(r.후보.map((x) => x.id), [a.id], "카페 사진만(단체 카테고리로 고친 c 는 빠진다)");
  assert.deepEqual(j.sceneCandidates("정원 모습", "카페", 3, "없는 공간").후보, []);
  /* 단체 글은 펜션&풀빌라 사진도(같은 리조트 외관 · 객실 — 2026-10-06 단체 원고 「리조트 외관 전경」 이 비던 것) · 카페 사진은 아니다 */
  j.edit([b.id], { 공간: "외관" });
  j.edit([b.id], { 카테고리: ["펜션&풀빌라"] });
  assert.deepEqual(j.sceneCandidates("리조트 외관 전경", "단체", 3).후보.map((x) => x.id), [b.id], "단체 글에 펜션&풀빌라 외관 사진");
  assert.deepEqual(j.sceneCandidates("리조트 외관 전경", "카페", 3).후보, [], "카페 글에는 펜션&풀빌라 사진을 안 쓴다");
});

test("원고기와 함께(MOTMOT_PHOTO_EMBED) — 마지막 폴더를 저절로 연다 · 새 사진을 찾아 더한다 · /api/scene space · 부모가 꺼지면 함께 꺼진다", async (t) => {
  const { d, src } = 폴더();
  writeFileSync(join(src, "a.jpg"), fakeJpeg(1)); 옛날(join(src, "a.jpg"));
  const app = join(d, "appdata");
  mkdirSync(join(app, "모토모토-사진정리"), { recursive: true });
  writeFileSync(join(app, "모토모토-사진정리", "최근.json"), JSON.stringify([src]));
  const parent = spawn(process.execPath, ["-e", "setTimeout(()=>{}, 60000)"]);
  const port = 5600 + Math.floor(Math.random() * 300);
  const child = spawn(process.execPath, [join(HERE, "..", "main.mjs"), "--no-open", "--port", String(port)], {
    env: { ...process.env, APPDATA: app, MOTMOT_PHOTO_EMBED: "1", MOTMOT_PHOTO_AUTO_MS: "300", MOTMOT_PHOTO_SETTLE_MS: "0", MOTMOT_PARENT_PID: String(parent.pid) },
    stdio: ["ignore", "pipe", "pipe"] });
  t.after(() => { try { child.kill(); } catch {} try { parent.kill(); } catch {} });
  let out = ""; child.stdout.on("data", (b) => { out += b; });
  const 기다리기 = async (f, ms = 8000) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { try { if (await f()) return true; } catch {} await new Promise((r) => setTimeout(r, 100)); } return false; };
  assert.ok(await 기다리기(() => out.includes("모토모토 사진정리 — ")), out);
  assert.match(out, /마지막 폴더를 열었습니다/);
  const st = async () => (await fetch(`http://127.0.0.1:${port}/api/state?light=1`)).json();
  assert.equal((await st()).셈 != null, true, "폴더가 열려 있다");
  assert.equal((await st()).자동.켜짐, true, "함께면 자동 정리가 처음 켜짐");
  writeFileSync(join(src, "b.jpg"), fakeJpeg(2));
  assert.ok(await 기다리기(async () => (await st()).준비모자람 === 2), "새 사진을 찾아 더했다(준비 2장 남음)");
  assert.ok(existsSync(join(app, "모토모토-사진정리", "실행기록.txt")) && /새 사진 1장 찾음/.test(readFileSync(join(app, "모토모토-사진정리", "실행기록.txt"), "utf8")));
  const sc = await (await fetch(`http://127.0.0.1:${port}/api/scene?text=${encodeURIComponent("정원 모습")}&cat=${encodeURIComponent("카페")}&n=3&space=${encodeURIComponent("카페 외부")}`)).json();
  assert.deepEqual([sc.ok, sc.공간], [true, ["카페 외부"]]);
  /* 끄기 스위치 */
  await fetch(`http://127.0.0.1:${port}/api/auto`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ 켜짐: false }) });
  assert.equal((await st()).자동.켜짐, false);
  /* 부모가 꺼지면 함께 */
  parent.kill();
  assert.ok(await 기다리기(() => child.exitCode !== null, 15000), "원고기가 꺼졌는데 사진정리가 안 꺼졌다");
  assert.match(readFileSync(join(app, "모토모토-사진정리", "실행기록.txt"), "utf8"), /원고기가 꺼져 함께 끔/);
});
