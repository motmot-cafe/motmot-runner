import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { Job } from "../lib/job.mjs";
import { classifyJob, findClaude, cleanEnv, buildPrompt, SCHEMA, toKorean } from "../lib/classify.mjs";
import { writeZip } from "../lib/zip.mjs";
import { tmp, fakeJpeg, fakeClaude } from "./_helpers.mjs";

async function jobWith(n) {
  const d = tmp();
  const z = join(d, "s.zip");
  await writeZip(z, Array.from({ length: n }, (_, i) => ({ name: `p${i}.jpg`, data: fakeJpeg(i + 1) })));
  const j = new Job(z);
  for (const p of j.photos) { writeFileSync(j.thumbPath(p.id), fakeJpeg(50)); j.setInfo(p.id, { w: 10, h: 10, dhash: (Number(p.id.slice(1)) * 0x1111111).toString(16).padStart(16, "f").slice(0, 16) }); }
  return { d, j };
}

test("10장씩 묶어 부르고, 답을 사진마다 붙인다 — 확신 낮음은 확인필요", async () => {
  const { d, j } = await jobWith(12);
  const bin = fakeClaude(d);
  const r = await classifyJob(j, { env: { ...process.env, MOTMOT_CLAUDE_BIN: bin, ANTHROPIC_API_KEY: "x" }, parallel: 1 });
  assert.ok(r.ok, r.msg);
  assert.equal(r.calls, 2);
  const calls = readFileSync(join(d, "calls.log"), "utf8").trim().split("\n").map((l) => JSON.parse(l));
  assert.ok(calls[0].args.includes("--tools") && calls[0].args.includes("Read"));
  assert.ok(calls[0].args.includes("--model") && calls[0].args.includes("sonnet"));
  assert.ok(!calls[0].args.includes("--bare"));
  const ps = j.photos;
  assert.equal(ps[0].공간, "객실 침실"); assert.equal(ps[0].본사람, "클로드");
  assert.equal(ps[1].공간, "글래스룸"); // 「식당」 이라 답해도 옮겨 읽는다
  assert.equal(ps[9].본사람, "확인필요"); // 묶음의 마지막 = 확신 낮음
  assert.ok(ps.every((p) => p.공간));
});

test("비슷한 묶음은 대표 한 장만 보인다", async () => {
  const { d, j } = await jobWith(5);
  for (const p of j.photos) j.setInfo(p.id, { dhash: "0123456789abcdef" });
  const bin = fakeClaude(d);
  const r = await classifyJob(j, { env: { ...process.env, MOTMOT_CLAUDE_BIN: bin } });
  assert.ok(r.ok);
  const calls = readFileSync(join(d, "calls.log"), "utf8").trim().split("\n");
  assert.equal(calls.length, 1);
  assert.ok(j.photos.every((p) => p.공간 === "객실 침실"));
});

test("한도에 걸리면 멈추고 알아듣게 말한다 · 이미 붙은 건 다시 안 부른다", async () => {
  const { d, j } = await jobWith(3);
  const r = await classifyJob(j, { env: { ...process.env, MOTMOT_CLAUDE_BIN: fakeClaude(d, "limit") } });
  assert.equal(r.ok, false);
  assert.match(r.msg, /한도/);
  const ok = await classifyJob(j, { env: { ...process.env, MOTMOT_CLAUDE_BIN: fakeClaude(d) } });
  assert.ok(ok.ok);
  const again = await classifyJob(j, { env: { ...process.env, MOTMOT_CLAUDE_BIN: fakeClaude(d) } });
  assert.equal(again.calls, 0);
});

test("claude 가 없으면 알려 준다 · API 키는 빼고 부른다", () => {
  assert.equal(findClaude({ PATH: "/nowhere", HOME: "/nowhere" }, "linux").found, false);
  assert.deepEqual(Object.keys(cleanEnv({ ANTHROPIC_API_KEY: 1, CLAUDECODE: 1, PATH: "p" })), ["PATH"]);
});

test("프롬프트에 사장님 표 · 구별 단서가 들어가고, 답 모양의 카테고리는 넷뿐", () => {
  const t = buildPrompt(["01.jpg", "02.jpg"]);
  for (const w of ["식당2층", "식당3층 반찬 케이터링", "글래스룸", "카페 실내수영장", "족구장", "흰 조각상", "글래스룸 앞", "삼각", "Ciel"]) assert.ok(t.includes(w), w);
  assert.deepEqual(SCHEMA.properties.photos.items.properties.categories.items.enum, ["펜션&풀빌라", "단체", "카페", "공통"]);
});

test("얼굴 · 누움 · 어두움 제안이 가공으로 들어가고 웹용을 다시 그리게 한다 · 사람 있는 묶음은 따라 하지 않는다", async () => {
  const { d, j } = await jobWith(3);
  for (const p of j.photos) j.setInfo(p.id, { dhash: "0123456789abcdef" }); // 셋 다 비슷
  const r = await classifyJob(j, { env: { ...process.env, MOTMOT_CLAUDE_BIN: fakeClaude(d, "face") } });
  assert.ok(r.ok, r.msg);
  const calls = readFileSync(join(d, "calls.log"), "utf8").trim().split("\n");
  assert.equal(calls.length, 2); // 대표에 얼굴 → 나머지 둘은 따로 보인다
  const [a, b] = j.photos;
  assert.deepEqual(a.가공.얼굴, [[0.2, 0.3, 0.3, 0.25]]);
  assert.equal(a.웹다시, true);
  assert.ok(j.photos.slice(1).some((p) => p.가공?.회전 === 90 && p.가공.밝기 === 20));
  assert.ok(j.photos.slice(1).some((p) => p.가공?.기울기 === -2.5 && p.가공.색온도 === 15 && p.가공.대비 === 10));
  assert.ok(j.pendingWeb() >= 2);
  await assert.rejects(j.organize(), /가공.*남았습니다/);
  for (const p of j.photos) j.webDone(p.id);
  assert.equal(j.pendingWeb(), 0);
});

test("예전에 나눠 둔 폴더 이름은 참고 단서로 프롬프트에(파일 이름 · 카메라 폴더는 뺌)", async () => {
  const { folderHint, buildPrompt } = await import("../lib/classify.mjs");
  assert.equal(folderHint("모토모토리조트 사진/카페/글래스룸/IMG_1.jpg"), "모토모토리조트 사진 / 카페 / 글래스룸");
  assert.equal(folderHint("DCIM/100APPLE/IMG_2.jpg"), "");
  const t = buildPrompt(["01.jpg", "02.jpg"], ["펜션 / 101호", ""]);
  assert.match(t, /01\.jpg: 펜션 \/ 101호/); assert.match(t, /사진이 우선/);
  assert.ok(!/참고 —/.test(buildPrompt(["01.jpg"], [""])));
});

test("스키마 키는 영문만(API 가 한글 키를 거절) · 답은 한글 키로 되돌린다", () => {
  const keys = [];
  const walk = (o) => { if (o && typeof o === "object") for (const [k, v] of Object.entries(o)) { if (k === "properties") keys.push(...Object.keys(v)); walk(v); } };
  walk(SCHEMA);
  assert.ok(keys.length > 20);
  for (const k of keys) assert.match(k, /^[a-zA-Z0-9_.-]{1,64}$/, k);
  const r = toKorean({ photos: [{ file: "01.jpg", space: "카페 외부", tune: { brightness: 5 }, faces: [{ x: 1, y: 2, w: 3, h: 4 }] }] });
  assert.deepEqual(r, { 사진: [{ 파일: "01.jpg", 공간: "카페 외부", 보정: { 밝기: 5 }, 얼굴: [{ x: 1, y: 2, w: 3, h: 4 }] }] });
  assert.deepEqual(toKorean({ 사진: [{ 파일: "a" }] }), { 사진: [{ 파일: "a" }] });
});

test("Claude 답의 사용량을 읽는다", async () => {
  const { usageOf } = await import("../lib/classify.mjs");
  assert.deepEqual(usageOf({ usage: { input_tokens: 4, output_tokens: 2825, cache_creation_input_tokens: 10973, cache_read_input_tokens: 10932 }, total_cost_usd: 0.079, duration_ms: 17400 }),
    { 입력: 4, 출력: 2825, 캐시쓰기: 10973, 캐시읽기: 10932, 달러: 0.079, 초: 17 });
  assert.equal(usageOf(null), null);
});
