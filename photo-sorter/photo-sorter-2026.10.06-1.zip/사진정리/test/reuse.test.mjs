import test from "node:test";
import assert from "node:assert/strict";
import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { Job, ISOLATED, RECOMPOSE, USED } from "../lib/job.mjs";
import { writeZip } from "../lib/zip.mjs";
import { tmp, fakeJpeg } from "./_helpers.mjs";
import { writeFileSync } from "node:fs";

async function three() {
  const d = tmp();
  const z = join(d, "s.zip");
  await writeZip(z, [{ name: "a.jpg", data: fakeJpeg(1) }, { name: "b.jpg", data: fakeJpeg(2) }, { name: "c.jpg", data: fakeJpeg(3) }]);
  const j = new Job(z);
  const [a, b, c] = j.photos;
  j.setInfo(a.id, { w: 10, h: 10, dhash: "ffff0000ffff0000" });
  j.setInfo(b.id, { w: 10, h: 10, dhash: "ffff0000ffff0001" }); // a 와 같은 구도
  j.setInfo(c.id, { w: 10, h: 10, dhash: "0000ffff0000ffff" });
  j.edit([a.id, b.id, c.id], { 공간: "글래스룸" });
  for (const p of [a, b, c]) { writeFileSync(j.webPath(p.id), fakeJpeg(7, 300)); j.webDone(p.id); }
  j.setWebHash(a.id, "ffff0000ffff0000"); j.setWebHash(b.id, "ffff0000ffff0001"); j.setWebHash(c.id, "0000ffff0000ffff");
  return { j, a, b, c };
}

test("한 장을 쓰면 같은 구도 묶음은 「재구성 필요」 — 공간목록에서 둘 다 빠지고 다른 사진은 그대로", async () => {
  const { j, a, b, c } = await three();
  j.edit([a.id], { 사용: { 원고: "원고1" } });
  assert.equal(j.status(a), "사용"); assert.equal(j.status(b), "재구성필요"); assert.equal(j.status(c), "보통");
  await j.organize();
  const list = JSON.parse(readFileSync(join(j.dir, "공간목록.json"), "utf8"));
  assert.deepEqual(Object.values(list.사진).map((v) => v.원본), ["c.jpg"]);
  assert.ok(existsSync(join(j.dir, `${USED}/원고1/원본/cafe-glass-room-001.jpg`)));
  assert.ok(existsSync(join(j.dir, `${RECOMPOSE}/원본/카페/글래스룸/cafe-glass-room-002.jpg`)));
  assert.match(readFileSync(join(j.dir, "목록.csv"), "utf8"), /재구성 필요/);
});

test("재구성 — 가공이 같거나 웹용 지문이 덜 달라지면 거절, 충분히 달라지면 재탕 표시와 함께 목록으로", async () => {
  const { j, a } = await three();
  j.edit([a.id], { 사용: { 원고: "원고1" } });
  assert.throws(() => j.edit([a.id], { 재구성: true }), /가공이 같습니다/);
  j.edit([a.id], { 가공: { 자르기: [0.1, 0.1, 0.8, 0.8] } });
  assert.throws(() => j.edit([a.id], { 재구성: true }), /그리는 중/);
  j.webDone(a.id); j.setWebHash(a.id, "ffff0000ffff00ff"); // 8비트만 다름
  assert.throws(() => j.edit([a.id], { 재구성: true }), /너무 비슷합니다\(차이 8\/64/);
  j.setWebHash(a.id, "0f0f0f0fffff0000"); // 16비트 다름
  j.edit([a.id], { 재구성: true });
  assert.equal(j.status(a), "보통");
  assert.equal(j.spaceList().사진[Object.keys(j.spaceList().사진).find((k) => j.spaceList().사진[k].원본 === "a.jpg")].재탕, 1);
});

test("같은 구도 묶음이 재탕 한도(3번)를 다 쓰면 격리 — 목록에 다시 안 나온다", async () => {
  const { j, a, b } = await three();
  j.edit([a.id], { 사용: { 원고: "원고1" } });
  j.edit([b.id], { 사용: { 원고: "원고2" } });
  assert.equal(j.status(a), "사용");
  j.edit([a.id], { 사용: { 원고: "원고3" } });
  assert.equal(j.status(a), "격리"); assert.equal(j.status(b), "격리");
  assert.throws(() => j.edit([b.id], { 재구성: true }), /격리/);
  await j.organize();
  assert.ok(existsSync(join(j.dir, `${ISOLATED}/원본/카페/글래스룸/cafe-glass-room-001.jpg`)));
  assert.equal(j.summary().격리, 2);
  // 같은 원고로 두 번 묶이지 않는다 · 풀기는 마지막 기록을 지운다
  const { j: k, c } = await three();
  k.edit([c.id], { 사용: { 원고: "x" } }); k.edit([c.id], { 사용: { 원고: "x" } });
  assert.equal(c.사용기록.length, 1);
  k.edit([c.id], { 사용: null });
  assert.equal(c.사용기록.length, 0); assert.equal(k.status(c), "보통");
});
