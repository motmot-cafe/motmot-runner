import test from "node:test";
import assert from "node:assert/strict";
import { SPACES, ALIASES, spaceInfo, normalizeCategories, spaceSlug, CATEGORIES, safeFolder } from "../lib/spaces.mjs";

// 제작도구 ai작업/사진/공간목록.json(2026-09-28 · 142장)에 실제로 있는 공간 이름 — 하나도 길을 잃으면 안 된다
const 옛목록 = ["객실 침실", "객실 거실", "객실 테라스", "객실 거실·주방", "객실 실내수영장", "바베큐 자리", "객실 욕실", "객실 주방", "카페", "야외수영장",
  "애견 운동장", "외관", "객실 스파", "객실 다락", "객실 복층", "식당", "대연회장", "세미나실", "야외 테라스", "객실 라운지", "애견카페 실내"];

test("옛 공간목록의 이름은 모두 표에 있거나 옮겨 읽힌다", () => {
  for (const n of 옛목록) assert.ok(spaceInfo(n), n);
  assert.equal(spaceInfo("식당").이름, "글래스룸"); // 사장님 2026-09-30
  assert.equal(spaceInfo("카페").이름, "카페 내부");
  assert.ok(!SPACES.some((s) => /애견/.test(s.이름))); // 애견카페 안 함 — 표에 없다(사장님 2026-09-30)
  assert.equal(spaceInfo("애견 운동장").이름, "카페 외부");
});

test("사장님 표(2026-09-30)의 공간이 다 있다", () => {
  for (const n of ["카페 외부", "카페 내부", "식음료", "카페 실내수영장", "글래스룸", "글래스룸 앞", "단체객실 샤워시설", "대형 단체룸 거실", "캐빈하우스 실내", "족구장", "주차장", "식당2층", "식당3층 홀", "식당3층 단체식사", "식당3층 반찬 케이터링"]) assert.ok(spaceInfo(n), n);
});

test("이름 · slug 가 겹치지 않고, 옮김표가 표 안을 가리킨다", () => {
  assert.equal(new Set(SPACES.map((s) => s.이름)).size, SPACES.length);
  assert.equal(new Set(SPACES.map((s) => s.slug)).size, SPACES.length);
  for (const [a, b] of Object.entries(ALIASES)) { assert.ok(spaceInfo(b), b); assert.ok(!SPACES.some((s) => s.이름 === a), a); }
  for (const s of SPACES) { assert.ok(CATEGORIES.includes(s.카테고리)); assert.match(s.slug, /^[a-z0-9-]+$/); }
});

test("카테고리 다듬기", () => {
  assert.deepEqual(normalizeCategories(["펜션", "애견카페", "없는것"], "x"), ["펜션&풀빌라", "카페"]);
  assert.deepEqual(normalizeCategories([], "세미나실"), ["단체"]);
  assert.deepEqual(normalizeCategories([], "모르는 곳"), ["공통"]);
});

test("파일 이름 조각은 영문 · 폴더 이름은 윈도우에서 쓸 수 있게", () => {
  assert.equal(spaceSlug("식당"), "glass-room");
  assert.match(spaceSlug("새로운 곳"), /^space-[a-z0-9]+$/);
  assert.equal(safeFolder('a:b?'), "a b");
});
