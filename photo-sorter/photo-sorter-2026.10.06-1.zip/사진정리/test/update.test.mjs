import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";
import { join } from "node:path";
import { createHash } from "node:crypto";
import { newer, checkUpdate, applyUpdate, versionOf } from "../lib/update.mjs";
import { writeZip } from "../lib/zip.mjs";
import { tmp } from "./_helpers.mjs";

test("판 비교", () => {
  assert.equal(newer("2026.10.06-2", "2026.10.06-1"), true);
  assert.equal(newer("2026.10.06-1", "2026.10.06-1"), false);
  assert.equal(newer("2026.10.10-1", "2026.10.9-9"), true);
  assert.equal(newer("2026.10.06-1", "0"), true);
});

async function fakeRelease({ zipUrl = "https://raw.githubusercontent.com/motmot-cafe/motmot-runner/main/photo-sorter/photo-sorter-2026.10.06-2.zip", badSha = false } = {}) {
  const d = tmp(), z = join(d, "r.zip");
  await writeZip(z, [
    { name: "사진정리/main.mjs", data: Buffer.from("// 새 판") },
    { name: "사진정리/VERSION", data: Buffer.from("2026.10.06-2\n") },
    { name: "사진정리/lib/새파일.mjs", data: Buffer.from("export {}") },
    { name: "사진정리/node-path.txt", data: Buffer.from("C:\\엉뚱한\\node.exe") }, // 그 PC 의 것 — 덮지 않아야 한다
    { name: "사진정리/../밖.txt", data: Buffer.from("x") },                      // 폴더 밖으로 — 안 씀
  ], { deflate: true });
  const buf = readFileSync(z);
  const latest = { version: "2026.10.06-2", notes: "새 기능", zip: zipUrl, sha256: badSha ? "0".repeat(64) : createHash("sha256").update(buf).digest("hex") };
  const fetchImpl = async (url) => url.includes("latest.json")
    ? { ok: true, status: 200, json: async () => latest }
    : { ok: true, status: 200, arrayBuffer: async () => buf };
  return { fetchImpl };
}

test("업데이트 — 새 판을 알아보고, sha256 이 맞으면 덮어쓴다 · 그 PC 의 파일(node-path.txt)과 폴더 밖은 안 건드린다", async () => {
  const here = join(tmp(), "사진정리"); mkdirSync(here, { recursive: true });
  writeFileSync(join(here, "VERSION"), "2026.10.01-1\n"); writeFileSync(join(here, "main.mjs"), "// 옛 판"); writeFileSync(join(here, "node-path.txt"), "C:\\node\\node.exe");
  const { fetchImpl } = await fakeRelease();
  const u = await checkUpdate(here, { fetchImpl, url: "https://example/latest.json" });
  assert.deepEqual([u.있음, u.지금, u.판], [true, "2026.10.01-1", "2026.10.06-2"]);
  const n = await applyUpdate(here, u, { fetchImpl });
  assert.equal(n, 3);
  assert.equal(readFileSync(join(here, "main.mjs"), "utf8"), "// 새 판");
  assert.equal(versionOf(here), "2026.10.06-2");
  assert.ok(existsSync(join(here, "lib", "새파일.mjs")));
  assert.equal(readFileSync(join(here, "node-path.txt"), "utf8"), "C:\\node\\node.exe");
  assert.ok(!existsSync(join(here, "..", "밖.txt")));
});

test("업데이트 — sha256 이 다르거나 정해진 자리가 아니면 안 바꾼다", async () => {
  const here = join(tmp(), "사진정리"); mkdirSync(here, { recursive: true });
  writeFileSync(join(here, "main.mjs"), "// 옛 판");
  const bad = await fakeRelease({ badSha: true });
  const u = await checkUpdate(here, { fetchImpl: bad.fetchImpl, url: "https://example/latest.json" });
  await assert.rejects(applyUpdate(here, u, { fetchImpl: bad.fetchImpl }), /sha256/);
  assert.equal(readFileSync(join(here, "main.mjs"), "utf8"), "// 옛 판");
  const evil = await fakeRelease({ zipUrl: "https://evil.example/x.zip" });
  await assert.rejects(checkUpdate(here, { fetchImpl: evil.fetchImpl, url: "https://example/latest.json" }), /정해진 자리/);
});
