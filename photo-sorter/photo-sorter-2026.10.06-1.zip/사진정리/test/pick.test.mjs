import test from "node:test";
import assert from "node:assert/strict";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { Job, USED } from "../lib/job.mjs";
import { spacesInText, categoryOf } from "../lib/pick.mjs";
import { writeZip } from "../lib/zip.mjs";
import { tmp, fakeJpeg } from "./_helpers.mjs";

test("본문 낱말 → 공간(나온 차례 · 카테고리마다 다른 곳)", () => {
  assert.deepEqual(spacesInText("세미나실에서 워크샵을 하고 식당에서 뷔페로 식사", "단체").slice(0, 4), ["세미나실", "대연회장", "식당3층 홀", "식당3층 단체식사"]);
  assert.deepEqual(spacesInText("식당", "펜션&풀빌라"), ["식당2층"]);
  assert.equal(categoryOf({ category: "펜션&풀빌라" }), "펜션&풀빌라");
  assert.equal(categoryOf({ category: "", keyword: "춘천 단체 MT" }), "단체");
});

const HASHES = ["0000000000000000", "ffffffffffffffff", "00000000ffffffff", "ffffffff00000000", "0f0f0f0f0f0f0f0f", "f0f0f0f0f0f0f0f0", "3333333333333333", "cccccccccccccccc"];
async function pool() {
  const d = tmp();
  const z = join(d, "s.zip");
  const names = ["g1", "g2", "s1", "s2", "d1", "d2", "c1", "x1"];
  await writeZip(z, names.map((n, i) => ({ name: n + ".jpg", data: fakeJpeg(i + 1) })));
  const j = new Job(z);
  const set = { g1: "글래스룸", g2: "글래스룸", s1: "세미나실", s2: "세미나실", d1: "식당3층 단체식사", d2: "식당3층 홀", c1: "카페 외부", x1: "대연회장" };
  j.photos.forEach((p, i) => { const n = names[i]; j.setInfo(p.id, { w: 10, h: 10, dhash: HASHES[i] }); j.edit([p.id], { 공간: set[n] }); });
  j.edit([j.photos[0].id, j.photos[1].id], { 카테고리: ["카페", "단체"] });
  j.photos[1].품질 = "좋음";
  j.state.자동고르기시작 = "2026-01-01T00:00:00.000Z";
  for (const p of j.photos) { writeFileSync(j.webPath(p.id), fakeJpeg(7, 200)); j.webDone(p.id); }
  return j;
}

test("원고기 새 원고 → 본문 차례대로 사진을 골라 「원고번호-발행키워드」 폴더에 「사진N-장면」 · 01 은 썸네일 자리", async () => {
  const j = await pool();
  const rec = { job: "1234", category: "단체", keyword: "춘천 단체 워크샵", titles: ["춘천 워크샵 장소"], created_at: "2026-10-01T00:00:00Z",
    body: "세미나실이 넓고, 식사는 식당에서 케이터링으로. 저녁엔 글래스룸에서 뒤풀이.", 제목: "춘천 워크샵 장소" };
  assert.equal(j.pickFromRecords([rec]), 1);
  assert.equal(j.pickFromRecords([rec]), 0); // 한 번만
  const ms = j.state.원고들["1234"];
  assert.equal(ms.폴더, "1234-춘천 단체 워크샵");
  const order = ms.사진.map((id) => j.get(id).공간);
  // 키워드 「워크샵」 → 세미나실 · 대연회장, 본문 「식사」 → 식당3층 단체식사 → 홀, 「글래스룸」
  assert.deepEqual(order, ["세미나실", "대연회장", "식당3층 단체식사", "식당3층 홀", "글래스룸"]);
  assert.ok(!order.includes("카페 외부")); // 다른 카테고리는 안 쓴다
  assert.equal(j.get(ms.사진.find((id) => j.get(id).공간 === "글래스룸")).rel, "g2.jpg"); // 품질 좋음 먼저
  await j.organize();
  const dir = join(j.dir, USED, "1234-춘천 단체 워크샵");
  assert.ok(existsSync(join(dir, "원본", "사진2-세미나실.jpg")));
  assert.ok(existsSync(join(dir, "웹용", "사진5-식당3층홀.jpg")));
  const t = JSON.parse(readFileSync(join(dir, "원고사진.json"), "utf8"));
  assert.deepEqual(t.사진.map((x) => x.차례), [2, 3, 4, 5, 6]);
  // 켜기 전의 옛 원고는 안 고른다
  assert.equal(j.pickFromRecords([{ ...rec, job: "1", created_at: "2025-01-01T00:00:00Z" }]), 0);
});

test("재탕이면 파일 이름에 몇 번째인지 — 사진N-장면(2)", async () => {
  const j = await pool();
  const g2 = j.photos[1];
  j.edit([g2.id], { 사용: { 원고: "첫 원고" } });
  j.edit([g2.id], { 가공: { 좌우반전: true } }); j.webDone(g2.id); j.setWebHash(g2.id, "0000000000000000");
  j.photos.forEach((p) => { if (p !== g2) j.setWebHash(p.id, "ffffffffffffffff"); });
  g2.사용기록[0].웹지문 = "ffffffffffffffff";
  j.edit([g2.id], { 재구성: true });
  const rec = { job: "77", category: "카페", keyword: "글래스룸 대관", titles: [], created_at: "2026-10-02T00:00:00Z", body: "글래스룸", 제목: "글래스룸 대관" };
  j.pickFromRecords([rec]);
  assert.equal(g2.사용.번째, 2);
  await j.organize();
  assert.ok(existsSync(join(j.dir, USED, "77-글래스룸 대관", "원본", "사진2-글래스룸(2).jpg")));
});
