import test from "node:test";
import assert from "node:assert/strict";
import { existsSync, readFileSync, writeFileSync, mkdirSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { Job, jobDirFor, DRAW_VERSION } from "../lib/job.mjs";
import { writeZip } from "../lib/zip.mjs";
import { tmp, fakeJpeg } from "./_helpers.mjs";

async function sample() {
  const d = tmp();
  const z = join(d, "리조트사진.zip");
  await writeZip(z, [
    { name: "사진/IMG_0001.jpg", data: fakeJpeg(1) },
    { name: "사진/IMG_0002.JPG", data: fakeJpeg(2) },
    { name: "사진/복사본/IMG_0001.jpg", data: fakeJpeg(1) }, // 같은 파일
    { name: "사진/영상.mp4", data: Buffer.from("fake video") },
    { name: "사진/메모.txt", data: Buffer.from("x") },
    { name: "__MACOSX/사진/._IMG_0001.jpg", data: Buffer.from("junk") },
  ]);
  return { d, z };
}

test("열기 — 쓰레기 파일은 빼고, 같은 파일은 중복으로, 사진 · 영상 · 기타를 가른다", async () => {
  const { z } = await sample();
  const j = new Job(z);
  assert.equal(j.photos.length, 5);
  const by = Object.fromEntries(j.photos.map((p) => [p.rel, p]));
  assert.equal(by["사진/복사본/IMG_0001.jpg"].중복of, by["사진/IMG_0001.jpg"].id);
  assert.equal(by["사진/영상.mp4"].종류, "영상");
  assert.equal(by["사진/메모.txt"].종류, "기타");
  assert.equal(j.dir, jobDirFor(z));
  assert.ok(j.dir.endsWith("리조트사진-정리"));
});

test("다시 열면 상태를 이어받는다(id · 분류가 그대로)", async () => {
  const { z } = await sample();
  const j = new Job(z);
  const id = j.photos[0].id;
  j.edit([id], { 공간: "세미나실" });
  j.save(true);
  const k = new Job(z);
  assert.equal(k.get(id).공간, "세미나실");
  assert.equal(k.get(id).본사람, "사장님");
  assert.deepEqual(k.get(id).카테고리, ["단체"]);
});

test("Claude 답 — 확신 낮음 · 표에 없는 공간은 확인필요, 옛 이름은 옮겨 읽고, 사장님이 고친 건 안 덮는다", async () => {
  const { z } = await sample();
  const j = new Job(z);
  const [a, b, , , ] = j.photos;
  j.applyAi(a.id, { 공간: "식당", 카테고리: [], 설명: "유리벽 홀", 태그: ["실내"], 확신: "높음" });
  assert.equal(a.공간, "글래스룸"); assert.equal(a.본사람, "클로드"); assert.deepEqual(a.카테고리, ["카페"]);
  j.applyAi(b.id, { 공간: "우주정거장", 확신: "높음" });
  assert.equal(b.본사람, "확인필요");
  j.applyAi(b.id, { 공간: "객실 침실", 확신: "낮음" });
  assert.equal(b.본사람, "확인필요");
  j.edit([b.id], { 공간: "객실 욕실" });
  j.applyAi(b.id, { 공간: "카페 외부", 확신: "높음" });
  assert.equal(b.공간, "객실 욕실");
});

test("비슷한 사진 묶음 — dHash 가 6비트 이하로 다르면 한 묶음", async () => {
  const { z } = await sample();
  const j = new Job(z);
  const [a, b] = j.photos;
  j.setInfo(a.id, { w: 4000, h: 3000, dhash: "ffff0000ffff0000" });
  j.setInfo(b.id, { w: 4000, h: 3000, dhash: "ffff0000ffff003f" }); // 6비트 다름
  j.ensureSimilar();
  assert.ok(a.비슷 && a.비슷 === b.비슷);
  j.setInfo(b.id, { dhash: "ffff0000ffff007f" }); // 7비트
  j.ensureSimilar();
  assert.ok(!a.비슷 && !b.비슷);
});

test("폴더로 정리 — 카테고리/공간 폴더 · 영문 이름 · 중복·기타는 안 풀고 · 다시 정리하면 옮기기만", async () => {
  const { z } = await sample();
  const j = new Job(z);
  const by = Object.fromEntries(j.photos.map((p) => [p.rel, p]));
  const a = by["사진/IMG_0001.jpg"], b = by["사진/IMG_0002.JPG"], v = by["사진/영상.mp4"];
  j.setInfo(a.id, { w: 3000, h: 4000, 찍은날: "2025-07-02 10:00:00" });
  j.setInfo(b.id, { w: 4000, h: 3000, 찍은날: "2025-07-01 10:00:00" });
  writeFileSync(j.webPath(a.id), fakeJpeg(9, 500));
  j.edit([a.id, b.id], { 공간: "객실 침실" });
  j.edit([v.id], { 공간: "야외수영장" });
  const r = await j.organize();
  assert.deepEqual(r.오류, []);
  assert.equal(r.장수, 3);
  const P = (x) => join(j.dir, x);
  // 찍은 날 차례 — 7월 1일(b)이 001
  assert.ok(readFileSync(P("원본/펜션&풀빌라/객실 침실/pension-room-bedroom-001.jpg")).equals(readFileSync(P("원본/펜션&풀빌라/객실 침실/pension-room-bedroom-001.jpg"))));
  assert.ok(readFileSync(P("원본/펜션&풀빌라/객실 침실/pension-room-bedroom-002.jpg")).equals(fakeJpeg(1)));
  assert.ok(readFileSync(P("원본/펜션&풀빌라/객실 침실/pension-room-bedroom-001.jpg")).equals(fakeJpeg(2)));
  assert.ok(existsSync(P("웹용/펜션&풀빌라/객실 침실/pension-room-bedroom-002.jpg")));
  assert.ok(existsSync(P("영상/펜션&풀빌라/야외수영장/pension-outdoor-pool-001.mp4")));
  assert.ok(!existsSync(P("원본/미분류")));

  const list = JSON.parse(readFileSync(P("공간목록.json"), "utf8"));
  assert.deepEqual(Object.keys(list).slice(0, 4), ["_읽어라", "_고치는법", "갱신", "사진"]);
  const e = list.사진["ai작업/사진/펜션&풀빌라/객실 침실/pension-room-bedroom-002.jpg"];
  assert.equal(e.공간, "객실 침실"); assert.equal(e.본사람, "사장님"); assert.equal(e.방향, "세로"); assert.equal(e.원본, "사진/IMG_0001.jpg");
  const csv = readFileSync(P("목록.csv"), "utf8");
  assert.ok(csv.startsWith("﻿")); assert.match(csv, /중복\(사진\/IMG_0001\.jpg\)/); assert.match(csv, /사진 아님/);

  // 공간을 바꾸고 다시 — 옛 파일은 새 자리로 옮겨지고 옛 자리는 비어야 한다
  j.edit([a.id], { 공간: "세미나실" });
  const r2 = await j.organize();
  assert.deepEqual(r2.오류, []);
  assert.ok(readFileSync(P("원본/단체/세미나실/group-seminar-001.jpg")).equals(fakeJpeg(1)));
  assert.ok(!existsSync(P("원본/펜션&풀빌라/객실 침실/pension-room-bedroom-002.jpg")));
  assert.ok(!existsSync(P("웹용/펜션&풀빌라/객실 침실/pension-room-bedroom-002.jpg")));
  // 빼면 풀어 둔 것도 치운다
  j.edit([v.id], { 제외: true });
  await j.organize();
  assert.ok(!existsSync(P("영상/펜션&풀빌라/야외수영장/pension-outdoor-pool-001.mp4")));
});

test("목록 불러오기 — 표지(같은 파일) 또는 원본 이름으로 맞추고, 옛 이름은 옮긴다", async () => {
  const { z } = await sample();
  const j = new Job(z);
  const a = j.photos[0];
  const n = j.importList({ 사진: { "x/y.jpg": { 공간: "카페", 설명: "원목 바", 태그: ["카페"], 본사람: "클로드", 원본: a.rel } } });
  assert.equal(n, 1);
  assert.equal(a.공간, "카페 내부");
  assert.deepEqual(a.카테고리, ["카페"]);
});

test("폴더에서 열기 — 이미 풀어 둔 사진 폴더도 된다(정리 폴더는 다시 안 읽는다)", () => {
  const d = tmp();
  const src = join(d, "사진모음");
  mkdirSync(join(src, "a"), { recursive: true });
  writeFileSync(join(src, "a", "1.jpg"), fakeJpeg(1));
  writeFileSync(join(src, "2.jpg"), fakeJpeg(1));
  const j = new Job(src);
  assert.equal(j.photos.length, 2);
  assert.equal(j.photos.filter((p) => p.중복of).length, 1);
  assert.ok(readdirSync(d).includes("사진모음-정리"));
});

test("손으로 한 가공은 Claude 가 덮지 않고, 상자는 그림 밖으로 안 나가게 다듬는다", async () => {
  const { z } = await sample();
  const j = new Job(z);
  const a = j.photos[0];
  j.edit([a.id], { 가공: { 얼굴: [[0.9, 0.9, 0.5, 0.5], [0, 0, 0, 0], "x"], 회전: 45, 밝기: 99, 대비: -12.4, 채도: "x", 색온도: -80, 기울기: 3.3, 자르기: [0.1, 0.1, 0.8, 0.8] } });
  assert.deepEqual(a.가공, { 얼굴: [[0.9, 0.9, 0.1, 0.1]], 회전: 0, 밝기: 40, 대비: -12, 채도: 0, 색온도: -40, 기울기: 3.5, 자르기: [0.1, 0.1, 0.8, 0.8], 좌우반전: false, 손: true });
  assert.equal(a.웹다시, true);
  j.applyAi(a.id, { 공간: "카페 외부", 확신: "높음", 얼굴: [], 회전: 90 });
  assert.equal(a.가공.손, true); assert.equal(a.가공.회전, 0);
  // 가공 없음 · 빈 제안이면 가공 칸을 안 만든다
  const b = j.photos[1];
  j.applyAi(b.id, { 공간: "카페 외부", 확신: "높음", 얼굴: [], 회전: 0, 어두움: false });
  assert.equal(b.가공, undefined); assert.equal(b.웹다시, undefined);
});

test("원고에 씀 — 「사용한 원고사진/<원고>/」 로 옮기고 공간목록에서 빼고 사용한사진.json 에 남긴다 · 풀면 돌아온다", async () => {
  const { z } = await sample();
  const j = new Job(z);
  const a = j.photos[0], b = j.photos[1];
  writeFileSync(j.webPath(a.id), fakeJpeg(9, 500));
  j.edit([a.id, b.id], { 공간: "카페 외부" });
  j.edit([a.id], { 사용: { 원고: "10월 카페 원고" } });
  await j.organize();
  const P = (x) => join(j.dir, x);
  assert.ok(readFileSync(P("사용한 원고사진/10월 카페 원고/원본/cafe-cafe-outside-001.jpg")).equals(fakeJpeg(1)));
  assert.ok(existsSync(P("사용한 원고사진/10월 카페 원고/웹용/cafe-cafe-outside-001.jpg")));
  const list = JSON.parse(readFileSync(P("공간목록.json"), "utf8"));
  assert.ok(!Object.values(list.사진).some((v) => v.원본 === a.rel));
  assert.ok(Object.values(list.사진).some((v) => v.원본 === b.rel));
  const used = JSON.parse(readFileSync(P("사용한사진.json"), "utf8"));
  assert.equal(used.사진[0].원고, "10월 카페 원고");
  assert.match(readFileSync(P("목록.csv"), "utf8"), /원고에 씀\(10월 카페 원고\)/);
  j.edit([a.id], { 사용: null });
  await j.organize();
  assert.ok(!existsSync(P("사용한 원고사진/10월 카페 원고/원본/cafe-cafe-outside-001.jpg")));
  assert.ok(existsSync(P("원본/카페/카페 외부/cafe-cafe-outside-001.jpg")));
});

test("C컷(품질 낮음)은 「C컷(판단 대기)」 로 · 살리면 본 폴더 · 지움(다른 가게 · 개)은 어디에도 안 풀고 되살릴 수 있다", async () => {
  const { z } = await sample();
  const j = new Job(z);
  const [a, b, , v] = j.photos;
  j.applyAi(a.id, { 공간: "객실 침실", 확신: "높음", 품질: "낮음", 품질이유: "흐림" });
  j.applyAi(b.id, { 공간: "카페 내부", 확신: "높음", 품질: "좋음", 다른가게: true });
  j.applyAi(v.id, { 공간: "애견 운동장", 확신: "높음", 품질: "좋음" });
  assert.equal(j.status(a), "C컷"); assert.equal(a.제외, false);
  assert.equal(j.status(b), "지움"); assert.match(b.지움, /다른 가게/);
  assert.equal(j.status(v), "지움"); assert.match(v.지움, /개 사진/);
  await j.organize();
  const P = (x) => join(j.dir, x);
  assert.ok(existsSync(P("C컷(판단 대기)/원본/펜션&풀빌라/객실 침실/pension-room-bedroom-001.jpg")));
  const list = JSON.parse(readFileSync(P("공간목록.json"), "utf8"));
  assert.equal(Object.keys(list.사진).length, 0);
  assert.match(readFileSync(P("목록.csv"), "utf8"), /지움\(다른 가게/);
  assert.equal(j.summary().C컷, 1); assert.equal(j.summary().지움, 2);
  // 사장님 판단 — 살리기 · 지움 되살리기(Claude 가 다시 지우지 않음)
  j.edit([a.id], { C살림: true }); j.edit([b.id], { 지움: false });
  j.applyAi(b.id, { 공간: "카페 내부", 확신: "높음", 다른가게: true });
  assert.equal(j.status(a), "보통"); assert.equal(j.status(b), "보통");
  await j.organize();
  assert.ok(existsSync(P("원본/펜션&풀빌라/객실 침실/pension-room-bedroom-001.jpg")));
  assert.ok(!existsSync(P("C컷(판단 대기)/원본/펜션&풀빌라/객실 침실/pension-room-bedroom-001.jpg")));
});

test("워터마크 — 기본 켜짐(모토모토리조트 1666-4510) · 바꾸면 웹용을 모두 다시 그리게 하고, 그린 값이 맞아야 끝으로 친다", async () => {
  const { z } = await sample();
  const j = new Job(z);
  assert.equal(j.state.설정.워터마크, true);
  assert.equal(j.state.설정.워터마크글, "모토모토리조트 1666-4510");
  const a = j.photos[0];
  j.setInfo(a.id, { w: 10, h: 10 });
  assert.deepEqual(JSON.parse(j.drawSpec(a)), { 가공: null, 워터마크: "모토모토리조트 1666-4510", 줄: 3, 판: DRAW_VERSION });
  j.setWatermark(false);
  assert.equal(a.웹다시, true);
  assert.equal(JSON.parse(j.drawSpec(a)).워터마크, null);
  assert.equal(j.pendingWeb(), 1);
});

test("HEIC — 브라우저가 바꾼 원래 크기 JPG 가 있으면 원본 자리에 .jpg 로 둔다(없으면 .heic 그대로)", async () => {
  const d = tmp();
  const z = join(d, "폰.zip");
  await writeZip(z, [{ name: "IMG_1.HEIC", data: Buffer.from("heic-bytes-1") }, { name: "IMG_2.heic", data: Buffer.from("heic-bytes-2") }]);
  const j = new Job(z);
  const [a, b] = j.photos;
  j.edit([a.id, b.id], { 공간: "객실 침실" });
  writeFileSync(j.fullJpgPath(a.id), fakeJpeg(3, 900));
  const r = await j.organize();
  assert.deepEqual(r.오류, []);
  const P = (x) => join(j.dir, x);
  assert.ok(readFileSync(P("원본/펜션&풀빌라/객실 침실/pension-room-bedroom-001.jpg")).equals(fakeJpeg(3, 900)));
  assert.ok(readFileSync(P("원본/펜션&풀빌라/객실 침실/pension-room-bedroom-002.heic")).equals(Buffer.from("heic-bytes-2")));
  await j.organize(); // 다시 눌러도 그대로
  assert.ok(existsSync(P("원본/펜션&풀빌라/객실 침실/pension-room-bedroom-001.jpg")));
});

test("정리 폴더 만들 곳을 고르면 그 안에 「<이름>-정리」", async () => {
  const { z } = await sample();
  const out = tmp();
  const j = new Job(z, { outRoot: out });
  assert.equal(j.dir, join(out, "리조트사진-정리"));
  assert.equal(jobDirFor(z, out), j.dir);
});

test("영양가 없는 사진(천장 · 벽만 · 소품 클로즈업 · 남의 광고)은 지움 — 사장님 2026-09-30", async () => {
  const { z } = await sample();
  const j = new Job(z);
  const [a] = j.photos;
  j.applyAi(a.id, { 공간: "카페 내부", 확신: "높음", 품질: "보통", 쓸모없음: true });
  assert.equal(j.status(a), "지움"); assert.match(a.지움, /영양가/);
});

test("분류 사용량은 이 작업 몫만 모은다(부름 · 보인 장수 · 토큰 · 달러) · 기록 전에 분류된 장수를 남긴다", async () => {
  const { z } = await sample();
  const j = new Job(z);
  j.applyAi(j.photos[0].id, { 공간: "카페 내부", 확신: "높음", 품질: "좋음" });
  j.addUsage({ 입력: 4, 출력: 2800, 캐시쓰기: 11000, 캐시읽기: 11000, 달러: 0.079, 초: 17 }, 10);
  j.addUsage(null, 0);
  const u = j.state.사용량;
  assert.equal(u.부름, 2); assert.equal(u.실패, 1); assert.equal(u.보인장수, 10);
  assert.equal(u.출력, 2800); assert.equal(u.달러, 0.079); assert.equal(u.기록전분류, 1);
});

test("원고 사진 바꾸기 — 같은 자리(사진N)로 들어가고, 뺀 사진은 풀리며, 대표 썸네일은 버리고 다른 것을 붙인다", async () => {
  const { z } = await sample();
  const j = new Job(z);
  const [a, b] = j.photos;
  for (const p of [a, b]) j.applyAi(p.id, { 공간: "세미나실", 카테고리: ["단체"], 확신: "높음", 품질: "좋음" });
  j.recordUse(a, { 원고: "대학 MT 장소 추천", 자동: "원고기(자동 고름)", 폴더: "1fb9da73-대학MT장소추천" }); a.사용.순번 = 7;
  j.state.원고들["1fb9da73-aaaa-bbbb"] = { 원고: "대학 MT 장소 추천", 폴더: "1fb9da73-대학MT장소추천", 카테고리: "단체", 키워드: "대학MT장소추천", 사진: [a.id], 썸네일카테고리: "단체" };
  j.state.썸네일 = [{ id: "t1", 카테고리: "단체", 배정: { 원고번호: "1fb9da73-aaaa-bbbb" } }, { id: "t2", 카테고리: "단체", 배정: null }];
  j.state.원고들["1fb9da73-aaaa-bbbb"].썸네일 = "t1";
  assert.equal(j.msKey("1fb9da73"), "1fb9da73-aaaa-bbbb"); // 앞자리로도 찾는다
  const v = j.msView("1fb9da73-aaaa-bbbb");
  assert.equal(v.사진[0].순번, 7); assert.equal(v.썸네일.id, "t1");
  const c = j.swapCandidates(a.id);
  assert.deepEqual(c.map((x) => x.id), [b.id]); assert.equal(c[0].같은공간, true);
  const r = j.swapUse(a.id, b.id);
  assert.equal(r.순번, 7); assert.equal(b.사용.순번, 7); assert.equal(b.사용.폴더, "1fb9da73-대학MT장소추천");
  assert.equal(a.사용, undefined); assert.equal(j.status(a), "보통"); assert.equal(a.사용풀림, true);
  assert.deepEqual(j.state.원고들["1fb9da73-aaaa-bbbb"].사진, [b.id]);
  assert.throws(() => j.swapUse(a.id, b.id), /원고에 쓴 사진이 아닙니다/);
  const t = j.swapThumb("1fb9da73");
  assert.equal(t.썸네일, "t2"); assert.equal(j.state.썸네일[0].버림, true); assert.equal(j.state.썸네일[0].배정, null);
  const t2 = j.swapThumb("1fb9da73"); // 남은 게 없으면 비워 두고 화면이 새로 만들어 붙인다
  assert.equal(t2.썸네일, null); assert.equal(t2.새로만들기, true);
  const plan = j.plan();
  assert.ok(plan.find((x) => x.p.id === b.id).원본.includes("사진7-세미나실"));
});

test("원고기 장면마다 후보 — 장면 글의 공간과 맞는 사진만 · 공간을 못 찾으면 빈 목록", async () => {
  const { z } = await sample();
  const j = new Job(z);
  const [a, b] = j.photos;
  j.applyAi(a.id, { 공간: "대형 단체룸 거실", 카테고리: ["단체"], 확신: "높음", 품질: "좋음" });
  j.applyAi(b.id, { 공간: "객실 실내수영장", 카테고리: ["펜션&풀빌라"], 확신: "높음", 품질: "좋음" });
  const r = j.sceneCandidates("대형 단체룸 내부", "단체");
  assert.deepEqual(r.공간, ["대형 단체룸 거실"]);
  assert.deepEqual(r.후보.map((x) => x.id), [a.id]); // 수영장 사진은 안 나온다
  assert.deepEqual(j.sceneCandidates("리조트의 따뜻한 분위기", "단체").후보, []);
});

test("분류 기억 — 다른 zip 에서 같은 파일(같은 열쇠 · 같은 크기+지문)을 만나면 다시 분류하지 않고 가져온다 · 사장님이 고친 값이 이긴다", async () => {
  const { Memory } = await import("../lib/memory.mjs");
  const memPath = join(tmp(), "분류기억.json");
  const { z } = await sample();
  const j1 = new Job(z);
  const [a, b] = j1.photos;
  j1.setInfo(b.id, { dhash: "0123456789abcdef" });
  j1.applyAi(a.id, { 공간: "세미나실", 카테고리: ["단체"], 확신: "높음", 품질: "좋음", 설명: "강의실" });
  j1.applyAi(b.id, { 공간: "카페 내부", 카테고리: ["카페"], 확신: "높음", 품질: "좋음" });
  j1.edit([b.id], { 공간: "글래스룸" }); // 사장님이 고침
  const m1 = new Memory(memPath); m1.syncFrom(j1);
  // 같은 파일이 든 다른 zip(이름 다름)
  const d2 = tmp(), z2 = join(d2, "새로받은.zip");
  await writeZip(z2, [{ name: "다른폴더/a.jpg", data: fakeJpeg(1) }, { name: "다른폴더/b.jpg", data: fakeJpeg(2) }, { name: "다른폴더/c.jpg", data: fakeJpeg(3) }]);
  const j2 = new Job(z2);
  const [a2, b2, c2] = j2.photos;
  j2.setInfo(b2.id, { dhash: "0123456789abcdef" });
  const m2 = new Memory(memPath);
  assert.equal(j2.recall(m2), 2);
  assert.equal(a2.공간, "세미나실"); assert.equal(a2.설명, "강의실"); assert.equal(a2.기억, true);
  assert.equal(b2.공간, "글래스룸"); assert.equal(b2.본사람, "사장님");
  assert.ok(!c2.공간); assert.ok(!c2.기억); // 처음 보는 사진은 Claude 에게
});
