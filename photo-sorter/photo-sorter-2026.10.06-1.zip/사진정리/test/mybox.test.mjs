import test from "node:test";
import assert from "node:assert/strict";
import { existsSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";
import { shareKeyOf, safePart, destOf, syncShare } from "../lib/mybox.mjs";
import { tmp } from "./_helpers.mjs";

test("공유 링크에서 shareKey 를 꺼낸다", () => {
  assert.equal(shareKeyOf("https://mybox.naver.com/share/list?shareKey=VlZ3g9qx6QLD9jCHAsIsrPlfk1F7J1SisIu8YTFR79AC"), "VlZ3g9qx6QLD9jCHAsIsrPlfk1F7J1SisIu8YTFR79AC");
  assert.equal(shareKeyOf(" VlZ3g9qx6QLD9jCHAsIsrPlfk1F7J1SisIu8YTFR79AC "), "VlZ3g9qx6QLD9jCHAsIsrPlfk1F7J1SisIu8YTFR79AC");
  assert.equal(shareKeyOf("https://naver.com"), "");
  assert.equal(safePart('카페: 내부?'), "카페_ 내부_");
  assert.ok(destOf("C:/받기", "/리조트 카페사진 [카페]/카페 내부/a.jpg").endsWith(join("리조트 카페사진 [카페]", "카페 내부", "a.jpg")));
});

/* MYBOX 를 흉내 낸 fetch — 실제 응답 모양(2026-10-05 실제 링크로 확인한 것) 그대로 */
function fakeMyBox({ files, password = false }) {
  const calls = [];
  const res = (body, { cookie, status = 200, bin } = {}) => ({
    ok: status < 400, status,
    headers: { getSetCookie: () => (cookie ? [cookie + "; Path=/; Secure"] : []), get: () => null },
    json: async () => body, arrayBuffer: async () => bin,
  });
  const fetchImpl = async (url, opt) => {
    calls.push({ url, cookie: opt?.headers?.cookie || "" });
    const u = new URL(url);
    if (u.pathname === "/service/link/property") return res({ code: "0", result: { resourceType: "folder", resourceName: "모토모토 사진 공유", resourceKey: "ROOT", hasPassword: password, blockDownload: false } }, { cookie: "NDV_SHARE=abc" });
    if (u.pathname === "/service/link/folder/list") {
      const key = u.searchParams.get("resourceKey");
      const list = key === "ROOT"
        ? [{ resourceType: "folder", resourceKey: "F1", subPath: "/리조트 카페사진 [카페]/" }, { resourceType: "folder", resourceKey: "DOG", subPath: "/기존자료/애견카페 (원본)/" }, ...files.filter((f) => f.dir === "/").map((f) => f.row)]
        : key === "DOG" ? [row("DOGPIC", "/기존자료/애견카페 (원본)/개.jpg", Buffer.from("dog"))]
        : files.filter((f) => f.dir !== "/").map((f) => f.row);
      return res({ code: "0", result: { list, totalCount: list.length } });
    }
    if (u.pathname === "/file/download.api") {
      const f = files.find((x) => x.row.resourceKey === u.searchParams.get("resourceKey"));
      return res(null, { bin: f.data });
    }
    return res({ code: "404" }, { status: 404 });
  };
  return { fetchImpl, calls };
}
const row = (key, subPath, data, fileType = "image") => ({ resourceType: "file", fileType, resourceKey: key, subPath, resourceSize: data.length, updateDate: 1789439950000, isUploaded: true });

test("MYBOX — 하위 폴더까지 사진 · 영상만 받고, 다시 돌리면 새 것만 받는다 · 쿠키를 붙인다", async () => {
  const d = tmp();
  const a = Buffer.from("jpeg-a"), b = Buffer.from("jpeg-bb"), v = Buffer.from("video"), doc = Buffer.from("pdf");
  const files = [
    { dir: "/", row: row("A", "/표지.jpg", a), data: a },
    { dir: "/x", row: row("B", "/리조트 카페사진 [카페]/카페 내부/b.jpg", b), data: b },
    { dir: "/x", row: row("V", "/리조트 카페사진 [카페]/카페 내부/v.mp4", v, "video"), data: v },
    { dir: "/x", row: row("D", "/리조트 카페사진 [카페]/메뉴.pdf", doc, "doc"), data: doc },
  ];
  const m = fakeMyBox({ files });
  const r1 = await syncShare("https://mybox.naver.com/share/list?shareKey=VlZ3g9qx6QLD9jCHAsIsrPlfk1F7J1SisIu8YTFR79AC", d, { fetchImpl: m.fetchImpl });
  assert.deepEqual([r1.이름, r1.전체, r1.받음, r1.실패], ["모토모토 사진 공유", 3, 3, 0]);
  assert.equal(readFileSync(join(d, "리조트 카페사진 [카페]", "카페 내부", "b.jpg"), "utf8"), "jpeg-bb");
  assert.ok(!existsSync(join(d, "리조트 카페사진 [카페]", "메뉴.pdf"))); // 사진 · 영상만
  assert.ok(!existsSync(join(d, "기존자료"))); // 애견카페 폴더는 받지 않는다(사장님 2026-10-06)
  assert.ok(!m.calls.some((c) => c.url.includes("resourceKey=DOG"))); // 그 폴더는 열어 보지도 않는다
  assert.equal(statSync(join(d, "표지.jpg")).mtimeMs, 1789439950000); // MYBOX 수정 시각
  assert.ok(m.calls.filter((c) => !c.url.includes("/property")).every((c) => c.cookie === "NDV_SHARE=abc"));
  // 다시 — 새로 올라온 한 장만
  const c = Buffer.from("new");
  files.push({ dir: "/x", row: row("C", "/리조트 카페사진 [카페]/카페 내부/c.jpg", c), data: c });
  const r2 = await syncShare("VlZ3g9qx6QLD9jCHAsIsrPlfk1F7J1SisIu8YTFR79AC", d, { fetchImpl: m.fetchImpl });
  assert.deepEqual([r2.전체, r2.받음, r2.있음], [4, 1, 3]);
});

test("MYBOX — 비밀번호 링크 · 링크 아님은 까닭을 말한다", async () => {
  await assert.rejects(syncShare("VlZ3g9qx6QLD9jCHAsIsrPlfk1F7J1SisIu8YTFR79AC", tmp(), { fetchImpl: fakeMyBox({ files: [], password: true }).fetchImpl }), /비밀번호/);
  await assert.rejects(syncShare("https://naver.com", tmp(), { fetchImpl: fakeMyBox({ files: [] }).fetchImpl }), /공유 링크/);
});

test("MYBOX 중복 거르기 — 한 번 받은 것(옮기거나 지워도) · PC 에 이름+크기 같은 것 · 내용이 같은 것은 안 받는다", async () => {
  const { headTailKey } = await import("../lib/source.mjs");
  const { writeFileSync, mkdirSync, rmSync } = await import("node:fs");
  const { nameSize } = await import("../lib/mybox.mjs");
  const d = tmp();
  const a = Buffer.from("aaaa"), b = Buffer.from("bbbbb"), c = Buffer.from("cccccc"), c2 = Buffer.from("cccccc");
  const files = [
    { dir: "/x", row: row("A", "/리조트 카페사진 [카페]/카페 내부/a.jpg", a), data: a },
    { dir: "/x", row: row("B", "/리조트 카페사진 [카페]/카페 내부/IMG_0001.jpg", b), data: b },   // PC 에 같은 이름 · 크기
    { dir: "/x", row: row("C", "/리조트 카페사진 [카페]/카페 내부/다른이름.jpg", c), data: c },   // PC 에 내용이 같은 사진(이름 다름)
    { dir: "/x", row: row("C2", "/리조트 카페사진 [카페]/카페 내부/또.jpg", c2), data: c2 },     // 같은 링크 안에 같은 내용이 또
  ];
  const pc = tmp(); mkdirSync(pc, { recursive: true }); writeFileSync(join(pc, "x.jpg"), c);
  const known = { names: new Set([nameSize("img_0001.jpg", b.length)]), keys: new Set([headTailKey(join(pc, "x.jpg"), c.length)]) };
  const m = fakeMyBox({ files });
  const r = await syncShare("VlZ3g9qx6QLD9jCHAsIsrPlfk1F7J1SisIu8YTFR79AC", d, { fetchImpl: m.fetchImpl, known, ledger: {} });
  assert.deepEqual([r.받음, r.중복], [1, 3]);
  assert.ok(existsSync(join(d, "리조트 카페사진 [카페]", "카페 내부", "a.jpg")));
  assert.ok(!existsSync(join(d, "리조트 카페사진 [카페]", "카페 내부", "다른이름.jpg"))); // 받고 보니 같은 내용 → 지움
  assert.ok(!m.calls.some((x) => x.url.includes("resourceKey=B"))); // 이름+크기로 받기 전에 거름
  // 받은 파일을 옮겨도(지워도) 다시 안 받는다
  rmSync(join(d, "리조트 카페사진 [카페]"), { recursive: true });
  const r2 = await syncShare("VlZ3g9qx6QLD9jCHAsIsrPlfk1F7J1SisIu8YTFR79AC", d, { fetchImpl: m.fetchImpl, known: { names: new Set(), keys: new Set() }, ledger: r.ledger });
  assert.deepEqual([r2.받음, r2.있음, r2.중복], [0, 1, 3]);
});
