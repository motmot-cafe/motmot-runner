import test from "node:test";
import assert from "node:assert/strict";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { Job, USED } from "../lib/job.mjs";
import { planThumbs, addThumb, thumbNeeds, LAYOUTS, PALETTES, FONTS } from "../lib/thumbs.mjs";
import { writeZip } from "../lib/zip.mjs";
import { tmp, fakeJpeg } from "./_helpers.mjs";

// 서로 멀리 떨어진 지문(같은 구도로 안 묶이게) — 정해진 씨앗의 난수
let seed = 7;
const rnd = () => (seed = (seed * 1103515245 + 12345) >>> 0);
const H = Array.from({ length: 20 }, () => (rnd().toString(16).padStart(8, "0") + rnd().toString(16).padStart(8, "0")).slice(0, 16));
async function pool(n = 8) {
  const d = tmp();
  const z = join(d, "s.zip");
  await writeZip(z, Array.from({ length: n }, (_, i) => ({ name: `p${i}.jpg`, data: fakeJpeg(i + 1) })));
  const j = new Job(z);
  j.photos.forEach((p, i) => { j.setInfo(p.id, { w: 10, h: 10, dhash: H[i % H.length] }); j.edit([p.id], { 공간: i % 2 ? "세미나실" : "대연회장" }); });
  j.state.자동고르기시작 = "2026-01-01T00:00:00.000Z";
  return j;
}

test("계획 — 조합(틀 · 색 · 글꼴)과 배경이 겹치지 않고, 이미 만든 것은 다시 안 고른다", async () => {
  const j = await pool();
  const a = planThumbs(j, "단체", 5);
  assert.equal(a.length, 5);
  assert.equal(new Set(a.map((x) => x.틀 + x.색 + x.글꼴)).size, 5);
  assert.equal(new Set(a.map((x) => x.틀)).size, 5); // 연달아 만든 것은 틀부터 다르게
  assert.equal(new Set(a.map((x) => x.배경)).size, 5);
  for (const x of a.slice(0, 2)) addThumb(j, { 카테고리: "단체", ...x }, fakeJpeg(9, 100));
  assert.throws(() => addThumb(j, { 카테고리: "단체", ...a[0] }, fakeJpeg(9, 100)), /이미 만든 조합|이미 쓴 배경/);
  const b = planThumbs(j, "단체", 20);
  assert.equal(b.length, 6); // 배경 8장 - 이미 쓴 2장
  assert.ok(!b.some((x) => a.slice(0, 2).some((y) => y.배경 === x.배경 || y.틀 + y.색 + y.글꼴 === x.틀 + x.색 + x.글꼴)));
  assert.equal(LAYOUTS.length * PALETTES.length, 480);
});

test("너무 비슷하지 않게 — 틀+색 짝은 카테고리를 가리지 않고 한 번만 · 이웃끼리 틀 · 색 · 글꼴이 모두 다름 · 480짝이 다 나옴", async () => {
  const { allCombos } = await import("../lib/thumbs.mjs");
  const all = allCombos();
  assert.equal(new Set(all.map((x) => x.틀 + "|" + x.색)).size, 480); assert.equal(all.length, 480);
  for (let i = 1; i < all.length; i++) {
    assert.notEqual(all[i].틀, all[i - 1].틀); assert.notEqual(all[i].색, all[i - 1].색); assert.notEqual(all[i].글꼴, all[i - 1].글꼴);
  }
  const j = await pool(14);
  j.photos.forEach((p) => j.edit([p.id], { 카테고리: ["단체", "카페"] }));
  const a = planThumbs(j, "단체", 3);
  a.forEach((x) => addThumb(j, { 카테고리: "단체", ...x }, fakeJpeg(5, 80)));
  const b = planThumbs(j, "카페", 10);
  assert.ok(!b.some((x) => a.some((y) => y.틀 === x.틀 && y.색 === x.색)));
  assert.throws(() => addThumb(j, { 카테고리: "카페", ...b[0], 틀: a[0].틀, 색: a[0].색 }, fakeJpeg(6, 80)), /이미 만든 조합/);
});

test("단체 썸네일은 펜션&풀빌라 사진도 배경으로 쓴다(카페는 안 씀)", async () => {
  const j = await pool(6);
  j.photos.forEach((p) => j.edit([p.id], { 공간: "객실 침실" })); // 펜션&풀빌라
  assert.equal(planThumbs(j, "단체", 10).length, 6);
  assert.equal(planThumbs(j, "카페", 10).length, 0);
});

test("원고에 붙이기 — 사진 고를 때 먼저 만든 썸네일부터 · 모자라면 표시하고 만들면 곧바로 붙는다 · 정리하면 사진1-대표썸네일", async () => {
  const j = await pool(14);
  const rec = (no) => ({ job: no, category: "단체", keyword: `워크샵 ${no}`, titles: [], created_at: "2026-10-01T00:00:00Z", body: "세미나실 대연회장", 제목: `원고 ${no}` });
  const [x] = planThumbs(j, "단체", 1);
  addThumb(j, { 카테고리: "단체", ...x }, fakeJpeg(11, 120));
  j.pickFromRecords([rec("1"), rec("2")]);
  assert.ok(j.state.원고들["1"].썸네일);
  assert.equal(j.state.원고들["2"].썸네일, null);
  assert.deepEqual(thumbNeeds(j), { 단체: 1 });
  const [y] = planThumbs(j, "단체", 1);
  addThumb(j, { 카테고리: "단체", ...y }, fakeJpeg(12, 120));
  assert.ok(j.state.원고들["2"].썸네일);
  assert.deepEqual(thumbNeeds(j), {});
  for (const p of j.photos) { writeFileSync(j.webPath(p.id), fakeJpeg(7, 200)); j.webDone(p.id); }
  await j.organize();
  const f = join(j.dir, USED, "1-워크샵 1", "웹용", "사진1-대표썸네일.jpg");
  assert.ok(readFileSync(f).equals(fakeJpeg(11, 120)));
  assert.ok(existsSync(join(j.dir, "썸네일", "단체", "thumb-group-002.jpg")));
  const list = JSON.parse(readFileSync(join(j.dir, "썸네일목록.json"), "utf8"));
  assert.equal(list.썸네일.length, 2); assert.equal(list.썸네일[0].배정.원고번호, "1");
});

test("문구가 다채롭게 — 썸네일마다 윗줄 · 칩 묶음이 돌아가고, 옛 모양(한 줄)으로 저장한 문구도 읽는다", async () => {
  const j = await pool(14);
  const a = planThumbs(j, "단체", 6);
  assert.ok(new Set(a.map((x) => x.윗줄)).size >= 4); // 세미나실 · 대연회장 사진이면 그 시설 문구가 섞인다
  assert.ok(a.some((x) => x.윗줄 === "큰 행사도 넉넉한 강당"));
  assert.ok(new Set(a.map((x) => x.칩.join())).size >= 3);
  assert.ok(new Set(a.map((x) => x.윗줄 + x.칩.join())).size >= 5);
  addThumb(j, { 카테고리: "단체", ...a[0], 칩: a[0].칩.join(",") }, fakeJpeg(3, 90));
  assert.deepEqual(j.state.썸네일[0].칩, a[0].칩);
  const { textFor } = await import("../lib/thumbs.mjs");
  j.state.썸네일문구 = { 카페: { 윗줄: "하나뿐", 칩: ["커피"] } };
  assert.deepEqual(textFor(j, "카페").윗줄들, ["하나뿐"]); assert.deepEqual(textFor(j, "카페").칩묶음, [["커피"]]);
});

test("시설을 말하는 문구는 그 공간 사진에만 · 수영장 · 스파 문구 · 칩은 기본값에 없다 · 카테고리 방향(사장님 2026-09-30)", async () => {
  const { pickLine, parseLine, DEFAULT_TEXT } = await import("../lib/thumbs.mjs");
  assert.deepEqual(parseLine("바베큐 굽는 저녁 @바베큐 자리, 야외 테라스"), { 글: "바베큐 굽는 저녁", 공간들: ["바베큐 자리", "야외 테라스"] });
  const lines = DEFAULT_TEXT["펜션&풀빌라"].윗줄들;
  for (let k = 0; k < 40; k++) {
    const t = pickLine(lines, "객실 침실", k);
    assert.ok(!/바베큐|테라스|주방|거실/.test(t), t); // 침실 사진에 다른 시설 문구가 붙지 않는다
  }
  assert.ok([0, 2, 4].map((k) => pickLine(lines, "바베큐 자리", k)).includes("바베큐 굽는 저녁이 있는 곳"));
  const everything = JSON.stringify(DEFAULT_TEXT);
  assert.ok(!/수영장|실내수영|스파/.test(everything));
  const chips = (c) => DEFAULT_TEXT[c].칩묶음.flat().join(" ");
  for (const w of ["애견펜션", "호캉스", "풀빌라", "가족여행", "우정여행"]) assert.ok(chips("펜션&풀빌라").includes(w), w);
  for (const c of ["단체", "공통"]) assert.ok(!/애견|강아지/.test(JSON.stringify(DEFAULT_TEXT[c])), c); // 애견은 개인 고객에만(사장님 2026-09-30)
  for (const w of ["복합문화공간", "공연", "공간대여", "포토존", "음료"]) assert.ok(chips("카페").includes(w), w);
  for (const w of ["객실", "강당", "식사", "부대시설"]) assert.ok(chips("단체").includes(w), w);
});
