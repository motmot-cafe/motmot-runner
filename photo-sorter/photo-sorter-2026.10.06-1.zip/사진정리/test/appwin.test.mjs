import test from "node:test";
import assert from "node:assert/strict";
import { writeFileSync, chmodSync, readFileSync, existsSync } from "node:fs";
import { join } from "node:path";
import { spawn } from "node:child_process";
import { findAppBrowser, appArgs } from "../lib/appwin.mjs";
import { tmp } from "./_helpers.mjs";

test("프로그램 창 — 엣지(없으면 크롬)를 앱 모드로 · 전용 프로필", () => {
  const d = tmp();
  const fake = join(d, "msedge.exe"); writeFileSync(fake, "");
  assert.equal(findAppBrowser({ MOTMOT_APP_BROWSER: fake }), fake);
  assert.equal(findAppBrowser({ ProgramFiles: "/없음" }), null);
  const a = appArgs("http://127.0.0.1:5178/", "C:\\p");
  assert.ok(a.includes("--app=http://127.0.0.1:5178/") && a.includes("--user-data-dir=C:\\p"));
});

const HERE = new URL("..", import.meta.url).pathname;
const run = (args, env) => spawn(process.execPath, [join(HERE, "main.mjs"), ...args], { env: { ...process.env, ...env }, stdio: ["ignore", "pipe", "pipe"] });
const waitOut = (c, re, ms = 8000) => new Promise((ok, no) => { let s = ""; const t = setTimeout(() => no(new Error("시간: " + s)), ms); c.stdout.on("data", (b) => { s += b; if (re.test(s)) { clearTimeout(t); ok(s); } }); });

test("이미 켜져 있으면 새로 안 켜고 끝낸다(같은 자리 · /api/ping)", async () => {
  const d = tmp();
  const a = run(["--no-open", "--port", "5361"], { APPDATA: d });
  await waitOut(a, /5361/);
  const b = run(["--no-open", "--port", "5361"], { APPDATA: d });
  await waitOut(b, /이미 켜져 있습니다/);
  const code = await new Promise((ok) => b.on("exit", ok));
  assert.equal(code, 0);
  a.kill();
});
