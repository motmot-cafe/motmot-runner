import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { Job } from "../lib/job.mjs";
import { writeProgress } from "../lib/progress.mjs";
import { writeZip } from "../lib/zip.mjs";
import { tmp, fakeJpeg } from "./_helpers.mjs";

test("진행상황 파일 — 콘텐츠 업로드 자동화 세션이 읽을 한 장(두 곳 · 최근 작업 먼저 · 퍼센트)", async () => {
  const d = tmp(), conf = join(d, "conf");
  const z = join(d, "a.zip");
  await writeZip(z, [{ name: "1.jpg", data: fakeJpeg(1) }, { name: "2.jpg", data: fakeJpeg(2) }, { name: "3.jpg", data: fakeJpeg(1) }, { name: "4.jpg", data: fakeJpeg(4) }]);
  const j = new Job(z);
  const [a, b, , c] = j.photos;
  j.setInfo(a.id, { w: 1, h: 1 }); j.setInfo(b.id, { w: 1, h: 1 });
  j.edit([a.id], { 공간: "세미나실", 가공: { 얼굴: [[0.1, 0.1, 0.1, 0.1]] } });
  j.edit([c.id], { 제외: true });
  const task = { 이름: "Claude 로 분류", 진행: 1, 전체: 4, 말: "1/4장", 돌아감: true, 끝말: "" };
  writeProgress(conf, j, task, { 주소: "http://127.0.0.1:5178/" });
  const all = JSON.parse(readFileSync(join(conf, "진행상황.json"), "utf8"));
  assert.equal(all.판, 1); assert.equal(all.켜짐, true); assert.equal(all.지금작업, j.srcPath);
  const w = all.작업[0];
  assert.deepEqual(w.장수, { 전체: 4, 사진: 4, 영상: 0, 기타: 0, 중복: 1, 비슷: 0 });
  assert.deepEqual(w.단계.준비, { 된: 2, 전체: 3, 퍼센트: 66.7 });
  assert.deepEqual(w.단계.분류, { 된: 1, 전체: 2, 퍼센트: 50 });
  assert.equal(w.단계.가공.얼굴가림, 1); assert.equal(w.단계.가공.그리는중, 1); assert.equal(w.단계.뺀것, 1);
  assert.deepEqual(w.지금일, { 이름: "Claude 로 분류", 진행: 1, 전체: 4, 퍼센트: 25, 말: "1/4장", 돌아감: true });
  assert.equal(JSON.parse(readFileSync(join(j.work, "진행상황.json"), "utf8")).작업[0].곳, j.srcPath);
  // 다른 작업을 열면 앞에 오고, 옛 작업은 남는다 · 끄면 켜짐 false
  const z2 = join(d, "b.zip");
  await writeZip(z2, [{ name: "x.jpg", data: fakeJpeg(9) }]);
  const k = new Job(z2);
  writeProgress(conf, k, null, { 켜짐: false });
  const all2 = JSON.parse(readFileSync(join(conf, "진행상황.json"), "utf8"));
  assert.deepEqual(all2.작업.map((x) => x.곳), [k.srcPath, j.srcPath]);
  assert.equal(all2.켜짐, false); assert.equal(all2.작업[0].지금일, null);
});
