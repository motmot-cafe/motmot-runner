import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { writeZip, listZip, extractEntry, decodeName } from "../lib/zip.mjs";
import { tmp, fakeJpeg } from "./_helpers.mjs";

test("쓰고 읽기 — 저장 · deflate · 한글 이름 · CRC", async () => {
  const d = tmp();
  const z = join(d, "a.zip");
  const big = Buffer.from("가나다".repeat(20000));
  await writeZip(z, [{ name: "펜션/침실 1.jpg", data: fakeJpeg(7) }, { name: "글.txt", data: big }], { deflate: true });
  const es = listZip(z);
  assert.deepEqual(es.map((e) => e.name), ["펜션/침실 1.jpg", "글.txt"]);
  await extractEntry(z, es[1], join(d, "o.txt"));
  assert.ok(readFileSync(join(d, "o.txt")).equals(big));
});

test("윈도우 탐색기 zip — UTF-8 표시 없이 CP949 로 적은 한글 이름", () => {
  const cp949 = Buffer.from([0xc4, 0xab, 0xc6, 0xe4, 0x2e, 0x6a, 0x70, 0x67]); // 「카페.jpg」
  assert.equal(decodeName(cp949, false, null), "카페.jpg");
});

test("맥 zip — 풀린 자모(NFD)를 모은다(NFC)", () => {
  assert.equal(decodeName(Buffer.from("카페.jpg".normalize("NFD")), false, null), "카페.jpg");
});

test("CP949 이름을 실제 zip 에서 — 플래그를 끈 zip", async () => {
  const d = tmp();
  const z = join(d, "b.zip");
  await writeZip(z, [{ name: "ab.jpg", data: fakeJpeg(1) }]);
  // 이름 두 바이트를 CP949 「카」 로, 플래그 11 을 끈다(지역 머리 · 중앙 목록 둘 다)
  const b = readFileSync(z);
  for (let i = 0; i < b.length - 4; i++) {
    const sig = b.readUInt32LE(i);
    if (sig === 0x04034b50) { b.writeUInt16LE(0, i + 6); b[i + 30] = 0xc4; b[i + 31] = 0xab; }
    if (sig === 0x02014b50) { b.writeUInt16LE(0, i + 8); b[i + 46] = 0xc4; b[i + 47] = 0xab; }
  }
  writeFileSync(z, b);
  assert.equal(listZip(z)[0].name, "카.jpg");
});

test("zip 이 아니면 알아듣게 말한다", () => {
  const d = tmp();
  writeFileSync(join(d, "x.zip"), "not a zip");
  assert.throws(() => listZip(join(d, "x.zip")), /zip 파일이 아니거나/);
});
