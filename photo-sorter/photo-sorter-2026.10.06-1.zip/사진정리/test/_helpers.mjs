/* 시험 발판 — 가짜 사진(바이트만 다른 JPEG 머리) · 임시 폴더 · 가짜 claude */
import { mkdtempSync, writeFileSync, chmodSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

export const tmp = () => mkdtempSync(join(tmpdir(), "photo-sorter-test-"));
/** 화면이 못 여는 가짜 JPEG — 분류 · 정리 시험에는 바이트만 있으면 된다 */
export const fakeJpeg = (seed, n = 3000) => { const b = Buffer.alloc(n, seed); b[0] = 0xff; b[1] = 0xd8; b[2] = 0xff; b[n - 2] = 0xff; b[n - 1] = 0xd9; return b; };

/** 가짜 claude — stdin 의 프롬프트에서 파일 이름을 읽어 정해진 답을 낸다. mode: ok | limit | face(첫 장에 얼굴 하나 · 둘째 장은 90° 누움 · 어두움) */
export function fakeClaude(dir, mode = "ok", space = "객실 침실") {
  const p = join(dir, "fake-claude.mjs");
  writeFileSync(p, `#!/usr/bin/env node
import { appendFileSync } from "node:fs";
let s = ""; process.stdin.on("data", (b) => s += b); process.stdin.on("end", () => {
  appendFileSync(${JSON.stringify(join(dir, "calls.log"))}, JSON.stringify({ args: process.argv.slice(2), cwd: process.cwd() }) + "\\n");
  if (${JSON.stringify(mode)} === "limit") { console.log(JSON.stringify({ type: "result", is_error: true, result: "You've hit your weekly limit" })); process.exit(1); }
  const files = (s.match(/이 폴더의 사진 ([^\\n]*?) 를 Read/) || [])[1].split(", ");
  const 사진 = files.map((f, i) => ({ 파일: f, 공간: i === 0 ? ${JSON.stringify(space)} : "식당", 카테고리: [], 설명: "보이는 것 " + f, 태그: ["실내"], 확신: i === files.length - 1 && files.length > 1 ? "낮음" : "높음", 사람: ${JSON.stringify(mode)} === "face" && i === 0, 홈페이지감: true,
    얼굴: ${JSON.stringify(mode)} === "face" && i === 0 ? [{ x: 200, y: 300, w: 300, h: 250 }] : [], 회전: ${JSON.stringify(mode)} === "face" && i === 1 ? 90 : 0, 어두움: ${JSON.stringify(mode)} === "face" && i === 1,
    보정: ${JSON.stringify(mode)} === "face" && i === 1 ? { 대비: 10, 색온도: 15, 기울기: -2.4 } : {} }));
  console.log(JSON.stringify({ type: "result", is_error: false, result: "", structured_output: { 사진 } }));
});
`);
  chmodSync(p, 0o755);
  return p;
}
