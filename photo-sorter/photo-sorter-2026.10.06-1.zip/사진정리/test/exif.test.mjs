import test from "node:test";
import assert from "node:assert/strict";
import { readExif } from "../lib/exif.mjs";

/** 작은 EXIF JPEG 머리 — IFD0(ExifIFD 포인터 · GPS 포인터) → DateTimeOriginal */
function exifJpeg({ le = true, gps = true } = {}) {
  const t = Buffer.alloc(200);
  const w16 = (o, v) => (le ? t.writeUInt16LE(v, o) : t.writeUInt16BE(v, o));
  const w32 = (o, v) => (le ? t.writeUInt32LE(v, o) : t.writeUInt32BE(v, o));
  t.write(le ? "II" : "MM", 0, "ascii"); w16(2, 42); w32(4, 8);
  w16(8, 2); // IFD0: 2개
  w16(10, 0x8769); w16(12, 4); w32(14, 1); w32(18, 40);
  w16(22, gps ? 0x8825 : 0x0100); w16(24, 4); w32(26, 1); w32(30, 90);
  w16(40, 1); w16(42, 0x9003); w16(44, 2); w32(46, 20); w32(50, 60);
  t.write("2025:07:14 16:02:09\0", 60, "ascii");
  w16(90, 2); w16(92, 2); w16(94, 5); w32(96, 3); w32(100, 0); w16(104, 4); w16(106, 5); w32(108, 3); w32(112, 0);
  const app1 = Buffer.concat([Buffer.from("Exif\0\0", "ascii"), t]);
  const len = Buffer.alloc(2); len.writeUInt16BE(app1.length + 2);
  return new Uint8Array(Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe1]), len, app1, Buffer.from([0xff, 0xda])]));
}

test("찍은 날 · GPS 있음 — 두 바이트 차례 모두", () => {
  assert.deepEqual(readExif(exifJpeg()), { 찍은날: "2025-07-14 16:02:09", gps: true });
  assert.deepEqual(readExif(exifJpeg({ le: false, gps: false })), { 찍은날: "2025-07-14 16:02:09", gps: false });
});

test("EXIF 가 없거나 JPEG 가 아니면 빈 값", () => {
  assert.deepEqual(readExif(new Uint8Array([0x89, 0x50, 0x4e, 0x47])), { 찍은날: null, gps: false });
  assert.deepEqual(readExif(new Uint8Array([0xff, 0xd8, 0xff, 0xda, 0, 2])), { 찍은날: null, gps: false });
});
