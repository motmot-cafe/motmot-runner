/* 대표 썸네일 그리기(1080×1080) — 틀 6 × 색 6 × 글꼴 3 (lib/thumbs.mjs 와 같은 이름). 배경은 원고에 안 쓴 사진.
   내용은 늘 같다(윗줄 · 지역 · 이름 · 전화 · 칩 4개) — 모양만 다르다(사장님 2026-09-30). */
const S = 1080;
const FONT_FILES = { Jua: "Jua-Regular.ttf", "Black Han Sans": "BlackHanSans-Regular.ttf", "Do Hyeon": "DoHyeon-Regular.ttf" };
let fontsReady = null;
export function loadFonts() {
  fontsReady ||= Promise.all(Object.entries(FONT_FILES).map(async ([name, file]) => {
    const f = new FontFace(name, `url(/vendor/fonts/${file})`);
    await f.load(); document.fonts.add(f);
  }));
  return fontsReady;
}
const PAL = {
  숲: { 판: "#f7f3ea", 글: "#1d1d1b", 강조: "#1c97a6", 이름색: "#79a71e", 칩: "#4a5d3a", 칩글: "#ffffff" },
  "네이비 골드": { 판: "#15243b", 글: "#ffffff", 강조: "#f2c14e", 이름색: "#ffffff", 칩: "#f2c14e", 칩글: "#15243b" },
  "베이지 브라운": { 판: "#efe4d2", 글: "#3b2a1a", 강조: "#b5651d", 이름색: "#5a3a1c", 칩: "#8b5e34", 칩글: "#ffffff" },
  "코랄 크림": { 판: "#fff5ec", 글: "#2b2b2b", 강조: "#ff6f59", 이름색: "#e0533d", 칩: "#ff8c73", 칩글: "#ffffff" },
  "차콜 옐로": { 판: "#232323", 글: "#ffffff", 강조: "#ffb800", 이름색: "#ffb800", 칩: "#ffb800", 칩글: "#232323" },
  "하늘 화이트": { 판: "#ffffff", 글: "#16324f", 강조: "#2b8fd6", 이름색: "#16324f", 칩: "#2b8fd6", 칩글: "#ffffff" },
  "올리브 민트": { 판: "#eef5ec", 글: "#1f3326", 강조: "#3aa17e", 이름색: "#2f5d3a", 칩: "#3aa17e", 칩글: "#ffffff" },
  "버건디 크림": { 판: "#faf3ea", 글: "#2a1a1a", 강조: "#9b2c3a", 이름색: "#7a1f2b", 칩: "#9b2c3a", 칩글: "#ffffff" },
  라벤더: { 판: "#f3effa", 글: "#2b2340", 강조: "#7b61c9", 이름색: "#5a44a8", 칩: "#7b61c9", 칩글: "#ffffff" },
  "딥 틸": { 판: "#0f3b40", 글: "#ffffff", 강조: "#5fd1c4", 이름색: "#ffffff", 칩: "#5fd1c4", 칩글: "#0f3b40" },
  "선셋 오렌지": { 판: "#fff1e0", 글: "#3a2410", 강조: "#f07b1d", 이름색: "#c8550c", 칩: "#f07b1d", 칩글: "#ffffff" },
  모노: { 판: "#ffffff", 글: "#111111", 강조: "#111111", 이름색: "#111111", 칩: "#111111", 칩글: "#ffffff" },
  "민트 네이비": { 판: "#e8f7f3", 글: "#14213d", 강조: "#18a999", 이름색: "#14213d", 칩: "#14213d", 칩글: "#ffffff" },
  "핑크 베이지": { 판: "#fbeee9", 글: "#3d2b2b", 강조: "#e76f8a", 이름색: "#c24d6a", 칩: "#e76f8a", 칩글: "#ffffff" },
  머스타드: { 판: "#fff6d6", 글: "#2d2a1e", 강조: "#d9a400", 이름색: "#8a6a00", 칩: "#2d2a1e", 칩글: "#ffd84a" },
  "올리브 브라운": { 판: "#f1ede0", 글: "#2e2a1f", 강조: "#7a8b3a", 이름색: "#5b4a2e", 칩: "#7a8b3a", 칩글: "#ffffff" },
  "스카이 옐로": { 판: "#e9f5ff", 글: "#123049", 강조: "#ffc93c", 이름색: "#1b6fb3", 칩: "#1b6fb3", 칩글: "#ffffff" },
  체리: { 판: "#fff0f0", 글: "#2b1414", 강조: "#d7263d", 이름색: "#b0172b", 칩: "#d7263d", 칩글: "#ffffff" },
  "포레스트 골드": { 판: "#1f3a2c", 글: "#f6f1de", 강조: "#e3b04b", 이름색: "#f6f1de", 칩: "#e3b04b", 칩글: "#1f3a2c" },
  "크림 그린": { 판: "#fbf7ea", 글: "#233021", 강조: "#5c9e4a", 이름색: "#3e7a31", 칩: "#5c9e4a", 칩글: "#ffffff" },
  인디고: { 판: "#1d1f4f", 글: "#ffffff", 강조: "#8ea6ff", 이름색: "#ffffff", 칩: "#8ea6ff", 칩글: "#1d1f4f" },
  테라코타: { 판: "#f7ebe2", 글: "#3a2419", 강조: "#c8653d", 이름색: "#a44a26", 칩: "#c8653d", 칩글: "#ffffff" },
  슬레이트: { 판: "#eef1f4", 글: "#1f2933", 강조: "#52606d", 이름색: "#1f2933", 칩: "#52606d", 칩글: "#ffffff" },
  레몬: { 판: "#fffbe0", 글: "#262200", 강조: "#f2d40f", 이름색: "#3d7a00", 칩: "#3d7a00", 칩글: "#fffbe0" },
};
/** 어두운 판인가 — 판 위 글자가 흰색 계열인지 가르는 데 */
const darkPanel = (P) => { const n = parseInt(P.판.slice(1), 16); return ((n >> 16) * 299 + ((n >> 8) & 255) * 587 + (n & 255) * 114) / 1000 < 110; };

/* ── 도움 ─────────────────────────────────────────── */
function cover(g, img, x, y, w, h) {
  const k = Math.max(w / img.width, h / img.height), sw = w / k, sh = h / k;
  g.drawImage(img, (img.width - sw) / 2, (img.height - sh) / 2, sw, sh, x, y, w, h);
}
function rr(g, x, y, w, h, r) { g.beginPath(); g.roundRect(x, y, w, h, r); }
/** 너비에 맞게 글자 크기를 줄여 가운데(또는 왼쪽)에 쓴다 */
function fit(g, text, x, y, maxW, size, font, color, align = "center", weight = "") {
  let s = size;
  do { g.font = `${weight} ${s}px "${font}"`; s -= 2; } while (g.measureText(text).width > maxW && s > 12);
  g.fillStyle = color; g.textAlign = align; g.textBaseline = "middle";
  g.fillText(text, x, y);
  return s + 2;
}
function shade(hex, a) { const n = parseInt(hex.slice(1), 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`; }

/* 선 아이콘 — 칩 글자로 고른다 */
const ICONS = [
  [/포토|인생샷|사진/, "camera"], [/공연|음악|버스킹/, "music"], [/공간대여|대관|부대시설/, "house"], [/복합문화/, "star"], [/호캉스/, "bed"], [/강당/, "monitor"],
  [/MT|캠핑|야외/, "tent"], [/워크샵|단체|모임|가족|커플|친구/, "people"], [/수련|행사|대회|연회/, "flag"], [/컨벤션|세미나|회의|강연|연수/, "monitor"],
  [/케이터링|식사|뒤풀이/, "grill"], [/테라스|좌석/, "house"],
  [/풀빌라|수영|풀/, "wave"], [/바베큐|바비큐|BBQ/, "grill"], [/스파|온수|욕조/, "drops"], [/객실|침실|숙박|숙소/, "bed"],
  [/음료|커피|카페/, "cup"], [/베이커리|빵|디저트/, "bread"], [/반려|애견|강아지/, "paw"], [/글래스룸|유리/, "house"], [/전망|산|숲|풍경/, "mountain"],
];
function icon(g, name, cx, cy, s, color) {
  g.save(); g.strokeStyle = color; g.fillStyle = color; g.lineWidth = s * 0.07; g.lineJoin = "round"; g.lineCap = "round";
  const P = (pts, close) => { g.beginPath(); pts.forEach(([x, y], i) => (i ? g.lineTo(cx + x * s, cy + y * s) : g.moveTo(cx + x * s, cy + y * s))); if (close) g.closePath(); g.stroke(); };
  const C = (x, y, r) => { g.beginPath(); g.arc(cx + x * s, cy + y * s, r * s, 0, Math.PI * 2); g.stroke(); };
  switch (name) {
    case "tent": P([[-0.4, 0.3], [0, -0.35], [0.4, 0.3]], true); P([[0, -0.35], [0, 0.3]]); break;
    case "people": C(-0.12, -0.15, 0.13); g.beginPath(); g.arc(cx - 0.12 * s, cy + 0.3 * s, 0.25 * s, Math.PI, 0); g.stroke(); C(0.2, -0.12, 0.1); g.beginPath(); g.arc(cx + 0.2 * s, cy + 0.3 * s, 0.2 * s, Math.PI * 1.1, 0); g.stroke(); break;
    case "flag": P([[-0.2, 0.38], [-0.2, -0.38]]); P([[-0.2, -0.36], [0.28, -0.36], [0.12, -0.18], [0.28, 0], [-0.2, 0]]); break;
    case "monitor": g.beginPath(); g.roundRect(cx - 0.38 * s, cy - 0.3 * s, 0.76 * s, 0.46 * s, 0.05 * s); g.stroke(); P([[0, 0.16], [0, 0.32]]); P([[-0.18, 0.34], [0.18, 0.34]]); break;
    case "wave": for (const y of [-0.15, 0.1]) { g.beginPath(); for (let i = 0; i <= 20; i++) { const x = -0.4 + i * 0.04; const yy = y + Math.sin(i / 20 * Math.PI * 3) * 0.06; i ? g.lineTo(cx + x * s, cy + yy * s) : g.moveTo(cx + x * s, cy + yy * s); } g.stroke(); } P([[-0.1, -0.38], [-0.1, -0.22]]); P([[0.12, -0.38], [0.12, -0.22]]); break;
    case "grill": g.beginPath(); g.arc(cx, cy - 0.05 * s, 0.34 * s, 0, Math.PI); g.stroke(); P([[-0.38, -0.05], [0.38, -0.05]]); P([[-0.18, 0.25], [-0.28, 0.4]]); P([[0.18, 0.25], [0.28, 0.4]]); P([[-0.12, -0.35], [-0.08, -0.2]]); P([[0.08, -0.35], [0.12, -0.2]]); break;
    case "drops": for (const [x, y] of [[-0.18, 0], [0.18, -0.1]]) { g.beginPath(); g.moveTo(cx + x * s, cy + (y - 0.3) * s); g.quadraticCurveTo(cx + (x + 0.2) * s, cy + (y + 0.05) * s, cx + x * s, cy + (y + 0.2) * s); g.quadraticCurveTo(cx + (x - 0.2) * s, cy + (y + 0.05) * s, cx + x * s, cy + (y - 0.3) * s); g.stroke(); } break;
    case "bed": P([[-0.42, 0.3], [-0.42, -0.25]]); P([[-0.42, 0.08], [0.42, 0.08], [0.42, 0.3]]); P([[-0.3, -0.04], [-0.05, -0.04], [-0.05, -0.16], [-0.3, -0.16]], true); P([[0.02, -0.04], [0.42, -0.04], [0.42, 0.08]]); break;
    case "cup": g.beginPath(); g.roundRect(cx - 0.3 * s, cy - 0.15 * s, 0.46 * s, 0.45 * s, 0.08 * s); g.stroke(); g.beginPath(); g.arc(cx + 0.2 * s, cy + 0.05 * s, 0.1 * s, -Math.PI / 2, Math.PI / 2); g.stroke(); P([[-0.12, -0.38], [-0.12, -0.24]]); P([[0.02, -0.38], [0.02, -0.24]]); break;
    case "bread": g.beginPath(); g.moveTo(cx - 0.38 * s, cy + 0.25 * s); g.lineTo(cx - 0.38 * s, cy - 0.05 * s); g.quadraticCurveTo(cx - 0.38 * s, cy - 0.35 * s, cx, cy - 0.35 * s); g.quadraticCurveTo(cx + 0.38 * s, cy - 0.35 * s, cx + 0.38 * s, cy - 0.05 * s); g.lineTo(cx + 0.38 * s, cy + 0.25 * s); g.closePath(); g.stroke(); P([[-0.15, -0.15], [-0.05, 0.05]]); P([[0.08, -0.18], [0.18, 0.02]]); break;
    case "paw": C(0, 0.12, 0.17); C(-0.24, -0.12, 0.07); C(-0.08, -0.26, 0.07); C(0.08, -0.26, 0.07); C(0.24, -0.12, 0.07); break;
    case "house": P([[-0.38, 0.35], [-0.38, -0.05], [0, -0.38], [0.38, -0.05], [0.38, 0.35]], true); P([[-0.38, -0.05], [0.38, -0.05]]); P([[0, -0.38], [0, 0.35]]); break;
    case "mountain": P([[-0.42, 0.3], [-0.12, -0.2], [0.05, 0.05], [0.18, -0.1], [0.42, 0.3]], true); C(0.25, -0.3, 0.07); break;
    case "camera": g.beginPath(); g.roundRect(cx - 0.4 * s, cy - 0.2 * s, 0.8 * s, 0.52 * s, 0.08 * s); g.stroke(); P([[-0.14, -0.2], [-0.08, -0.32], [0.08, -0.32], [0.14, -0.2]]); C(0, 0.06, 0.15); break;
    case "music": P([[-0.12, 0.28], [-0.12, -0.32], [0.3, -0.4], [0.3, 0.2]]); C(-0.22, 0.28, 0.1); C(0.2, 0.2, 0.1); break;
    default: P([[0, -0.36], [0.1, -0.1], [0.38, -0.1], [0.16, 0.06], [0.24, 0.34], [0, 0.18], [-0.24, 0.34], [-0.16, 0.06], [-0.38, -0.1], [-0.1, -0.1]], true);
  }
  g.restore();
}
const iconFor = (t) => (ICONS.find(([re]) => re.test(t)) || [0, "star"])[1];
function houses(g, cx, y, s, color) { // 참고 이미지의 작은 집 셋
  g.save(); g.strokeStyle = color; g.lineWidth = s * 0.05; g.lineJoin = "round";
  [[-1.1, 0.8], [0, 1], [1.2, 0.9]].forEach(([dx, k]) => {
    const w = s * 0.8 * k, h = s * 0.8 * k, x = cx + dx * s - w / 2, b = y + s * 0.5;
    g.beginPath(); g.moveTo(x, b); g.lineTo(x, b - h * 0.55); g.lineTo(x + w / 2, b - h); g.lineTo(x + w, b - h * 0.55); g.lineTo(x + w, b); g.closePath(); g.stroke();
    g.strokeRect(x + w * 0.38, b - h * 0.3, w * 0.24, h * 0.3);
  });
  g.restore();
}
/** 칩 — 둥근 네모 + 아이콘 + 아래 글자(큰 칩) 또는 알약(작은 칩) */
function chipsSquare(g, chips, cx, y, size, gap, P, font, labelColor) {
  const n = chips.length, total = n * size + (n - 1) * gap;
  chips.forEach((t, i) => {
    const x = cx - total / 2 + i * (size + gap);
    g.fillStyle = P.칩; rr(g, x, y, size, size, size * 0.24); g.fill();
    icon(g, iconFor(t), x + size / 2, y + size / 2, size * 0.5, P.칩글);
    fit(g, t, x + size / 2, y + size + size * 0.34, size + gap * 0.9, size * 0.3, font, labelColor);
  });
}
function chipsPill(g, chips, cx, y, h, P, font, maxW) {
  g.font = `${h * 0.46}px "${font}"`;
  const ws = chips.map((t) => g.measureText(t).width + h * 1.35);
  let total = ws.reduce((a, b) => a + b, 0) + (chips.length - 1) * h * 0.25;
  const k = Math.min(1, maxW / total); total *= k;
  let x = cx - total / 2;
  chips.forEach((t, i) => {
    const w = ws[i] * k;
    g.fillStyle = P.칩; rr(g, x, y, w, h, h / 2); g.fill();
    icon(g, iconFor(t), x + h * 0.52, y + h / 2, h * 0.5, P.칩글);
    fit(g, t, x + h * 0.9, y + h / 2, w - h * 1.05, h * 0.46 * k, font, P.칩글, "left");
    x += w + h * 0.25 * k;
  });
}

/* ── 틀 6 ─────────────────────────────────────────── */
function textBlock(g, T, P, F, cx, top, maxW, k = 1, align = "center") {
  let y = top;
  fit(g, T.윗줄, cx, y, maxW, 46 * k, F, P.글, align); y += 150 * k;
  fit(g, T.지역, cx, y, maxW, 120 * k, F, P.강조, align); y += 135 * k;
  fit(g, T.이름, cx, y, maxW, 150 * k, F, P.이름색, align); y += 145 * k;
  fit(g, T.전화, cx, y, maxW, 128 * k, F, P.글, align, ""); y += 90 * k;
  return y;
}
const LAYOUT = {
  "아치 카드"(g, bg, T, P, F) {
    cover(g, bg, 0, 0, S, S);
    g.fillStyle = shade("#000000", 0.08); g.fillRect(0, 0, S, S);
    const L = 70, R = S - 70, B = 900, cxA = S / 2, r = (R - L) / 2, cyA = 40 + r;
    g.save(); g.shadowColor = "rgba(0,0,0,.25)"; g.shadowBlur = 30;
    g.beginPath(); g.moveTo(L, B - 36); g.lineTo(L, cyA); g.arc(cxA, cyA, r, Math.PI, 0); g.lineTo(R, B - 36); g.arcTo(R, B, R - 36, B, 36); g.lineTo(L + 36, B); g.arcTo(L, B, L, B - 36, 36); g.closePath();
    g.fillStyle = P.판; g.fill(); g.restore();
    houses(g, cxA, 95, 52, P.글);
    textBlock(g, T, P, F, cxA, 205, R - L - 160, 0.92);
    chipsSquare(g, T.칩, cxA, 690, 118, 70, P, F, P.글);
  },
  "아래 띠"(g, bg, T, P, F) {
    cover(g, bg, 0, 0, S, 620);
    g.fillStyle = P.판; g.beginPath(); g.moveTo(0, 560); g.quadraticCurveTo(S / 2, 660, S, 560); g.lineTo(S, S); g.lineTo(0, S); g.closePath(); g.fill();
    g.save(); g.fillStyle = shade("#000000", 0.35); rr(g, 60, 60, 520, 84, 42); g.fill(); g.restore();
    fit(g, T.윗줄, 320, 102, 480, 38, F, "#ffffff");
    fit(g, `${T.지역} ${T.이름}`, S / 2, 700, S - 120, 110, F, P.이름색);
    fit(g, T.전화, S / 2, 815, S - 200, 104, F, P.강조);
    chipsPill(g, T.칩, S / 2, 900, 96, P, F, S - 100);
  },
  "가운데 원"(g, bg, T, P, F) {
    cover(g, bg, 0, 0, S, S);
    g.fillStyle = shade("#000000", 0.18); g.fillRect(0, 0, S, S);
    g.save(); g.shadowColor = "rgba(0,0,0,.3)"; g.shadowBlur = 40;
    g.beginPath(); g.arc(S / 2, 470, 400, 0, Math.PI * 2); g.fillStyle = shade(P.판, 0.95); g.fill(); g.restore();
    g.beginPath(); g.arc(S / 2, 470, 380, 0, Math.PI * 2); g.strokeStyle = P.강조; g.lineWidth = 4; g.setLineDash([2, 14]); g.lineCap = "round"; g.stroke(); g.setLineDash([]);
    textBlock(g, T, P, F, S / 2, 210, 560, 0.86);
    chipsPill(g, T.칩, S / 2, 930, 92, P, F, S - 90);
  },
  "좌우 나눔"(g, bg, T, P, F) {
    g.fillStyle = P.판; g.fillRect(0, 0, S, S);
    g.save(); rr(g, 40, 40, 500, S - 80, 36); g.clip(); cover(g, bg, 40, 40, 500, S - 80); g.restore();
    const x = 590, w = S - x - 50;
    fit(g, T.윗줄, x, 130, w, 40, F, P.글, "left");
    g.fillStyle = P.강조; g.fillRect(x, 180, 90, 8);
    fit(g, T.지역, x, 285, w, 110, F, P.강조, "left");
    fit(g, T.이름, x, 420, w, 120, F, P.이름색, "left");
    fit(g, T.전화, x, 560, w, 96, F, P.글, "left");
    // 칩은 한 줄에 하나 — 오른쪽 칸이 좁아 두 줄 두 칸이면 글자가 너무 작아진다(114장 시험에서 잡힘)
    T.칩.forEach((t, i) => {
      const cy = 640 + i * 96;
      g.fillStyle = P.칩; rr(g, x, cy, 78, 78, 20); g.fill();
      icon(g, iconFor(t), x + 39, cy + 39, 44, P.칩글);
      fit(g, t, x + 100, cy + 40, w - 105, 46, F, P.글, "left");
    });
  },
  "폴라로이드"(g, bg, T, P, F) {
    g.fillStyle = P.판; g.fillRect(0, 0, S, S);
    g.save(); g.shadowColor = "rgba(0,0,0,.22)"; g.shadowBlur = 30; g.shadowOffsetY = 10;
    g.fillStyle = "#ffffff"; rr(g, 70, 50, S - 140, 600, 20); g.fill(); g.restore();
    g.save(); rr(g, 94, 74, S - 188, 552, 12); g.clip(); cover(g, bg, 94, 74, S - 188, 552); g.restore();
    g.save(); g.fillStyle = P.강조; rr(g, S / 2 - 250, 590, 500, 80, 40); g.fill(); g.restore();
    fit(g, T.윗줄, S / 2, 630, 460, 38, F, "#ffffff");
    fit(g, `${T.지역} ${T.이름}`, S / 2, 745, S - 140, 100, F, P.이름색);
    fit(g, T.전화, S / 2, 850, S - 240, 96, F, P.글);
    chipsPill(g, T.칩, S / 2, 930, 88, P, F, S - 120);
  },
  "액자 테두리"(g, bg, T, P, F) {
    cover(g, bg, 0, 0, S, S);
    g.fillStyle = shade("#000000", 0.12); g.fillRect(0, 0, S, S);
    g.lineWidth = 36; g.strokeStyle = P.강조; g.strokeRect(18, 18, S - 36, S - 36);
    g.lineWidth = 3; g.strokeStyle = shade("#ffffff", 0.9); g.strokeRect(52, 52, S - 104, S - 104);
    g.save(); g.shadowColor = "rgba(0,0,0,.25)"; g.shadowBlur = 30;
    g.fillStyle = shade(P.판, 0.93); rr(g, 130, 200, S - 260, 560, 40); g.fill(); g.restore();
    textBlock(g, T, P, F, S / 2, 280, S - 360, 0.8);
    chipsPill(g, T.칩, S / 2, 880, 92, P, F, S - 150);
  },
};

/* ── 틀 6 더(2026-09-30 「너무 유사」 → 12) — 앞의 6과 한눈에 다르게 ───────── */
Object.assign(LAYOUT, {
  "거꾸로 아치"(g, bg, T, P, F) { // 사진이 위 아치 창, 아래가 판
    g.fillStyle = P.판; g.fillRect(0, 0, S, S);
    g.save(); g.beginPath(); g.moveTo(90, 560); g.lineTo(90, 480); g.arc(S / 2, 480, 450, Math.PI, 0); g.lineTo(S - 90, 560); g.closePath(); g.clip(); cover(g, bg, 90, 30, S - 180, 530); g.restore();
    g.strokeStyle = P.강조; g.lineWidth = 6; g.beginPath(); g.moveTo(90, 560); g.lineTo(90, 480); g.arc(S / 2, 480, 450, Math.PI, 0); g.lineTo(S - 90, 560); g.stroke();
    fit(g, T.윗줄, S / 2, 615, S - 200, 40, F, P.강조);
    fit(g, `${T.지역} ${T.이름}`, S / 2, 700, S - 140, 104, F, P.이름색);
    fit(g, T.전화, S / 2, 805, S - 240, 92, F, P.글);
    chipsSquare(g, T.칩, S / 2, 868, 92, 110, P, F, P.글);
  },
  "위 띠"(g, bg, T, P, F) { // 글자 띠가 위, 사진이 아래
    cover(g, bg, 0, 420, S, S - 420);
    g.fillStyle = P.판; g.beginPath(); g.moveTo(0, 0); g.lineTo(S, 0); g.lineTo(S, 470); g.quadraticCurveTo(S / 2, 380, 0, 470); g.closePath(); g.fill();
    fit(g, T.윗줄, S / 2, 70, S - 160, 40, F, P.강조);
    fit(g, `${T.지역} ${T.이름}`, S / 2, 175, S - 120, 110, F, P.이름색);
    fit(g, T.전화, S / 2, 295, S - 220, 100, F, P.글);
    g.save(); g.fillStyle = shade("#000000", 0.28); rr(g, 40, S - 150, S - 80, 120, 60); g.fill(); g.restore();
    chipsPill(g, T.칩, S / 2, S - 134, 88, P, F, S - 120);
  },
  "가운데 네모"(g, bg, T, P, F) { // 흐린 배경 + 기울인 카드
    g.save(); g.filter = "blur(10px) brightness(.85)"; cover(g, bg, -30, -30, S + 60, S + 60); g.restore();
    g.save(); g.translate(S / 2, S / 2); g.rotate(-0.035);
    g.shadowColor = "rgba(0,0,0,.35)"; g.shadowBlur = 40; g.fillStyle = P.판; rr(g, -400, -400, 800, 800, 28); g.fill(); g.shadowColor = "transparent";
    g.save(); rr(g, -360, -360, 720, 330, 18); g.clip(); cover(g, bg, -360, -360, 720, 330); g.restore();
    fit(g, T.윗줄, 0, 5, 680, 36, F, P.강조);
    fit(g, `${T.지역} ${T.이름}`, 0, 85, 700, 86, F, P.이름색);
    fit(g, T.전화, 0, 180, 600, 84, F, P.글);
    chipsPill(g, T.칩, 0, 262, 82, P, F, 720);
    g.restore();
  },
  "좌우 반대"(g, bg, T, P, F) { // 사진이 오른쪽, 글자가 왼쪽 · 세로 칩
    g.fillStyle = P.판; g.fillRect(0, 0, S, S);
    g.save(); g.beginPath(); g.moveTo(S * 0.52, 0); g.lineTo(S, 0); g.lineTo(S, S); g.lineTo(S * 0.42, S); g.closePath(); g.clip(); cover(g, bg, S * 0.4, 0, S * 0.6, S); g.restore();
    const x = 60, w = S * 0.4;
    g.fillStyle = P.강조; g.fillRect(x, 110, 10, 250);
    fit(g, T.윗줄, x + 30, 140, w, 34, F, P.글, "left");
    fit(g, T.지역, x + 30, 225, w, 96, F, P.강조, "left");
    fit(g, T.이름, x + 30, 330, w, 92, F, P.이름색, "left");
    fit(g, T.전화, x, 470, w + 20, 88, F, P.글, "left");
    T.칩.forEach((t, i) => {
      const cy = 560 + i * 110;
      g.fillStyle = P.칩; rr(g, x, cy, w - 20, 88, 44); g.fill();
      icon(g, iconFor(t), x + 46, cy + 44, 46, P.칩글);
      fit(g, t, x + 90, cy + 46, w - 130, 44, F, P.칩글, "left");
    });
  },
  "사진 아래 카드"(g, bg, T, P, F) { // 위 글자 카드 · 아래 사진(둥근 창) — 폴라로이드의 거꾸로
    g.fillStyle = P.강조; g.fillRect(0, 0, S, S);
    g.fillStyle = P.판; rr(g, 50, 50, S - 100, S - 100, 40); g.fill();
    fit(g, T.윗줄, S / 2, 120, S - 200, 40, F, P.강조);
    fit(g, T.이름, S / 2, 215, S - 180, 112, F, P.이름색);
    g.save(); rr(g, 90, 300, S - 180, 470, 30); g.clip(); cover(g, bg, 90, 300, S - 180, 470); g.restore();
    g.save(); g.fillStyle = P.칩; rr(g, S / 2 - 250, 730, 500, 90, 45); g.fill(); g.restore();
    fit(g, `${T.지역} · ${T.전화}`, S / 2, 776, 460, 50, F, P.칩글);
    chipsPill(g, T.칩, S / 2, 880, 82, P, F, S - 180);
  },
  "흰 테두리"(g, bg, T, P, F) { // 굵은 판색 테두리 + 아래 왼쪽 글자 덩어리(사진이 크게)
    g.fillStyle = P.판; g.fillRect(0, 0, S, S);
    g.save(); rr(g, 60, 60, S - 120, S - 120, 12); g.clip(); cover(g, bg, 60, 60, S - 120, S - 120);
    const grd = g.createLinearGradient(0, S * 0.45, 0, S); grd.addColorStop(0, "rgba(0,0,0,0)"); grd.addColorStop(1, "rgba(0,0,0,.72)"); g.fillStyle = grd; g.fillRect(60, 60, S - 120, S - 120);
    g.restore();
    fit(g, T.윗줄, 110, 610, S - 260, 40, F, "#ffffff", "left");
    fit(g, `${T.지역} ${T.이름}`, 110, 700, S - 240, 96, F, "#ffffff", "left");
    g.fillStyle = P.강조 === "#111111" ? "#ffffff" : P.강조; g.fillRect(110, 752, 70, 8); // 강조색은 밑줄로만 — 어두운 사진 위 전화번호는 흰 글씨(114장 시험에서 잡힘)
    fit(g, T.전화, 110, 810, S - 300, 88, F, "#ffffff", "left");
    chipsPill(g, T.칩, S / 2, 880, 78, P, F, S - 220);
  },
});

/* ── 틀 8 더(20) — 모양 자체가 다른 것들 ───────────────────────── */
function cornerText(g, T, P, F, x, y, w, color) { // 왼쪽 정렬 3줄 덩어리
  fit(g, T.지역, x, y, w, 70, F, P.강조 === color ? P.이름색 : P.강조, "left");
  fit(g, T.이름, x, y + 90, w, 92, F, color, "left");
  fit(g, T.전화, x, y + 190, w, 84, F, color, "left");
}
Object.assign(LAYOUT, {
  "대각선 나눔"(g, bg, T, P, F) {
    // 대각선 = (S, 0.22S) → (-0.1S, S). 글자 폭은 그 줄에서 선까지 남는 만큼만(띠에 안 걸리게 — 미리보기에서 잡힘)
    cover(g, bg, 0, 0, S, S);
    g.fillStyle = P.판; g.beginPath(); g.moveTo(S, S * 0.22); g.lineTo(S, S); g.lineTo(-S * 0.1, S); g.closePath(); g.fill();
    g.strokeStyle = P.강조; g.lineWidth = 14; g.beginPath(); g.moveTo(S, S * 0.2); g.lineTo(-S * 0.1, S * 0.98); g.stroke();
    const room = (y) => S - 60 - (S - (y - S * 0.22) * 1.41) - 30;
    fit(g, T.윗줄, S - 60, S * 0.58, room(S * 0.56), 40, F, P.강조, "right");
    fit(g, T.지역, S - 60, S * 0.655, room(S * 0.63), 78, F, P.강조, "right");
    fit(g, T.이름, S - 60, S * 0.745, room(S * 0.72), 100, F, P.이름색, "right");
    fit(g, T.전화, S - 60, S * 0.835, room(S * 0.81), 92, F, P.글, "right");
    chipsPill(g, T.칩, S * 0.6, S - 110, 74, P, F, S * 0.7);
  },
  "원형 뱃지"(g, bg, T, P, F) {
    cover(g, bg, 0, 0, S, S);
    g.save(); g.fillStyle = P.강조; g.beginPath(); g.moveTo(0, 60); g.lineTo(640, 60); g.lineTo(600, 130); g.lineTo(640, 200); g.lineTo(0, 200); g.closePath(); g.fill(); g.restore();
    fit(g, T.윗줄, 40, 130, 540, 44, F, darkPanel({ 판: P.강조 }) ? "#ffffff" : P.글, "left");
    const cx = S - 300, cy = S - 330, r = 250;
    g.save(); g.shadowColor = "rgba(0,0,0,.35)"; g.shadowBlur = 30; g.fillStyle = P.판; g.beginPath(); g.arc(cx, cy, r, 0, Math.PI * 2); g.fill(); g.restore();
    g.strokeStyle = P.강조; g.lineWidth = 8; g.beginPath(); g.arc(cx, cy, r - 18, 0, Math.PI * 2); g.stroke();
    fit(g, T.지역, cx, cy - 110, 300, 60, F, P.강조);
    fit(g, T.이름, cx, cy - 20, 400, 76, F, P.이름색);
    fit(g, T.전화, cx, cy + 80, 380, 70, F, P.글);
    T.칩.forEach((t, i) => {
      const x = 90 + i * 0 , y = S - 520 + i * 120;
      g.fillStyle = P.칩; g.beginPath(); g.arc(x, y, 48, 0, Math.PI * 2); g.fill(); icon(g, iconFor(t), x, y, 50, P.칩글);
      g.save(); g.shadowColor = "rgba(0,0,0,.7)"; g.shadowBlur = 8; fit(g, t, x + 64, y, 260, 40, F, "#ffffff", "left"); g.restore();
    });
  },
  "포스터"(g, bg, T, P, F) {
    g.fillStyle = P.판; g.fillRect(0, 0, S, S);
    fit(g, T.윗줄, 70, 90, S - 140, 42, F, P.강조, "left");
    fit(g, T.전화, S / 2, 250, S - 100, 190, F, P.이름색);
    fit(g, `${T.지역} ${T.이름}`, 70, 400, S - 140, 70, F, P.글, "left");
    g.save(); g.beginPath(); g.roundRect(0, 470, S, S - 470, [60, 60, 0, 0]); g.clip(); cover(g, bg, 0, 470, S, S - 470); g.restore();
    g.save(); g.fillStyle = shade("#000000", 0.35); rr(g, 50, S - 140, S - 100, 100, 50); g.fill(); g.restore();
    chipsPill(g, T.칩, S / 2, S - 130, 80, P, F, S - 140);
  },
  "필름 스트립"(g, bg, T, P, F) {
    g.fillStyle = P.판; g.fillRect(0, 0, S, S);
    fit(g, T.윗줄, S / 2, 95, S - 160, 44, F, P.강조);
    fit(g, `${T.지역} ${T.이름}`, S / 2, 190, S - 120, 100, F, P.이름색);
    g.fillStyle = "#151515"; g.fillRect(0, 280, S, 420);
    for (let x = 20; x < S; x += 64) { g.fillStyle = "#f4f4f4"; rr(g, x, 296, 30, 22, 5); g.fill(); rr(g, x, 662, 30, 22, 5); g.fill(); }
    const fw = 320, fh = 300, sx = [0, 0.34, 0.68];
    sx.forEach((ox, i) => { // 한 사진을 세 자리로 잘라 세 컷처럼
      const x = 30 + i * (fw + 25), y = 340;
      g.save(); rr(g, x, y, fw, fh, 8); g.clip();
      const k = Math.max(fh / bg.height, (fw * 2.4) / bg.width), w = bg.width * k;
      g.drawImage(bg, x - (w - fw) * ox, y - (bg.height * k - fh) / 2, w, bg.height * k); g.restore();
    });
    fit(g, T.전화, S / 2, 800, S - 240, 110, F, P.글);
    chipsPill(g, T.칩, S / 2, 900, 88, P, F, S - 120);
  },
  "잡지 표지"(g, bg, T, P, F) {
    cover(g, bg, 0, 0, S, S);
    const grd = g.createLinearGradient(0, 0, 0, S); grd.addColorStop(0, "rgba(0,0,0,.45)"); grd.addColorStop(0.35, "rgba(0,0,0,0)"); grd.addColorStop(0.6, "rgba(0,0,0,0)"); grd.addColorStop(1, "rgba(0,0,0,.65)");
    g.fillStyle = grd; g.fillRect(0, 0, S, S);
    fit(g, T.이름, S / 2, 130, S - 80, 150, F, "#ffffff");
    g.fillStyle = P.강조; g.fillRect(S / 2 - 60, 225, 120, 8);
    fit(g, T.윗줄, S / 2, 280, S - 200, 40, F, "#ffffff");
    g.save(); g.fillStyle = P.강조; rr(g, 60, S - 300, 220, 70, 10); g.fill(); g.restore();
    fit(g, T.지역, 170, S - 265, 200, 46, F, darkPanel({ 판: P.강조 }) ? "#ffffff" : "#111111");
    fit(g, T.전화, 60, S - 170, 620, 110, F, "#ffffff", "left");
    T.칩.forEach((t, i) => { g.save(); g.shadowColor = "rgba(0,0,0,.8)"; g.shadowBlur = 10; fit(g, "· " + t, S - 60, S - 380 + i * 70, 320, 46, F, "#ffffff", "right"); g.restore(); });
  },
  "티켓"(g, bg, T, P, F) {
    g.fillStyle = P.강조; g.fillRect(0, 0, S, S);
    for (let i = 0; i < 40; i++) { g.fillStyle = shade("#ffffff", 0.06); g.beginPath(); g.arc((i * 137) % S, (i * 211) % S, 30 + (i % 5) * 10, 0, Math.PI * 2); g.fill(); }
    const x = 60, y = 250, w = S - 120, h = 580, notch = 36;
    g.save(); g.shadowColor = "rgba(0,0,0,.3)"; g.shadowBlur = 30;
    g.beginPath(); g.moveTo(x + 20, y); g.lineTo(x + w - 20, y); g.arcTo(x + w, y, x + w, y + 20, 20); g.lineTo(x + w, y + h / 2 - notch); g.arc(x + w, y + h / 2, notch, -Math.PI / 2, Math.PI / 2, true);
    g.lineTo(x + w, y + h - 20); g.arcTo(x + w, y + h, x + w - 20, y + h, 20); g.lineTo(x + 20, y + h); g.arcTo(x, y + h, x, y + h - 20, 20); g.lineTo(x, y + h / 2 + notch); g.arc(x, y + h / 2, notch, Math.PI / 2, -Math.PI / 2, true); g.lineTo(x, y + 20); g.arcTo(x, y, x + 20, y, 20); g.closePath();
    g.fillStyle = P.판; g.fill(); g.restore();
    g.save(); rr(g, x + 30, y + 30, 420, h - 60, 16); g.clip(); cover(g, bg, x + 30, y + 30, 420, h - 60); g.restore();
    g.setLineDash([14, 12]); g.strokeStyle = P.강조; g.lineWidth = 4; g.beginPath(); g.moveTo(x + 480, y + 30); g.lineTo(x + 480, y + h - 30); g.stroke(); g.setLineDash([]);
    const tx = x + 510, tw = w - 540;
    fit(g, "TICKET", tx, y + 70, tw, 34, F, P.강조, "left");
    cornerText(g, T, P, F, tx, y + 150, tw, P.글);
    T.칩.slice(0, 4).forEach((t, i) => fit(g, "✓ " + t, tx + (i % 2) * (tw / 2), y + 430 + Math.floor(i / 2) * 60, tw / 2 - 10, 36, F, P.글, "left"));
    fit(g, T.윗줄, S / 2, 150, S - 160, 56, F, darkPanel({ 판: P.강조 }) ? "#ffffff" : "#111111");
    chipsPill(g, T.칩, S / 2, S - 150, 80, { ...P, 칩: P.판, 칩글: P.글 }, F, S - 140);
  },
  "네온"(g, bg, T, P, F) {
    g.save(); g.filter = "brightness(.35) saturate(.8)"; cover(g, bg, 0, 0, S, S); g.restore();
    const glow = (t, x, y, w, size, color) => { g.save(); g.shadowColor = color; g.shadowBlur = 30; fit(g, t, x, y, w, size, F, color); g.shadowBlur = 12; fit(g, t, x, y, w, size, F, "#ffffff"); g.restore(); };
    const neon = darkPanel(P) ? P.강조 : P.강조;
    g.save(); g.strokeStyle = neon; g.shadowColor = neon; g.shadowBlur = 25; g.lineWidth = 6; rr(g, 90, 150, S - 180, 640, 40); g.stroke(); g.restore();
    fit(g, T.윗줄, S / 2, 230, S - 260, 42, F, "#ffffff");
    glow(T.지역, S / 2, 350, S - 260, 100, neon);
    glow(T.이름, S / 2, 490, S - 240, 120, neon);
    glow(T.전화, S / 2, 640, S - 300, 110, neon);
    T.칩.forEach((t, i) => {
      const w = 220, x = S / 2 - (4 * w + 3 * 20) / 2 + i * (w + 20), y = 860;
      g.save(); g.strokeStyle = neon; g.shadowColor = neon; g.shadowBlur = 16; g.lineWidth = 4; rr(g, x, y, w, 90, 45); g.stroke(); g.restore();
      icon(g, iconFor(t), x + 45, y + 45, 44, "#ffffff"); fit(g, t, x + 80, y + 46, w - 95, 38, F, "#ffffff", "left");
    });
  },
  "말풍선"(g, bg, T, P, F) {
    cover(g, bg, 0, 0, S, S);
    g.save(); g.shadowColor = "rgba(0,0,0,.3)"; g.shadowBlur = 24; g.fillStyle = P.판;
    rr(g, 70, 70, S - 140, 330, 60); g.fill();
    g.beginPath(); g.moveTo(230, 395); g.lineTo(200, 480); g.lineTo(330, 395); g.closePath(); g.fill(); g.restore();
    fit(g, `“${T.윗줄}”`, S / 2, 170, S - 220, 58, F, P.강조);
    fit(g, `${T.지역} ${T.이름}`, S / 2, 285, S - 220, 86, F, P.이름색);
    g.save(); g.fillStyle = P.칩; rr(g, S - 560, S - 330, 490, 120, 60); g.fill(); g.restore();
    fit(g, T.전화, S - 315, S - 268, 440, 84, F, P.칩글);
    chipsPill(g, T.칩, S / 2, S - 160, 82, P, F, S - 140);
  },
});

/* 디자인 방식 — 사진 처리(배경에 먼저) · 장식(맨 끝에 위로) */
function treatBg(bg, how, P) {
  if (!how || how === "기본") return bg;
  const c = document.createElement("canvas"); c.width = bg.width; c.height = bg.height;
  const g = c.getContext("2d");
  g.filter = how === "따뜻하게" ? "sepia(.25) saturate(1.15) brightness(1.03)" : how === "선명하게" ? "contrast(1.12) saturate(1.25)" : "grayscale(1) contrast(1.05)";
  g.drawImage(bg, 0, 0); g.filter = "none";
  if (how === "한 색 톤") { g.globalCompositeOperation = "soft-light"; g.globalAlpha = 0.75; g.fillStyle = P.강조; g.fillRect(0, 0, c.width, c.height); }
  return c;
}
function decorate(g, how, P) {
  if (!how || how === "없음") return;
  g.save(); g.strokeStyle = P.강조; g.fillStyle = P.강조; g.lineCap = "round";
  if (how === "모서리 꺾쇠") { g.lineWidth = 10; for (const [x, y, dx, dy] of [[28, 28, 1, 1], [S - 28, 28, -1, 1], [28, S - 28, 1, -1], [S - 28, S - 28, -1, -1]]) { g.beginPath(); g.moveTo(x, y + dy * 70); g.lineTo(x, y); g.lineTo(x + dx * 70, y); g.stroke(); } }
  if (how === "점 무늬") { g.globalAlpha = 0.85; for (let i = 0; i < 5; i++) for (let j = 0; j < 5; j++) { g.beginPath(); g.arc(S - 150 + i * 26, 40 + j * 26, 5, 0, Math.PI * 2); g.fill(); g.beginPath(); g.arc(46 + i * 26, S - 150 + j * 26, 5, 0, Math.PI * 2); g.fill(); } }
  if (how === "물결 줄") { g.lineWidth = 7; for (const y0 of [22, S - 22]) { g.beginPath(); for (let x = 0; x <= S; x += 8) { const y = y0 + Math.sin(x / 26) * 8; x ? g.lineTo(x, y) : g.moveTo(x, y); } g.stroke(); } }
  g.restore();
}

/** @returns {Promise<Blob>} 1080×1080 JPEG */
export async function renderThumb({ 틀, 색, 글꼴, 처리, 장식 }, text, bg) {
  await loadFonts();
  const cv = document.createElement("canvas"); cv.width = S; cv.height = S;
  const g = cv.getContext("2d"); g.imageSmoothingQuality = "high";
  const P = PAL[색] || PAL.숲;
  (LAYOUT[틀] || LAYOUT["아치 카드"])(g, treatBg(bg, 처리, P), { ...text, 칩: (text.칩 || []).slice(0, 4) }, P, 글꼴);
  decorate(g, 장식, P);
  return new Promise((r) => cv.toBlob(r, "image/jpeg", 0.9));
}
