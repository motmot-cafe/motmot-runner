#!/usr/bin/env node
/* 모토모토 사진정리 — 사장님 PC 에서 도는 작은 프로그램(브라우저 화면).
     node main.mjs [zip 또는 폴더 경로] [--port 5178] [--no-open]
   윈도우에서는 `사진정리.cmd` 를 두 번 누르거나, zip 을 그 위에 끌어다 놓는다.

   하는 일: ① zip(또는 폴더)을 읽는다(20GB 도 통째로 풀지 않는다) ② 브라우저가 썸네일 · 웹용 사본(1600px · 400KB) · 비슷함 지문을 만든다
            ③ Claude(이 PC 의 Claude Code 구독)가 사진을 보고 공간 · 카테고리 · 설명을 붙인다 ④ 사장님이 확인 화면에서 고친다
            ⑤ 「폴더로 정리」 — 카테고리/공간 폴더 · 영문 파일 이름 · 공간목록.json · 목록.csv
   ★ 이 컴퓨터(127.0.0.1)에서만 열린다. 사진은 밖으로 나가지 않는다 — Claude 에게 보이는 썸네일만 Claude Code 를 거친다.
   ★ 외부 의존성 0 (DEPENDENCY_POLICY) — node 만 있으면 된다.
*/
import http from "node:http";
import { readFileSync, existsSync, statSync, createReadStream, createWriteStream, mkdirSync, writeFileSync, appendFileSync, rmSync } from "node:fs";
import { join, dirname, resolve, extname, relative, isAbsolute } from "node:path";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";
import { homedir } from "node:os";
import { Job, jobDirFor } from "./lib/job.mjs";
import { SPACES, CATEGORIES, GROUPS } from "./lib/spaces.mjs";
import { classifyJob, findClaude } from "./lib/classify.mjs";
import { writeZip } from "./lib/zip.mjs";
import { readUsage, readRecords } from "./lib/usage.mjs";
import { writeProgress } from "./lib/progress.mjs";
import { openAppWindow } from "./lib/appwin.mjs";
import { Memory } from "./lib/memory.mjs";
import { syncShare, shareKeyOf, readMyBoxConf, nameSize } from "./lib/mybox.mjs";
import { checkUpdate, applyUpdate, versionOf, hasUpdater } from "./lib/update.mjs";
import { planThumbs, addThumb, thumbPath, thumbNeeds, textFor, DEFAULT_TEXT } from "./lib/thumbs.mjs";

const HERE = dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const flag = (n) => args.includes(n);
const opt = (n, d) => { const i = args.indexOf(n); return i >= 0 ? args[i + 1] : d; };
const firstPath = args.find((a, i) => !a.startsWith("--") && !(i > 0 && ["--port"].includes(args[i - 1])));
const PORT0 = Number(opt("--port", process.env.MOTMOT_PHOTO_PORT || 5178));

const CONF_DIR = join(process.env.APPDATA || join(homedir(), ".config"), "모토모토-사진정리");
const RECENT = join(CONF_DIR, "최근.json");
const AUTO_FILE = join(CONF_DIR, "자동정리.json");
const recent = () => { try { return JSON.parse(readFileSync(RECENT, "utf8")); } catch { return []; } };
const remember = (p) => { mkdirSync(CONF_DIR, { recursive: true }); writeFileSync(RECENT, JSON.stringify([p, ...recent().filter((x) => x !== p)].slice(0, 8))); };

let job = null;
const task = { 이름: "", 진행: 0, 전체: 0, 말: "", 돌아감: false, 멈춰: false, 끝말: "" };

/* ── 원고기와 함께(블로그 원고기 판 2026.10.02-4 · 사장님 2026-10-02 「사진정리 프로그램이랑 블로그 원고프로그램이 통합운영 되었으면 좋겠음」 ·
      「폴더링 되어있으니까, 그거 알아서 새로 업로드 된 사진들 찾아서 추가 폴더링 작업하고」) ──
   MOTMOT_PHOTO_EMBED=1 — 원고기가 창 없이(--no-open) 함께 켠 것: 바탕화면 아이콘을 안 만든다 · 이미 켜진 사진정리가 있으면 조용히 끝낸다 ·
   마지막에 연 폴더를 저절로 연다 · MOTMOT_PARENT_PID(원고기)가 꺼지면 함께 끈다 · 「새 사진 자동 정리」 기본 켜짐.
   새 사진 자동 정리(AUTO) — 몇 분마다 원본 폴더를 다시 읽어(Job.rescan) 새 사진을 더하고 → 준비(화면이 열려 있을 때 — 원고기 창이 품고 있다)
   → 분류(classifyJob · 남은 것만) → 한 번이라도 「폴더로 정리」 를 했으면 다시 정리(번호는 그대로 · 새 사진은 뒤에). */
const EMBED = process.env.MOTMOT_PHOTO_EMBED === "1";
const AUTO_MS = Number(process.env.MOTMOT_PHOTO_AUTO_MS) || 2 * 60 * 1000;
const SETTLE_MS = process.env.MOTMOT_PHOTO_SETTLE_MS != null ? Number(process.env.MOTMOT_PHOTO_SETTLE_MS) : 60 * 1000;

/* 정리 폴더를 만들 곳 — 원본마다 기억한다(다시 열면 같은 곳 · 상태가 그 안 _작업 에 있다) */
const OUTS = join(CONF_DIR, "정리위치.json");
const outs = () => { try { return JSON.parse(readFileSync(OUTS, "utf8")); } catch { return {}; } };
const clean = (p) => String(p || "").trim().replace(/^"|"$/g, "");

/* 분류 기억(lib/memory.mjs) — 예전에 분류한 같은 파일은 다시 Claude 에게 보이지 않는다(사장님 2026-10-02 「중복되니까」).
   열 때 · 분류 시작 때 가져오고, 분류 · 고치기 뒤에 적는다 */
let memory = null;
const classMem = () => (memory ||= new Memory(join(CONF_DIR, "분류기억.json")));
function recallMemory() { try { const n = job ? job.recall(classMem()) : 0; if (n) usageMsg = `예전에 분류한 같은 사진 ${n}장은 다시 분류하지 않고 기록에서 가져왔습니다`; return n; } catch (e) { logError("분류 기억 읽기", e); return 0; } }
function saveMemory() { try { if (job) classMem().syncFrom(job); } catch (e) { logError("분류 기억 적기", e); } }

function openJob(p, out) {
  const path = resolve(clean(p));
  if (!clean(p)) throw new Error("zip 파일이나 폴더 경로를 넣어 주세요(「찾아보기」 로 골라도 됩니다)");
  if (!existsSync(path)) throw new Error(`그 자리에 파일이 없습니다: ${path}`);
  // 경로가 비었거나 프로그램 폴더를 가리키면 열지 않는다 — 빈 칸으로 「열기」 를 눌러 프로그램 폴더(로고 1장)가 열렸다(사장님 화면 2026-09-30)
  { const r = relative(path, HERE); if (r === "" || (!r.startsWith("..") && !isAbsolute(r))) throw new Error("사진정리 프로그램이 든 폴더는 열 수 없습니다 — 사진이 든 폴더를 골라 주세요(「폴더 찾아보기」)"); }
  if (!statSync(path).isDirectory() && !/\.zip$/i.test(path)) throw new Error("zip 파일이나 폴더를 골라 주세요");
  if (task.돌아감) throw new Error("다른 일이 도는 중입니다 — 끝나거나 멈춘 뒤에 여세요");
  let outRoot = clean(out) ? resolve(clean(out)) : (outs()[path] || "");
  if (outRoot) {
    if (!existsSync(outRoot) || !statSync(outRoot).isDirectory()) throw new Error(`정리 폴더를 만들 곳이 없습니다: ${outRoot}`);
    const rel = relative(path, outRoot);
    if (statSync(path).isDirectory() && (rel === "" || (!rel.startsWith("..") && !isAbsolute(rel)))) {
      throw new Error("정리 폴더를 원본 폴더 안에 만들 수는 없습니다 — 바깥 자리를 골라 주세요");
    }
    mkdirSync(CONF_DIR, { recursive: true });
    writeFileSync(OUTS, JSON.stringify({ ...outs(), [path]: outRoot }, null, 1));
  }
  job = new Job(path, { outRoot });
  remember(path);
  recallMemory();
  syncUsage();
  return job;
}

/**
 * 원고기에서 쓴 사진 챙기기 — 열 때 · 1분마다. 새로 묶인 사진이 있고 이미 한 번 정리했으면 **저절로 다시 정리**해서
 * `사용한 원고사진/<원고>/` 로 옮긴다(이미 푼 파일은 옮기기만 해서 빠르다). 다른 일이 돌거나 웹용을 그리는 중이면 다음 번에.
 */
let usageMsg = "";
function syncUsage() {
  if (!job || task.돌아감) return;
  if (reorganize && !job.pendingWeb()) { reorganize = false; afterMsChange(); return; }
  let n = 0;
  let m = 0;
  try { n = job.applyUsage(readUsage()); m = job.pickFromRecords(readRecords()); } catch (e) { usageMsg = `원고기 기록을 못 읽었습니다: ${e.message}`; return; }
  if (!n && !m) return;
  usageMsg = [n ? `원고기에서 쓴 사진 ${n}장을 「원고에 씀」 으로 묶었습니다` : "", m ? `새 원고 ${m}편에 맞는 사진을 골랐습니다` : ""].filter(Boolean).join(" · ");
  if (job.state.정리한때 && !job.pendingWeb()) {
    runTask("원고에 쓴 사진 옮기기", (prog) => job.organize(prog).then((r) => `${usageMsg} · 「사용한 원고사진」 으로 옮김(정리 ${r.장수}장)`));
  }
}
setInterval(syncUsage, 60 * 1000).unref();

/* 네이버 MYBOX 공유 링크에서 받기(lib/mybox.mjs) — 받는 곳(사진 폴더)에 새 파일만 받고, 그 폴더를 사진정리 출처로 열어
   새 사진 자동 정리(준비 → 분류 → 정리 폴더)가 이어서 한다. 「10분마다」 를 켜 두면 새로 올라온 것만 계속 받는다. */
const MYBOX_FILE = join(CONF_DIR, "MYBOX.json");
const myboxConf = () => ({ 받는곳: join(homedir(), "Desktop", "MYBOX 받은 사진"), ...readMyBoxConf(MYBOX_FILE) });
const saveMyBox = (c) => { mkdirSync(CONF_DIR, { recursive: true }); writeFileSync(MYBOX_FILE, JSON.stringify(c, null, 1)); };
let myboxAt = 0;
/** PC 에 이미 있는 사진 — 지금 연 작업 + 최근에 연 작업들의 상태 파일(이름+크기 · 내용 열쇠) + 분류 기억의 열쇠.
    MYBOX 에서 같은 사진을 또 받지 않게(사장님 2026-10-06 「이미 pc 내에 있던 사진들은 제외」) */
function knownPhotos() {
  const names = new Set(), keys = new Set();
  const add = (list) => { for (const p of list || []) { if (!p || p.종류 === "기타") continue; if (p.rel && p.size) names.add(nameSize(p.rel.split("/").pop(), p.size)); if (p.key && !String(p.key).startsWith("x:")) keys.add(p.key); } };
  if (job) add(job.photos);
  for (const src of recent()) {
    try { const sp = join(jobDirFor(src, outs()[src] || ""), "_작업", "상태.json"); if (existsSync(sp)) add(JSON.parse(readFileSync(sp, "utf8")).사진); } catch { /* 깨진 상태 파일은 건너뜀 */ }
  }
  try { for (const k of Object.keys(classMem().map)) if (!k.startsWith("d:")) keys.add(k); } catch {}
  return { names, keys };
}
function runMyBox() {
  const c = myboxConf();
  if (!c.링크) throw new Error("MYBOX 공유 링크를 먼저 넣어 주세요");
  myboxAt = Date.now();
  const ledger = c.받은목록 || {};
  runTask("MYBOX 에서 받기", (prog) => syncShare(c.링크, c.받는곳, { onProgress: prog, shouldStop: () => task.멈춰, ledger, known: knownPhotos() }).then((r) => {
    saveMyBox({ ...myboxConf(), 받은목록: r.ledger, 마지막: { 때: new Date().toISOString(), 이름: r.이름, 전체: r.전체, 받음: r.받음, 중복: r.중복, 실패: r.실패 } });
    runLog(`MYBOX 받기 — 「${r.이름}」 ${r.전체}개 중 새로 ${r.받음}개${r.실패 ? ` · 실패 ${r.실패}` : ""}`);
    if (r.실패들.length) logError("MYBOX 받기 실패", r.실패들.join("\n"));
    /* 받는 곳을 사진정리 출처로 — 이미 열려 있으면 자동 정리가 새 파일을 찾아 이어 간다 */
    try { writeFileSync(AUTO_FILE, JSON.stringify({ 켜짐: true })); } catch {}
    setTimeout(() => {
      try { if (!job || resolve(job.srcPath) !== resolve(c.받는곳)) openJob(c.받는곳); else autoTick(); } catch (e) { usageMsg = `MYBOX 로 받은 폴더를 못 열었습니다: ${e.message}`; }
    }, 0);
    return `MYBOX 「${r.이름}」 — 모두 ${r.전체}개 · 새로 받음 ${r.받음}개 · 이미 받음 ${r.있음}개${r.중복 ? ` · PC 에 이미 있어 건너뜀 ${r.중복}개` : ""}${r.실패 ? ` · 실패 ${r.실패}개(오류기록.txt)` : ""} → 받은 사진은 저절로 준비 · 분류 · 정리됩니다(이 창을 열어 두세요)`;
  }));
}
/* 프로그램 안 업데이트(lib/update.mjs) — 켤 때 · 6시간마다 새 판을 보고, 사장님이 「업데이트」 를 누르면 받아서 다시 켠다.
   원고기와 함께(EMBED)면 원고기 업데이트가 사진정리까지 바꾸므로 안 한다 */
let update = { 지금: versionOf(HERE), 있음: false };
async function checkForUpdate() {
  if (EMBED || process.env.MOTMOT_PHOTO_NO_UPDATE === "1") return;
  try { update = { ...(await checkUpdate(HERE)), 본때: new Date().toISOString() }; } catch (e) { update = { ...update, 말: e.message }; }
}
setTimeout(checkForUpdate, 5000).unref();
setInterval(checkForUpdate, 6 * 60 * 60 * 1000).unref();

setInterval(() => {
  const c = myboxConf();
  if (c.켜짐 && c.링크 && !task.돌아감 && Date.now() - myboxAt > 10 * 60 * 1000) { try { runMyBox(); } catch { /* 다음 번에 */ } }
}, 60 * 1000).unref();

/* 새 사진 자동 정리 — 켜고 끄기는 화면 스위치(자동정리.json · 원고기와 함께면 처음 켜짐) */
const autoOn = () => { try { return JSON.parse(readFileSync(AUTO_FILE, "utf8")).켜짐 === true; } catch { return EMBED; } };
const auto = { 말: "", 새: 0, 마지막: "", 쉼까지: 0, 정리할것: false };
function autoTick() {
  if (!autoOn() || !job || task.돌아감) return;
  let r = { 새: 0, 사라짐: 0, 기다림: 0 };
  try { r = job.rescan({ settleMs: SETTLE_MS }); } catch (e) { auto.말 = `새 사진 찾기 실패: ${e.message}`; return; }
  auto.마지막 = new Date().toISOString();
  if (r.새) { auto.새 += r.새; auto.정리할것 = true; runLog(`새 사진 ${r.새}장 찾음(자동)`); }
  if (r.사라짐) auto.정리할것 = true;
  const 준비 = job.pendingPrep();
  if (준비) { auto.말 = `새 사진 ${준비}장 준비 중 — 원고기(또는 사진정리) 창이 열려 있어야 준비됩니다`; return; }
  if (job.pendingClassify() && Date.now() >= auto.쉼까지) {
    auto.말 = `새 사진 ${job.pendingClassify()}장 분류 중(자동)`;
    try {
      runTask("Claude 로 분류(새 사진 자동)", (prog) => classifyJob(job, { model: job.state.설정.모델, redo: false, onProgress: prog, shouldStop: () => task.멈춰, memory: classMem() }).then((x) => {
        if (/한도|로그인|찾지 못|못 찾/.test(String(x?.msg || ""))) auto.쉼까지 = Date.now() + 30 * 60 * 1000;   // 한도 · 로그인이면 30분 쉰다(되풀이 안 하게)
        auto.정리할것 = true;
        return x.msg;
      }));
    } catch { /* 다른 일이 돈다 — 다음 번에 */ }
    return;
  }
  if (auto.정리할것 && job.state.정리한때 && !job.pendingWeb()) {
    auto.정리할것 = false;
    auto.말 = "새 사진을 폴더로 정리 중(자동)";
    try { runTask("폴더로 정리(새 사진 자동)", (prog) => job.organize(prog).then((x) => { auto.새 = 0; auto.말 = `새 사진까지 폴더로 정리했습니다 — ${x.장수}장`; return auto.말; })); } catch { auto.정리할것 = true; }
    return;
  }
  if (!auto.정리할것) auto.말 = auto.새 ? auto.말 : "새 사진 없음";
}
setInterval(() => { try { autoTick(); } catch (e) { logError("autoTick", e); } }, AUTO_MS).unref();

/* 원고기와 함께 — 원고기(MOTMOT_PARENT_PID)가 꺼지면(갑자기 꺼져도) 함께 끈다 */
const PARENT = Number(process.env.MOTMOT_PARENT_PID) || 0;
if (PARENT) setInterval(() => { try { process.kill(PARENT, 0); } catch { quit("원고기가 꺼져 함께 끔"); } }, 10000).unref();

/* 진행상황 파일(lib/progress.mjs) — 콘텐츠 업로드 자동화 세션이 읽는다. 5초마다 · 끌 때 「켜짐: false」 */
let 주소 = "";
const progress = (켜짐 = true) => { try { writeProgress(CONF_DIR, job, task, { 켜짐, 주소 }); } catch { /* 적기 실패는 프로그램을 멈추지 않는다 */ } };
setInterval(progress, 5000).unref();
/* 실행 기록 — 켜고 끈 때 · 이유 · 메모리를 `실행기록.txt` 에 남긴다(사장님 「다시 꺼지는데?」 2026-09-30 — 원인을 파일로 보려고).
   켜져 있는 동안 30초마다 `켜짐.json` 에 숨결(시각 · 메모리)을 적고, 제대로 끌 때 지운다 → 다음에 켤 때 그 파일이 남아 있으면 「지난번에 갑자기 꺼짐」. */
const RUNLOG = join(CONF_DIR, "실행기록.txt"), BEAT = join(CONF_DIR, "켜짐.json");
const mb = (n) => Math.round(n / 1048576);
const mem = () => { const m = process.memoryUsage(); return `메모리 ${mb(m.rss)}MB(힙 ${mb(m.heapUsed)}MB)`; };
function runLog(msg) {
  try {
    mkdirSync(CONF_DIR, { recursive: true });
    if (existsSync(RUNLOG) && statSync(RUNLOG).size > 1024 * 1024) writeFileSync(RUNLOG, readFileSync(RUNLOG, "utf8").slice(-256 * 1024));
    appendFileSync(RUNLOG, `[${new Date().toLocaleString("ko-KR")}] ${msg}\n`);
  } catch { /* 기록 실패는 무시 */ }
}
let lastCrash = "", owner = false;
/** 이 실행이 서버 자리를 잡은 뒤에만 부른다 — 이미 켜진 것에 창만 띄우러 온 실행이 남의 숨결 파일을 건드리지 않게 */
function startBeat() {
  owner = true;
  try {
    if (existsSync(BEAT)) {
      const b = JSON.parse(readFileSync(BEAT, "utf8"));
      lastCrash = `지난번에 프로그램이 갑자기 꺼졌습니다(마지막 기록 ${b.때} · ${b.메모리}${b.일 ? ` · 하던 일: ${b.일}` : ""})${flag("--restarted") ? " — 자동으로 다시 켰습니다" : ""}. 되풀이되면 %APPDATA%\\모토모토-사진정리\\실행기록.txt 를 보내 주세요`;
      runLog(`⚠ 지난번 비정상 종료 — 마지막 숨결 ${b.때} · ${b.메모리} · 일 ${b.일 || "없음"}`);
    }
  } catch { /* 깨진 숨결 파일은 무시 */ }
  runLog(`켜짐 — node ${process.version} · pid ${process.pid}${flag("--restarted") ? " · 자동 재시작" : ""}`);
  beat(); setInterval(beat, 30000).unref();
}
const beat = () => { try { writeFileSync(BEAT, JSON.stringify({ 때: new Date().toLocaleString("ko-KR"), 메모리: mem(), 일: task.돌아감 ? task.이름 : "" })); } catch {} };
/** 끄는 곳은 모두 여기로 — 이유를 남기고 숨결 파일을 지운다(= 제대로 끔) */
function quit(reason, code = 0) {
  if (!owner) process.exit(code);
  runLog(`꺼짐 — ${reason} · ${mem()}`);
  try { rmSync(BEAT, { force: true }); } catch {}
  progress(false); process.exit(code);
}
process.on("exit", (code) => { if (owner && existsSync(BEAT)) runLog(`꺼짐 — 이유 모름(코드 ${code}) · ${mem()}`); });
for (const sig of ["SIGINT", "SIGTERM", "SIGBREAK", "SIGHUP"]) process.on(sig, () => quit(`신호 ${sig}`));

/* 예기치 않은 오류로 프로그램이 조용히 꺼지지 않게 — 콘솔 없이 도니(photo-sorter.vbs) 오류는 파일에 남기고 계속 돈다.
   사장님 2026-09-30 「왜 나가지지?」 */
function logError(kind, e) {
  try { mkdirSync(CONF_DIR, { recursive: true }); appendFileSync(join(CONF_DIR, "오류기록.txt"), `[${new Date().toISOString()}] ${kind}: ${e?.stack || e}\n`); } catch { /* 기록 실패는 무시 */ }
  runLog(`오류(계속 돎) ${kind}: ${String(e?.message || e).slice(0, 200)}`);
}
process.on("uncaughtException", (e) => logError("uncaughtException", e));
process.on("unhandledRejection", (e) => logError("unhandledRejection", e));

/* 창이 살아 있나 — 브라우저 프로세스가 끝났다고 곧장 끄지 않는다(엣지는 업데이트 · 창 넘기기로 처음 프로세스가 먼저 끝나기도 한다).
   화면이 3분 넘게 아무 요청도 안 했고 도는 일도 없을 때만 끈다. 화면은 15초마다 /api/alive 를 부른다. */
let lastHit = Date.now();
const IDLE_EXIT_MS = 3 * 60 * 1000;
function exitWhenIdle() {
  const t = setInterval(() => {
    if (Date.now() - lastHit < IDLE_EXIT_MS || task.돌아감) return;
    clearInterval(t); quit("창이 닫히고 3분 동안 화면 요청 없음");
  }, 15000);
}

function runTask(name, fn) {
  if (task.돌아감) throw new Error(`「${task.이름}」 이(가) 도는 중입니다`);
  Object.assign(task, { 이름: name, 진행: 0, 전체: 0, 말: "시작", 돌아감: true, 멈춰: false, 끝말: "" });
  fn((d, t, m) => Object.assign(task, { 진행: d, 전체: t, 말: m }))
    .then((r) => { task.끝말 = r; })
    .catch((e) => { task.끝말 = `실패: ${e.message}`; })
    .finally(() => { task.돌아감 = false; progress(); });
}

const TYPES = { html: "text/html; charset=utf-8", mjs: "text/javascript; charset=utf-8", js: "text/javascript; charset=utf-8", css: "text/css; charset=utf-8", json: "application/json; charset=utf-8",
  jpg: "image/jpeg", jpeg: "image/jpeg", png: "image/png", webp: "image/webp", gif: "image/gif", bmp: "image/bmp", heic: "image/heic", heif: "image/heif", tif: "image/tiff", tiff: "image/tiff",
  mp4: "video/mp4", m4v: "video/mp4", mov: "video/quicktime", webm: "video/webm", avi: "video/x-msvideo", mkv: "video/x-matroska", "3gp": "video/3gpp", wmv: "video/x-ms-wmv" };

const send = (res, code, body, type = "application/json; charset=utf-8") => {
  res.writeHead(code, { "content-type": type, "cache-control": "no-store" });
  res.end(typeof body === "string" || Buffer.isBuffer(body) ? body : JSON.stringify(body));
};
const readBody = (req, limit = 20 * 1024 * 1024) => new Promise((ok, no) => {
  const parts = []; let n = 0;
  req.on("data", (b) => { n += b.length; if (n > limit) { no(new Error("너무 큽니다")); req.destroy(); } else parts.push(b); });
  req.on("end", () => ok(Buffer.concat(parts)));
  req.on("error", no);
});
const json = async (req) => { const b = await readBody(req); return b.length ? JSON.parse(b.toString("utf8")) : {}; };

function stateView() {
  if (!job) return { 작업: null, 최근: recent(), 공간: SPACES, 묶음: GROUPS, 카테고리: CATEGORIES, 일: task, claude: findClaude() };
  job.ensureSimilar();
  const photos = job.photos.map((p) => ({ 자리: p.종류 === "기타" || p.중복of ? "" : job.status(p), 재탕: (job.groupUses(p) || []).length, 재구성차이: p.재구성차이, id: p.id, rel: p.rel, 종류: p.종류, ext: p.ext, size: p.size, w: p.w, h: p.h, 찍은날: p.찍은날, gps: p.gps, 실패: p.실패,
    준비: !!p.준비, 웹다시: !!p.웹다시, 가공: p.가공 || null, spec: job.drawSpec(p), 사용: p.사용 || null, 사용기록: p.사용기록 || [], 글자: !!p.글자, 품질: p.품질, 품질이유: p.품질이유, 제외이유: p.제외이유, 중복of: p.중복of, 비슷: p.비슷, 공간: p.공간, 카테고리: p.카테고리, 설명: p.설명, 태그: p.태그, 본사람: p.본사람, 확신: p.확신, 사람: p.사람, 홈페이지감: p.홈페이지감, 제외: p.제외 }));
  return { 정리위치들: outs(), 작업: { 곳: job.srcPath, 종류: job.src.kind, 폴더: job.dir, 설정: job.state.설정, 정리한때: job.state.정리한때, 셈: job.summary(), 사용량: job.state.사용량 || null,
      썸네일: job.state.썸네일 || [], 썸네일모자람: thumbNeeds(job), 썸네일문구: Object.fromEntries(Object.keys(DEFAULT_TEXT).map((c) => [c, textFor(job, c)])), 원고들: job.state.원고들 || {} },
    사진: photos, 최근: recent(), 공간: SPACES, 묶음: GROUPS, 카테고리: CATEGORIES, 일: task, claude: findClaude() };
}

function streamOriginal(req, res, p) {
  const type = TYPES[p.ext] || "application/octet-stream";
  const m = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range || "");
  if (m && job.src.canRange(p.rel)) {
    const start = m[1] ? Number(m[1]) : Math.max(0, p.size - Number(m[2]));
    const end = m[1] && m[2] ? Math.min(Number(m[2]), p.size - 1) : p.size - 1;
    res.writeHead(206, { "content-type": type, "content-range": `bytes ${start}-${end}/${p.size}`, "content-length": end - start + 1, "accept-ranges": "bytes" });
    job.src.read(p.rel, { start, end }).on("error", () => res.destroy()).pipe(res);
    return;
  }
  res.writeHead(200, { "content-type": type, "content-length": p.size, "accept-ranges": job.src.canRange(p.rel) ? "bytes" : "none" });
  job.src.read(p.rel).on("error", () => res.destroy()).pipe(res);
}

function openInExplorer(p) {
  const cmd = process.platform === "win32" ? "explorer.exe" : process.platform === "darwin" ? "open" : "xdg-open";
  try { spawn(cmd, [p], { detached: true, stdio: "ignore" }).on("error", () => {}).unref(); } catch {}
}

async function handle(req, res) {
  const url = new URL(req.url, "http://x");
  const path = decodeURIComponent(url.pathname);
  // 이 컴퓨터 안에서만 — 다른 사이트가 주소를 돌려 부르는 것(DNS rebinding)을 막는다
  if (!/^(127\.0\.0\.1|localhost)(:\d+)?$/.test(req.headers.host || "")) return send(res, 403, { 말: "이 컴퓨터에서만 열 수 있습니다" });
  /* 원고 대필 페이지(/write · motmot.co.kr)가 이 PC 의 사진정리에 원고 사진을 묻고 바꾼다 — /api/ms/* 만, 그 사이트에서 온 것만 열어 준다 */
  const isMs = path.startsWith("/api/ms/"), siteOk = isMs && SITE_ORIGINS.test(req.headers.origin || "");
  if (siteOk) {
    res.setHeader("access-control-allow-origin", req.headers.origin); res.setHeader("vary", "origin");
    if (req.method === "OPTIONS") {
      res.writeHead(204, { "access-control-allow-methods": "GET, POST", "access-control-allow-headers": "content-type", "access-control-allow-private-network": "true", "access-control-max-age": "600" });
      return res.end();
    }
  }
  if (req.method === "POST" && req.headers.origin && !siteOk && !/^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?$/.test(req.headers.origin)) return send(res, 403, { 말: "다른 곳에서 온 요청" });
  if (path !== "/api/ping") lastHit = Date.now(); // 화면이 살아 있다는 뜻(다른 실행의 ping 은 빼고)

  if (req.method === "GET" && (path === "/" || path === "/index.html")) return send(res, 200, readFileSync(join(HERE, "ui", "index.html")), TYPES.html);
  if (req.method === "GET" && path === "/vendor/libheif-bundle.mjs") { res.writeHead(200, { "content-type": TYPES.mjs, "cache-control": "max-age=86400" }); return createReadStream(join(HERE, "vendor", "libheif-bundle.mjs")).pipe(res); } // HEIC 해독기(D-094)
  if (req.method === "GET" && path === "/ui/thumbs.mjs") return send(res, 200, readFileSync(join(HERE, "ui", "thumbs.mjs")), TYPES.mjs);
  if (req.method === "GET" && /^\/vendor\/fonts\/[A-Za-z-]+\.(ttf|otf)$/.test(path)) { res.writeHead(200, { "content-type": path.endsWith("otf") ? "font/otf" : "font/ttf", "cache-control": "max-age=86400" }); return createReadStream(join(HERE, path)).pipe(res); } // 썸네일 · 워터마크 글꼴(OFL)
  if (req.method === "GET" && path === "/ui/logo.png") return send(res, 200, readFileSync(join(HERE, "ui", "logo.png")), "image/png"); // 워터마크 로고(assets/logo.png 사본)
  if (req.method === "GET" && /^\/lib\/(exif|spaces)\.mjs$/.test(path)) return send(res, 200, readFileSync(join(HERE, path)), TYPES.mjs);
  if (req.method === "POST" && path === "/api/alive") return send(res, 200, { ok: true });
  if (req.method === "GET" && path === "/api/ping") return send(res, 200, { 프로그램: "모토모토 사진정리" });
  if (req.method === "GET" && /^\/ui\/app\.(png|ico)$/.test(path)) return send(res, 200, readFileSync(join(HERE, path)), path.endsWith("png") ? "image/png" : "image/x-icon");
  if (req.method === "GET" && path === "/api/state") {
    if (url.searchParams.get("light")) return send(res, 200, { 알림: lastCrash, 일: task, 셈: job?.summary() || null, 원고기: usageMsg, 썸네일모자람: job ? thumbNeeds(job) : {},
      준비모자람: job ? job.pendingPrep() : 0, 자동: { 켜짐: autoOn(), 함께: EMBED, ...auto } });
    return send(res, 200, { ...stateView(), 자동: { 켜짐: autoOn(), 함께: EMBED, ...auto } });
  }
  if (req.method === "POST" && path === "/api/auto") {
    const b = await json(req);
    mkdirSync(CONF_DIR, { recursive: true });
    writeFileSync(AUTO_FILE, JSON.stringify({ 켜짐: b.켜짐 === true }));
    if (b.켜짐 === true) setTimeout(() => { try { autoTick(); } catch (e) { logError("autoTick", e); } }, 100);
    return send(res, 200, { ok: true, 켜짐: autoOn() });
  }
  if (req.method === "POST" && path === "/api/open") {
    const b = await json(req);
    try { openJob(b.경로, b.정리위치); } catch (e) { return send(res, 400, { 말: e.message }); }
    return send(res, 200, { ok: true, 정리폴더: job.dir });
  }
  /* 찾아보기 — 윈도우의 파일 · 폴더 고르기 창(PowerShell · 따로 설치 없음). 경로를 손으로 안 쳐도 되게 */
  /* 업데이트 — 보기 · 지금 다시 보기 · 받기(받은 뒤 코드 75 로 끝나면 photo-sorter.vbs 가 새 판으로 다시 켠다) */
  if (req.method === "GET" && path === "/api/update") { if (url.searchParams.get("check")) await checkForUpdate(); return send(res, 200, { ...update, 함께: EMBED }); }
  if (req.method === "POST" && path === "/api/update") {
    if (EMBED) return send(res, 400, { 말: "원고기와 함께 도는 사진정리는 원고기의 「업데이트」 로 바뀝니다" });
    if (!update.있음) return send(res, 400, { 말: "새 판이 없습니다" });
    if (!hasUpdater(HERE)) return send(res, 400, { 말: "이 폴더에는 다시 켜 주는 photo-sorter.vbs 가 없습니다 — zip 을 덮어써 주세요" });
    try {
      runTask("업데이트", (prog) => applyUpdate(HERE, update, { onProgress: prog }).then((n) => {
        runLog(`업데이트 — 판 ${update.지금} → ${update.판} (${n}개 파일)`);
        setTimeout(() => quit(`업데이트 — 판 ${update.판} 으로 다시 켭니다`, 75), 1500); // 0 이 아니면 지킴이가 다시 켠다
        return `판 ${update.판} 으로 바꿨습니다 — 잠시 뒤 다시 켜집니다`;
      }));
    } catch (e) { return send(res, 400, { 말: e.message }); }
    return send(res, 200, { ok: true });
  }
  /* MYBOX 받기 — 설정 저장 · 바로 한 번 받기 */
  if (req.method === "GET" && path === "/api/mybox") { const { 받은목록, ...c } = myboxConf(); return send(res, 200, { ...c, 받은수: Object.keys(받은목록 || {}).length }); }
  if (req.method === "POST" && path === "/api/mybox") {
    const b = await json(req), c = myboxConf();
    if (typeof b.링크 === "string") { if (b.링크.trim() && !shareKeyOf(b.링크)) return send(res, 400, { 말: "MYBOX 공유 링크가 아닙니다(mybox.naver.com/share/…?shareKey=…)" }); c.링크 = b.링크.trim(); }
    if (typeof b.받는곳 === "string" && b.받는곳.trim()) c.받는곳 = resolve(clean(b.받는곳));
    if (typeof b.켜짐 === "boolean") c.켜짐 = b.켜짐;
    saveMyBox(c);
    delete c.받은목록;
    if (b.받기) { try { runMyBox(); } catch (e) { return send(res, 400, { 말: e.message }); } }
    return send(res, 200, { ok: true, ...c });
  }
  if (req.method === "POST" && path === "/api/pick") {
    const b = await json(req);
    if (process.platform !== "win32") return send(res, 501, { 말: "찾아보기 창은 윈도우에서만 뜹니다 — 경로를 붙여 넣어 주세요" });
    const ps = b.종류 === "zip"
      ? `Add-Type -AssemblyName System.Windows.Forms; $d = New-Object System.Windows.Forms.OpenFileDialog; $d.Filter = 'zip (*.zip)|*.zip'; $d.Title = '사진 zip 고르기'; if ($d.ShowDialog((New-Object System.Windows.Forms.Form -Property @{TopMost=$true})) -eq 'OK') { $d.FileName }`
      : `Add-Type -AssemblyName System.Windows.Forms; $d = New-Object System.Windows.Forms.FolderBrowserDialog; $d.Description = '${b.종류 === "out" ? "정리 폴더를 만들 곳" : "사진 폴더"} 고르기'; $d.ShowNewFolderButton = $true; if ($d.ShowDialog((New-Object System.Windows.Forms.Form -Property @{TopMost=$true})) -eq 'OK') { $d.SelectedPath }`;
    const r = await new Promise((ok) => {
      const c = spawn("powershell.exe", ["-NoProfile", "-STA", "-Command", "[Console]::OutputEncoding=[Text.Encoding]::UTF8; " + ps], { windowsHide: true });
      const out = []; c.stdout.on("data", (x) => out.push(x)); c.on("error", () => ok("")); c.on("close", () => ok(Buffer.concat(out).toString("utf8").trim()));
    });
    return send(res, 200, { 경로: r });
  }

  if (!job) return send(res, 409, { 말: "먼저 zip 이나 폴더를 여세요" });
  let m;
  if (req.method === "GET" && (m = /^\/(f|t|w)\/(p\d+)$/.exec(path))) {
    const p = job.get(m[2]);
    if (!p) return send(res, 404, { 말: "없는 사진" });
    if (m[1] === "f") return streamOriginal(req, res, p);
    const fp = m[1] === "t" ? job.thumbPath(p.id) : job.webPath(p.id);
    if (!existsSync(fp)) return send(res, 404, { 말: "아직 없음" });
    res.writeHead(200, { "content-type": "image/jpeg", "cache-control": "no-cache" });
    return createReadStream(fp).pipe(res);
  }
  if (req.method === "POST" && (m = /^\/api\/(thumb|web|full)\/(p\d+)$/.exec(path))) {
    const p = job.get(m[2]);
    if (!p) return send(res, 404, { 말: "없는 사진" });
    const b = await readBody(req, m[1] === "full" ? 80 * 1024 * 1024 : 8 * 1024 * 1024);
    if (b[0] !== 0xff || b[1] !== 0xd8) return send(res, 400, { 말: "jpeg 가 아닙니다" });
    if (m[1] === "full") { writeFileSync(job.fullJpgPath(p.id), b); return send(res, 200, { ok: true }); } // HEIC → 원래 크기 JPG(정리 때 원본 자리에)
    writeFileSync(m[1] === "thumb" ? job.thumbPath(p.id) : job.webPath(p.id), b);
    if (m[1] === "web") job.setWebHash(p.id, url.searchParams.get("wh")); // 그린 웹용의 지문 — 재구성 때 견준다
    if (m[1] === "web" && url.searchParams.get("spec") === job.drawSpec(p)) job.webDone(p.id); // 그린 값(가공 · 워터마크)이 지금 값과 같을 때만 끝으로 친다
    return send(res, 200, { ok: true });
  }
  if (req.method === "POST" && (m = /^\/api\/info\/(p\d+)$/.exec(path))) { job.setInfo(m[1], await json(req)); return send(res, 200, { ok: true }); }
  if (req.method === "GET" && path === "/api/thumb-plan") {
    const cat = url.searchParams.get("cat");
    return send(res, 200, { 계획: planThumbs(job, cat, Math.min(20, Number(url.searchParams.get("n")) || 1)), 문구: textFor(job, cat) });
  }
  if (req.method === "POST" && path === "/api/thumb") {
    const meta = Object.fromEntries(["카테고리", "틀", "색", "글꼴", "배경", "윗줄", "칩", "처리", "장식"].map((k) => [k, url.searchParams.get(k)]));
    const b = await readBody(req, 8 * 1024 * 1024);
    try { return send(res, 200, { ok: true, 썸네일: addThumb(job, meta, b) }); } catch (e) { return send(res, 400, { 말: e.message }); }
  }
  if (req.method === "POST" && path === "/api/thumb-text") {
    const b = await json(req);
    job.state.썸네일문구 ||= {};
    job.state.썸네일문구[b.카테고리] = { ...textFor(job, b.카테고리), ...b.문구 }; // 윗줄들 · 칩묶음 · 지역 · 이름 · 전화
    job.save();
    return send(res, 200, { ok: true });
  }
  if (req.method === "GET" && (m = /^\/th\/(t\d+)$/.exec(path))) {
    const fp = thumbPath(job, m[1]);
    if (!existsSync(fp)) return send(res, 404, { 말: "없음" });
    res.writeHead(200, { "content-type": "image/jpeg" });
    return createReadStream(fp).pipe(res);
  }
  if (req.method === "POST" && path === "/api/edit") {
    const b = await json(req);
    try { job.edit(b.ids || [], b.patch || {}); } catch (e) { job.save(); return send(res, 400, { 말: e.message }); } // 재구성 거절 등 — 까닭을 화면에
    if (["공간", "카테고리", "설명", "태그"].some((k) => k in (b.patch || {}))) saveMemory(); // 사장님이 고친 분류도 기억(다음에 같은 파일을 만나면 이것으로)
    return send(res, 200, { ok: true });
  }
  if (req.method === "POST" && path === "/api/settings") {
    const b = await json(req);
    if (typeof b.모델 === "string") job.state.설정.모델 = b.모델;
    if (typeof b.앞머리 === "string") job.state.설정.앞머리 = b.앞머리;
    if (Number(b.재탕한도) >= 1) job.state.설정.재탕한도 = Math.min(10, Math.round(Number(b.재탕한도)));
    if (typeof b.원고자동고르기 === "boolean") job.state.설정.원고자동고르기 = b.원고자동고르기;
    if (typeof b.워터마크 === "boolean" || typeof b.워터마크글 === "string" || [2, 3].includes(b.워터마크줄)) job.setWatermark(b.워터마크, b.워터마크글, b.워터마크줄);
    job.save();
    return send(res, 200, { ok: true });
  }
  if (req.method === "POST" && path === "/api/import") { const n = job.importList(await json(req)); return send(res, 200, { ok: true, 맞춘장수: n }); }
  if (req.method === "POST" && path === "/api/classify") {
    const b = await json(req);
    runTask("Claude 로 분류", (prog) => classifyJob(job, { model: job.state.설정.모델, redo: !!b.다시, onProgress: prog, shouldStop: () => task.멈춰, memory: classMem() }).then((r) => r.msg));
    return send(res, 200, { ok: true });
  }
  if (req.method === "POST" && path === "/api/usage-sync") { syncUsage(); return send(res, 200, { ok: true, 말: usageMsg || "새로 묶을 사진이 없습니다" }); }
  if (req.method === "POST" && path === "/api/stop") { task.멈춰 = true; return send(res, 200, { ok: true }); }
  if (req.method === "POST" && path === "/api/organize") {
    const pending = job.pendingWeb();
    if (pending) return send(res, 409, { 말: `얼굴 가리기 등 가공을 다시 그리는 사진이 ${pending}장 남았습니다 — 화면을 열어 둔 채 잠시 뒤에 다시 누르세요` });
    runTask("폴더로 정리", (prog) => job.organize(prog).then((r) => `${r.장수}장 정리 끝${r.오류.length ? ` · 못 한 것 ${r.오류.length}장: ${r.오류.slice(0, 3).join(" / ")}` : ""}`));
    return send(res, 200, { ok: true });
  }
  if (req.method === "POST" && path === "/api/export-web") {
    runTask("웹용 zip 만들기", async (prog) => {
      const plan = job.plan().filter((it) => it.웹용);
      prog(0, plan.length, "묶는 중");
      const out = join(job.dir, "웹용-공간목록.zip");
      await writeZip(out, [...plan.map((it) => ({ name: it.웹용.replace(/^웹용\//, ""), path: job.webPath(it.p.id) })),
        { name: "공간목록.json", data: Buffer.from(JSON.stringify(job.spaceList(), null, 2)) }]);
      prog(plan.length, plan.length, "끝");
      return `웹용 ${plan.length}장 + 공간목록.json → ${out}`;
    });
    return send(res, 200, { ok: true });
  }
  if (isMs) return handleMs(req, res, path, url);
  /* 원고기(같은 PC · Node)가 사진 목록의 장면마다 후보를 묻는 곳 — GET /api/scene?text=장면&cat=단체&n=3 (D-101 덧붙임) */
  if (req.method === "GET" && path === "/api/scene") {
    return send(res, 200, { ok: true, ...job.sceneCandidates(url.searchParams.get("text") || "", url.searchParams.get("cat") || "", Math.min(10, Number(url.searchParams.get("n")) || 3), url.searchParams.get("space") || "") });
  }
  if (req.method === "POST" && path === "/api/open-folder") { mkdirSync(job.dir, { recursive: true }); openInExplorer(job.dir); return send(res, 200, { ok: true }); }
  return send(res, 404, { 말: "없는 길" });
}

/** 바탕화면 아이콘 — 켤 때마다 확인해 없거나 옮겨졌으면 다시 만든다(사장님 「cmd 안돌려도 아이콘 누르면 켜지게」 2026-09-30).
    PowerShell 명령을 UTF-16 으로 넘겨(-EncodedCommand) 한글 경로가 안 깨진다 */
function ensureShortcut() {
  const q = (x) => "'" + String(x).replace(/'/g, "''") + "'";
  const ps = `$ws=New-Object -ComObject WScript.Shell; $d=[Environment]::GetFolderPath('Desktop'); $p=Join-Path $d '모토모토 사진정리.lnk';
$want=${q(join(HERE, "photo-sorter.vbs"))}; if (Test-Path $p) { $o=$ws.CreateShortcut($p); if ($o.Arguments -like ('*' + $want + '*')) { exit 0 } }
$l=$ws.CreateShortcut($p); $l.TargetPath=(Join-Path $env:WINDIR 'System32\\wscript.exe'); $l.Arguments='"' + $want + '"'; $l.WorkingDirectory=${q(HERE)};
$l.IconLocation=${q(join(HERE, "ui", "app.ico"))} + ',0'; $l.Description='모토모토 사진정리'; $l.Save()`;
  const c = spawn("powershell", ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-EncodedCommand", Buffer.from(ps, "utf16le").toString("base64")], { windowsHide: true, stdio: "ignore" });
  c.on("error", () => {}); c.on("exit", (code) => { if (code) runLog(`바탕화면 아이콘을 못 만듦(코드 ${code})`); });
}

/* 원고별 사진 바꾸기(원고 대필 페이지 · D-101 덧붙임) — 원고 보기 · 후보 · 한 장 바꾸기 · 대표 썸네일 바꾸기. 바꾼 뒤 정리해 둔 적이 있으면 폴더도 다시 맞춘다 */
const SITE_ORIGINS = new RegExp(process.env.MOTMOT_PHOTO_SITE || "^https://(www\\.)?motmot\\.co\\.kr$");
let reorganize = false;
function afterMsChange() {
  if (!job?.state.정리한때) return;
  try { runTask("원고 사진 바꾼 것 폴더에 반영", (prog) => job.organize(prog).then((r) => `원고 사진을 바꿔 폴더를 다시 맞췄습니다(정리 ${r.장수}장)`)); }
  catch { reorganize = true; } // 다른 일이 도는 중 — 1분마다 다시 본다(syncUsage)
}
async function handleMs(req, res, path, url) {
  if (!job) return send(res, 409, { 말: "사진정리 프로그램에 사진 폴더가 열려 있지 않습니다" });
  const m = /^\/api\/ms\/([^/]+)(\/candidates|\/swap|\/thumb)?$/.exec(path);
  if (!m) return send(res, 404, { 말: "없는 길" });
  const no = m[1], what = m[2] || "";
  try {
    if (req.method === "GET" && !what) {
      const v = job.msView(no);
      return v ? send(res, 200, { ok: true, ...v, 정리중: task.돌아감 ? task.이름 : "" }) : send(res, 404, { 말: "이 원고에 사진정리가 고른 사진이 없습니다(사진정리를 켠 뒤 원고기가 쓴 원고만 고릅니다)" });
    }
    if (req.method === "GET" && what === "/candidates") {
      if (!job.msKey(no)) return send(res, 404, { 말: "사진정리가 모르는 원고입니다" });
      return send(res, 200, { ok: true, 후보: job.swapCandidates(url.searchParams.get("id") || "", Math.min(80, Number(url.searchParams.get("n")) || 40)) });
    }
    if (req.method === "POST" && what === "/swap") {
      const b = await json(req), key = job.msKey(no);
      if (!key || !(job.state.원고들[key].사진 || []).includes(b.뺄)) return send(res, 400, { 말: "이 원고의 사진이 아닙니다" });
      const r = job.swapUse(b.뺄, b.넣을); afterMsChange();
      return send(res, 200, { ok: true, ...r, 원고: job.msView(key) });
    }
    if (req.method === "POST" && what === "/thumb") {
      const r = job.swapThumb(no); afterMsChange();
      return send(res, 200, { ok: true, ...r, 원고: job.msView(no) });
    }
  } catch (e) { return send(res, 400, { 말: e.message }); }
  return send(res, 405, { 말: "안 되는 요청" });
}

/** 창 띄우기 — 윈도우면 프로그램 창(엣지 앱 모드) · 창을 닫으면 끈다. 앱 창을 못 띄우면 보통 브라우저 */
function showWindow(url) {
  if (flag("--no-open")) return;
  if (process.platform === "win32") {
    const ok = openAppWindow(url, { onClose: exitWhenIdle });
    if (!ok) spawn("rundll32", ["url.dll,FileProtocolHandler", url], { detached: true, stdio: "ignore" }).on("error", () => {}).unref();
  } else openInExplorer(url);
}

/** 이미 켜져 있으면(같은 자리에서 사진정리가 답하면) 새로 켜지 않고 그 창만 띄우고 끝낸다 */
async function alreadyRunning(port) {
  try {
    const r = await fetch(`http://127.0.0.1:${port}/api/ping`, { signal: AbortSignal.timeout(800) });
    return r.ok && (await r.json()).프로그램 === "모토모토 사진정리";
  } catch { return false; }
}

async function listen(port, tries = 10) {
  if (await alreadyRunning(port)) {
    if (EMBED) { console.log("이미 켜진 사진정리가 있어 그것을 씁니다"); quit("원고기와 함께 — 이미 켜진 사진정리가 있음"); return; }
    const url = `http://127.0.0.1:${port}/`;
    console.log(`이미 켜져 있습니다 — ${url} 창을 띄웁니다`);
    if (firstPath) { try { await fetch(url + "api/open", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ 경로: firstPath }) }); } catch {} } // zip 을 아이콘에 끌어다 놓은 경우
    if (process.platform === "win32" && !flag("--no-open")) { openAppWindow(url) || spawn("rundll32", ["url.dll,FileProtocolHandler", url], { detached: true, stdio: "ignore" }).unref(); }
    setTimeout(() => quit("이미 켜져 있어 그 창만 띄움"), 1500);
    return;
  }
  const server = http.createServer((req, res) => handle(req, res).catch((e) => send(res, 500, { 말: e.message })));
  server.once("error", (e) => { if (e.code === "EADDRINUSE" && tries > 0) listen(port + 1, tries - 1); else { console.error(e.message); quit(`자리를 못 잡음: ${e.message}`, 1); } });
  server.listen(port, "127.0.0.1", () => {
    const url = `http://127.0.0.1:${port}/`;
    startBeat();
    주소 = url; progress();
    console.log(`모토모토 사진정리 — ${url}`);
    if (!flag("--restarted")) showWindow(url);
    else setTimeout(() => { if (Date.now() - lastHit > 20000) showWindow(url); }, 25000); // 자동 재시작 — 창이 아직 떠 있으면 그 창이 다시 붙는다, 20초 넘게 조용하면 새 창
    if (process.platform === "win32" && !EMBED) ensureShortcut();   // 원고기와 함께면 바탕화면 아이콘을 안 만든다(원고기 아이콘 하나)
  });
}

if (firstPath && !(await alreadyRunning(PORT0))) {
  try { openJob(firstPath); console.log(`열었습니다: ${job.srcPath} (${job.photos.length}개 파일)`); } catch (e) { console.error(e.message); }
} else if (!firstPath && (EMBED || flag("--restarted")) && recent()[0] && !(await alreadyRunning(PORT0))) {
  /* 원고기와 함께 · 자동 재시작 — 마지막에 연 폴더를 저절로(원고기가 장면마다 후보를 바로 물을 수 있게 · 새 사진 자동 정리) */
  try { openJob(recent()[0]); console.log(`마지막 폴더를 열었습니다: ${job.srcPath} (${job.photos.length}개 파일)`); } catch (e) { console.error(`마지막 폴더를 못 열었습니다: ${e.message}`); }
}
listen(PORT0);
