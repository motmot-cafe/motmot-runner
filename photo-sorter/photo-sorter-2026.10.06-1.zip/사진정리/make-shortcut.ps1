﻿# 바탕화면에 「모토모토 사진정리」 아이콘을 만든다 — 사진정리.cmd 가 처음 켤 때 부른다(UTF-8 BOM 으로 저장해야 한글이 안 깨진다)
$here = $PSScriptRoot
$ws = New-Object -ComObject WScript.Shell
$desk = [Environment]::GetFolderPath('Desktop')
$lnk = $ws.CreateShortcut((Join-Path $desk '모토모토 사진정리.lnk'))
$lnk.TargetPath = Join-Path $env:WINDIR 'System32\wscript.exe'
$lnk.Arguments = '"' + (Join-Path $here 'photo-sorter.vbs') + '"'
$lnk.WorkingDirectory = $here
$lnk.IconLocation = (Join-Path $here 'ui\app.ico') + ',0'
$lnk.Description = '모토모토 사진정리 — 사진 분류 · 가공 · 썸네일'
$lnk.Save()
