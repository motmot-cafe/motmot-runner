/* 반영 — 대시보드가 만든 "손으로 막아야 할 것" 을 파트너센터에서 대신 한다 (요구 2: 품절 처리 동기화, 요구 1의 차단 방향).
   할 일(manual_close_todos) 하나 = 채널·객실·기간·막기/열기. 처리하면 op=todo_done (BR-003).
   지난 날짜는 파트너센터에서도 못 막으니 실행 없이 정리만 한다(BR-005). 같은 할 일을 계속 실패하면 셋째부터는 경보만 남긴다. */
import { eachDate, isPastRange, todayKst } from '../lib/kst.js';
import { forDashboard } from '../lib/log.js';
import { NeedsHumanError, SKIP_NOT_FOUND, SKIP_UNKNOWN_STATE } from '../adapters/json-adapter.js';
import { loadRoomLabels } from './room-label.js';

const MAX_ATTEMPTS = 3;
/* 3회 실패한 할 일도 한 시간 뒤에는 다시 해 본다 — 파트너센터가 잠깐 흔들린 것을
   영구 포기로 굳히면 그 방은 계속 팔린다(BR-006). */
const RETRY_COOLDOWN_MS = 60 * 60000;

/**
 * @returns {Promise<{ok:boolean, done:number, cleaned:number, failed:number, skipped:number, unmapped:string[]}>}
 */
export async function runOutbound({ channel, adapter, dashboard, log, state, now = new Date(), notSold = [], maxTodos = null }) {
  const startedAt = now;
  const today = todayKst(now);
  const out = { ok: true, done: 0, cleaned: 0, failed: 0, skipped: 0, unmapped: [] };
  /* v3(D-080): 한 판에 파트너센터에서 처리할 할 일 수 상한. 처음 켤 때 쌓여 있던 할 일을 한꺼번에 몰아치지 않고
       다음 판(OUTBOUND_INTERVAL_SEC 뒤)으로 나눈다 — 고정 간격·상한으로만 줄인다(무작위 흉내 없음, D-076 5.).
     ★ 지난 날 정리·매핑 없음·쉬는 중(3회 실패)은 파트너센터를 안 여므로 세지 않는다. null 이면 상한 없음(여기어때, 예전 그대로). */
  const cap = Number.isInteger(maxTodos) && maxTodos > 0 ? maxTodos : null;
  let acted = 0;
  try {
    const todos = await dashboard.openTodos(channel);
    if (!todos.length) {
      await dashboard.recordRun({ channel, kind: 'outbound', startedAt, finishedAt: new Date(), ok: true, detail: { todos: 0 } });
      return out;
    }
    /* ★ 한 객실(resource)에 채널 상품이 여럿 붙어 있을 수 있다(같은 방을 여러 상품으로 파는 경우).
         Map 으로 덮어쓰면 마지막 하나만 막고 나머지는 계속 팔린다 — 전부 모아 둔다. */
    /* 안 파는 객실은 사장님이 **이름**으로 적어 둔다(id 를 외울 수 없다). 이름 → id 로 푼다. */
    const skipRooms = new Set(notSold);
    if (notSold.length && dashboard.resources) {
      const norm = (x) => String(x || '').replace(/\s+/g, '').toLowerCase();
      const wanted = new Set(notSold.map(norm));
      for (const r of await dashboard.resources().catch(() => [])) {
        if (wanted.has(norm(r.name)) || wanted.has(norm(r.code)) || wanted.has(norm(r.id))) skipRooms.add(r.id);
      }
    }
    const map = new Map();
    for (const m of await dashboard.roomMap(channel)) {
      if (!map.has(m.resource_id)) map.set(m.resource_id, []);
      map.get(m.resource_id).push(m.channel_room_key);
    }
    /* 보여 줄 때만 이름으로 바꾼다 — 일은 그대로 코드로 한다(room-label.js 머리말). */
    const label = await loadRoomLabels(dashboard, map);
    for (const todo of todos) {
      // 지난 것 정리 — 콘솔의 "지난 것 정리" 와 같은 규칙
      if (isPastRange(todo.to_date, today)) {
        const r = await dashboard.todoDone(todo.id);
        if (r && r.ok) { out.cleaned++; state.markTodoDone(todo.id); }
        continue;
      }
      const roomKeys = map.get(todo.resource_id);
      if (!roomKeys || !roomKeys.length) {
        /* ★ 그 채널에 **아예 안 올린 객실**은 매핑이 없는 것이 정상이다 — 영영 안 고쳐질 줄을
             주기마다 알리면 진짜 미매핑이 생겨도 묻힌다(2026-09-11 소유자 요청).
             할 일 자체는 그대로 둔다 — 날짜가 지나면 위의 '지난 것 정리' 가 알아서 닫는다. */
        if (!skipRooms.has(todo.resource_id)) out.unmapped.push(todo.resource_id);
        continue;
      }
      const mem = state.todoAfterCooldown(todo.id, RETRY_COOLDOWN_MS, now.getTime());
      if (mem.attempts >= MAX_ATTEMPTS) { out.skipped++; continue; }
      if (cap && acted >= cap) { out.deferred = (out.deferred || 0) + 1; continue; }
      acted++;
      const dates = eachDate(todo.from_date, todo.to_date).filter((d) => d >= today);
      const closed = todo.action !== 'open';
      try {
        let applied = 0;
        const skipped = [];
        /* v3(I-112): 한 방에 매핑 줄이 여럿이면(코드 줄 + 옛 이름 줄) **하나라도 찾았으면** 그 할 일은 된 것이다.
             예전에는 이름 줄 하나가 화면에 없다고 곧바로 던져서, 코드 줄로 이미 막아 놓고도 할 일이 실패로 남았다 —
             한 시간마다 같은 경보가 되풀이돼 진짜 실패가 묻혔다(2026-09-23 할 일 430, 201·202호).
           ★ 모든 줄이 못 찾았을 때만 실패다 — 그때는 정말로 아무 데도 못 막은 것이다(오버부킹). */
        const lost = [];
        let foundAny = false;
        /* v3.1: 날마다 '어느 줄에서든 판단이 섰나'. 상태 문구를 못 알아본 날(SKIP_UNKNOWN_STATE)은 판단이 안 선 날이다. */
        const settled = new Set();
        const unreadable = new Set();
        for (const roomKey of roomKeys) {
          const r = await adapter.setClosed({ roomKey, dates, closed });
          applied += r.applied;
          skipped.push(...r.skipped);
          for (const d of dates) {
            const k = r.skipped.find((x) => x.date === d);
            if (!k || (k.why !== SKIP_NOT_FOUND && k.why !== SKIP_UNKNOWN_STATE)) settled.add(d);
            else if (k.why === SKIP_UNKNOWN_STATE) unreadable.add(d);
          }
          /* ★ 우리가 막은 날은 반드시 기억해 둔다. 캘린더 대조는 이 기억(wasClosedByUs)이 있는 날만
               다시 연다 — 여기서 안 남기면 할 일로 막은 밤은 예약이 취소돼도 영영 막힌 채로 남는다.
               실제로 그렇게 남은 밤이 있었다(2026-09-25 펜션202). 못 찾은 날은 기억하지 않는다. */
          const took = dates.filter((d) => !r.skipped.some((k) => k.date === d && (k.why === SKIP_NOT_FOUND || k.why === SKIP_UNKNOWN_STATE)));
          if (closed) state.markClosedByUs(channel, roomKey, took);
          else state.forgetClosedByUs(channel, roomKey, took);
          /* ★ 한 날도 못 찾았으면 완료로 닫지 않는다. 닫아 버리면 대시보드는 "막았다" 고 보고
               서버 크론도 같은 할 일을 다시 만들지 않는데, 파트너센터는 그대로 팔고 있다 → 오버부킹. */
          const notFound = r.skipped.filter((s) => s.why === SKIP_NOT_FOUND);
          if (notFound.length === dates.length && dates.length > 0) lost.push(roomKey);
          else foundAny = true;
        }
        if (lost.length && !foundAny) {
          throw new Error(`파트너센터에서 ${lost.join('·')} 의 ${dates.length}일을 찾지 못했다 — 객실 매핑이나 화면 구조를 확인할 것`);
        }
        /* ★ v3.1: 상태 문구를 못 알아봐 **어느 줄에서도 판단이 안 선 날**이 있으면 완료로 닫지 않는다.
             닫으면 대시보드는 막았다고 보는데 그 밤은 손대지 않은 채다(예약이 든 밤일 수도, 열린 밤일 수도 있다).
             할 일을 열어 두면 다음 판에 다시 보고, 세 번이면 사람에게 경보가 간다(아래 catch). 문구 자체는 값이라 안 찍는다. */
        const stuck = [...unreadable].filter((d) => !settled.has(d)).sort();
        if (stuck.length) {
          throw new Error(`판매 상태 문구를 못 알아본 날 ${stuck.length}일(${stuck.slice(0, 3).join(', ')}${stuck.length > 3 ? ' …' : ''}) — ` +
            '손대지 않았다(BR-015). 채널 JSON 의 availability.states 를 확인할 것');
        }
        /* 못 찾은 줄은 알리되 **줄이 바뀔 때만** — 매 판 같은 줄을 내면 진짜 경고가 묻힌다(아래 미매핑과 같은 규칙). */
        if (lost.length && !state.saidBefore?.(`lostKey:${channel}:${todo.resource_id}`, lost.join(','))) {
          /* 사장님 2026-09-28 "끄지 말고, 병렬 연결되게 해주면 안될까" — 이름 줄은 예약 연결(유입)의 예비로 계속 쓴다.
               그래서 끄라고 하지 않는다. 막기에는 안 쓰인다는 사실만 한 번 알린다. */
          log.info(`${channel}: ${lost.map((k) => label.both(k)).join('·')} — 파트너센터 막기 화면에 없는 매핑 줄이다. ` +
            '같은 방의 다른 줄로 막았다(이 줄은 예약 연결용으로 그대로 둔다, I-112)');
        }
        const done = await dashboard.todoDone(todo.id);
        if (!done || !done.ok) throw new Error(`todo_done 실패: ${(done && done.error) || '응답 오류'}`);
        state.markTodoDone(todo.id);
        out.done++;
        /* 화면의 '방금 한 일' 목록 — 대시보드 → 여기어때 방향(이 PC 에만 남는다, state.js 머리말). */
        if (applied) {
          state.addRecentOutbound?.(channel, roomKeys.map((k) => (
            { roomName: label.forKey(k), dates, action: closed ? '품절처리' : '다시 열기' })));
        }
        log.info(`${channel}: ${roomKeys.map((k) => label.both(k)).join('·')} ${todo.from_date}~${todo.to_date} ${closed ? '마감' : '재개'} — 실행 ${applied}일` +
          (skipped.length ? `, 건너뜀 ${skipped.length}일(${skipped.map((s) => s.why).filter((v, i, a) => a.indexOf(v) === i).join('·')})` : ''));
      } catch (e) {
        if (e instanceof NeedsHumanError) throw e;
        state.markTodoAttempt(todo.id, e.message);
        out.failed++;
        log.error(`${channel}: 할 일 ${todo.id}(${roomKeys.map((k) => label.both(k)).join('·')} ${todo.from_date}~${todo.to_date}) 실패 ${state.todo(todo.id).attempts}회 — ${e.message}`);
        if (state.todo(todo.id).attempts >= MAX_ATTEMPTS) {
          await dashboard.openAlert({ kind: 'sync_stale', channel, resourceId: todo.resource_id, onDate: todo.from_date,
            detail: { reason: `${closed ? '마감' : '재개'}을 ${MAX_ATTEMPTS}번 실패 — 파트너센터에서 직접 확인`, todoId: todo.id, source: 'outbound' } }).catch(() => {});
        }
      }
    }
    if (out.unmapped.length) {
      const uniq = [...new Set(out.unmapped)].sort();
      /* ★ 이 줄은 **영영 안 바뀔 수 있다** — OTA 에 아예 안 올린 객실이면 매핑이 없는 것이 정상이다
           (2026-09-11 소유자 확인). 그런 줄을 1~2분마다 내면 진짜 미매핑이 생겼을 때 묻힌다.
           집합이 바뀔 때만 알린다. 경보(openAlert)도 같은 규칙으로 — 콘솔이 같은 카드를 계속 되살리면
           사장님이 카드를 통째로 무시하게 된다. */
      if (!state.saidBefore(`unmapped:${channel}`, uniq.join(','))) {
        log.warn(`${channel}: 객실 매핑이 없어 못 막는 할 일 — ${uniq.join(', ')}` +
          ' (콘솔 채널 탭에서 매핑할 것. 그 채널에 안 올린 객실이면 이대로 두면 된다)');
        for (const rid of uniq) {
          await dashboard.openAlert({ kind: 'unmapped', channel, resourceId: rid, detail: { roomKey: rid, direction: 'outbound', source: 'outbound' } }).catch(() => {});
        }
      }
    }
    /* ★ 미매핑 경보는 한 번 열리면 스스로 안 닫힌다. 매핑을 넣거나 "안 파는 객실" 로 적어 둔
         뒤에도 카드가 콘솔에 그대로 남아, 사장님은 고쳐도 안 고쳐진 것으로 본다.
         지금도 미매핑인 것만 남기고 나머지는 닫는다. */
    await dashboard.resolveAlerts({ kind: 'unmapped', channel, source: 'outbound', keep: new Set(out.unmapped) })
      .catch(() => 0);
    if (out.deferred) log.info(`${channel}: 한 판 상한 ${cap}건 — 남은 할 일 ${out.deferred}건은 다음 판에 한다`);
    out.ok = out.failed === 0;
    await dashboard.recordRun({ channel, kind: 'outbound', startedAt, finishedAt: new Date(), ok: out.ok,
      detail: { todos: todos.length, done: out.done, cleaned: out.cleaned, failed: out.failed, unmapped: out.unmapped.length,
                ...(out.deferred ? { deferred: out.deferred } : {}) } });
    return out;
  } catch (e) {
    const human = e instanceof NeedsHumanError;
    log.error(`${channel}: 반영 실패 — ${e.message}`);
    await dashboard.recordRun({ channel, kind: 'outbound', startedAt, finishedAt: new Date(), ok: false, detail: { error: String(e.message).slice(0, 300) } }).catch(() => {});
    await dashboard.openAlert({ kind: 'sync_stale', channel, detail: { reason: human ? '2단계 인증 필요 — 페어링 다시' : forDashboard(e.message), source: 'outbound' } }).catch(() => {});
    return { ...out, ok: false, error: e.message, needsHuman: human };
  }
}
