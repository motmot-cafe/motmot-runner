#!/usr/bin/env node
/* 모양 보기 — 탐색 기록(artifacts/discover/<채널>/<시각>/)의 JSON 응답에서 **키 이름만** 뽑는다.
     npm run shapes -- yeogi              가장 최근 기록
     npm run shapes -- yeogi --all        오래된 기록까지 전부 훑어 합친다
     npm run shapes -- yeogi --dir <경로> 폴더를 직접 지정
   값(예약자 이름·전화·금액)은 한 글자도 찍지 않는다. 그래서 이 출력은 그대로 공유해도 된다 — 채널 JSON 의
   fromJson 필드 매핑을 채우는 데 필요한 것은 "어떤 키가 어디 있는지" 뿐이다. */
import fs from 'node:fs';
import path from 'node:path';
import { loadEnvFile, loadConfig } from '../lib/config.js';
import { scrubSecrets, maskPii } from '../lib/log.js';

const MAX_KEYS = 60;      // 한 노드에서 보여 줄 키 수
const MAX_DEPTH = 8;   // products 안쪽까지 봐야 판매 상태 필드가 보인다

/** 값을 빼고 모양만 남긴다. 배열은 첫 원소의 모양으로 대표하고 길이만 적는다. */
function shapeOf(v, depth = 0) {
  if (v === null) return 'null';
  if (Array.isArray(v)) {
    if (!v.length) return '[]';
    if (depth >= MAX_DEPTH) return '[…]';
    return [`[${v.length}개]`, shapeOf(v[0], depth + 1)];
  }
  if (typeof v === 'object') {
    if (depth >= MAX_DEPTH) return '{…}';
    const out = {};
    for (const k of Object.keys(v).slice(0, MAX_KEYS)) out[k] = shapeOf(v[k], depth + 1);
    if (Object.keys(v).length > MAX_KEYS) out['…'] = `그 밖 ${Object.keys(v).length - MAX_KEYS}개`;
    return out;
  }
  return typeof v;   // string | number | boolean — 값은 안 찍는다
}

/* 상태·구분처럼 '정해진 몇 값' 만 도는 칸은 값까지 알아야 매핑할 수 있다(판매중 ↔ 판매중지).
   이름이 이 목록에 있는 칸만 값을 모은다 — 이름·전화가 들어갈 이름이 아니다.
   ★ v3: 끝이 Status·State·Type 인 칸도 모은다(야놀자 inventoryStatus·dailyInventoryStatus 가 빠졌다 — 2026-09-23 1차 기록).
   ★ v3: 'name' 은 뺐다 — 예약 목록의 name 칸은 **예약자 이름**일 수 있다(BR-020). 객실 이름은 아래 ROOM_NAME_KEYS 로 따로 본다. */
const ENUM_KEYS = /^(status|statusLabel|state|saleType|saleTypeLabel|blockType|rateBase|planType|type|code|label)$|[a-z](Status|State|Type)$/;
/* 객실 이름 — 매핑(channel_room_map)을 채우려면 값이 필요하다. 손님 이름이 들어갈 자리가 아니다. */
const ROOM_NAME_KEYS = /^(roomtypeName|roomTypeName|roomName|productName|productTitle)$/;
/* 모은 값이 전화·이메일처럼 보이거나 길면 버린다 — 정해진 값은 짧다. */
const enumOk = (val) => typeof val === 'number' || (typeof val === 'string' && val.length <= 40 && maskPii(val) === val);

/* ★ v3: 광고·통계·로그 수집처는 뺀다. 파트너센터가 아니고, 보낸 몸통에 기기·계정 식별값이 실려 있다
     (1차 기록에 kinesis 로그·알림 토큰이 그대로 찍혔다 — 2026-09-23). */
const NOISE_HOST = /(^|\.)(google-analytics\.com|analytics\.google\.com|googletagmanager\.com|doubleclick\.net|amazonaws\.com|facebook\.(com|net)|clarity\.ms|hotjar\.com|sentry\.io|datadoghq\.com|braze\.com|amplitude\.com)$/i;
export function isNoise(url) {
  try { const u = new URL(url); return NOISE_HOST.test(u.hostname) || /^\/cdn-cgi\//.test(u.pathname); } catch { return false; }
}
/* ★ v3: 보낸 몸통·질의의 비밀값을 가린다. 칸 이름으로 한 번(token·secret·session …), 생김새로 한 번(길고 불투명한 값). */
const SECRET_KEY = /token|secret|passw|credential|session|cookie|auth|signature|api_?key|access_?key|refresh|otp/i;
const LONG_OPAQUE = /[A-Za-z0-9+/=_\-.:]{40,}/g;
export function maskSent(v, depth = 0) {
  if (v == null || depth > 8) return v;
  if (typeof v === 'string') return maskPii(v).replace(LONG_OPAQUE, (m) => `(긴 값 ${m.length}자 가림)`);
  if (Array.isArray(v)) return v.map((x) => maskSent(x, depth + 1));
  if (typeof v === 'object') {
    const out = {};
    for (const [k, x] of Object.entries(v)) out[k] = SECRET_KEY.test(k) ? '(가림)' : maskSent(x, depth + 1);
    return out;
  }
  return v;
}
/* 쓰기 요청을 '같은 종류' 로 묶는 열쇠 — 날짜·번호·글자는 자리만 남기고, 정해진 값처럼 생긴 것(SALE·CLOSE 같은 대문자)만 남긴다.
   ★ 날짜마다 몸통이 달라 6가지 칸이 방열기로만 찼다 — 방막기(CLOSE)가 묻히지 않게 **동작으로** 가른다. */
export function variantOf(v, depth = 0) {
  if (v == null || depth > 8) return v;
  if (typeof v === 'number') return 'n';
  if (typeof v === 'boolean') return v;
  if (typeof v === 'string') return /^[A-Z][A-Z0-9_]{1,30}$/.test(v) ? v : (/^\d{4}-?\d{2}-?\d{2}/.test(v) ? 'd' : 's');
  if (Array.isArray(v)) return v.length ? [variantOf(v[0], depth + 1)] : [];
  const out = {};
  for (const k of Object.keys(v).sort()) out[k] = variantOf(v[k], depth + 1);
  return out;
}

/* 질의 **값** 하나를 가리는 기준 — 칸 이름은 남기고 값만 본다. 회원 번호(UUID 36자)처럼 40자가 안 돼도
   불투명한 긴 값은 식별값이라 가린다. 날짜·숫자 번호(propertyId 8자리)·SALE 같은 짧은 값은 그대로 둔다. */
const LONG_VALUE = /[A-Za-z0-9+/=_\-.:%]{24,}/g;
const safeDecode = (k) => { try { return decodeURIComponent(k); } catch { return k; } };

/** a=1&token=… 같은 글자 — 비밀 칸의 값과 긴 값을 가린다.
    ★ v3.1: **칸 이름은 남긴다.** 예전에는 `이름=값` 을 통째로 한 덩어리로 보고 가려서, 야놀자 방막기 요청에
      어떤 칸이 더 붙는지(`(긴 값 49자 가림)`)조차 알 수 없었다(2026-09-28). 이름은 값이 아니다 — 가릴 까닭이 없다. */
export function maskQuery(q) {
  const text = maskPii(String(q));
  const lead = text.startsWith('?') ? '?' : '';
  return lead + text.slice(lead.length).split('&').map((seg) => {
    const at = seg.indexOf('=');
    if (at < 0) return seg.replace(LONG_OPAQUE, (m) => `(긴 값 ${m.length}자 가림)`);   // 이름 없는 덩어리
    const k = seg.slice(0, at), x = seg.slice(at + 1);
    if (SECRET_KEY.test(safeDecode(k))) return `${k}=(가림)`;
    /* v3.1: **주소만 있는 값**(화면 주소 — 질의·조각 없음)은 그대로 보인다. 야놀자 방막기 요청의 referer 칸이 이것이라
         (2026-09-28) 값을 알아야 실행기가 같게 보낸다. 질의(?·=·&)가 붙은 주소는 토큰이 들 수 있어 여전히 가린다. */
    const plain = safeDecode(x);
    if (/^https?:\/\/[A-Za-z0-9.-]+(\/[A-Za-z0-9._~\/-]*)?$/.test(plain) && plain.length <= 160) return `${k}=${plain}`;
    return `${k}=${x.replace(LONG_VALUE, (m) => `(긴 값 ${m.length}자 가림)`)}`;
  }).join('&');
}

function collectEnums(v, key = '', out = new Map(), depth = 0) {
  if (depth >= MAX_DEPTH || v == null) return out;
  if (Array.isArray(v)) { for (const x of v.slice(0, 200)) collectEnums(x, key, out, depth + 1); return out; }
  if (typeof v === 'object') {
    for (const [k, val] of Object.entries(v)) {
      if ((ENUM_KEYS.test(k) || ROOM_NAME_KEYS.test(k)) && enumOk(val)) {
        if (!out.has(k)) out.set(k, new Set());
        if (out.get(k).size < 12) out.get(k).add(val);
      }
      collectEnums(val, k, out, depth + 1);
    }
    return out;
  }
  return out;
}

/** 리스트로 보이는 자리를 찾아 준다 — fromJson 의 list 에 쓸 경로. */
function listPaths(v, prefix = '', out = [], depth = 0) {
  if (depth >= MAX_DEPTH || !v || typeof v !== 'object') return out;
  if (Array.isArray(v)) {
    if (v.length && typeof v[0] === 'object' && !Array.isArray(v[0])) {
      out.push({ path: prefix || '(최상위)', count: v.length, fields: Object.keys(v[0]).slice(0, MAX_KEYS) });
    }
    return out;
  }
  for (const k of Object.keys(v)) listPaths(v[k], prefix ? `${prefix}.${k}` : k, out, depth + 1);
  return out;
}

function newestDir(base) {
  const dirs = fs.readdirSync(base, { withFileTypes: true })
    .filter((e) => e.isDirectory()).map((e) => path.join(base, e.name))
    .sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs);
  return dirs[0];
}

export function shapes(argv = process.argv.slice(2), { out = console.log } = {}) {
  loadEnvFile();
  const cfg = loadConfig(process.env, { requireDashboard: false });
  const channel = argv.find((a) => !a.startsWith('--'));
  if (!channel) { out('어느 채널인지 적어 주세요: npm run shapes -- yeogi'); return 2; }

  const at = argv.indexOf('--dir');
  const base = path.join(cfg.paths.artifactsDir, 'discover', channel);
  let dirs;
  if (at >= 0 && argv[at + 1]) dirs = [path.resolve(argv[at + 1])];
  else if (!fs.existsSync(base)) { out(`탐색 기록이 없다: ${base}\n먼저 npm run discover -- ${channel} 를 돌리세요.`); return 1; }
  else if (argv.includes('--all')) {
    dirs = fs.readdirSync(base, { withFileTypes: true }).filter((e) => e.isDirectory()).map((e) => path.join(base, e.name));
  } else dirs = [newestDir(base)];

  const seen = new Map();   // "METHOD /경로" → { status, shape, lists }
  let files = 0, skippedNoise = 0;
  for (const dir of dirs) {
    if (!dir || !fs.existsSync(dir)) continue;
    for (const f of fs.readdirSync(dir).filter((f) => /^\d+\.json$/.test(f)).sort()) {
      let rec;
      try { rec = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8')); } catch { continue; }
      files++;
      /* ★ 응답이 JSON 이 아니어도(빈 응답·텍스트) 버리지 않는다. 쓰기 요청은 **보낸 몸통**이 핵심인데
           예전엔 여기서 continue 해서 PUT close/open 이 통째로 사라졌다. */
      if (isNoise(rec.url)) { skippedNoise++; continue; }        // v3: 광고·통계·로그 수집처
      let body = null, bodyIsJson = true;
      try { body = JSON.parse(rec.body); } catch { bodyIsJson = false; }
      /* ★ 쓰기 요청(PUT/POST)은 **보낸 몸통**이 핵심이다 — 방막기가 어떤 객실·날짜를 어떤 형식으로
           보내는지가 거기 있다. 값에 개인정보가 들어갈 자리가 아니므로(객실 id·날짜·수량) 값까지 남긴다.
         ★ v3: 그래도 비밀 칸(token·session …)과 길고 불투명한 값은 가린다(maskSent) — 1차 기록에 알림 토큰이 찍혔다. */
      let sent = null;
      if (rec.method !== 'GET' && rec.postData) {
        try { sent = maskSent(JSON.parse(rec.postData)); } catch { sent = maskQuery(String(rec.postData).slice(0, 800)); }
      }
      const q = String(rec.url).includes('?') ? maskQuery(String(rec.url).split('?')[1].slice(0, 400)) : null;
      /* 같은 주소는 한 번만 — 다만 v3: ① 읽기는 **정해진 값을 합친다**(첫 달엔 판매중만 있고 다음 달에 방막음이 나올 수 있다).
         ② 쓰기는 **보낸 몸통이 다르면 따로** 보인다(방막기·방열기가 같은 주소에 다른 몸통일 수 있다 — 한 주소에 6가지까지). */
      const path0 = `${rec.method} ${String(rec.url).replace(/\?.*$/, '')}`;
      let key = path0;
      if (rec.method !== 'GET' && sent !== null) {
        const variant = JSON.stringify(variantOf(sent)).slice(0, 300);
        const same = [...seen.keys()].filter((k) => k === path0 || k.startsWith(path0 + ' #'));
        const hit = same.find((k) => seen.get(k).variant === variant);
        if (hit) key = hit;
        else if (same.length >= 6) continue;
        else key = same.length ? `${path0} #${same.length + 1}` : path0;
      }
      if (seen.has(key)) {
        if (bodyIsJson) {
          const into = seen.get(key).enums;
          for (const [k, set] of collectEnums(body)) {
            if (!into.has(k)) into.set(k, new Set());
            for (const x of set) if (into.get(k).size < 12) into.get(k).add(x);
          }
        }
        continue;
      }
      seen.set(key, {
        variant: sent !== null ? JSON.stringify(variantOf(sent)).slice(0, 300) : null,
        status: rec.status, sent, q,
        shape: bodyIsJson ? shapeOf(body) : `(JSON 아님, ${rec.size ?? 0}바이트)`,
        lists: bodyIsJson ? listPaths(body) : [],
        enums: bodyIsJson ? collectEnums(body) : new Map(),
      });
    }
  }

  if (!seen.size) { out(`JSON 응답을 찾지 못했다(파일 ${files}개를 봤다). 폴더가 맞는지 확인할 것: ${dirs.join(', ')}`); return 1; }

  out(`# ${channel} 응답 모양 — 값은 빼고 키 이름만(정해진 값·객실 이름은 값까지). 비밀 칸·긴 값은 가렸다.`);
  out(`# 기록: ${dirs.join(', ')}  (응답 ${seen.size}종 · 광고·통계 ${skippedNoise}건은 뺐다)`);
  /* v3: 쓰기 요청을 맨 위에 모아 보인다 — 방막기·방열기를 눌렀는데 기록에 없으면 여기서 곧바로 안다. */
  const writes = [...seen.keys()].filter((k) => !k.startsWith('GET '));
  out(`# 쓰기 요청(GET 이 아닌 것) ${writes.length}종${writes.length ? '' : ' — 방막기·방열기를 눌렀다면 기록이 안 된 것이다(다시 기록할 것)'}`);
  for (const k of writes) out(`#   ${k}`);
  out('');
  for (const [key, v] of [...seen].sort()) {
    out(`## ${key}   [${v.status}]`);
    if (v.q) out(`   질의: ?${v.q}`);
    if (v.sent !== null) out('   보낸 것: ' + scrubSecrets(typeof v.sent === 'string' ? v.sent : JSON.stringify(v.sent)).slice(0, 2000));
    if (v.enums && v.enums.size) {
      const parts = [...v.enums].map(([k, set]) => `${k}=${[...set].map((x) => JSON.stringify(x)).join('|')}`);
      out('   정해진 값들: ' + parts.join('  '));
    }
    if (v.lists.length) {
      out('   목록으로 쓸 만한 자리:');
      for (const l of v.lists) out(`     - ${l.path}  (${l.count}개)  ${l.fields.join(', ')}`);
    }
    out('   ' + scrubSecrets(JSON.stringify(v.shape)).slice(0, 4000));
    out('');
  }
  out('이 출력을 그대로 붙여 주면 config/selectors/' + channel + '.json 의 fromJson 매핑을 채울 수 있다.');
  return 0;
}

if (process.argv[1] && /cli[\\/]shapes\.js$/.test(process.argv[1])) {
  process.exit(shapes());
}
