/* 이미 원장에 있는 예약은 다시 안 보낸다 — **새 예약만** 보낸다.

   왜 (2026-09-11 실계정):
     대시보드는 `bookings`(원장)와 `ota_reservations`(채널에서 받은 것)를 **같은 예약으로 안 묶는다.**
     그래서 이미 원장에 있는 예약을 우리가 또 보내면 점유가 둘로 세어져, 실제 예약마다
     오버부킹 경보가 뜬다. 방이 실제로 겹친 건 아니지만 **사장님이 캘린더를 못 믿게 된다.**

     그렇다고 유입을 끄면 이 프로그램의 존재 이유가 없어진다. 새로 들어온 예약을 잡는 것이 본업이다.
     그래서 **가려서 보낸다** — 원장에 이미 있는 것은 빼고, 새 것만.

   ★ 취소는 예외다. 원장에 있어도 **취소는 보내야** 대시보드가 그 밤을 다시 열 수 있다.
     "이미 아는 예약" 이라고 취소를 빼면, 손님이 취소한 밤을 우리가 계속 막아 두게 된다.
   ★★ 다만 **이미 반영된 취소는 다시 안 보낸다** (2026-09-23, 모토모토 I-114).
     예전에는 취소를 "원장에 있어도 늘" 보냈다. 그러면 목록에 무엇 하나만 바뀌어 저장할 때마다 **창 안의 모든 취소가 다시 나가고**
     「방금 한 일」 에 같은 취소가 "6번째" 로 되풀이돼 쌓였다(사장님: "이거 자꾸 중복으로 뜨는데").
     서버는 이미 취소된 줄을 다시 취소하지 않으므로(모토모토 I-109) 되보내기는 할 일 없이 화면만 어지럽힌다.
     → 원장에 그 번호의 줄이 있고 **전부 끝난 줄(취소)** 이면 뺀다. 하나라도 살아 있으면 보낸다(그래야 그 밤이 열린다).
     → 원장에 줄이 없으면(원장에 오기 전에 취소된 예약 등) 이 PC 가 **한 번 저장까지 보낸 취소**인지 본다(state.cancelSent). */

/** 원장 한 줄에서 채널 예약번호를 찾는다. 열 이름을 모르므로 줄 전체 글자에서 찾는다.
    (대시보드는 메모에 "채널 예약 자동 반영 (yeogi · 260908130174E6YE1)" 처럼 적어 둔다.) */
export function knownNosFrom(rows, nos) {
  const found = new Set();
  if (!Array.isArray(rows) || !nos.length) return found;
  for (const row of rows) {
    let text;
    try { text = JSON.stringify(row); } catch { continue; }
    for (const no of nos) if (no && text.includes(no)) found.add(no);
  }
  return found;
}

/**
 * 원장 줄이 이 예약과 **같은 예약인가** — 번호가 없을 때의 두 번째 잣대(기본으로는 안 쓴다).
 *
 * ★ 2026-09-11 실측: 번호로만 맞추면 덜 걸러진다. 원장 줄 중에는 여기어때 번호가 안 적힌 것이
 *   섞여 있었다(만든 경로가 달랐다). 그래서 **입실·퇴실 날짜가 같고 예약자 이름이 그 줄 어딘가에
 *   있으면** 같은 예약으로 보는 길을 뒀다. 객실은 안 본다 — 사장님이 방을 옮겨 둔 예약이 있다.
 *
 * ★★ 2026-09-15: 이 잣대가 **위험하다**는 것이 실제로 드러났다. 같은 손님이 같은 날짜로 방을
 *   여러 개 잡으면(가족·단체) 원장에 한 줄만 있어도 셋 다 "이미 있다"로 걸러져, 나머지 방은
 *   빈 것으로 남아 그 날 또 팔린다 — 오버부킹이다. 그래서 두 가지를 바꿨다:
 *     1) 기본 잣대는 **예약번호**다(DUPE_MATCH=no). 번호가 다르면 다른 예약이다.
 *     2) 이름·날짜 잣대를 켠 판(DUPE_MATCH=stay)에서도 **원장 한 줄은 예약 하나만 흡수한다.**
 *        줄이 하나뿐이면 둘째·셋째는 새 예약으로 보낸다.
 *
 *   이름은 **비교만 하고 어디에도 안 남긴다**(로그·기록물 어디에도 안 찍는다).
 */
export function sameStay(row, cols, item) {
  if (!cols || !cols.checkIn || !cols.checkOut) return false;
  const day = (v) => String(v ?? '').slice(0, 10);
  if (day(row[cols.checkIn]) !== day(item.checkIn)) return false;
  if (day(row[cols.checkOut]) !== day(item.checkOut)) return false;
  const name = String(item.guestName || '').replace(/\s+/g, '');
  if (name.length < 2) return false;                 // 한 글자 이름으로 맞추지 않는다
  let text;
  try { text = JSON.stringify(row).replace(/\s+/g, ''); } catch { return false; }
  return text.includes(name);
}

const rowHasNo = (row, no) => {
  try { return JSON.stringify(row).includes(no); } catch { return false; }
};

/* ★★★ **돈·판매채널이 빈 채로 원장에 앉은 예약은 채우러 다시 보낸다 — 칸마다 한 번** (2026-10-13, 모토모토 I-142 · I-102).

   왜: 0.9.0 전까지 여기어때 판매 금액 · 입금 예정 금액 · 판매채널을 못 읽었다(칸 이름이 틀렸다).
     그 사이에 들어온 예약은 원장에 **금액 없이** 앉아 있다. 위 규칙(이미 있는 예약은 안 보낸다) 때문에
     칸 이름을 고쳐도 그 예약들은 다시 안 나가 **영영 빈칸**이다 — 정산 화면에 「미기입」 으로 빠진다.
   그래서 아래가 **모두** 맞을 때만 다시 보낸다:
     1) 원장 줄이 **대시보드가 이 채널 예약으로 만든(또는 이어 붙인) 줄**이다 — 메모에 "(yeogi · 번호)" 가 있다.
        (대시보드가 적는 「채널 예약 자동 반영 (yeogi · 번호)」 · 「채널 예약 연결 (yeogi · 번호)」.)
        사람이 손으로 만든 줄은 안 건드린다 — 그 예약은 채널 원장 줄이 없어 새로 들어가면 두 줄이 될 수 있다.
     2) 아직 퇴실 전이다 — 대시보드는 퇴실이 지난 예약을 예약표로 옮기지 않아(promoteToBookings) 보내도 못 채운다.
     3) 그 줄에 비어 있는 칸을 **이번에 읽은 값이 채울 수 있다** — 'a' 금액(amount) · 'p' 입금예정(payout_amount, 또는
        기본 수수료로 계산해 둔 값 'rate') · 'c' 판매채널(sale_channel, 연동 예약사이트일 때만). 칸이 없는 옛 원장(열쇠가 없다)은 안 본다.
     4) 그 칸을 이 PC 가 **아직 채우러 보내지 않았다**(state.backfillSent 가 칸 글자를 돌려준다).
        ★ 칸마다 따로 적는다 — 한 판에 PMS 목록을 못 받아 판매채널 없이 금액만 보냈어도, 다음 판에 판매채널이 오면
          그 칸만 한 번 더 보낸다(예약 하나에 한 번이면 네이버예약 표시가 영영 못 간다 — 2026-10-13 검토).
   대시보드는 같은 번호의 채널 원장 줄을 찾아 **빈 칸만** 채운다(사람이 적은 값은 안 덮는다 — 서버 promoteToBookings). */
const LINKED_SALE = /^CHANNEL$|연동|네이버|naver/i;
const hasKey = (r, k) => r && Object.prototype.hasOwnProperty.call(r, k);
/** 이번에 읽은 값이 채울 수 있는 빈 칸 — 'a' · 'p' · 'c' 를 이어 붙인 글자(없으면 ''). */
export function backfillGaps(it, rows, channel) {
  const no = String(it?.reservationNo ?? '').trim();
  if (!no || !channel || !Array.isArray(rows)) return '';
  const tag = `(${channel} · ${no})`;
  const mine = rows.filter((r) => String(r?.memo ?? '').includes(tag));
  if (!mine.length) return '';
  const amount = it.amount != null && it.amount !== '';
  const settle = it.settleAmount != null && it.settleAmount !== '';
  const linked = LINKED_SALE.test(String(it.saleChannel ?? '').trim());
  let out = '';
  if (amount && mine.some((r) => hasKey(r, 'amount') && r.amount == null)) out += 'a';
  if (settle && mine.some((r) => hasKey(r, 'payout_amount') && (r.payout_amount == null || r.payout_basis === 'rate'))) out += 'p';
  if (linked && mine.some((r) => hasKey(r, 'sale_channel') && r.sale_channel == null)) out += 'c';
  return out;
}
export function needsBackfill(it, rows, channel) { return backfillGaps(it, rows, channel) !== ''; }

/**
 * 보낼 것을 가린다.
 * @param {object[]} items 파트너센터에서 읽은 예약
 * @param {Set<string>} known 원장에서 찾은 예약번호
 * @param {(s:any)=>string} normalize 상태를 우리 말로 옮기는 함수
 * @param {{rows?:object[], cols?:object|null, matchBy?:'no'|'stay'}} [opt]
 *        matchBy: 'no' = 예약번호만으로 중복을 본다(기본). 'stay' = 번호에 더해 이름·날짜도 본다.
 * @param {{channel:string, today?:string, sent?:(no:string)=>string}|null} [opt.backfill] 돈·판매채널이 빈 원장 줄을 칸마다 한 번 채우러 보낸다(★★★).
 *        sent(no) = 이미 채우러 보낸 칸 글자('a' · 'p' · 'c'). today = 오늘(YYYY-MM-DD) — 퇴실이 그 날 이전이면 안 보낸다.
 * @returns {{send:object[], skipped:object[], backfilled:object[], backfillKinds:Map<string,string>}} backfilled ⊂ send,
 *          backfillKinds = 번호 → 이번에 채우러 보낸 칸 글자
 */
export function pickToSend(items, known, normalize, { rows = [], cols = null, matchBy = 'no', isLive = null, cancelSent = null, backfill = null } = {}) {
  const send = [], skipped = [], backfilled = [], backfillKinds = new Map();
  /* ★ 이름·날짜로 맞출 때 **원장 한 줄은 한 번만 쓴다.** 안 그러면 같은 이름·같은 날짜의
       예약 셋이 줄 하나에 모두 걸려, 둘은 원장에 영영 안 들어간다(그 방이 다시 팔린다). */
  const used = new Set();
  for (const it of items) {
    const no = String(it.reservationNo ?? '');
    const cancelled = normalize(it.status) === '예약취소';
    /* 취소는 원장에 **아직 반영 안 됐으면** 보낸다 — 안 보내면 취소된 밤을 계속 막아 둔다(위 ★★). */
    if (cancelled) {
      if (no && typeof isLive === 'function') {
        const mine = rows.filter((r) => rowHasNo(r, no));
        if (mine.length) {
          /* 판정이 던지면 살아 있는 것으로 본다 — 모르면 보낸다(취소를 빼먹으면 그 밤이 계속 막힌다). */
          const dead = mine.every((r) => { try { return !isLive(r); } catch { return false; } });
          if (dead) { skipped.push(it); continue; }
          send.push(it); continue;
        }
        if (typeof cancelSent === 'function' && cancelSent(no)) { skipped.push(it); continue; }
      }
      send.push(it); continue;
    }
    if (no && known.has(no)) {
      /* 번호로 뺀 예약은 **자기 줄을 먹는다** — 그 줄이 남아 있으면 같은 이름·날짜의 다른 방
         예약이 그 줄에 걸려 안 보내진다. 자기 번호가 적힌 줄만 쓴다(없으면 아무 줄도 안 쓴다). */
      if (matchBy === 'stay') {
        const mine = rows.findIndex((r, i) => !used.has(i) && rowHasNo(r, no));
        if (mine >= 0) used.add(mine);
      }
      /* 빈 돈·판매채널을 채우러 **칸마다 한 번** 다시 보낸다(위 ★★★). 판정이 던지면 안 보낸다 — 모르면 예전처럼 둔다. */
      let fresh = '';
      if (backfill && backfill.channel) {
        try {
          const live = !backfill.today || String(it.checkOut ?? '').slice(0, 10) > backfill.today;
          const done = String((typeof backfill.sent === 'function' && backfill.sent(no)) || '');
          fresh = live ? [...backfillGaps(it, rows, backfill.channel)].filter((k) => !done.includes(k)).join('') : '';
        } catch { fresh = ''; }
      }
      if (fresh) { send.push(it); backfilled.push(it); backfillKinds.set(no, fresh); continue; }
      skipped.push(it);
      continue;
    }
    if (matchBy !== 'stay') { send.push(it); continue; }
    const hit = rows.findIndex((r, i) => !used.has(i) && sameStay(r, cols, it));
    if (hit >= 0) { used.add(hit); skipped.push(it); }
    else send.push(it);
  }
  return { send, skipped, backfilled, backfillKinds };
}

/* 보낼 것을 **취소와 새 예약으로 갈라 센다.**

   왜 (2026-09-17 소유자 로그): 매 주기 "새 예약·취소 6건만 보낸다" 가 똑같이 반복됐다.
   그런데 그 줄만으로는 **정상인지 고장인지 갈리지 않는다** —
     취소라면 정상이다. 취소는 원장에 있어도 늘 보낸다(위 머리말).
     새 예약이라면 고장이다. 한 번 보냈으면 다음 주기엔 원장에서 번호로 걸러져야 하는데,
     계속 나간다는 것은 **원장에 안 앉고 있다**는 뜻이다(2분마다 같은 예약을 다시 꽂는다).
   번호는 주문 식별자라 이름·연락처와 달리 개인정보가 아니므로 눈으로 맞춰 볼 수 있게 찍는다. */
export function sendBreakdown(items = [], normalize = () => '') {
  const cancelled = [], fresh = [];
  for (const it of items) (normalize(it.status) === '예약취소' ? cancelled : fresh).push(String(it.reservationNo ?? ''));
  return { cancelled: cancelled.length, fresh: fresh.length, freshNos: fresh.filter(Boolean) };
}

/** 위 갈라 센 것을 로그 한 조각으로. */
export function breakdownText(b) {
  const head = `취소 ${b.cancelled}건(원장에 아직 반영 안 된 것) · 새 예약 ${b.fresh}건`;
  if (!b.freshNos.length) return head;
  const shown = b.freshNos.slice(0, 5).join(', ');
  return `${head}: ${shown}${b.freshNos.length > 5 ? ` 외 ${b.freshNos.length - 5}건` : ''}` +
    ' ← 다음 주기에도 같은 번호가 나오면 원장에 안 앉고 있는 것이다';
}
