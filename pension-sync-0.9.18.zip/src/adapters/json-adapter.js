/* 채널 어댑터 — 어느 채널이든 같은 다섯 가지를 한다. 방법은 전부 채널 JSON 에 있고, 여기는 순서와 정규화만 안다.
     ensureLoggedIn()                       로그인돼 있는가. 자격증명이 있고 auto 단계가 있으면 스스로 로그인해 본다.
     listReservations({from,to})           예약 목록 → [{reservationNo, roomName, checkIn, checkOut, guestName, status, raw}]
     listRooms()                            채널의 객실 목록 → [{roomKey, name}]
     readAvailability({from,to})           날짜별 판매 상태 → [{roomKey, date, state:'open'|'closed'|'sold'|'unknown'}]
     setClosed({roomKey, dates, closed})   마감/재개 → {applied, skipped:[{date, why}]}
     setRate({roomKey, date, price})        요금 입력(JSON 에 rates 절이 있을 때만)
   사람 손이 필요한 상황(2단계 인증 등)은 NeedsHumanError 로 알린다. */
import { StepRunner, getPath } from './runner.js';
import { ymOf, normalizeState, writesLocked, writesLockReason } from './spec.js';
import { addDays, eachDate, parseLooseDate, todayKst } from '../lib/kst.js';
import { normalizeStatus } from '../dashboard/paste.js';
import { scrubSecrets } from '../lib/log.js';
import { loginByForm } from './form-login.js';
import { soft } from '../lib/deadline.js';

/** 400 이지만 인증 문제인가 — 대답 몸의 code 가 「AUT」 로 시작(여기어때 AUT017-400 등 · 0.9.14 · I-336) */
export function isAuthCode400(e) {
  const status = e && (e.status || e.cause?.status);
  const code = e && (e.apiCode || e.cause?.apiCode);
  return status === 400 && typeof code === 'string' && /^AUT/i.test(code);
}

export class NeedsHumanError extends Error {
  constructor(msg, channel) { super(msg); this.name = 'NeedsHumanError'; this.channel = channel; }
}

/* 쓰기 잠금(채널 JSON "writes": false 등 — spec.js writesLockReason)인데 파트너센터에 쓰려 했다는 뜻(D-075).
   ★ 어댑터에도 한 번 더 막는다. 엔진(worker)이 먼저 거르지만, 손막음(hold)처럼 엔진을 안 거치는 길이 있고
     나중에 새 길이 생겨도 **확인 안 된 선택자로 방을 누르는 일**은 여기서 끝난다.
     고장이 아니라 정한 일이므로 사람을 기다리는 표시(pausedWaiting)를 단다 — 경보로 올리지 않는다. */
export class WriteLockedError extends Error {
  constructor(channel, what, why = '채널 JSON "writes": false') {
    super(`${channel}: 쓰기 잠금(${why}) — ${what} 를 하지 않는다(확인 전 선택자). 확인이 끝나면 writes 를 true 로`);
    this.name = 'WriteLockedError'; this.channel = channel; this.writeLocked = true; this.pausedWaiting = true;
  }
}

/* 세션을 빼앗겼을 때 **잠깐 비켜 준다** 는 뜻. 고장이 아니므로 경보를 열지 않는다
   (`pausedWaiting` 은 worker 가 "사람을 기다리는 중" 으로 조용히 넘기는 표시다). */
export class SessionYieldError extends Error {
  constructor(msg, channel) { super(msg); this.name = 'SessionYieldError'; this.channel = channel; this.pausedWaiting = true; }
}

/* ★ 여기어때는 한 계정 동시 로그인이 안 된다(I-010). 세션이 풀리는 이유는 대개
     **사장님이 방금 파트너센터에 들어왔기 때문**이다. 그 자리에서 곧바로 다시 들어가면
     사장님이 튕겨 나가고, 사장님이 또 들어오면 우리가 튕긴다 — 서로 밀어내며 아무도 일을 못 한다.
     그래서 5분은 비켜 준다. 5분이 지나면 우리가 다시 들어가 수집을 이어 간다(소유자 지시, 2026-09-09).
     `.env` 의 RELOGIN_YIELD_MIN 으로 바꾼다 — 그 값은 **loadConfig 가 읽어(cfg.relogin.yieldMs)
     어댑터에 `yieldMs` 로 넘긴다**. 여기서 process.env 를 직접 읽으면 안 된다: 이 모듈은 정적 import 라
     main.js 의 loadEnvFile() 보다 먼저 돌아서 .env 값이 아직 없다(I-046). 아래는 못 받았을 때의 기본값이다. */
export const RELOGIN_YIELD_MS = 5 * 60000;

/* 비켜 줄지 말지를 가르는 창. 우리가 들어간 지 이 시간 안에 세션이 또 풀리면 **누가 밀어낸 것**이고,
   그보다 오래 버텼으면 그냥 만료다 — 만료는 비킬 일이 아니라 그 자리에서 다시 들어갈 일이다. */
export const EVICT_WINDOW_MS = 2 * 60000;

/* setClosed 가 건너뛴 이유. 앞의 둘은 "손댈 필요가 없었다"(정상)이고,
   NOT_FOUND 는 "파트너센터에서 그 자리를 못 찾았다"(실패) — 부르는 쪽이 이 둘을 갈라야 한다. */
export const SKIP_ALREADY = '이미 그 상태';
export const SKIP_HAS_BOOKING = '예약이 들어 있어 손대지 않는다';
export const SKIP_NOT_FOUND = '화면에 그 날짜·객실이 없다';
/* v3.1: 판매 상태 문구를 못 알아본 날 — 캘린더 대조(diffRoom)처럼 할 일 길에서도 **누르지 않는다**(BR-015).
   예전에는 할 일 길(setClosed)이 'unknown' 을 '이미 그 상태' 가 아닌 것으로 보고 눌렀다. */
export const SKIP_UNKNOWN_STATE = '상태 문구를 못 알아봐 손대지 않았다';
/* 0.9.15(모토모토 D-557 · I-350): 파트너센터 판매 현황에 그 날짜가 **어느 객실에도 없다** — 사장님이 그 달을 아직 안 열었다
     (사장님 2026-11-14 「내년 7월이 아마 닫혀있을건데, 아직 일정이 많이 남아서 안열었던 것으로 기억해」 · 「금액 셋팅 문제도 있고 해서」).
   실패가 아니라 「아직 안 열림」 이다 — 그 날은 지금 팔리지도 않는다. 부르는 쪽(outbound.js)은 할 일을 닫지 않고 열어 두었다가
   달이 열린 뒤의 판에 막는다. ⚠ 같은 판에 판매 현황이 **한 칸이라도** 왔을 때만 이 이름을 붙인다(아래 do_setClosed) —
   API 가 통째로 빈손이면(주소 · 모양이 바뀜) 예전처럼 NOT_FOUND(실패 → 경보)다. 조용히 영영 안 막히는 일을 만들지 않는다. */
export const SKIP_NOT_OPEN = '파트너센터에 아직 안 연 날';

function monthsBetween(from, to) {
  const out = [];
  let cur = from.slice(0, 7) + '-01';
  while (cur < to) { out.push(cur); cur = addDays(cur, 32).slice(0, 7) + '-01'; }
  return out;
}

/* 손님 정보를 값으로 만든다. 파트너센터는 같은 것을 숫자로도, '150,000원' 으로도, 객체로도 준다. */

/** 전화번호 — 숫자와 하이픈만 남긴다. 안심번호(0504…)도 그대로 쓸 수 있는 번호다. */
export function onlyPhone(v) {
  if (v == null) return '';
  const s = String(typeof v === 'object' ? (v.number ?? v.phone ?? v.value ?? '') : v);
  const d = s.replace(/[^0-9]/g, '');
  if (d.length < 9 || d.length > 12) return '';       // 전화번호로 볼 수 없는 것은 안 넣는다
  return s.trim().replace(/[^0-9-]/g, '');
}

/* 금액이 객체로 오는 판이 흔하다(payment:{…}). 안에서 금액처럼 생긴 칸을 찾아 쓴다.
   ★ 할인액(discount…)은 **쓰지 않는다** — 그것을 총액 자리에 넣으면 원장의 금액이 틀린다.

   ★★ 2026-09-15: **판매(결제) 금액과 정산(입금예정) 금액을 섞지 않는다.** 파트너센터 한 예약에
      289,000원(판매) 과 257,210원(입금 예정) 이 같이 실려 오는데, 둘을 한 자리에서 찾으면
      어느 쪽이 먼저 잡히느냐로 원장의 금액이 달라진다 — 어제는 판매가, 오늘은 수수료 뗀 값이
      들어가는 식이다. 그래서 찾는 이름을 두 벌로 갈랐다. '금액' 은 **손님이 낸 돈**,
      '정산금액' 은 **우리에게 들어올 돈**이다. */
const MONEY_KEYS = ['amount', 'price', 'value', 'totalAmount', 'totalPrice', 'payAmount', 'paymentAmount',
  'totalPaymentAmount', 'salesAmount', 'totalSalesAmount',
  'salePrice', 'sellPrice', 'finalPrice', 'orderAmount', 'total', 'payment'];

/** 정산(입금 예정) 금액에서만 쓰는 이름. 판매 금액 자리에서는 **이 이름들을 안 본다.** */
const SETTLE_KEYS = ['settleAmount', 'settlementAmount', 'expectedSettleAmount', 'expectedSettlementAmount',
  'settlePrice', 'payoutAmount', 'depositAmount', 'amount', 'price', 'value', 'total', 'settlement'];

/** 금액 — 숫자만 남긴다. **0 을 null 로 접지 않는다**(무료 예약이 '금액 모름' 이 되면 안 된다). */
export function onlyMoney(v, depth = 0, keys = MONEY_KEYS) {
  if (v == null) return null;
  if (typeof v === 'number') return Number.isFinite(v) ? Math.round(v) : null;
  if (typeof v === 'object' && depth < 2) {
    for (const k of keys) {
      if (v[k] != null) {
        const got = onlyMoney(v[k], depth + 1, keys);
        if (got != null) return got;
      }
    }
    return null;
  }
  const d = String(v).replace(/[^0-9]/g, '');
  return d === '' ? null : Number(d);
}

/** 정산(입금 예정) 금액 — 판매 금액과 **다른 칸**이다. 못 찾으면 null(빈칸)이고, 그것 때문에
    예약이 버려지지는 않는다. 원장의 '금액' 자리에는 절대 이 값을 넣지 않는다. */
export function onlySettleMoney(v) { return onlyMoney(v, 0, SETTLE_KEYS); }

/** 참거짓 칸 — true · 'true' · 'Y' · 1 만 참이다. 모르면 거짓(그 줄의 금액을 지우지 않는다). */
export function onlyFlag(v) {
  if (v === true || v === 1) return true;
  return typeof v === 'string' && /^(true|y|yes|1)$/i.test(v.trim());
}

/** 짧은 글자 칸(판매채널 등) — 객체면 이름표를 꺼낸다. 탭·줄바꿈은 표를 깨므로 공백으로, 40자까지. */
/* 0.9.18(모토모토 D-587): 추가 옵션 — 여기어때 PMS 목록 itemList[].addOptionList(파트너센터 예약 상세가 그리는 이름:
   addOptionName · count · unit · perDayOption · countPerDay · stayNights · salePrice · onSitePayment). 취소된 상품(isCanceled)의 옵션은 뺀다.
   한 줄로 — 「미온수 (1회) 100000 | [현장결제] 숯 추가 (1회) 30000」. 대시보드가 이 꼴을 읽는다(api/_ota/core/otaopts.mjs parseAddOptions).
   못 읽으면 ''(대시보드는 빈칸을 「모름」 으로 보고 지우지 않는다). */
export function onlyOptions(v) {
  const list = Array.isArray(v) ? v : (v && typeof v === 'object' ? [v] : []);
  const clean = (s) => String(s ?? '').replace(/[|()\[\]\t\r\n]+/g, ' ').replace(/\s+/g, ' ').trim();
  const out = [];
  for (const el of list) {
    if (!el || typeof el !== 'object' || el.isCanceled === true) continue;
    const inner = Array.isArray(el.addOptionList) ? el.addOptionList
      : Array.isArray(el.orderItemAddOptionList) ? el.orderItemAddOptionList
      : (el.addOptionName != null ? [el] : []);
    for (const o of inner) {
      if (!o || typeof o !== 'object') continue;
      const name = clean(o.addOptionName ?? o.name).slice(0, 40);
      if (!name) continue;
      const unit = clean(o.unit);
      const qty = o.perDayOption && o.countPerDay != null && o.stayNights != null
        ? `${clean(o.countPerDay)}${unit}x${clean(o.stayNights)}박`
        : (o.count != null ? `${clean(o.count)}${unit}` : '');
      const price = Number(o.salePrice);
      out.push(`${o.onSitePayment ? '[현장결제] ' : ''}${name} (${qty})${Number.isFinite(price) && price > 0 ? ' ' + Math.round(price) : ''}`);
    }
  }
  return out.join(' | ').slice(0, 500);
}

export function onlyLabel(v) {
  const raw = v && typeof v === 'object' && !Array.isArray(v)
    ? (v.code ?? v.name ?? v.value ?? v.label ?? '') : v;
  if (raw == null || typeof raw === 'object') return '';
  return String(raw).replace(/\s+/g, ' ').trim().slice(0, 40);
}

/** 인원 — 1 이상의 정수만. */
export function onlyCount(v) {
  const n = Number(String(v ?? '').replace(/[^0-9]/g, ''));
  return Number.isFinite(n) && n > 0 ? n : null;
}

/* 로그인 API 가 200 을 주면서 몸통에 실패 사유를 담아 보내는 판이 있다. 그때 "됐다" 로 넘어가면
   그 뒤 모든 일이 조용히 실패한다. 사유가 될 만한 칸만 뽑아 적는다 — 토큰·개인정보는 안 뽑는다. */
const WHY_KEYS = /^(code|message|msg|error|errorCode|errorMessage|resultCode|resultMessage|status|result|reason|detail)$/i;
export function whyFromBody(body, depth = 0) {
  if (body == null || depth > 3) return '';
  if (typeof body === 'string') return body.slice(0, 120);
  if (typeof body !== 'object') return String(body).slice(0, 120);
  const out = [];
  for (const [k, v] of Object.entries(body)) {
    if (WHY_KEYS.test(k) && (typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean')) {
      out.push(`${k}=${JSON.stringify(v)}`);
    } else if (v && typeof v === 'object' && depth < 3) {
      const inner = whyFromBody(v, depth + 1);
      if (inner) out.push(inner);
    }
    if (out.length >= 6) break;
  }
  return out.join(' ');
}

/**
 * 이 예약이 우리가 물은 창 [a, b) 와 겹치는가.
 * ★ 대실(입실 == 퇴실)은 그 날 하루를 쓰는 예약이다 — [입실, 입실] 로 본다.
 *   숙박은 [입실, 퇴실) 이다(퇴실일 밤은 안 쓴다). 예전에는 대실도 checkOut > a 로 봐서
 *   **창 첫날 대실**이 창 밖으로 밀렸고, 그 한 건뿐인 창은 "물은 기간과 다른 것이 왔다" 로
 *   통째로 실패했다(엔진 inbound.js 는 대실을 통과시킨다 — 규칙이 서로 달랐다).
 */
export function overlapsWindow(r, a, b) {
  if (!r || !r.checkIn || !r.checkOut) return false;
  if (!(r.checkIn < b)) return false;
  return r.checkOut > r.checkIn ? r.checkOut > a : r.checkOut >= a;
}

/** 채널 JSON 의 단계 어디엔가 sniff.proof 가 선언돼 있는가 — 이 채널이 증거를 요구하는지. */
export function declaresProof(node, depth = 0) {
  if (!node || typeof node !== 'object' || depth > 8) return false;
  if (Array.isArray(node)) return node.some((v) => declaresProof(v, depth + 1));
  if (node.sniff && node.sniff.proof) return true;
  /* 단계가 ifExists·forEach 같은 것에 감싸여 있어도 찾는다 — 못 찾으면 "증거 없음" 을 못 알아본다. */
  return Object.values(node).some((v) => declaresProof(v, depth + 1));
}

export class JsonAdapter {
  /**
   * @param {object} o { spec, page, log, artifactsDir, creds?:{loginId,password}, baseUrl?(spec 덮어쓰기), vars?(추가 치환값) }
   */
  constructor(o) {
    this.spec = o.spec;
    this.channel = o.spec.channel;
    this.page = o.page;
    this.log = o.log;
    this.creds = o.creds || null;
    this.baseUrl = o.baseUrl || o.spec.baseUrl;
    this.vars = o.vars || {};
    // 세션을 빼앗겼을 때 비켜 줄 시간(ms). 설정(cfg.relogin.yieldMs)에서 온다 — 없으면 기본 5분.
    this.yieldMs = Number.isFinite(o.yieldMs) && o.yieldMs >= 0 ? Math.round(o.yieldMs) : RELOGIN_YIELD_MS;
    /* 우리가 마지막으로 **직접 로그인한** 시각. 그 로그인이 얼마 못 갔으면 만료가 아니라 밀려난 것이다.
       0 이면 "우리가 들어간 적이 없다"(이미 붙어 있던 세션을 물려받았다)는 뜻이다. */
    this.loggedInAt = 0;
    /* 세션을 잃어서 **되찾은 적이 있는가.** 되찾은 세션마저 곧 풀리면 밀려나는 중이다. */
    this.recoveredOnce = false;
    /* 들어간 지 이 시간 안에 또 풀리면 '밀려났다' 로 본다. 실행기의 가장 짧은 주기가 60초라
       두 주기를 못 버틴 로그인은 스스로 만료된 것이 아니다. */
    this.evictWindowMs = Number.isFinite(o.evictWindowMs) && o.evictWindowMs >= 0 ? Math.round(o.evictWindowMs) : EVICT_WINDOW_MS;
    this.runner = new StepRunner({ page: o.page, baseUrl: this.baseUrl, log: o.log, artifactsDir: o.artifactsDir, channel: this.channel, warmUp: o.spec.warmUp,
      learnFrom: o.spec.api && o.spec.api.learnFrom });
  }

  run(steps, vars) {
    return this.runner.run(steps, { ...this.vars, ...vars });
  }

  /** 마지막으로 예약 목록을 고를 때 **못 붙인 칸**과 **응답에 남아 있던 이름**. 값은 없다. */
  get spareFields() { return this.runner.spareFields || []; }
  get missingFields() { return this.runner.missingFields || []; }
  get pickedFields() { return this.runner.pickedFields || {}; }

  /**
   * 마지막 예약 조회에서 **창마다 우리 창으로 물었다는 증거가 있었는지**.
   * 유입(engine/inbound.js)이 0건을 성공으로 볼지 실패로 볼지 이것으로 정한다(BR-019).
   * proof 를 선언하지 않은 채널(mock·야놀자)은 windows 가 비어 있거나 declared:false 다 — 그때는 지금과 같이 돈다.
   * @returns {{windows:{from:string,toInclusive:string,declared:boolean,proven:boolean|null,provenEmpty:boolean|null,got:number,inWindow:number}[]}}
   */
  get lastAsk() { return { windows: this.askWindows || [] }; }

  /**
   * 하는 일을 감싼다 — 도중에 세션이 풀리면(401·403) **그 자리에서 다시 로그인해 한 번 더 해 본다**.
   * 왜: 여기어때는 한 계정 동시 로그인이 안 돼서(I-010) 사장님이 파트너센터에 들어가는 순간
   * 실행기가 밀려난다. 그때 다음 주기(1~2분)를 기다리면 그 사이 들어온 예약이 늦는다.
   * 두 번은 안 한다 — 정말로 못 들어가는 상황이면 사람을 불러야지 계속 두드리면 안 된다.
   */
  /**
   * 세션을 잃었다 — **비켜 줄 일인지 가른다.**
   *
   * ★ 2026-09-11 실측으로 드러난 것: "붙어 있다가 풀렸으면 비킨다" 는 너무 넓다.
   *   보통의 쿠키 만료도 그 조건에 걸려서, 상주로 돌면 만료 때마다 5분씩 논다.
   *   D-018 이 실제로 막으려던 것은 **서로 밀어내기** 다 — 우리가 되찾으면 사장님이 튕기고,
   *   사장님이 들어오면 우리가 튕기는 그 왕복. 그 왕복은 **우리가 방금 들어갔는데 곧바로 또
   *   풀릴 때만** 생긴다. 그래서 그 경우에만 비킨다. 첫 만료는 그냥 다시 들어간다.
   *
   * @returns {number} 아직 비켜 줄 밀리초. 0 이면 지금 다시 들어가도 된다.
   */
  noteSessionLost(now = Date.now()) {
    if (this.sessionLostAt) return this.yieldMsLeft(now);   // 이미 비키는 중이면 그대로 센다
    /* ★ 시간만으로는 만료와 밀려남을 못 가른다 — 로그인 직후에 끊기는 일은 둘 다에서 생긴다.
         가르는 것은 **다시 들어가 봤는가** 다. 처음 풀린 것은 그냥 만료로 보고 되찾는다.
         되찾았는데 그 세션마저 창 안에 또 풀렸다면, 그때는 누가 우리를 밀어내고 있는 것이다. */
    const 되찾았는데또 = this.recoveredOnce
      && this.loggedInAt > 0 && (now - this.loggedInAt) <= this.evictWindowMs;
    if (!되찾았는데또) return 0;
    this.sessionLostAt = now;
    return this.yieldMsLeft(now);
  }

  /**
   * 우리가 **직접 로그인했다.**
   * @param {{recovery?:boolean}} [o] recovery = 세션을 잃어서 되찾은 것인가(첫 로그인은 아니다)
   */
  noteLoggedIn(o = {}, now = Date.now()) {
    this.wasLoggedIn = true;
    this.loggedInAt = now;
    if (o.recovery) this.recoveredOnce = true;
    this.clearSessionLost();
  }

  /**
   * 일이 됐다 = 세션이 살아 있다. 그 세션이 **창을 넘겨 버텼으면** 건강한 것으로 보고
   * 되찾음 표시를 지운다. 아직 창 안이면 안 지운다 — 30초 뒤에 또 풀릴 수 있고, 그게 밀어내기다.
   */
  noteWorking(now = Date.now()) {
    this.wasLoggedIn = true;
    this.clearSessionLost();
    if (!this.loggedInAt || now - this.loggedInAt > this.evictWindowMs) this.recoveredOnce = false;
  }

  /** 아직 비켜 줘야 할 시간(ms). 0 이면 지금 들어가도 된다. */
  yieldMsLeft(now = Date.now()) {
    if (!this.sessionLostAt) return 0;
    return Math.max(0, this.yieldMs - (now - this.sessionLostAt));
  }

  /** 다시 붙었으면 기억을 지운다 — 다음에 풀릴 때 5분을 처음부터 센다. */
  clearSessionLost() { this.sessionLostAt = 0; }

  async withRelogin(what, fn) {
    try {
      const r = await fn();
      this.noteWorking();           // 일이 됐다는 것은 세션이 살아 있다는 뜻이다
      return r;
    } catch (e) {
      const status = e.status || e.cause?.status;
      /* ★ 0.9.14(I-336): 여기어때는 인증 머리가 없거나 낡으면 401 이 아니라 **400 + code 「AUT…」**(AUT017-400 「부적절한 요청입니다」)를 준다.
           그것도 세션이 풀린 것으로 보고 다시 로그인 · 머리를 다시 주운 뒤 한 번 더 한다. 다른 400(요청 모양 문제)은 예전처럼 그대로 던진다. */
      if (status !== 401 && status !== 403 && !isAuthCode400(e)) throw e;
      if (e instanceof NeedsHumanError) throw e;
      /* ★ 0.9.14(I-336): 400 AUT 는 대개 **머리가 빈 채로 나간 요청**이다(「화면에서 주운 머리: 없음」) — 남이 밀어낸 것이 아니다.
           먼저 화면을 다시 열어 머리를 줍고 한 번 더 해 본다(로그인은 안 건드림). 그래도 AUT 면 아래 다시 로그인으로 — 비켜 주기(5분)는 건너뛴다. */
      let authOnly = false;
      if (status === 400) {
        authOnly = true;
        this.log?.warn(`${this.channel}: ${what} 가 인증 머리 문제로 거절됐다(400 ${e.apiCode || e.cause?.apiCode || ''}) — 화면을 다시 열어 머리를 줍고 한 번 더 해 본다`);
        this.runner.learned = {};
        this.runner.warmedUp = false;
        try {
          const r2 = await fn();
          this.noteWorking();
          return r2;
        } catch (e2) {
          if (!isAuthCode400(e2) || e2 instanceof NeedsHumanError) throw e2;
          e = e2;
        }
      }
      /* ★ **붙어 있다가 밀려난 경우에만** 비켜 준다(ensureLoggedIn 과 같은 규칙, D-018).
           한 번도 못 들어간 401 은 "다른 사람이 들어와 있다" 가 아니라 그냥 "아직 세션이 없다" 다.
           거기서도 5분을 비키면 새로 깐 PC 나 브라우저를 다시 연 직후에 스스로 못 들어간다(I-044). */
      if (this.wasLoggedIn && !authOnly) {
        const left = this.noteSessionLost();
        if (left > 0) {
          throw new SessionYieldError(
            `${this.channel}: ${what} 도중 세션이 풀렸다(HTTP ${status}) — 파트너센터에 다른 로그인이 들어와 있다.` +
            ` ${Math.ceil(left / 60000)}분 뒤에 스스로 다시 들어간다`, this.channel);
        }
      }
      this.log?.warn(`${this.channel}: ${what} 도중 세션이 풀렸다(HTTP ${status}${authOnly ? " · 머리를 다시 주워도 AUT" : ""}) — 다시 로그인하고 한 번 더 해 본다`);
      /* 주워 둔 머리도 그 세션의 것이라 같이 버린다 — 안 그러면 옛 머리를 붙여 또 튕긴다. */
      this.runner.learned = {};
      this.runner.warmedUp = false;
      /* ★ 여기서 isLoggedIn 을 다시 묻지 않는다. 401 은 이미 "세션이 죽었다" 는 분명한 답이고,
           화면은 세션이 없어도 멀쩡히 그려져서 "로그인돼 있다" 고 대답할 수 있다(I-034).
           증거가 있는데 화면에 되물으면 재로그인을 통째로 건너뛴다. */
      await this.relogin();
      this.clearSessionLost();
      /* ★ 여기가 '서로 밀어내기' 가 드러나는 자리다 — 방금 들어갔는데 그 한 번이 또 튕기면
           만료가 아니라 누가 우리를 밀어내고 있는 것이다. 그때만 비켜 준다(D-018). */
      try {
        return await fn();
      } catch (again) {
        const s2 = again.status || again.cause?.status;
        if ((s2 !== 401 && s2 !== 403 && !isAuthCode400(again)) || again instanceof NeedsHumanError) throw again;
        const left = this.noteSessionLost();
        if (left > 0) {
          throw new SessionYieldError(
            `${this.channel}: 다시 들어가자마자 ${what} 가 또 튕겼다(HTTP ${s2}) — 파트너센터에 다른 로그인이 들어와 있다.` +
            ` ${Math.ceil(left / 60000)}분 비켜 주고 스스로 다시 들어간다`, this.channel);
        }
        throw again;
      }
    }
  }

  // ── 로그인 ─────────────────────────────────────────────────
  /** 로그인 확인용 API 를 한 번 불러 본다.
   *  @returns {{loggedIn:true|false|null, status:number|null, why:string}}
   *           loggedIn 이 null 이면 "이걸로는 판단할 수 없다"(우리 요청이 틀렸거나 서버가 흔들린다). */
  async probeLogin(req) {
    let res;
    try {
      res = await this.page.context().request.fetch(this.runner.url(req.url), {
        method: req.method || 'GET', timeout: req.timeout || 15000, failOnStatusCode: false,
      });
    } catch (e) {
      return { loggedIn: null, status: null, why: `불리지 않았다(${String(e.message).slice(0, 80)})` };
    }
    const status = res.status();
    if (status === 401 || status === 403) return { loggedIn: false, status, why: `${status} — 로그인이 아니다` };
    if (status >= 400) return { loggedIn: null, status, why: `${status} 를 줬다` };
    if (!req.expect) return { loggedIn: true, status, why: `${status}` };
    const body = await res.json().catch(() => null);
    if (body === null) return { loggedIn: null, status, why: `${status} 인데 JSON 이 아니다` };
    if (getPath(body, req.expect) != null) return { loggedIn: true, status, why: `${status}` };
    /* 200 을 주면서 몸통이 빈 판 — 로그인 화면을 대신 준 것일 수도, 그냥 객실이 없는 것일 수도 있다.
       어느 쪽인지 우리가 못 가리므로 판단을 화면에 넘긴다. */
    return { loggedIn: null, status, why: `${status} 인데 ${req.expect} 가 비어 있다` };
  }

  /**
   * 지금 로그인돼 있는가.
   * 화면(header·nav)만 보는 것은 믿을 게 못 된다 — 로그인 화면에도 머리띠가 있어서 "로그인돼 있다" 로
   * 잘못 읽으면 그 뒤 작업이 전부 조용히 실패한다. 그래서 `loggedIn.request` 로 **로그인해야만 되는 API**
   * 를 먼저 불러 본다. 다만 그 API 가 401·403 이 아닌 다른 이유로 실패하면 그것으로 로그아웃이라고
   * 우기지 않고 화면으로 넘어간다 — 우리 요청이 틀린 것을 사장님 탓으로 돌리면 안 된다.
   */
  async isLoggedIn() {
    const li = this.spec.login.loggedIn;
    if (li.request) {
      const seen = await this.probeLogin(li.request);
      this.lastLoginCheck = seen;
      /* 401·403 만이 "로그인이 아니다" 라는 분명한 답이다. 그 밖의 실패(400·404·5xx·네트워크)는
         **우리 요청이 틀렸다는 뜻**이지 사장님이 로그아웃됐다는 뜻이 아니다 — 그것으로 로그아웃이라고
         판정하면 방금처럼 직접 로그인한 사람에게도 "아직 로그인 안 됐다" 고 한다. 그때는 화면으로 본다. */
      if (seen.loggedIn === true || seen.loggedIn === false) return seen.loggedIn;
      this.log?.warn(`${this.channel}: 로그인 확인 API 가 ${seen.why} — 화면으로 판단한다(채널 JSON 의 loggedIn.request 를 손볼 것)`);
    }
    const url = this.page.url();
    if (li.urlNotContains && url.includes(li.urlNotContains)) return false;
    /* ★ **없어야 할 것**을 먼저 본다. 있어야 할 것(header·nav)만 보면 로그인 화면도 통과한다 —
         실제로 그렇게 통과해서, 파트너센터가 돌려준 로그인 화면을 "로그인됨" 으로 읽고 그 뒤 모든
         요청이 400 으로 튕겼다(I-034). 비밀번호 칸이 보이면 그건 로그인 화면이다. */
    if (li.notSelector && (await this.page.locator(li.notSelector).count()) > 0) {
      this.lastLoginCheck = { loggedIn: false, status: null, why: `화면에 '${li.notSelector}' 가 있다 — 로그인 화면이다` };
      return false;
    }
    /* Next.js 는 지금 그려진 화면의 경로를 스스로 들고 있다. 우리가 부른 주소와 다르면 딴 데로 보내진 것이다. */
    if (li.pageNot && li.pageNot.length) {
      /* 굳은 렌더러에서는 evaluate 가 안 돌아온다(시간제한 옵션이 없다). 못 읽으면 '모른다' 로 간다. */
      const page = await soft(this.page.evaluate(() => {
        try { return JSON.parse(document.getElementById('__NEXT_DATA__').textContent).page || null; } catch { return null; }
      }), 10000, null);
      if (page && li.pageNot.some((bad) => page === bad || page.startsWith(bad))) {
        this.lastLoginCheck = { loggedIn: false, status: null, why: `화면이 '${page}' 로 그려졌다 — 로그인 화면으로 보내졌다` };
        return false;
      }
    }
    if (li.selector) return (await this.page.locator(li.selector).count()) > 0;
    return true;
  }

  /**
   * 화면으로 로그인해 본다 — API 가 거절할 때의 **두 번째 길**.
   * 여기어때는 우리 로그인 요청을 400 으로 거절한다(I-026). 요청 모양을 맞추려면 실측이 필요한데,
   * 화면을 채우는 쪽은 파트너센터의 자기 자바스크립트가 요청을 만들어 주므로 **몰라도 된다.**
   * @returns {Promise<boolean>} 실제로 로그인됐는지(isLoggedIn 으로 확인한 결과)
   */
  async tryFormLogin(why) {
    const L = this.spec.login;
    if (L.form === false) return false;                  // 채널이 명시적으로 껐다
    const url = this.runner.url(L.form?.url || L.loginUrl || L.checkUrl || L.url);
    this.log?.warn(`${this.channel}: 화면으로 로그인해 본다(${L.form?.url || '로그인 화면'}) — 까닭: ${why}`);
    const r = await loginByForm({ page: this.page, url, creds: this.creds, log: this.log, channel: this.channel })
      .catch((e) => ({ ok: false, why: e.message }));
    if (!r.ok) { this.log?.warn(`${this.channel}: 화면 로그인도 못 했다 — ${r.why}`); return false; }
    if (L.twoFactor?.selector && (await this.page.locator(L.twoFactor.selector).count().catch(() => 0)) > 0) {
      throw new NeedsHumanError(`${this.channel}: 2단계 인증이 떠서 사람이 필요하다 — npm run pair -- ${this.channel}`, this.channel);
    }
    /* ★ 제출 직후 한 번만 보고 포기하면 안 된다 — 파트너센터가 리다이렉트·토큰 교환을 끝내기 전에
         물으면 "아직 로그인 아님" 으로 읽힌다. 느린 PC 에서 자동 복구가 **될 때도 있고 안 될 때도 있는**
         물건이 된다(실제로 e2e 가 한 번은 통과하고 한 번은 실패했다). 몇 번 더 물어본다. */
    let ok = false;
    for (let i = 0; i < 3 && !ok; i++) {
      if (i) await this.page.waitForTimeout(1500);
      await this.page.goto(this.runner.url(L.checkUrl || L.url), { waitUntil: 'domcontentloaded' }).catch(() => {});
      if (L.loggedIn.waitMs) await this.page.waitForTimeout(L.loggedIn.waitMs);
      ok = await this.isLoggedIn();
    }
    this.log?.[ok ? 'info' : 'warn'](`${this.channel}: 화면 로그인 ${ok ? '성공' : '실패'}` +
      (ok ? '' : ` · 판정: ${this.lastLoginCheck?.why || '알 수 없다'}`));
    return ok;
  }

  /** 묻지 않고 **그냥 다시 로그인한다.** 401·403 을 받은 뒤처럼 세션이 죽은 것이 분명할 때 쓴다. */
  async relogin() {
    const L = this.spec.login;
    if (!L.auto || !this.creds) {
      throw new NeedsHumanError(
        `${this.channel}: 세션이 풀렸는데 스스로 들어갈 자격증명이 없다 — npm run pair -- ${this.channel} 로 저장할 것`,
        this.channel);
    }
    try {
      await this.run(L.auto, { loginId: this.creds.loginId, password: this.creds.password });
    } catch (e) {
      const status = e.status || e.cause?.status;
      if (status === 401 || status === 403) {
        throw new NeedsHumanError(
          `${this.channel}: 저장된 아이디·비밀번호로 다시 로그인이 거절됐다(HTTP ${status}) — npm run pair -- ${this.channel} --wipe`,
          this.channel);
      }
      /* 그 밖의 거절(400·404·422 = 요청 모양이 다르다)은 화면으로 해 본다. 여기서 그냥 던지면
         유입·반영이 통째로 서고, 사람이 올 때까지 그 밤들이 계속 팔린다(I-026). */
      if (await this.tryFormLogin(`다시 로그인 API 가 ${status || '오류'} 를 줬다`)) {
        this.noteLoggedIn({ recovery: true });
        this.log?.info(`${this.channel}: 화면으로 다시 로그인했다`);
        return true;
      }
      throw e;
    }
    if (L.twoFactor && L.twoFactor.selector && (await this.page.locator(L.twoFactor.selector).count()) > 0) {
      throw new NeedsHumanError(`${this.channel}: 2단계 인증이 떠서 사람이 필요하다 — npm run pair 로 다시 페어링할 것`, this.channel);
    }
    if (L.loggedIn.waitMs) await this.page.waitForTimeout(L.loggedIn.waitMs);
    this.noteLoggedIn({ recovery: true });
    this.log?.info(`${this.channel}: 다시 로그인했다`);
    return true;
  }

  /** 시작 페이지를 열어 로그인 여부를 본다. 안 돼 있으면 자동 로그인을 시도한다. 결과 true/false. */
  async ensureLoggedIn() {
    const L = this.spec.login;
    await this.page.goto(this.runner.url(L.checkUrl || L.url), { waitUntil: 'domcontentloaded' });
    if (L.loggedIn.waitMs) await this.page.waitForTimeout(L.loggedIn.waitMs);
    if (await this.isLoggedIn()) { this.wasLoggedIn = true; this.clearSessionLost(); return true; }
    if (!L.auto) return false;
    /* ★ **붙어 있다가 풀린 경우에만** 5분 비켜 준다. 그때는 누가 들어와 우리를 밀어낸 것이고,
         곧바로 되찾으면 사장님과 서로 밀어내기 때문이다(D-018).
         아직 한 번도 안 붙은 첫 시작은 기다릴 이유가 없다 — 기다리면 실행기가 5분 동안 아무 일도 안 한다. */
    if (this.wasLoggedIn) {
      const left = this.noteSessionLost();
      if (left > 0) {
        throw new SessionYieldError(
          `${this.channel}: 파트너센터에 다른 로그인이 들어와 있다 — ${Math.ceil(left / 60000)}분 비켜 주고 스스로 다시 들어간다`,
          this.channel);
      }
    }
    if (!this.creds) {
      /* 새로 돌릴 때 여기서 걸리면 원인이 하나뿐이다 — 페어링할 때 아이디·비밀번호를 저장하지 않았다.
         그러면 세션이 풀릴 때마다 사람이 붙어야 한다. 로그에 무엇을 하면 되는지 적어 둔다. */
      this.log?.warn(`${this.channel}: 로그인이 풀렸는데 저장된 아이디·비밀번호가 없어 스스로 못 들어간다 — npm run pair -- ${this.channel} 로 저장할 것`);
      return false;
    }
    this.log?.info(`${this.channel}: 로그인이 풀려 있어 저장된 자격증명으로 다시 로그인한다`);
    let autoVars = {};
    try {
      autoVars = await this.run(L.auto, { loginId: this.creds.loginId, password: this.creds.password });
    } catch (e) {
      const status = e.status || e.cause?.status;
      /* 401·403 = 아이디·비밀번호가 틀렸거나 막힌 계정이다. 다시 해도 같으니 사람을 부른다. */
      if (status === 401 || status === 403) {
        throw new NeedsHumanError(
          `${this.channel}: 저장된 아이디·비밀번호로 로그인이 거절됐다(HTTP ${status}) — npm run pair -- ${this.channel} --wipe 로 다시 페어링할 것`,
          this.channel);
      }
      /* ★ 400·404·422 = **우리가 보낸 요청이 파트너센터가 받는 모양이 아니다**(빠진 항목·달라진 주소).
           이것을 "비밀번호가 틀렸다" 로 말하면 사장님이 멀쩡한 비밀번호를 계속 다시 넣게 된다.
           스스로는 못 들어가니 false 로 돌려 사람이 페어링하게 하고, 무엇이 문제인지 그대로 적는다. */
      if (status >= 400 && status < 500) {
        /* ★ 여기서 false 로 끝내면 **세션이 만료될 때마다 사람이 붙어야 한다** — 24시간 무인이 아니게 된다.
             400 은 "요청 모양이 다르다" 는 뜻이지 "못 들어간다" 가 아니다. 화면으로 해 보면 된다(I-026). */
        this.log?.warn(`${this.channel}: 로그인 API 가 우리 요청을 거절했다(HTTP ${status}) — 비밀번호 문제가 아니라 요청 형식이 다르다`);
        if (await this.tryFormLogin(`로그인 API 가 ${status} 를 줬다`)) { this.noteLoggedIn({ recovery: this.wasLoggedIn }); return true; }
        /* ★ 이 줄에 **"비밀번호 문제가 아니다"** 가 반드시 있어야 한다. 없으면 사장님이 멀쩡한
             비밀번호를 몇 번이고 다시 넣는다. 사장님이 보는 것은 error 줄이다. */
        this.log?.error(`${this.channel}: 스스로 못 들어갔다 — 로그인 API 가 HTTP ${status} 로 거절했고` +
          ' (비밀번호 문제가 아니라 요청 형식이 파트너센터와 다르다) 화면으로도 못 들어갔다.' +
          ` npm run pair -- ${this.channel} 로 사람이 한 번 들어가면 계속 돈다 (${String(e.message).slice(0, 200)})`);
        return false;
      }
      throw e;
    }
    if (L.twoFactor && L.twoFactor.selector && (await this.page.locator(L.twoFactor.selector).count()) > 0) {
      throw new NeedsHumanError(`${this.channel}: 2단계 인증이 떠서 사람이 필요하다 — npm run pair 로 다시 페어링할 것`, this.channel);
    }
    if (L.loggedIn.waitMs) await this.page.waitForTimeout(L.loggedIn.waitMs);
    let ok = await this.isLoggedIn();
    if (!ok && await this.tryFormLogin('API 로는 못 들어갔다')) ok = true;
    if (!ok) {
      /* ★ "했는데도 안 됐다" 만 말하면 고칠 수가 없다. 로그인 API 가 200 과 함께 돌려준 **사유 칸**을
           적는다 — 기기 확인·잠금·다른 곳에서 로그인 같은 것이 여기 담겨 온다. 토큰은 안 적는다. */
      const said = Object.entries(autoVars)
        .filter(([k]) => /res|login/i.test(k))
        .map(([k, v]) => `${k}: ${whyFromBody(v)}`)
        .filter((t) => t.split(': ')[1])
        .join(' | ');
      const seen = this.lastLoginCheck ? ` · 판정: ${this.lastLoginCheck.why}` : '';
      this.log?.warn(`${this.channel}: 자동 로그인을 했는데도 로그인 상태가 아니다${seen}` +
        (said ? ` · 파트너센터가 준 말: ${scrubSecrets(said)}` : ' · 응답에 사유가 없다') +
        ` — npm run pair -- ${this.channel} 로 사람이 한 번 들어가 볼 것`);
    }
    /* ★ 여기로 오는 것은 **이미 붙어 있다가 풀려서** 다시 들어온 경우이거나(wasLoggedIn) 첫 시작이다.
         전자를 '되찾음' 으로 안 찍으면 recoveredOnce 가 영영 안 켜져서, 밀어내기 판정이 이 길에서는
         죽은 가지가 된다 — 사장님이 파트너센터를 여는 동안 1분마다 서로 튕긴다(D-018 이 무력해진다).
         첫 시작(wasLoggedIn=false)은 지금처럼 안 기다린다(I-044). */
    if (ok) this.noteLoggedIn({ recovery: this.wasLoggedIn });
    return ok;
  }

  // ── 예약 ───────────────────────────────────────────────────
  listReservations({ from, to }) {
    return this.withRelogin('listReservations', () => this.do_listReservations({ from, to }));
  }

  async do_listReservations({ from, to }) {
    const R = this.spec.reservations;
    const out = [];
    /* ★ 창마다 "우리 창으로 물었다는 증거가 있었는가" 를 남긴다. 유입(engine/inbound.js)이 이것을 보고
         0건을 성공으로 넘길지 실패로 볼지 정한다(BR-019). 값은 담지 않는다 — 날짜·건수뿐이다. */
    this.askWindows = [];
    /* 이 채널이 증거를 요구하는가(채널 JSON 이 sniff.proof 를 선언했는가). 단계가 안 돌거나
       sniff 없는 단계로 바뀌면 lastAsk 가 안 남는데, 그때 "증거 없음" 을 못 알아보면 안 된다. */
    const declares = declaresProof(R.steps);
    /* 거르개 효험은 그 API 의 성질이지 창의 성질이 아니다 — 한 바퀴에 한 번만 확인한다(D-001). */
    this.runner.probeVerdicts = new Map();
    let a = from;
    while (a < to) {
      const b = addDays(a, R.maxDays) < to ? addDays(a, R.maxDays) : to;
      const toInclusive = addDays(b, -1);   // 파트너센터 조회는 보통 끝날 포함
      const before = out.length;
      /* ★ 창마다 지운다. 안 지우면 두 번째 창이 첫 번째 창의 증거를 물려받는다 —
           지금은 단계가 sniff 하나뿐이라 우연히 안 겹치지만, 그런 우연에 기대면 안 된다. */
      this.runner.lastAsk = null;
      const vars = await this.run(R.steps, { from: a, to: b, toInclusive, ym: ymOf(a, this.spec.availability.ymFormat) });
      for (const row of vars[R.result || 'rows'] || []) out.push(this.normalizeReservation(row));
      const ask = this.runner.lastAsk || null;
      const got = out.slice(before);
      /* ★ 증거가 없으면 여기서 멈춘다. 화면 기본 거르개('예약일 + 일별 + 오늘')가 준 오늘치 목록을
           우리 창 180일치의 전부로 오해하면, 대시보드는 나머지 예약을 모르고 그 날을 계속 판다(BR-019). */
      if (declares && !(ask && ask.proven)) {
        throw new Error(`우리 창(${a} ~ ${toInclusive})으로 물었다는 증거가 없는 목록이다 — ` +
          `그 목록을 그 기간의 전부로 볼 수 없다(예약 ${got.length}건). ` +
          '채널 JSON 의 reservations.steps[].sniff 의 ask·query 를 볼 것');
      }
      /* ★ 창 대조 — 판매 상태(readAvailability)에는 있는 검사가 예약에만 없었다. **버리지는 않는다**:
           파트너센터가 창을 무시하고 전부 주는 것은 우리에게 손해가 아니고, 창 밖 줄이 있다는 사실
           자체가 "질의가 안 먹었다" 의 단서이기 때문이다. 하나도 안 겹치면 그때는 던진다.
           ★ 대실(입실 == 퇴실)은 그 날 하루를 쓰는 예약이다. checkOut > a 로만 보면 창 첫날 대실이
             창 밖으로 밀려, 그 한 건뿐인 창이 통째로 실패한다(엔진은 대실을 통과시킨다 — 규칙이 서로
             달랐다). 대실은 [입실, 입실] 로, 숙박은 [입실, 퇴실) 로 본다. */
      const inWindow = got.filter((r) => overlapsWindow(r, a, b)).length;
      this.askWindows.push({ from: a, toInclusive, proven: ask ? ask.proven : null, provenEmpty: ask ? ask.provenEmpty : null,
        declared: declares, got: got.length, inWindow });
      if (got.length && !inWindow) {
        throw new Error(`우리가 물은 기간과 다른 것이 왔다 — ${a} ~ ${toInclusive} 를 물었는데 ` +
          `받은 ${got.length}건이 하나도 그 안에 안 든다. 조회 기준(입실일인지 예약일인지)을 볼 것`);
      }
      a = b;
    }
    return out.filter((r) => r.reservationNo);
  }

  normalizeReservation(row) {
    const m = this.spec.reservations.fields || {};
    const pick = (k) => row[m[k] || k];
    /* ★ 하드블럭(채널이 미리 사 둔 방)은 판매 금액이 손님 값이 아니다 — 파트너센터도 그 줄에는 판매 금액을
         안 그린다(공개 JS: `!e.isHardBlock && "판매 금액 …"`). 입금 예정 금액은 그대로 둔다(2026-10-13). */
    const hard = onlyFlag(pick('hardBlock'));
    return {
      reservationNo: String(pick('reservationNo') ?? '').trim(),
      roomName: String(pick('roomName') ?? '').trim(),
      checkIn: parseLooseDate(pick('checkIn')) || '',
      checkOut: parseLooseDate(pick('checkOut')) || '',
      guestName: String(pick('guestName') ?? '').trim(),
      status: normalizeStatus(pick('status')),
      /* 손님 정보 — 대시보드 예약표(bookings)의 guest_phone·amount·party_size·memo 자리다.
         못 잡으면 '' 또는 null 이고, 그것 때문에 예약이 버려지지는 않는다(있는 것만 채운다). */
      guestPhone: onlyPhone(pick('guestPhone')),
      amount: hard ? null : onlyMoney(pick('amount')),
      /* 정산(입금 예정) 금액 — 판매 금액에서 수수료를 뗀 값이다. 둘은 **다른 숫자**라
         한 칸에 섞으면 결제·정산 내역이 서로 안 맞는다(2026-09-15). */
      settleAmount: onlySettleMoney(pick('settleAmount')),
      partySize: onlyCount(pick('partySize')),
      memo: String(pick('memo') ?? '').replace(/\s+/g, ' ').trim().slice(0, 500),
      /* 판매채널 — 여기어때 PMS 목록의 channelType(YEOGI · CHANNEL = 연동 예약사이트 · PMS_HOMEPAGE · PMS_MANUAL).
         글자 그대로 보낸다. 무엇을 「네이버예약」 으로 볼지는 대시보드가 정한다(fees.mjs saleChannelOf · D-108). */
      saleChannel: onlyLabel(pick('saleChannel')),
      /* 0.9.18: 추가 옵션(PMS 목록에서 빌려 온 itemList — sniff.enrich) */
      addOptions: onlyOptions(pick('addOptions')),
      raw: row,
    };
  }

  // ── 객실 ───────────────────────────────────────────────────
  listRooms() {
    return this.withRelogin('listRooms', () => this.do_listRooms());
  }

  async do_listRooms() {
    const S = this.spec.rooms;
    const vars = await this.run(S.steps, {});
    /* 이름이 빈 문자열인 것도 '없는 것' 으로 본다 — ?? 는 '' 를 그냥 통과시켜서
       이름 없는 객실이 만들어지고, 그것이 매핑을 헝클어뜨린다. */
    return (vars[S.result || 'rooms'] || []).map((r) => ({
      roomKey: String(r.roomKey || r.name || '').trim(),
      name: String(r.name || r.productTitle || r.roomKey || '').trim(),
    }))
      .filter((r) => r.roomKey);
  }

  // ── 판매 상태 ───────────────────────────────────────────────
  readAvailability({ from, to }) {
    return this.withRelogin('readAvailability', () => this.do_readAvailability({ from, to }));
  }

  async do_readAvailability({ from, to }) {
    const A = this.spec.availability;
    const out = [];
    for (const first of monthsBetween(from, to)) {
      /* 채널마다 부르는 방식이 다르다 — 어떤 곳은 연·월 하나(ym), 여기어때는 그 달의 날짜를 쉼표로 나열한다.
         둘 다 쓸 수 있게 같이 넘긴다. monthDates 는 그 달 1일~말일. */
      const monthEnd = addDays(first, 32).slice(0, 7) + '-01';
      const monthDates = eachDate(first, monthEnd).join(',');
      /* v3.1: monthFrom = 그 달 1일과 물은 첫날 중 늦은 날. 야놀자 판매 캘린더는 '그 날부터 그 달 끝까지' 를 돌려주고,
           화면도 오늘 날짜로 묻는다 — 이번 달은 지난 날(1일)부터 묻지 않는다. 여기어때는 이 값을 안 쓴다. */
      const monthFrom = from > first ? from : first;
      const vars = await this.run(A.read.steps, { ym: ymOf(first, A.ymFormat), from, to, monthFirst: first, monthFrom, monthDates });
      for (const c of vars[A.read.result || 'cells'] || []) {
        const date = parseLooseDate(c.date);
        if (!date || date < from || date >= to) continue;
        out.push({ roomKey: String(c.roomKey ?? '').trim(), date, state: normalizeState(c.state, A.states), raw: c });
      }
    }
    return out;
  }

  /**
   * 마감(closed=true)/재개(false). 이미 그 상태면 건너뛰고, 예약이 든 날(sold)은 손대지 않는다.
   * @returns {{applied:number, skipped:Array<{date:string, why:string}>}}
   */
  setClosed({ roomKey, dates, closed }) {
    /* ★ 잠겨 있으면 판매 상태 읽기도 하지 않고 곧바로 거절한다 — 누를 일이 없으니 읽을 까닭도 없다.
       ★ v3: "writes": ["setClosed"] 면 이것만 열린다(D-080). 요금(setRate)은 아래 writesLocked(전부) 로 계속 잠긴다. */
    if (writesLocked(this.spec, 'setClosed')) return Promise.reject(new WriteLockedError(this.channel, closed ? '방막기' : '방열기', writesLockReason(this.spec, 'setClosed')));
    return this.withRelogin('setClosed', () => this.do_setClosed({ roomKey, dates, closed }));
  }

  /* 0.9.16: 오늘 판매 현황(「API 가 살아 있나」 · 「이 객실이 살아 있나」 의 증거). 한 판에 할 일이 여럿이라 5분 담아 둔다.
       빈손이면 아래 판단은 늘 예전처럼 「못 찾음」(실패 → 경보) 쪽으로 간다. 못 읽으면(오류) 0.9.15 처럼 그대로 던진다. */
  #today = null;
  async #todayCells() {
    const t0 = todayKst();
    if (this.#today && this.#today.day === t0 && Date.now() - this.#today.at < 5 * 60000) return this.#today.cells;
    const cells = await this.readAvailability({ from: t0, to: addDays(t0, 1) });
    this.#today = { day: t0, at: Date.now(), cells };
    return cells;
  }

  async do_setClosed({ roomKey, dates, closed }) {
    const A = this.spec.availability;
    const want = closed ? 'closed' : 'open';
    const steps = closed ? A.close.steps : A.open.steps;
    const skipped = [];
    let applied = 0;
    if (!dates.length) return { applied, skipped };
    const from = dates[0], to = addDays(dates[dates.length - 1], 1);
    const cells = await this.readAvailability({ from, to });
    const current = new Map(cells.filter((c) => c.roomKey === roomKey).map((c) => [c.date, c.state]));
    /* 0.9.15: 그 날짜가 어느 객실에도 없으면 「아직 안 연 날」 후보다. 판매 현황 API 가 살아 있다는 증거(한 칸이라도)가
         이 판에 없으면 오늘 칸을 한 번 더 물어 본다 — 그것도 빈손이면 API 가 고장 난 것이라 예전처럼 NOT_FOUND 다. */
    const listed = new Set(cells.map((c) => c.date));
    let apiAlive = cells.length > 0;
    if (!apiAlive && dates.some((d) => !listed.has(d))) {
      apiAlive = (await this.#todayCells()).length > 0;
    }
    /* 0.9.16(모토모토 D-566 · I-354): 다른 객실은 그 날을 열었는데 **이 객실만** 판매 현황에 없다 — 사장님이 달을 객실마다 따로 연다
         (요금을 넣은 방부터 연다 · 0.9.15 는 「어느 객실에도 없는 날」 만 「아직 안 연 날」 로 봐서, 한 방이라도 연 날의 나머지 방은
         「못 찾음」 → 3번 실패 → 「마감 실패」 가 그대로 났다). 아래 둘이 **다 맞을 때만** 「아직 안 연 날」 이다:
           ① 이 객실이 살아 있다 — 오늘 판매 현황(또는 이 판에 읽은 다른 날)에 이 객실이 있다. 매핑이 틀린 방은 오늘도 없다 → 예전처럼 「못 찾음」.
           ② 그 날 판매 현황의 객실이 **모두 오늘도 있는 객실**이다 — 그 날에만 나오는 새 객실(같은 방을 철마다 다른 상품으로 판다)이 있으면
              이 방이 그 상품으로 팔리고 있을 수 있다(매핑에 없는 상품) → 예전처럼 「못 찾음」(경보). 조용히 안 막히는 길을 만들지 않는다. */
    const byDate = new Map();
    for (const c of cells) { if (!byDate.has(c.date)) byDate.set(c.date, new Set()); byDate.get(c.date).add(c.roomKey); }
    let todayKeys = null;
    const roomNotOpenYet = async (date) => {
      if (todayKeys === null) todayKeys = new Set((await this.#todayCells()).map((c) => c.roomKey));
      const alive = todayKeys.has(roomKey) || current.size > 0;
      return alive && [...(byDate.get(date) || [])].every((k) => todayKeys.has(k));
    };
    for (const date of dates) {
      const state = current.get(date);
      if (state === undefined) {
        const why = !apiAlive ? SKIP_NOT_FOUND
          : !listed.has(date) ? SKIP_NOT_OPEN
          : (await roomNotOpenYet(date)) ? SKIP_NOT_OPEN : SKIP_NOT_FOUND;
        skipped.push({ date, why });
        continue;
      }
      if (state === want) { skipped.push({ date, why: SKIP_ALREADY }); continue; }
      if (state === 'sold') { skipped.push({ date, why: SKIP_HAS_BOOKING }); continue; }
      if (state === 'unknown') { skipped.push({ date, why: SKIP_UNKNOWN_STATE }); continue; }
      await this.run(steps, { roomKey, date, ym: ymOf(date, A.ymFormat) });
      applied++;
    }
    if (applied && A.verify !== false) {
      const after = new Map((await this.readAvailability({ from, to })).filter((c) => c.roomKey === roomKey).map((c) => [c.date, c.state]));
      const wrong = dates.filter((d) => current.get(d) !== undefined && current.get(d) !== 'sold' && current.get(d) !== 'unknown' && after.get(d) !== want);
      if (wrong.length) throw new Error(`${this.channel}: ${roomKey} ${wrong.join(', ')} 을(를) ${closed ? '마감' : '재개'}했는데 화면이 그대로다`);
    }
    return { applied, skipped };
  }

  // ── 요금 ───────────────────────────────────────────────────
  /** 이 채널에 쓰면 안 되는가(spec.js writesLockReason). 여기어때(칸 없음)는 false — 지금처럼 쓴다. */
  get writesLocked() { return writesLocked(this.spec); }

  /* 잠겨 있으면 rates 절이 있어도 '요금 넣을 줄 모른다' 로 답한다 — rates.js 가 조용히 건너뛴다. */
  get canSetRates() { return !this.writesLocked && !!(this.spec.rates && this.spec.rates.set); }

  async setRate({ roomKey, date, price, minNights }) {
    if (this.writesLocked) throw new WriteLockedError(this.channel, '요금 입력', writesLockReason(this.spec));
    if (!this.canSetRates) throw new Error(`${this.channel}: 요금 입력 단계가 JSON 에 없다`);
    await this.run(this.spec.rates.set.steps, { roomKey, date, price, minNights: minNights ?? 1, ym: ymOf(date, this.spec.availability.ymFormat) });
    return true;
  }
}

export { eachDate };
