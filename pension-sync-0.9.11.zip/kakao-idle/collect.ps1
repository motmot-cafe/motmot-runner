﻿<#
  ============================================================
  카톡 휴면방 수집기 — 서버 PC 에서 돈다 (D-134)

  하는 일
    1) 켜져 있는 PC 카카오톡의 「채팅」 목록 창을 찍는다(창을 앞으로 가져오지 않는다 · PrintWindow).
    2) 윈도우에 들어 있는 글자 인식(Windows.Media.Ocr, 한국어)으로 글자와 위치를 읽는다.
    3) 목록을 맨 위부터 끝까지 조금씩 내려 가며 1~2 를 되풀이한다(장끼리 겹치게).
    4) 읽은 글자 조각을 그대로 https://motmot.co.kr/api/push?op=kakao_push 로 보낸다.
       「방 이름 · 마지막 대화 날짜」 로 바꾸는 판정은 **서버**가 한다(api/_kakao.mjs) —
       카톡 화면이 바뀌어도 이 PC 는 손대지 않고 서버만 고치면 되게.
    5) 목록을 맨 위로 돌려 놓고, 정한 분(기본 30분)만큼 쉰다.

  ★ 대화 내용(미리보기)은 서버로 가기는 하지만 서버가 **버린다** — 표에는 방 이름과 날짜만 남는다.
  ★ 사람이 이 PC 를 만지고 있으면(1분 안에 키보드 · 마우스 입력) 최대 10분 기다렸다가 찍는다(-Once 는 바로).
  ★ 「지금 한 번 읽기」(-OpenNow · 실행기 화면 단추)는 1분 규칙 없이 단체방도 연다 — 누른 사람이 열라고 한 것이다(D-164).
    그래도 회차 도중 키보드 · 마우스를 만지면 방 열기를 멈춘다(방 창이 손 밑에서 뜨면 치던 글자가 손님 방에 들어갈 수 있다).
  ★ 카톡을 여러 개 켜 둔 PC(개인 카톡은 샌드박스 · 다른 윈도우 사용자로 — D-175)에서는 **이 수집기와 같은 윈도우 사용자이고 샌드박스 밖인 카톡**만
    업무 카톡으로 본다. 그런 카톡이 하나뿐이 아니면 그 회차는 읽지도 열지도 않고 서버에 그 까닭을 보낸다(개인 톡방을 건드리지 않게).
  ★ 관리자 화면 「지금 읽기」(D-172) — 쉬는 동안 30초마다 서버(op=kakao_poll)에 묻고, 부탁이 있으면 바로 **보통 회차**를 돈다
    (그 PC 를 누가 쓰는 중이면 기다리고 · 방은 1분 넘게 안 만질 때만 — 부탁한 사람은 그 PC 앞에 없다).

  실행
    powershell -NoProfile -ExecutionPolicy Bypass -File collect.ps1           # 계속 돈다(시작프로그램용)
    powershell -NoProfile -ExecutionPolicy Bypass -File collect.ps1 -Once     # 한 번만
    powershell -NoProfile -ExecutionPolicy Bypass -File collect.ps1 -Once -OpenNow   # 한 번만 · 방도 바로 연다(도는 수집기가 있으면 그쪽에 부탁)
    powershell -NoProfile -ExecutionPolicy Bypass -File collect.ps1 -Once -DryRun   # 보내지 않고 last-scan.json 만
  설정: 같은 폴더 config.json (config.example.json 을 복사해 열쇠를 넣는다 · 저장소에 안 들어간다)
  기록: 같은 폴더 collect.log · 마지막으로 읽은 것: last-scan.json (둘 다 이 PC 에만)

  ⚠ 이 파일은 **UTF-8 BOM** 으로 저장돼 있어야 한다 — 윈도우 PowerShell 5.1 은 BOM 이 없으면
    한글(「카카오톡」 창 이름 등)을 깨뜨려 창을 못 찾는다.
  ============================================================
#>
param(
  [switch]$Once,
  [switch]$DryRun,
  [switch]$OpenNow,           # 「지금 한 번 읽기」 — 1분 규칙 없이 방도 연다(-Once 와 함께 · D-164)
  [string]$Config = "",
  [string]$StateDir = ""      # 기록 · 상태를 둘 곳. 실행기 화면이 띄울 때는 pension-sync\state\kakao-idle (업데이트가 안 덮는 자리)
)

$ErrorActionPreference = 'Stop'
# 진행 막대를 안 그린다 — 콘솔 없이 뜬 수집기(실행기가 띄운 것)에서 막대를 그리려다 「핸들이 잘못되었습니다」 로 멈출 수 있다(보내기 Invoke-RestMethod).
$ProgressPreference = 'SilentlyContinue'
$VER = '2026.10.23-3'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $Config) { $Config = Join-Path $Here 'config.json' }
$Base = if ($StateDir) { $StateDir } else { $Here }
if (-not (Test-Path $Base)) { [void](New-Item -ItemType Directory -Force $Base) }
$LogPath = Join-Path $Base 'collect.log'
# 시작하다 멈추면(C# 붙이기 · 글자 인식 엔진 · 설정 등) 그 까닭을 기록에 남기고 나간다 — 콘솔 없이 뜬 수집기는 화면에 아무것도 못 보여 줘
# 「켜긴 했는데 자리를 안 잡았습니다」 만 남고 까닭이 없었다(2026-10-17 서버 PC). 회차 안의 오류는 안쪽 try 가 먼저 받는다.
trap {
  $stopLine = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') + '  멈춤: ' + $_.Exception.Message
  try { Add-Content -Path $LogPath -Value $stopLine -Encoding UTF8 } catch { }
  try { Write-Host $stopLine } catch { }                            # 「지금 한 번 읽기」 는 화면이 이것을 흘려 보여 준다(콘솔 없으면 조용히 넘어간다)
  exit 1
}
$LastScanPath = Join-Path $Base 'last-scan.json'
# 실행기 화면(실행기.exe 「카톡 휴면방」)이 읽는 자리 — 지금 상태 · 도는 수집기 번호 · 「지금 한 번」 깃발
$StatusPath = Join-Path $Base 'status.json'
$PidPath = Join-Path $Base 'collector.pid'
$NowFlag = Join-Path $Base 'now.flag'
# 이번 회차는 1분 규칙 없이 방을 여나 — -OpenNow(한 번 읽기) · 도는 수집기는 회차마다 「지금 한 번」 깃발에서 정한다(Test-OpenNowFlag)
$script:OpenNow = [bool]$OpenNow
# 이 수집기가 뜬 때 — 「지금 한 번」 깃발은 그 뒤에 꽂힌 것만 믿는다(끄고 켜는 사이 남은 부탁이 사람 없는 때 방을 열지 않게) · 「카톡만 끄기」 깃발도 이것과 견준다
$script:Born = $null; try { $script:Born = (Get-Process -Id $PID).StartTime } catch { }

function Write-Status($h) {
  $h['ver'] = $VER
  $h['pid'] = $PID
  $h['loop'] = -not $Once
  try { Set-Content -Path $StatusPath -Value (($h | ConvertTo-Json -Depth 4 -Compress)) -Encoding UTF8 } catch { }
}

# 기록 — **파일 먼저**, 화면은 그다음(되면). 실행기가 띄운 수집기는 콘솔이 없어 화면에 쓰기(Write-Host)가
# 「핸들이 잘못되었습니다」 로 실패한다 — 예전에는 그것이 맨 앞이라 첫 기록에서 수집기가 통째로 멈추고 파일에도 아무것도 안 남았다(2026-10-17).
function Write-Log([string]$msg) {
  $line = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') + '  ' + $msg
  try {
    if ((Test-Path $LogPath) -and ((Get-Item $LogPath).Length -gt 1MB)) {
      Move-Item -Force $LogPath ($LogPath + '.old')
    }
    Add-Content -Path $LogPath -Value $line -Encoding UTF8
  } catch { }
  try { Write-Host $line } catch { }
}

# ── 설정 ──────────────────────────────────────────────────
function Read-Config {
  if (-not (Test-Path $Config)) {
    throw "설정 파일이 없습니다: $Config — config.example.json 을 config.json 으로 복사하고 secret 을 넣어 주세요."
  }
  $c = Get-Content -Raw -Encoding UTF8 $Config | ConvertFrom-Json
  $d = @{
    endpoint          = 'https://motmot.co.kr/api/push?op=kakao_push'
    secret            = ''
    intervalMinutes   = 60         # 몇 분마다 찍나 — 사장님 2026-10-17 「1시간에 한번씩 해도 충분」(실행기 0.9.5 기본과 같다)
    wheelClicksPerPage = 3
    maxPages          = 80
    settleMs          = 450
    scrollMode        = 'wheel'
    windowTitle       = '카카오톡'
    openRooms         = $true      # 방을 열어 창 제목(정확한 이름)을 읽는다 — 사장님 2026-10-15 「들어가서 읽어도 됨」(D-148)
    openMax           = 60         # 한 회차에 여는 방 수 상한(나머지는 다음 회차에) — 안 맞았던 것 · 못 연 것도 센다
    openWaitMs        = 1500       # 방 창이 뜰 때까지 기다리는 시간
    openMinMembers    = 6          # 이 인원 이상인 단체방만 연다(개인 대화 · 작은 방은 안 연다 — D-142 「단체방 = 6명 이상」)
    openWay           = 'auto'     # 방을 여는 길 — auto(키보드로 골라 엔터 · 세 회차 연달아 안 열리면 하루 동안 줄 누르기) · keys · click (D-160)
    peekSeconds       = 60         # 쉬는 동안 몇 초마다 목록 **지금 보이는 한 화면**만 보나 — 새 방이 보이면 바로 읽는다(0 = 안 봄 · 20 아래는 20) — 사장님 2026-10-23 「새로운 톡방이 생기면, 바로 읽어야 하는데」(D-183)
    peekGapMinutes    = 5          # 맨 위 보기로 회차를 돌린 뒤 이만큼은 다시 안 돌린다(글자 인식이 달리 읽은 줄로 회차를 거듭 돌지 않게)
  }
  foreach ($k in @($d.Keys)) {
    if ($null -ne $c.$k -and "$($c.$k)" -ne '') { $d[$k] = $c.$k }
  }
  if (-not $DryRun -and ("$($d.secret)").Length -lt 16) {
    throw "config.json 의 secret 이 비었거나 짧습니다(16자 이상) — Vercel 환경변수 KAKAO_AGENT_SECRET 과 같은 값을 넣어 주세요."
  }
  return $d
}

# ── 윈도우 창 다루기 ───────────────────────────────────────
Add-Type -ReferencedAssemblies System.Drawing -TypeDefinition @"
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Text;

public static class MotmotKakaoWin {
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
  [StructLayout(LayoutKind.Sequential)] struct LASTINPUTINFO { public uint cbSize; public uint dwTime; }
  delegate bool EnumProc(IntPtr h, IntPtr l);

  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern IntPtr FindWindow(string cls, string title);
  [DllImport("user32.dll")] static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr l);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder sb, int n);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int cmd);
  [DllImport("user32.dll")] static extern bool PrintWindow(IntPtr h, IntPtr hdc, uint flags);
  [DllImport("user32.dll")] static extern bool PostMessage(IntPtr h, uint msg, IntPtr w, IntPtr l);
  [DllImport("user32.dll")] static extern bool GetLastInputInfo(ref LASTINPUTINFO p);
  [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc cb, IntPtr l);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder sb, int n);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] static extern bool GetCursorPos(out POINT p);
  [DllImport("kernel32.dll")] static extern void Sleep(uint ms);
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("kernel32.dll", SetLastError = true)] static extern IntPtr OpenProcess(uint access, bool inherit, uint pid);
  [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
  [DllImport("advapi32.dll", SetLastError = true)] static extern bool OpenProcessToken(IntPtr proc, uint access, out IntPtr token);
  [DllImport("advapi32.dll", SetLastError = true)] static extern bool GetTokenInformation(IntPtr token, int cls, IntPtr buf, int len, out int ret);
  [DllImport("kernel32.dll", SetLastError = true)] static extern IntPtr CreateToolhelp32Snapshot(uint flags, uint pid);
  [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] static extern bool Module32FirstW(IntPtr snap, ref MODULEENTRY32W me);
  [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] static extern bool Module32NextW(IntPtr snap, ref MODULEENTRY32W me);
  [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)] struct MODULEENTRY32W {
    public uint dwSize, th32ModuleID, th32ProcessID, GlblcntUsage, ProccntUsage;
    public IntPtr modBaseAddr; public uint modBaseSize; public IntPtr hModule;
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)] public string szModule;
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)] public string szExePath;
  }
  [DllImport("user32.dll")] static extern IntPtr WindowFromPoint(POINT p);
  [DllImport("user32.dll")] static extern bool IsChild(IntPtr parent, IntPtr h);
  [DllImport("user32.dll")] static extern uint SendInput(uint n, INPUT[] inputs, int size);
  [DllImport("user32.dll")] static extern int GetSystemMetrics(int i);
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; }
  [StructLayout(LayoutKind.Sequential)] struct MOUSEINPUT { public int dx, dy; public uint mouseData, dwFlags, time; public IntPtr dwExtraInfo; }
  [StructLayout(LayoutKind.Sequential)] struct INPUT { public uint type; public MOUSEINPUT mi; }

  public static string Title(IntPtr h) { var sb = new StringBuilder(512); GetWindowText(h, sb, 512); return sb.ToString(); }
  static string Cls(IntPtr h) { var sb = new StringBuilder(256); GetClassName(h, sb, 256); return sb.ToString(); }

  /* 지금 화면에 떠 있는 카톡 창들(큰 창 빼고 · 카톡 프로그램 것만) — 방 창이 새로 떴는지 앞뒤로 견준다 */
  static uint Pid(IntPtr h) { uint p; GetWindowThreadProcessId(h, out p); return p; }
  public static uint PidOf(IntPtr h) { return Pid(h); }

  /* ── 카톡을 여러 개 켜 둔 PC(D-175) ── 개인 카톡은 샌드박스(Sandboxie) · 다른 윈도우 사용자로 띄운다(사장님 2026-10-22).
     카톡 큰 창을 프로그램(pid)마다 하나씩 센다 — 샌드박스 카톡도 세어야 「여러 개」 를 안다. 숨긴 창(트레이)도 센다.
     Sandboxie 는 기본으로 창 갈래 이름 앞에 「Sandbox:상자:」 를, 제목에 「[#] … [#]」(상자 이름 보이기를 켜면 「[#] [상자] … [#]」)를 붙인다 — 떼고 견준다.
     샌드박스 표시 없는 「EVA_Window」 갈래 큰 창이 없으면 제목만 같고 목록 칸이 있는 창도 본다. */
  static string Plain(string c) {
    if (!c.StartsWith("Sandbox:")) return c;
    int k = c.IndexOf(':', 8);
    return k < 0 ? "" : c.Substring(k + 1);
  }
  static string Bare(string t) {
    if (t.IndexOf("[#]") < 0) return t.Trim();
    string s = t.Replace("[#]", "").Trim();
    if (s.StartsWith("[")) { int e = s.IndexOf(']'); if (e > 0) s = s.Substring(e + 1).Trim(); }
    return s;
  }
  /* 창만 보고 아는 샌드박스 표시 — 프로그램을 들여다보지 않아도(권한이 없어도) 안다 */
  public static bool SandboxMark(IntPtr h) { return Cls(h).StartsWith("Sandbox:") || Title(h).IndexOf("[#]") >= 0; }
  /* 한 프로그램의 창 가운데 큰 창 고르기 점수 — 목록 칸(EVA_VH_ListControl)이 있으면 +2 · 글 쓰는 칸(RichEdit — 방 창의 입력칸)이 없으면 +1.
     「카카오톡」 이라는 이름의 방 창도 대화 목록 칸이 있어 목록 칸만으로는 못 가른다(검토 2026-10-22). 점수가 같으면 먼저 찾은 창(앞에 있는 창). */
  static int Rank(IntPtr top) {
    bool list = false, edit = false;
    EnumChildWindows(top, (h, l) => {
      string c = Plain(Cls(h));
      if (c.StartsWith("EVA_VH_ListControl")) list = true;
      else if (c.StartsWith("RichEdit", StringComparison.OrdinalIgnoreCase)) edit = true;
      return true;
    }, IntPtr.Zero);
    return (list ? 2 : 0) + (edit ? 0 : 1);
  }
  public static long[] MainWindows(string title) {
    var byPid = new Dictionary<uint, IntPtr>();
    bool plain = false;                               // 샌드박스 표시 없는 창을 찾았나 — 샌드박스 카톡만 찾았으면 제목만 같은 창도 본다(검토 2026-10-22)
    for (int pass = 0; pass < 2 && !plain; pass++) {
      EnumWindows((h, x) => {
        if (pass == 0 ? !(Plain(Cls(h)).StartsWith("EVA_Window") && Bare(Title(h)) == title) : (Title(h) != title || Rank(h) < 2)) return true;   // 제목만 같은 창은 목록 칸이 있어야(「카카오톡」 폴더 · 브라우저 창 말고)
        if (!SandboxMark(h)) plain = true;
        uint p = Pid(h);
        IntPtr had;
        if (!byPid.TryGetValue(p, out had) || Rank(h) > Rank(had)) byPid[p] = h;
        return true;
      }, IntPtr.Zero);
    }
    var l = new List<long>();
    foreach (var h in byPid.Values) l.Add(h.ToInt64());
    return l.ToArray();
  }
  /* 그 프로그램을 띄운 윈도우 사용자(SID 글) — 못 읽으면 null(권한 · 이미 꺼짐) */
  public static string OwnerSid(uint pid) {
    IntPtr p = OpenProcess(0x1000, false, pid);                     // PROCESS_QUERY_LIMITED_INFORMATION
    if (p == IntPtr.Zero) return null;
    IntPtr tok = IntPtr.Zero, buf = IntPtr.Zero;
    try {
      if (!OpenProcessToken(p, 0x8, out tok)) return null;          // TOKEN_QUERY
      int len;
      GetTokenInformation(tok, 1, IntPtr.Zero, 0, out len);         // TokenUser — 먼저 크기만
      if (len <= 0) return null;
      buf = Marshal.AllocHGlobal(len);
      if (!GetTokenInformation(tok, 1, buf, len, out len)) return null;
      return new System.Security.Principal.SecurityIdentifier(Marshal.ReadIntPtr(buf)).Value;   // TOKEN_USER.User.Sid
    } catch { return null; }
    finally { if (buf != IntPtr.Zero) Marshal.FreeHGlobal(buf); if (tok != IntPtr.Zero) CloseHandle(tok); CloseHandle(p); }
  }
  /* 샌드박스(Sandboxie) 안의 프로그램인가 — 그 프로그램에 SbieDll.dll 이 붙어 있다. 1 = 그렇다 · 0 = 아니다 · -1 = 못 읽음(관리자 권한으로 켠 카톡 · 막힌 상자 등).
     ★ 샌드박스 카톡도 윈도우 사용자는 같다(Sandboxie 기본) — 사용자로는 못 가르고 이것만 가른다. 그래서 -1 은 업무 카톡으로 안 본다(검토 2026-10-22).
     32비트 카톡도 보게 TH32CS_SNAPMODULE32 까지. 스냅샷은 잠깐 실패할 수 있어(ERROR_BAD_LENGTH) 세 번까지. */
  public static int InSandbox(uint pid) {
    for (int k = 0; k < 3; k++) {
      IntPtr snap = CreateToolhelp32Snapshot(0x8 | 0x10, pid);
      if (snap == IntPtr.Zero || snap == new IntPtr(-1)) { Sleep(50); continue; }
      try {
        var me = new MODULEENTRY32W();
        me.dwSize = (uint)Marshal.SizeOf(typeof(MODULEENTRY32W));
        if (!Module32FirstW(snap, ref me)) return -1;
        do { if (string.Equals(me.szModule, "SbieDll.dll", StringComparison.OrdinalIgnoreCase)) return 1; } while (Module32NextW(snap, ref me));
        return 0;
      } finally { CloseHandle(snap); }
    }
    return -1;
  }
  public static long[] ChatWindows(IntPtr main) {
    long[] l = new long[0];
    uint pid = Pid(main);
    EnumWindows((h, x) => {
      if (IsChatWindow(h, main, pid)) { Array.Resize(ref l, l.Length + 1); l[l.Length - 1] = h.ToInt64(); }
      return true;
    }, IntPtr.Zero);
    return l;
  }
  /* 방 창 모두 — **최소화된 창까지**(최소화하면 창 크기가 작아져 ChatWindows 에서 빠진다). 원래 떠 있던 창(직원 창)을 셀 때 쓴다 —
     엔터 · 두 번 누르기가 최소화된 직원 창을 되살려도 「새로 뜬 우리 창」 으로 보고 닫지 않게(D-160 검토). 숨겨진 창은 넣지 않는다. */
  public static long[] ChatWindowsAll(IntPtr main) {
    long[] l = new long[0];
    uint pid = Pid(main);
    EnumWindows((h, x) => {
      if (IsChatWindow(h, main, pid) || (h != main && IsWindowVisible(h) && IsIconic(h) && Pid(h) == pid && Cls(h).StartsWith("EVA_Window") && Title(h).Length > 0)) {
        Array.Resize(ref l, l.Length + 1); l[l.Length - 1] = h.ToInt64();
      }
      return true;
    }, IntPtr.Zero);
    return l;
  }
  public static bool IsChatWindow(IntPtr h, IntPtr main) { return IsChatWindow(h, main, Pid(main)); }
  static bool IsChatWindow(IntPtr h, IntPtr main, uint pid) {
    if (h == IntPtr.Zero || h == main || !IsWindowVisible(h) || Pid(h) != pid || !Cls(h).StartsWith("EVA_Window")) return false;
    RECT r; GetWindowRect(h, out r);
    return r.Right - r.Left >= 200 && r.Bottom - r.Top >= 200 && Title(h).Length > 0;   // 알림 창 · 작은 팝업은 방 창이 아니다
  }

  /* 목록 한 줄 두 번 누르기 — ① 목록 창에 메시지로(마우스를 안 움직인다) ② 진짜 마우스(창을 앞으로 가져와야 한다).
     cx · cy 는 목록 창 안 좌표(픽셀). */
  public static void PostDbl(IntPtr list, int cx, int cy) {
    IntPtr lp = (IntPtr)((cy << 16) | (cx & 0xFFFF));
    PostMessage(list, 0x0200, IntPtr.Zero, lp);                                   // WM_MOUSEMOVE — 그 줄 위에 있다고 먼저 알린다
    PostMessage(list, 0x0201, (IntPtr)1, lp); PostMessage(list, 0x0202, IntPtr.Zero, lp);
    PostMessage(list, 0x0203, (IntPtr)1, lp); PostMessage(list, 0x0202, IntPtr.Zero, lp);
  }
  public static bool MouseDbl(IntPtr main, IntPtr list, int cx, int cy) {
    RECT r; GetWindowRect(list, out r);
    POINT at; at.X = r.Left + cx; at.Y = r.Top + cy;
    SetForegroundWindow(main);
    Sleep(150);
    IntPtr hit = WindowFromPoint(at);
    if (hit != list && !IsChild(list, hit)) return false;   // 그 자리를 다른 창이 덮고 있으면 누르지 않는다(엉뚱한 창을 두 번 누르게 된다)
    POINT keep; GetCursorPos(out keep);
    /* 누르기 · 떼기 두 번을 **한 번에**(SendInput 은 사이에 다른 입력이 끼지 않는다) · 이벤트마다 절대 좌표(가상 화면 기준)
       → 사람이 그 순간 마우스를 움직여도 그 줄 자리에서 눌린다 */
    int vx = GetSystemMetrics(76), vy = GetSystemMetrics(77), vw = Math.Max(2, GetSystemMetrics(78)), vh = Math.Max(2, GetSystemMetrics(79));
    int nx = (int)(((long)(at.X - vx) * 65535) / (vw - 1)), ny = (int)(((long)(at.Y - vy) * 65535) / (vh - 1));
    uint[] flags = { 0x0002, 0x0004, 0x0002, 0x0004 };                 // 누름 · 뗌 · 누름 · 뗌
    var ins = new INPUT[flags.Length];
    for (int i = 0; i < flags.Length; i++) {
      ins[i].type = 0;                                                 // INPUT_MOUSE
      ins[i].mi.dx = nx; ins[i].mi.dy = ny;
      ins[i].mi.dwFlags = flags[i] | 0x0001 | 0x8000 | 0x4000;         // + MOVE · ABSOLUTE · VIRTUALDESK
    }
    SendInput((uint)ins.Length, ins, Marshal.SizeOf(typeof(INPUT)));
    Sleep(150);                                       // 넣은 누르기가 다 처리된 뒤에 마우스를 제자리로
    SetCursorPos(keep.X, keep.Y);
    return true;
  }
  public static void Close(IntPtr h) { PostMessage(h, 0x0010, IntPtr.Zero, IntPtr.Zero); }   // WM_CLOSE
  /* 목록 창에 키 메시지 — 아래(0x28) · 위(0x26) · 엔터(0x0D) **만**. 다른 키는 안 보낸다(카톡 목록 단축키: Delete = 방 나가기 · R = 읽음).
     창을 앞으로 가져오지 않고 포커스도 안 바꾼다 — 2026-10-16 서버 PC 점검: 포커스 없이도 목록 고르기가 움직였다(I-181 · D-160). */
  public static bool PostKey(IntPtr list, int vk) {
    int scan, ext;
    if (vk == 0x28) { scan = 0x50; ext = 1 << 24; }
    else if (vk == 0x26) { scan = 0x48; ext = 1 << 24; }
    else if (vk == 0x0D) { scan = 0x1C; ext = 0; }
    else return false;
    int lp = 1 | (scan << 16) | ext;
    bool a = PostMessage(list, 0x0100, (IntPtr)vk, (IntPtr)lp);
    bool b = PostMessage(list, 0x0101, (IntPtr)vk, new IntPtr(lp | unchecked((int)0xC0000000)));
    return a && b;
  }
  public static int ListWidth(IntPtr list) { RECT r; GetWindowRect(list, out r); return r.Right - r.Left; }

  /* 편집 거리 — 열린 방 제목이 그 줄의 글자와 같은 방인지 견준다(목록 순서가 그새 바뀌면 다른 방이 열린다) */
  public static int Lev(string a, string b) {
    var d = new int[b.Length + 1];
    for (int j = 0; j <= b.Length; j++) d[j] = j;
    for (int i = 1; i <= a.Length; i++) {
      int prev = d[0]; d[0] = i;
      for (int j = 1; j <= b.Length; j++) {
        int tmp = d[j];
        d[j] = Math.Min(Math.Min(d[j] + 1, d[j - 1] + 1), prev + (a[i - 1] == b[j - 1] ? 0 : 1));
        prev = tmp;
      }
    }
    return d[b.Length];
  }

  /* 카톡 채팅 목록 = 보이는 EVA_VH_ListControl* 중 가장 큰 것.
     「친구」 목록도 같은 종류지만 「채팅」 탭에서는 숨어 있다(안 보인다). */
  public static IntPtr FindList(IntPtr top) {
    IntPtr best = IntPtr.Zero; long bestArea = 0;
    EnumChildWindows(top, (h, l) => {
      var sb = new StringBuilder(256);
      GetClassName(h, sb, 256);
      if (sb.ToString().StartsWith("EVA_VH_ListControl") && IsWindowVisible(h)) {
        RECT r; GetWindowRect(h, out r);
        long a = (long)(r.Right - r.Left) * (r.Bottom - r.Top);
        if (a > bestArea) { bestArea = a; best = h; }
      }
      return true;
    }, IntPtr.Zero);
    return best;
  }

  /* 큰 창을 통째로 찍고(가려져 있어도 된다 · 2 = PW_RENDERFULLCONTENT) 목록 자리만 오려 scale 배로 키운다.
     키우는 까닭: 윈도우 글자 인식은 작은 글씨(9~10pt)에서 자주 틀린다. */
  /* scale = 0 이면 글자 인식이 받는 가장 큰 그림(maxDim)에 맞춰 2~4배로 고른다(2026-10-15 — 오탈자 줄이기).
     작은 글씨(카톡 목록 9~10pt)는 크게 키울수록 덜 틀린다. 너무 크면 인식이 그림을 거절한다. */
  public static Bitmap Snap(IntPtr top, IntPtr list, int scale, int maxDim) {
    RECT la; GetWindowRect(list, out la);
    int lw = Math.Max(1, la.Right - la.Left), lh = Math.Max(1, la.Bottom - la.Top);
    if (scale <= 0) scale = Math.Max(2, Math.Min(4, maxDim / Math.Max(lw, lh)));
    RECT w, a; GetWindowRect(top, out w); GetWindowRect(list, out a);
    int ww = w.Right - w.Left, wh = w.Bottom - w.Top;
    if (ww <= 0 || wh <= 0) return null;
    using (var full = new Bitmap(ww, wh, PixelFormat.Format32bppArgb)) {
      using (var g = Graphics.FromImage(full)) {
        IntPtr dc = g.GetHdc();
        try { PrintWindow(top, dc, 2); } finally { g.ReleaseHdc(dc); }
      }
      var crop = new Rectangle(a.Left - w.Left, a.Top - w.Top, a.Right - a.Left, a.Bottom - a.Top);
      crop.Intersect(new Rectangle(0, 0, ww, wh));
      if (crop.Width <= 0 || crop.Height <= 0) return null;
      LastInk = InkOf(full, crop);                    // 글자 인식에 넘기는 그림과 **같은 순간**의 줄 모양
      var outBmp = new Bitmap(crop.Width * scale, crop.Height * scale, PixelFormat.Format32bppArgb);
      using (var g2 = Graphics.FromImage(outBmp)) {
        g2.InterpolationMode = InterpolationMode.HighQualityBicubic;
        /* 흑백만(대비 그대로) — 2026.10.15-4. 앞 판의 「대비 1.3」 은 흰 바탕을 넘겨 자르면서 **옅은 회색 글자를 더 옅게** 했다
           (#999 0.40 → 0.37 · #c8c8c8 0.22 → 0.13 · 글자 가장자리 #e0e0e0 0.12 → 0.01). 카톡의 시각 표기와 인원수가 그 옅은 회색이다 —
           시각을 못 읽은 줄은 방으로 안 친다(검토). 글자 인식은 어차피 흑백으로 읽는다. */
        float c = 1f, t = 0.5f * (1f - c);
        var cm = new ColorMatrix(new float[][] {
          new float[] { 0.299f * c, 0.299f * c, 0.299f * c, 0, 0 },
          new float[] { 0.587f * c, 0.587f * c, 0.587f * c, 0, 0 },
          new float[] { 0.114f * c, 0.114f * c, 0.114f * c, 0, 0 },
          new float[] { 0, 0, 0, 1, 0 },
          new float[] { t, t, t, 0, 1 } });
        using (var ia = new ImageAttributes()) {
          ia.SetColorMatrix(cm);
          g2.DrawImage(full, new Rectangle(0, 0, outBmp.Width, outBmp.Height), crop.X, crop.Y, crop.Width, crop.Height, GraphicsUnit.Pixel, ia);
        }
      }
      return outBmp;
    }
  }

  /* 한 가지 색뿐인 그림 = 못 찍은 것(잠금 화면 · 최소화 · 그리기 전) */
  public static bool IsBlank(Bitmap b) {
    Color c0 = b.GetPixel(0, 0);
    int stepX = Math.Max(1, b.Width / 40), stepY = Math.Max(1, b.Height / 80);
    for (int y = 0; y < b.Height; y += stepY)
      for (int x = 0; x < b.Width; x += stepX)
        if (b.GetPixel(x, y).ToArgb() != c0.ToArgb()) return false;
    return true;
  }

  /* 휠 굴리기 — 목록 창에 직접 보낸다(앞으로 가져오지 않는다). clicks > 0 = 위로, < 0 = 아래로 */
  public static void Wheel(IntPtr list, int clicks) {
    RECT r; GetWindowRect(list, out r);
    int x = (r.Left + r.Right) / 2, y = (r.Top + r.Bottom) / 2;
    uint wp = ((uint)(ushort)(short)(clicks * 120)) << 16;
    uint lp = (((uint)(ushort)(short)y) << 16) | (uint)(ushort)(short)x;
    PostMessage(list, 0x020A, (IntPtr)unchecked((int)wp), (IntPtr)unchecked((int)lp));
  }
  /* 휠이 안 먹는 판을 위한 다른 길(scrollMode = vscroll) — WM_VSCROLL. code 0 = 한 줄 위 · 1 = 한 줄 아래 · 6 = 맨 위 */
  public static void VScroll(IntPtr list, int code) {
    PostMessage(list, 0x0115, (IntPtr)code, IntPtr.Zero);
  }

  public static uint IdleMs() {
    var p = new LASTINPUTINFO(); p.cbSize = (uint)Marshal.SizeOf(p);
    if (!GetLastInputInfo(ref p)) return uint.MaxValue;
    return unchecked((uint)Environment.TickCount - p.dwTime);
  }
  public static uint Tick() { return unchecked((uint)Environment.TickCount); }
  /* mark 뒤에 키보드 · 마우스 입력이 있었나 — 사람이 돌아왔다(우리가 넣은 누르기 뒤에는 mark 를 새로 잡는다) */
  public static bool InputSince(uint mark) {
    var p = new LASTINPUTINFO(); p.cbSize = (uint)Marshal.SizeOf(p);
    if (!GetLastInputInfo(ref p)) return true;
    return unchecked((int)(p.dwTime - mark)) > 0;
  }

  /* 목록 왼쪽 55%(사진 · 이름 · 미리보기)의 줄마다 「글자 칸 수」 — 방 순서가 바뀌었나 견준다.
     ★ 배경과 많이 다른 칸만 센다 → 고른 줄의 옅은 배경 · 오른쪽 안 읽음 표시는 안 걸리고, 줄이 밀리면 달라진다. 밝은 · 어두운 화면 모두.
     ★ Snap 이 찍은 그 그림에서 센 것을 LastInk 에 남긴다(따로 다시 찍으면 그사이 움직임을 놓친다).
     ★ 줄마다 따로 복사한다 — 오린 자리를 통째로 복사하면 그림 끝을 넘어 읽을 수 있다. */
  public static int[] LastInk = new int[0];
  static int[] InkOf(Bitmap full, Rectangle list) {
    var r = new Rectangle(list.X, list.Y, (int)(list.Width * 0.55), list.Height);
    r.Intersect(new Rectangle(0, 0, full.Width, full.Height));
    if (r.Width <= 0 || r.Height <= 0) return new int[0];
    var data = full.LockBits(new Rectangle(0, 0, full.Width, full.Height), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
    try {
      int cw = r.Width, ch = r.Height;
      var row = new byte[cw * 4]; var lum = new byte[cw * ch]; var hist = new int[256];
      for (int y = 0; y < ch; y++) {
        Marshal.Copy(new IntPtr(data.Scan0.ToInt64() + (long)(r.Y + y) * data.Stride + (long)r.X * 4), row, 0, cw * 4);
        for (int x = 0; x < cw; x++) {
          int i = x * 4, l = (row[i + 2] * 299 + row[i + 1] * 587 + row[i] * 114) / 1000;
          lum[y * cw + x] = (byte)l; hist[l]++;
        }
      }
      int bg = 0;
      for (int k = 1; k < 256; k++) if (hist[k] > hist[bg]) bg = k;
      var ink = new int[ch];
      for (int y = 0; y < ch; y++) {
        int c = 0;
        for (int x = 0; x < cw; x++) if (Math.Abs(lum[y * cw + x] - bg) > 60) c++;
        ink[y] = c;
      }
      return ink;
    } finally { full.UnlockBits(data); }
  }
  public static int[] RowInk(IntPtr top, IntPtr list) {
    RECT w, a; GetWindowRect(top, out w); GetWindowRect(list, out a);
    int ww = w.Right - w.Left, wh = w.Bottom - w.Top;
    if (ww <= 0 || wh <= 0) return new int[0];
    using (var full = new Bitmap(ww, wh, PixelFormat.Format32bppArgb)) {
      using (var g = Graphics.FromImage(full)) {
        IntPtr dc = g.GetHdc();
        try { PrintWindow(top, dc, 2); } finally { g.ReleaseHdc(dc); }
      }
      var crop = new Rectangle(a.Left - w.Left, a.Top - w.Top, a.Right - a.Left, a.Bottom - a.Top);
      crop.Intersect(new Rectangle(0, 0, ww, wh));
      if (crop.Width <= 0 || crop.Height <= 0) return new int[0];
      return InkOf(full, crop);
    }
  }
  /* 목록 맨 위부터 yEnd(목록 안 픽셀)까지가 그대로인가 — 새 메시지는 방을 **맨 위로** 올려 그 위의 줄을 모두 민다.
     그래서 누를 줄과 그 위만 본다(두 줄이 자리를 바꿔도 걸리게 · 아래쪽 변화는 상관없다). */
  public static bool SameInkTo(int[] a, int[] b, int yEnd) {
    if (a == null || b == null || a.Length == 0 || a.Length != b.Length) return false;
    int n = Math.Min(a.Length, Math.Max(1, yEnd));
    long diff = 0, tot = 0;
    for (int i = 0; i < n; i++) { diff += Math.Abs(a[i] - b[i]); tot += a[i]; }
    return diff <= Math.Max(30L, tot * 4 / 100);
  }
  /* 낱말 칸의 「글자 진하기」 — 칸 안 가장 흔한 밝기(배경)에서 가장 먼 5% 의 거리. 단체방 인원수는 이름보다 옅은 회색이다. */
  public static int InkCore(Bitmap b, double x, double y, double w, double h) {
    int x0 = Math.Max(0, (int)x), y0 = Math.Max(0, (int)y);
    int x1 = Math.Min(b.Width, (int)Math.Ceiling(x + w)), y1 = Math.Min(b.Height, (int)Math.Ceiling(y + h));
    if (x1 - x0 < 2 || y1 - y0 < 2) return -1;
    var v = new int[(x1 - x0) * (y1 - y0)]; int k = 0;
    for (int yy = y0; yy < y1; yy++)
      for (int xx = x0; xx < x1; xx++) {
        Color c = b.GetPixel(xx, yy);
        v[k++] = (c.R * 299 + c.G * 587 + c.B * 114) / 1000;
      }
    return CoreOf(v);
  }
  /* 밝기들(0~255) → 가장 흔한 밝기(배경)에서 가장 먼 5% 의 거리 */
  public static int CoreOf(int[] v) {
    if (v == null || v.Length == 0) return -1;
    int n = v.Length; var hist = new int[256]; var d = new int[n];
    for (int i = 0; i < n; i++) hist[Math.Max(0, Math.Min(255, v[i]))]++;
    int bg = 0;
    for (int i = 1; i < 256; i++) if (hist[i] > hist[bg]) bg = i;
    for (int i = 0; i < n; i++) d[i] = Math.Abs(v[i] - bg);
    Array.Sort(d);
    return d[Math.Min(n - 1, (int)(n * 0.95))];
  }
}
"@
[void][MotmotKakaoWin]::SetProcessDPIAware()

# ── 글자 인식 (Windows.Media.Ocr) ───────────────────────────
Add-Type -AssemblyName System.Runtime.WindowsRuntime
[void][Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
[void][Windows.Globalization.Language, Windows.Foundation, ContentType = WindowsRuntime]
[void][Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics, ContentType = WindowsRuntime]
[void][Windows.Graphics.Imaging.SoftwareBitmap, Windows.Graphics, ContentType = WindowsRuntime]
[void][Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
[void][Windows.Storage.Streams.IRandomAccessStream, Windows.Storage.Streams, ContentType = WindowsRuntime]

$script:AsTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
  $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
  $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]

function Await($op, [Type]$type) {
  $task = $script:AsTask.MakeGenericMethod($type).Invoke($null, @($op))
  [void]$task.Wait(-1)
  return $task.Result
}

function New-OcrEngine {
  $lang = New-Object Windows.Globalization.Language 'ko'
  $eng = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($lang)
  if ($null -eq $eng) {
    throw "윈도우 한국어 글자 인식이 설치돼 있지 않습니다. 관리자 PowerShell 에서: Add-WindowsCapability -Online -Name 'Language.OCR~~~ko-KR~0.0.1.0'"
  }
  return $eng
}

# 그림 파일 하나 → { w, h, lines:[{ words:[{t,x,y,w,h}] }] }
function Read-Page($engine, [string]$png, [int]$w, [int]$h) {
  $file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($png)) ([Windows.Storage.StorageFile])
  $stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
  try {
    $decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
    $soft = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
    $res = Await ($engine.RecognizeAsync($soft)) ([Windows.Media.Ocr.OcrResult])
  } finally { $stream.Dispose() }
  $lines = New-Object System.Collections.ArrayList
  foreach ($ln in $res.Lines) {
    $words = New-Object System.Collections.ArrayList
    foreach ($wd in $ln.Words) {
      $r = $wd.BoundingRect
      [void]$words.Add([ordered]@{ t = $wd.Text; x = [math]::Round($r.X, 1); y = [math]::Round($r.Y, 1); w = [math]::Round($r.Width, 1); h = [math]::Round($r.Height, 1) })
    }
    if ($words.Count) { [void]$lines.Add([ordered]@{ words = @($words) }) }
  }
  return [ordered]@{ w = $w; h = $h; lines = @($lines) }
}

function Page-Texts($page) {
  $set = New-Object 'System.Collections.Generic.HashSet[string]'
  foreach ($ln in $page.lines) { [void]$set.Add((($ln.words | ForEach-Object { $_.t }) -join ' ')) }
  return ,$set
}

# 장끼리 겹쳤나를 볼 글자 — **여러 방에 흔한 줄은 뺀다**: 시각만 있는 줄(「어제」 · 「10월 13일」) · 4글자가 안 되는 줄(「사진」 · 「동영상」) ·
# 한 장에 두 번 이상 나온 줄. 예전에는 그런 줄 둘만 같아도 「겹친다」 고 봐서, 한 번에 많이 내려가면 사이 방을 건너뛰고도 끝까지 읽었다고 했다(검토 2026-10-15).
function Overlap-Texts($page) {
  $n = @{}
  foreach ($ln in $page.lines) { $t = (($ln.words | ForEach-Object { $_.t }) -join ' '); $n[$t] = 1 + [int]$n[$t] }
  $set = New-Object 'System.Collections.Generic.HashSet[string]'
  foreach ($t in $n.Keys) {
    if ($n[$t] -gt 1) { continue }
    if (($t -replace '[^\p{L}\p{Nd}]', '').Length -lt 4) { continue }
    if (Test-TimeLabel $t) { continue }
    [void]$set.Add($t)
  }
  return ,$set
}

# 장끼리 겹쳤나를 **방 단위로** — 줄 찾기(Find-Rows)로 읽은 방 열쇠(이름|인원). 한 장에 두 번 나온 열쇠는 뺀다.
# 줄 하나씩 견주면 짧은 이름(「김철수」) · 「사진」 만 보낸 1:1 방이 많은 목록에서 겹치는데도 「안 겹친다」 가 났다(검토 2026-10-15) — 방 열쇠는 그보다 훨씬 덜 겹친다.
function Row-Keys($page) {
  $n = @{}
  foreach ($row in (Find-Rows $page)) { $n[$row.key] = 1 + [int]$n[$row.key] }
  $set = New-Object 'System.Collections.Generic.HashSet[string]'
  foreach ($k in $n.Keys) { if ($n[$k] -eq 1 -and ($k -split '\|')[0].Length -ge 2) { [void]$set.Add($k) } }
  return ,$set
}

# ── 방을 열어 정확한 이름 읽기 (D-148) ─────────────────────
# 사장님(2026-10-15): "사실상 상담은 우리가 하는거라, 들어가서 읽어도 됨" · "이걸 실행기에서 계속 파악하고 새로고침 해줘야 함"
# ★ 카톡은 목록 글자를 텍스트로 내주지 않는다(UI Automation 점검). 방 창의 **제목**은 텍스트다 = 정확한 방 이름.
# ★ 여는 방 = **단체방(인원 openMinMembers 명 이상)** 만 — 인원수가 이름보다 옅은 회색으로 찍힌 줄만 단체방으로 본다
#   (「홍길동 5678」 처럼 이름 끝에 숫자를 붙여 저장한 개인 대화는 숫자가 이름과 같은 색이다 — 안 연다).
# ★ 사람이 PC 를 안 만질 때만(1분 넘게 입력 없음) 연다. 여는 사이에 입력이 생기면 그 회차는 그만 연다.
# ★ 한 번 읽은 이름은 기억한다(exact-names.json) — 다음 회차에는 새 줄 · 글자가 바뀐 줄만 연다(7일마다 한 번 다시 확인).
# ★ 찍은 뒤 목록이 움직였으면(새 메시지로 순서가 바뀜) 그 장은 그만 연다 — 엉뚱한 방을 열게 된다.
# ★ 연 방의 제목은 그 줄 글자와 숫자가 모두 같고 글자가 한두 자만 달라야 받는다. 목록이 「…」 로 자른 이름만 앞부분끼리 견준다.
# ⚠ 방을 열면 그 방의 안 읽은 메시지가 읽음이 된다(사장님 허락). 서버 PC 화면에 방 창이 잠깐 떴다 닫힌다.
# ★ 0.9.4(D-160): 줄 그림 자리를 누르지 않고, 찍기가 끝난 뒤 **목록 창에 키 메시지**(위 · 아래 화살표 · 엔터)로 골라 연다(Open-ByKeys).
#   엔터로 방이 세 회차 연달아 안 열리면 하루 동안 예전 길(줄 누르기)로 — config openWay = auto(기본) · keys · click.
$ExactPath = Join-Path $Base 'exact-names.json'
$StopFlag = Join-Path $Base 'stop.flag'
$script:Stopping = $false
$script:SaidNoExact = $false          # 「서버가 정확한 이름을 안 씀」 은 한 번만 적는다

# 켬/끔 값 읽기 — 비었으면 기본값 · "false" · "0" · "off" 는 끔
function Test-On($v, [bool]$default) {
  if ($null -eq $v -or "$v" -eq '') { return $default }
  if ($v -is [bool]) { return $v }
  return -not ("$v".Trim() -match '^(false|0|off|no)$')
}

# 이름 기억 — { names: { 열쇠: { t 제목, n 읽은 이름, m 인원, read 처음 읽은 때, at 마지막 본 때 } }, miss: { 열쇠: { at, n 연달아 안 맞은 수 } },
#              ambig: { 열쇠: 때 } } — 열쇠 = 글자 인식 이름(빈칸 뺌) + '|' + 인원. 30일 안 본 방은 버린다. 안 맞음은 한 번이면 12시간, 두 번 넘게면 7일 쉰다.
# ambig = 같은 글자로 보이는 다른 방이 있던 열쇠 — 7일 동안 그 글자엔 이름을 안 붙이고 안 연다(한 방 제목이 다른 방에 붙지 않게).
# ★ 파일을 못 읽으면(다른 프로그램이 쥠) bad — 그 회차는 방을 안 열고 덮어쓰지 않는다. 깨졌으면(.bad 로 치우고) 처음부터.
function Load-Exact {
  $h = @{ names = @{}; miss = @{}; ambig = @{}; way = @{ keysFail = 0; lost = 0; stale = 0; at = ''; base = 0; z = $null }; bad = $false }
  if (-not (Test-Path $ExactPath)) { return $h }
  $text = $null
  try { $text = Get-Content -Raw -Encoding UTF8 -ErrorAction Stop $ExactPath }
  catch { $h.bad = $true; Write-Log ('이름 기억 파일을 못 읽었습니다(다른 프로그램이 쥐고 있음?) — 이번 회차는 방을 안 열고 덮어쓰지도 않습니다: ' + $_.Exception.Message); return $h }
  try {
    $o = $null
    if ("$text".Trim()) { $o = $text | ConvertFrom-Json }
    $cut = (Get-Date).AddDays(-30); $mcut = (Get-Date).AddDays(-7)
    if ($o.names) {
      foreach ($p in $o.names.PSObject.Properties) {
        try {
          $v = $p.Value
          if ([datetime]$v.at -gt $cut -and "$($v.t)") {
            $h.names[$p.Name] = @{ t = "$($v.t)"; n = "$($v.n)"; m = $(if ($null -ne $v.m -and "$($v.m)" -ne '') { [int]$v.m } else { $null }); read = "$($v.read)"; at = "$($v.at)" }
          }
        } catch { }
      }
    }
    if ($o.miss) {
      foreach ($p in $o.miss.PSObject.Properties) {
        try { if ([datetime]$p.Value.at -gt $mcut) { $h.miss[$p.Name] = @{ at = "$($p.Value.at)"; n = [int]$p.Value.n } } } catch { }
      }
    }
    if ($o.ambig) {
      foreach ($p in $o.ambig.PSObject.Properties) { try { if ([datetime]$p.Value -gt $mcut) { $h.ambig[$p.Name] = "$($p.Value)" } } catch { } }
    }
    if ($o.way) { try { $h.way = @{ keysFail = [int]$o.way.keysFail; lost = [int]$o.way.lost; stale = [int]$o.way.stale; at = "$($o.way.at)"; base = [math]::Max(-3, [math]::Min(3, [int]$o.way.base))
                                    z = $(if ($null -ne $o.way.z -and "$($o.way.z)" -ne '') { [double]$o.way.z } else { $null }) } } catch { } }
  } catch {
    # 깨진 파일(전원이 나가며 반쯤 써짐 · 손으로 고치다 틀림) — 옆으로 치우고 처음부터. 안 치우면 매 회차 빈 기억으로 다 다시 연다.
    try { Move-Item -Force $ExactPath ($ExactPath + '.bad') } catch { }
    Write-Log ('이름 기억 파일이 깨져 exact-names.json.bad 로 옮기고 처음부터 기억합니다: ' + $_.Exception.Message)
  }
  return $h
}
# 다른 이름으로 쓴 뒤 바꿔 단다 — 쓰는 도중에 꺼져도 앞 파일이 남는다
function Save-Exact($h) {
  if ($null -eq $h -or $h.bad) { return }
  try {
    $tmpPath = $ExactPath + '.tmp'
    Set-Content -Path $tmpPath -Value ([ordered]@{ v = 2; names = $h.names; miss = $h.miss; ambig = $h.ambig; way = $h.way } | ConvertTo-Json -Depth 5 -Compress) -Encoding UTF8
    Move-Item -Force $tmpPath $ExactPath
  } catch { }
}
# 안 맞아 쉬는 중인가 — 한 번이면 12시간, 연달아 두 번 넘게면 7일
function Test-Missed($m) {
  if ($null -eq $m) { return $false }
  try { $age = ((Get-Date) - [datetime]$m.at).TotalHours } catch { return $false }
  return ($age -lt $(if ([int]$m.n -ge 2) { 168 } else { 12 }))
}

# 시각 표기인가 — 서버 resolveTimeLabel 을 그대로 옮겼다(숫자 옆 O → 0 · 시 1~12 · 분 0~59 · 요일은 2~7일 전 ·
# 월/일은 올해나 지난해에 있는 날 · 연월일은 오늘까지). 숫자는 [0-9] 만(JS \d 와 같다 — 전각 숫자는 아니다).
function Test-TimeLabel([string]$label) {
  $s = (($label -replace '\s+', ' ').Trim()) -replace '[Oo](?=[0-9])|(?<=[0-9])[Oo]', '0'
  $today = (Get-Date).Date
  if ($s -match '^(오전|오후)\s*([0-9]{1,2})\s*[:.;：]\s*([0-9]{2})$') { $h = [int]$Matches[2]; return ($h -ge 1 -and $h -le 12 -and [int]$Matches[3] -le 59) }
  if ($s -eq '어제') { return $true }
  if ($s -match '^([일월화수목금토])요일$') {
    $want = '일월화수목금토'.IndexOf($Matches[1])
    for ($k = 2; $k -le 7; $k++) { if ([int]$today.AddDays(-$k).DayOfWeek -eq $want) { return $true } }
    return $false
  }
  if ($s -match '^([0-9]{1,2})\s*월\s*([0-9]{1,2})\s*일$') {
    $mo = [int]$Matches[1]; $d = [int]$Matches[2]
    foreach ($y in @($today.Year, ($today.Year - 1))) { try { [void](New-Object DateTime $y, $mo, $d); return $true } catch { } }
    return $false
  }
  if ($s -match '^([0-9]{4})\s*[.\-/]\s*([0-9]{1,2})\s*[.\-/]\s*([0-9]{1,2})\s*\.?$') {
    try { $dt = New-Object DateTime ([int]$Matches[1]), ([int]$Matches[2]), ([int]$Matches[3]); return ($dt -le $today) } catch { return $false }
  }
  return $false
}

# 서버 tidyName 과 같다 — 숫자와 월 · 일 · 박 · 명 사이, 「/」 앞뒤 빈칸을 뗀다
function Tidy-Name([string]$s) {
  return ((($s -replace '([0-9])\s+(?=[월일박명시분])', '$1') -replace '(월)\s+(?=[0-9])', '$1') -replace '\s*/\s*', '/' -replace '\s+', ' ').Trim()
}

# 한 장의 글자 조각 → 목록 줄들 [{ y(그림 좌표 · 시각 칸 가운데), name(서버와 같은 꼴), members, key, line, mbox, nbox }]
# ★ 서버(api/_kakao.mjs readPage · splitName)와 같은 기준 — 시각 표기가 줄 오른쪽(너비 55% 오른쪽)에 있는 줄 · 장 끝 줄 버림 ·
#   세 줄 이상이면 이름 시작 가운데값보다 한참 왼쪽 낱말(프로필 사진 속 글자) 버림 · 끝 숫자 = 인원 · 앞에 혼자 있는 1~3자리 숫자 버림.
# mbox = 인원수 낱말 칸 · nbox = 가장 긴 이름 낱말 칸(인원수가 회색인지 견준다) · line = 그 줄 글자(겹친 장 알아보기)
function Find-Rows($page) {
  $all = @()
  foreach ($ln in $page.lines) { $all += ,@($ln.words) }
  $found = @()
  foreach ($words in $all) {
    $n = $words.Count
    for ($k = [math]::Min(3, $n); $k -ge 1; $k--) {
      $tail = @($words[($n - $k)..($n - 1)])
      if ($tail[0].x -lt $page.w * 0.55) { continue }
      if (-not (Test-TimeLabel (($tail | ForEach-Object { $_.t }) -join ' '))) { continue }
      # ⚠ Measure-Object -Property 는 사전([ordered]@{})의 칸을 못 읽는다 — 손으로 센다
      $top = [double]::MaxValue; $bot = [double]::MinValue
      foreach ($tw in $tail) { if ($tw.y -lt $top) { $top = $tw.y }; if (($tw.y + $tw.h) -gt $bot) { $bot = $tw.y + $tw.h } }
      if ($top -lt 2 -or $bot -gt $page.h - 2) { break }          # 장 끝에 걸린 줄은 다른 장에서
      # 이름 줄은 시각 칸 가운데보다 위로 더 멀리 올 수 있다 — 카톡 날짜(「2026-10-21」)는 작고 아래에 붙어 이름이 13~14px 위(서버 readPage 와 같은 배수 · D-179)
      $cy = ($top + $bot) / 2; $unit = [math]::Max($bot - $top, 8); $bandDown = $unit * 0.7; $bandUp = $unit * 1.3; $tx = $tail[0].x
      $parts = @()
      foreach ($w2 in $all) { foreach ($wd in $w2) {
        $dy = ($wd.y + $wd.h / 2) - $cy
        if ($dy -le $bandDown -and -$dy -le $bandUp -and ($wd.x + $wd.w) -le ($tx + 1) -and -not ($tail -contains $wd)) { $parts += $wd }
      } }
      if ($parts.Count) { $found += ,@{ cy = $cy; parts = @($parts | Sort-Object { $_.x }); line = (($words | ForEach-Object { $_.t }) -join ' ') } }
      break
    }
  }
  if ($found.Count -ge 3) {
    $starts = @($found | ForEach-Object { $_.parts[0].x } | Sort-Object)
    $mid = $starts[[math]::Floor($starts.Count / 2)]
    foreach ($f in $found) { $f.parts = @($f.parts | Where-Object { $_.x -ge $mid - $page.w * 0.04 }) }
  }
  $rows = New-Object System.Collections.ArrayList
  foreach ($f in $found) {
    $ws = New-Object System.Collections.ArrayList
    foreach ($wd in $f.parts) { if ("$($wd.t)".Trim()) { [void]$ws.Add($wd) } }
    if (-not $ws.Count) { continue }
    $members = $null; $mbox = $null
    if ($ws.Count -ge 2 -and "$($ws[$ws.Count - 1].t)" -match '^[0-9]{1,4}$') { $mbox = $ws[$ws.Count - 1]; $members = [int]$mbox.t; $ws.RemoveAt($ws.Count - 1) }
    while ($ws.Count -ge 2 -and "$($ws[0].t)" -match '^[0-9]{1,3}$') { $ws.RemoveAt(0) }
    $raw = ((($ws | ForEach-Object { $_.t }) -join ' ') -replace '\s+', ' ').Trim()
    if ($raw.Length -gt 120) { $raw = $raw.Substring(0, 120) }
    $name = Tidy-Name $raw
    if (-not $name) { continue }
    $nbox = $ws[0]; foreach ($wd in $ws) { if ($wd.w -gt $nbox.w) { $nbox = $wd } }
    [void]$rows.Add([ordered]@{ y = [math]::Round($f.cy, 1); name = $name; members = $members; key = (($name -replace '\s+', '') + '|' + "$members");
                               line = $f.line; mbox = $mbox; nbox = $nbox })
  }
  return ,$rows
}

# 견줄 글자만 — 빈칸 · 문장부호 · 그림 글자(이모지)를 뺀다(글자 인식은 이모지를 못 읽는다)
function Strip-Name([string]$s) { return ($s -replace '[^\p{L}\p{Nd}]', '') }

# 연 방 제목이 그 줄의 방인가.
# ★ 목록이 「…」 로 자른 이름이면: 제목이 보이는 글자만큼은 길어야 하고 그 길이만큼 앞부분끼리 견준다(마지막 숫자 덩이는 잘렸을 수 있다).
# ★ 안 잘린 이름이면: 길이가 한 자 넘게 다르면 안 되고 통째로 견준다(숫자 덩이는 모두 같아야 한다).
# ★ 숫자를 뺀 글자는 8자 미만이면 1자, 그 위면 2자까지 다를 수 있다. 4자 미만 이름은 받지 않는다(맞는지 가릴 수 없다).
function Title-Fits([string]$title, [string]$name) {
  $cut = $name -match '(…|\.{2,})\s*$'
  $a = Strip-Name $name; $b = Strip-Name $title
  if ($a.Length -lt 4 -or $b.Length -lt 1) { return $false }
  $k = if ($a.Length -lt 8) { 1 } else { 2 }
  if ($cut) {
    if ($b.Length -lt $a.Length - $k) { return $false }
    $n = [math]::Min($a.Length, $b.Length); $x = $a.Substring(0, $n); $y = $b.Substring(0, $n)
  } else {
    if ([math]::Abs($a.Length - $b.Length) -gt 1) { return $false }  # 안 잘린 이름 = 목록이 다 보여 준 이름 — 길이는 글자 인식이 한 자 빼먹거나 더한 만큼만
    $x = $a; $y = $b
  }
  $dx = @([regex]::Matches($x, '[0-9]+') | ForEach-Object { $_.Value })
  $dy = @([regex]::Matches($y, '[0-9]+') | ForEach-Object { $_.Value })
  if ($dx.Count -ne $dy.Count) { return $false }
  for ($i = 0; $i -lt $dx.Count; $i++) {
    if ($cut -and $i -eq $dx.Count - 1) { if (-not ($dy[$i].StartsWith($dx[$i]) -or $dx[$i].StartsWith($dy[$i]))) { return $false } }
    elseif ($dx[$i] -ne $dy[$i]) { return $false }
  }
  return ([MotmotKakaoWin]::Lev(($x -replace '[0-9]+', '#'), ($y -replace '[0-9]+', '#')) -le $k)
}

# 방을 열어도 되나 — 꺼졌거나 · 사람이 돌아왔거나 · 멈추라 했으면 이번 회차는 더 안 연다
function Test-OpenOk($st) {
  if ($st.how -eq 'off') { return $false }
  if (Test-Path $StopFlag) { $script:Stopping = $true; $st.how = 'off'; return $false }
  # 「지금 한 번 읽기」 회차는 손이 5초 넘게 떨어진 뒤에 연다 — 단추를 누른 손이 막 움직이던 참일 수 있다(줄 누르기 길은 첫 장부터 연다 · 못 연 줄은 다음 장 · 회차로)
  if ($script:OpenNow -and [MotmotKakaoWin]::IdleMs() -lt 5000) { return $false }
  if ([MotmotKakaoWin]::InputSince([uint32]$st.mark)) {
    $st.how = 'off'; $st.userBack = $true
    Write-Log '사람이 PC 를 만져 이번 회차는 방 열기를 멈춥니다(기억한 이름 · 글자 인식으로 계속)'
    return $false
  }
  try {
    $wt = (Get-Item $Config).LastWriteTimeUtc
    if ($wt -ne $st.cfgTime) {
      $c = Get-Content -Raw -Encoding UTF8 $Config | ConvertFrom-Json
      $st.cfgTime = $wt                                           # 읽기에 성공한 뒤에 — 실패하면 다음 방에서 다시 읽는다
      if (-not (Test-On $c.openRooms $true)) { $st.how = 'off'; Write-Log '「방 열어 정확한 이름 읽기」 가 꺼졌습니다 — 지금부터 안 엽니다'; return $false }
    }
  } catch { }
  return $true
}

function Note-Way($st, [string]$way, [bool]$ok) {
  if ($way -eq 'keys') { if ($ok) { $st.keysWin++ } }
  elseif ($way -eq 'post') { if ($ok) { $st.postOk = $true; $st.postFail = 0 } else { $st.postFail++ } }
  elseif ($ok) { $st.mouseOk = $true }
}

# 줄 하나를 열어 제목을 읽고 닫는다 → 제목 또는 $null
# ① 목록 창에 메시지로 두 번 누르기 ② 안 뜨면 — 그새 사람이 안 왔고 목록이 그대로일 때만 — 진짜 마우스(덮인 자리면 안 누름).
# 이미 열려 있던 방이면 새 창 없이 앞으로만 온다 → 그 창 제목(닫지 않는다). 새로 뜬 창이 여럿이면(알림 등) 그 줄에 맞는 제목을 고르고
# 새로 뜬 창은 모두 닫는다($st.ours). $ink · $yEnd = 그 장을 찍을 때의 줄 모양 · 누를 줄 아래 끝(마우스 전에 다시 견준다).
# $via = 'keys' 면 누르지 않고 목록 창에 엔터만 보낸다(이미 키보드로 그 줄을 골라 두었다 — Open-ByKeys · D-160).
function Open-Title($top, $list, [int]$cx, [int]$cy, [string]$name, $members, $st, $ink, [int]$yEnd, [string]$via = '') {
  $st.tried++
  Close-Late $top $st                                           # 앞 줄에서 늦게 뜬 우리 창부터 정리
  [void]$st.clicked.Add(@{ n = $name; m = $members })
  $before = [MotmotKakaoWin]::ChatWindowsAll($top)                # 최소화된 창까지 — 되살아난 직원 창을 새 창으로 안 보게
  $fg0 = [MotmotKakaoWin]::GetForegroundWindow()
  $tries = if ($via -eq 'keys') { @('keys') } elseif (-not $st.postOk -and $st.postFail -ge 3) { @('mouse') } else { @('post', 'mouse') }
  $new = @()
  foreach ($way in $tries) {
    if ($way -eq 'keys') { [void][MotmotKakaoWin]::PostKey($list, 0x0D) }
    elseif ($way -eq 'post') { [MotmotKakaoWin]::PostDbl($list, $cx, $cy) }
    else {
      # 메시지가 안 먹은 사이(1.5초 넘게) 사람이 왔거나 목록이 움직였으면 마우스는 안 쓴다
      if ([MotmotKakaoWin]::InputSince([uint32]$st.mark)) { $st.how = 'off'; $st.userBack = $true; Write-Log '사람이 PC 를 만져 이번 회차는 방 열기를 멈춥니다(기억한 이름 · 글자 인식으로 계속)'; break }
      if (-not [MotmotKakaoWin]::SameInkTo($ink, [MotmotKakaoWin]::RowInk($top, $list), $yEnd)) { $st.movedNow = $true; break }
      if (-not [MotmotKakaoWin]::MouseDbl($top, $list, $cx, $cy)) { $st.covered++; continue }   # 그 자리를 다른 창이 덮고 있다
      $st.mark = [MotmotKakaoWin]::Tick()                       # 우리가 넣은 누르기 — 사람 입력으로 치지 않는다(누른 때만)
    }
    for ($t = 0; $t -lt [int]$st.wait; $t += 100) {
      Start-Sleep -Milliseconds 100
      $new = @([MotmotKakaoWin]::ChatWindows($top) | Where-Object { $before -notcontains $_ })
      if ($new.Count) { break }
      $fg = [MotmotKakaoWin]::GetForegroundWindow()             # 이미 열려 있던 방이면 새 창 없이 앞으로만 온다(닫지 않는다)
      if ($fg -ne $fg0 -and ($before -contains $fg.ToInt64()) -and [MotmotKakaoWin]::IsChatWindow($fg, $top)) {
        Note-Way $st $way $true; $st.already++; return [MotmotKakaoWin]::Title($fg)
      }
    }
    if (-not $new.Count -and $way -ne 'mouse') {                # 느리게 뜬 창 — 한 번 더 보고 메시지(누르기 · 엔터) 덕으로 친다
      Start-Sleep -Milliseconds 300
      $new = @([MotmotKakaoWin]::ChatWindows($top) | Where-Object { $before -notcontains $_ })
    }
    # 키보드: 그 방이 이미 앞에 떠 있으면 엔터로는 아무것도 안 바뀐다 — 앞 창 제목이 그 줄에 가까우면 그 제목을 돌려준다(닫지 않는다).
    # 엔터가 안 먹은 것일 수도 있으니 엔터 덕으로 안 치고($st.fgHit) Open-ByKeys 가 엄격히 가린다(Test-OnlyRow).
    if (-not $new.Count -and $way -eq 'keys' -and $fg0 -ne [IntPtr]::Zero -and ($before -contains $fg0.ToInt64()) -and [MotmotKakaoWin]::IsChatWindow($fg0, $top) -and
        (Title-Fits (Clean-Title ([MotmotKakaoWin]::Title($fg0)) $members) $name)) {
      $st.fgHit = $true; return [MotmotKakaoWin]::Title($fg0)
    }
    Note-Way $st $way ([bool]$new.Count)
    if ($new.Count) { break }
  }
  if (-not $new.Count) {
    if ($st.how -ne 'off' -and -not $st.movedNow) {
      $st.failed++
      if ($st.failed -ge 3 -and $st.opened -eq 0 -and $st.already -eq 0) {
        $st.how = 'off'
        Write-Log '방을 열지 못했습니다(메시지 · 마우스 둘 다) — 이번 회차는 기억한 이름 · 글자 인식만 씁니다'
      }
    }
    return $null
  }
  # 첫 창이 뜬 뒤 조금 더 본다 — 알림 창이 먼저 뜨고 방 창이 뒤따를 수 있다
  Start-Sleep -Milliseconds 300
  $new = @([MotmotKakaoWin]::ChatWindows($top) | Where-Object { $before -notcontains $_ })
  # ★ 우리가 연 창만 닫는다 — 그 줄 이름에 맞는 창 · 앞서 누른 줄의 늦게 뜬 창 · (그새 사람이 안 왔고) 새로 뜬 창이 하나뿐이면 그것(목록이 밀려 다른 방이 열림).
  #   그 밖의 창(사람이 연 방 · 걸려 온 전화)은 건드리지 않는다.
  $fit = @(); $other = @()
  foreach ($h in $new) {
    if ($st.keep -contains $h) { continue }                       # 원래 떠 있던 창(직원 창)은 절대 닫지 않는다
    $t2 = [MotmotKakaoWin]::Title([IntPtr][long]$h)
    if (Title-Fits (Clean-Title $t2 $members) $name) { $fit += ,@($h, $t2) }
    elseif ($via -ne 'keys' -and (Test-Clicked $t2 $st $name)) { [void]$st.ours.Add([long]$h); [MotmotKakaoWin]::Close([IntPtr][long]$h) }   # 키보드는 엔터 한 번 = 창 하나 — 앞서 연 방이 또 열린 것이면 자리를 잃은 것(Open-ByKeys 가 가린다)
    else { $other += ,@($h, $t2) }
  }
  $title = $null; $mine = @()
  if ($fit.Count) { $title = $fit[0][1]; $mine = $fit }
  elseif ($other.Count -eq 1 -and -not [MotmotKakaoWin]::InputSince([uint32]$st.mark)) { $title = $other[0][1]; $mine = $other }
  foreach ($x in $mine) { [void]$st.ours.Add([long]$x[0]); [MotmotKakaoWin]::Close([IntPtr][long]$x[0]) }
  for ($t = 0; $t -lt 1500 -and $mine.Count; $t += 100) {
    $ids = @($mine | ForEach-Object { [long]$_[0] })
    $left = @([MotmotKakaoWin]::ChatWindows($top) | Where-Object { $ids -contains $_ })
    if (-not $left.Count) { break }
    Start-Sleep -Milliseconds 100
  }
  return $title
}

# 카톡 판에 따라 창 제목 끝에 인원수가 붙을 수 있다 — 그 줄 인원수와 같으면 떼고 견준다
function Clean-Title([string]$title, $members) {
  if ($null -eq $members -or -not $title) { return $title }
  return ($title -replace ('\s+' + $members + '\s*$'), '').Trim()
}
# 이번 회차에 앞서 누른 줄(지금 줄 빼고)의 방 창 제목인가 — clicked = [{ n 이름, m 인원 }]
function Test-Clicked([string]$title, $st, [string]$except) {
  foreach ($c in $st.clicked) { if ($c.n -ne $except -and (Title-Fits (Clean-Title $title $c.m) $c.n)) { return $true } }
  return $false
}
# 앞 줄에서 늦게 뜬 우리 창 — 원래 떠 있지 않았고 · 아직 우리 것으로 안 적었고 · 앞서 누른 줄의 방 제목인 창을 닫는다
function Close-Late($top, $st) {
  if (-not $st.clicked.Count) { return }
  foreach ($h in @([MotmotKakaoWin]::ChatWindows($top))) {
    if ($st.keep -contains $h -or $st.ours -contains $h) { continue }
    if (Test-Clicked ([MotmotKakaoWin]::Title([IntPtr][long]$h)) $st '') { [void]$st.ours.Add([long]$h); [MotmotKakaoWin]::Close([IntPtr][long]$h) }
  }
}

# 단체방 줄인가 — 인원이 openMinMembers 이상이고, 그 숫자가 이름보다 **옅게**(카톡 인원수 회색) 찍혔다.
# 이름 끝에 숫자를 붙여 저장한 개인 대화(「홍길동 5678」)는 숫자가 이름과 같은 진하기다. 가릴 수 없으면 단체방으로 안 본다.
function Test-GroupRow($row, $bmp, $cfg, $st) {
  if ($null -eq $row.members -or $row.members -lt [int]$cfg.openMinMembers) { return $false }
  if ((Strip-Name $row.name).Length -lt 4) { return $false }           # 제목을 맞춰 볼 수 없는 짧은 이름
  if ($null -eq $bmp -or $null -eq $row.mbox -or $null -eq $row.nbox) { return $false }
  $m = [MotmotKakaoWin]::InkCore($bmp, $row.mbox.x, $row.mbox.y, $row.mbox.w, $row.mbox.h)
  $n = [MotmotKakaoWin]::InkCore($bmp, $row.nbox.x, $row.nbox.y, $row.nbox.w, $row.nbox.h)
  if ($m -lt 0 -or $n -le 0 -or $m -ge $n * 0.8) { $st.grayK[$row.key] = 1; return $false }
  return $true
}

# 한 장의 줄들에 정확한 이름을 붙인다 → $page.titles = [{ y, t, k }]
# $s = 그 장을 찍은 것(그림 · 그때의 줄 모양 ink) · $pageNo · $prevTexts = 앞 장 줄 글자(겹친 줄 알아보기)
function Add-Titles($page, $s, [int]$pageNo, $prevTexts, $top, $list, $ex, $st, $cfg) {
  $titles = New-Object System.Collections.ArrayList
  $st.pageSeq++
  $lw = [MotmotKakaoWin]::ListWidth($list)
  $scale = if ($lw -gt 0) { $page.w / $lw } else { 1 }
  $rows = Find-Rows $page
  # 줄 사이 간격(목록 안 픽셀) — 누를 줄 아래 끝까지 움직임을 본다
  $gap = 60
  if ($rows.Count -ge 2) { $ds = @(); for ($i = 1; $i -lt $rows.Count; $i++) { $ds += ($rows[$i].y - $rows[$i - 1].y) / $scale }; $gap = [math]::Max(30, (@($ds | Sort-Object))[[math]::Floor($ds.Count / 2)]) }
  $dupKeys = @{}
  foreach ($row in $rows) { $dupKeys[$row.key] = 1 + [int]$dupKeys[$row.key] }
  $bmp = $null
  try { $bmp = New-Object System.Drawing.Bitmap $s.png } catch { }
  $now = (Get-Date).ToString('o')
  try {
    $moved = $false
    foreach ($row in $rows) {
      $key = $row.key
      # 키보드로 열 때(D-160) — 모든 줄을 남긴다: 장 · 높이(목록 픽셀)로 목록 번호를 매기고(Index-Rows) · 연 방이 어느 줄인지 이웃 줄과 견준다(Open-ByKeys)
      $rec = $null
      if ($st.keys) {
        $rec = @{ page = $page; pn = $st.pageSeq; yImg = $row.y; yL = $row.y / $scale; key = $key; name = $row.name; members = $row.members; eligible = $false; cand = $false; idx = $null }
        [void]$st.rows.Add($rec)
      }
      $fresh = $false
      if ($dupKeys[$key] -gt 1) { $st.dup++; $fresh = $true }                    # 한 장에 같은 글자 줄이 둘 = 다른 방 둘일 수 있다
      # 앞 장에서 본 같은 글자 줄이 겹친 자리(앞 장 끝 = 이 장 위쪽)가 아니면 다른 방일 수 있다 — 이번 회차는 그 글자에 이름을 안 붙인다
      $seen = $st.keySeen[$key]
      if ($null -ne $seen -and -not ($seen -eq $pageNo - 1 -and (($null -ne $prevTexts -and $prevTexts.Contains($row.line)) -or $row.y -lt $page.h * 0.6))) { $fresh = $true }
      $st.keySeen[$key] = $pageNo
      # 이 글자는 두 방일 수 있다 — 기억한 제목도 버리고(다음 회차에 다른 방에 붙지 않게) 7일 동안 안 열고 안 붙인다.
      # 시각은 **이번에 실제로 본 때만** 새로 적는다(물려받은 표시는 그대로 두어 7일 뒤 풀리게 — 한 번 잘못 본 것이 영영 막지 않게).
      if ($fresh -and -not $st.ambig.ContainsKey($key)) { $ex.ambig[$key] = $now }
      if ($fresh -or $ex.ambig.ContainsKey($key)) { $st.ambig[$key] = 1 }
      if ($st.ambig.ContainsKey($key)) { [void]$ex.names.Remove($key); continue }
      $e = $ex.names[$key]
      $eligible = Test-GroupRow $row $bmp $cfg $st
      if ($rec) { $rec.eligible = $eligible }
      $missed = Test-Missed $ex.miss[$key]
      $stale = $false
      if ($e) { try { $stale = ((Get-Date) - [datetime]$e.read).TotalDays -ge 7 } catch { $stale = $true } }
      $t = $null
      $canTry = ($eligible -and -not $missed -and -not $moved -and $st.tried -lt [int]$cfg.openMax -and $st.how -ne 'off')
      if ($e -and -not ($stale -and $canTry)) {
        $t = $e.t; $e.at = $now; $st.cachedK[$key] = 1
      } elseif ($canTry -and $st.keys) {
        $rec.cand = $true                                              # 찍기가 끝난 뒤 키보드로 연다(Open-ByKeys) — 그때까지는 기억한 이름(있으면)
        if ($e) { $t = $e.t; $e.at = $now }
      } elseif ($canTry -and (Test-OpenOk $st)) {
        $cyL = [int]($row.y / $scale); $yEnd = [int]($cyL + $gap)
        if (-not [MotmotKakaoWin]::SameInkTo($s.ink, [MotmotKakaoWin]::RowInk($top, $list), $yEnd)) { $moved = $true; $st.moved++ }
        else {
          $st.movedNow = $false; $a0 = $st.already
          $got = Open-Title $top $list ([int]($lw * 0.45)) $cyL $row.name $row.members $st $s.ink $yEnd
          $still = (-not $st.movedNow) -and [MotmotKakaoWin]::SameInkTo($s.ink, [MotmotKakaoWin]::RowInk($top, $list), $yEnd)
          if (-not $still) { $moved = $true; $st.moved++ }
          $got = Clean-Title $got $row.members                       # 창 제목 끝 인원수는 떼고 견준다
          if ($got -and $still -and (Title-Fits $got $row.name) -and -not ($st.given.ContainsKey($got) -and $st.given[$got] -ne $key)) {
            $t = $got; $st.openK[$key] = 1
            if ($st.already -eq $a0) { $st.opened++ }                 # 이미 떠 있던 방 창이면 「이미 열린 방」 으로 셌다(Open-Title)
            $ex.names[$key] = @{ t = $got; n = $row.name; m = $row.members; read = $now; at = $now }
            [void]$ex.miss.Remove($key)
          } elseif ($got -and $still) {
            $st.mismatch++
            $m0 = $ex.miss[$key]
            $ex.miss[$key] = @{ at = $now; n = $(if ($m0) { [int]$m0.n + 1 } else { 1 }) }
          }
        }
        if (-not $t -and $e) { $t = $e.t; $e.at = $now }            # 다시 확인을 못 했으면 기억한 이름
      } elseif ($e) {
        $t = $e.t; $e.at = $now; $st.cachedK[$key] = 1
      } elseif ($eligible -and -not $missed) {
        $st.skipK[$key] = 1  # 못 열면 글자 인식 이름 그대로 — 서버가 최근 방 이름에 붙인다(비슷한 이름을 여기서 짐작하지 않는다)
      }
      if ($t) {
        # 같은 제목을 다른 줄 글자에 또 붙이지 않는다(한 회차 안) — 엉뚱한 줄에 붙은 것일 수 있다
        if ($st.given.ContainsKey($t) -and $st.given[$t] -ne $key) { $st.conflict++; continue }
        $st.given[$t] = $key
        [void]$titles.Add([ordered]@{ y = $row.y; t = $t; k = $key })
      }
    }
  } finally { if ($bmp) { $bmp.Dispose() } }
  $page['titles'] = @($titles)
}

# ── 키보드로 방 열기 (D-160) ─────────────────────────────
# 사장님(2026-10-16): "톡방 이름 자체를 긁어서 확인할 수 있게" → 카톡은 목록 글자를 어떤 통로로도 안 내준다(I-181 점검 두 번).
# 남은 정확한 이름 = 방 창 제목. 0.9.2 는 그 줄 그림 자리를 눌러 열었다(목록이 가려지거나 · 연 방의 안 읽음 표시가 지워져 그림이 바뀌면 그 장은 그만 열었다).
# 0.9.4 는 찍기가 끝난 뒤 **목록 창에 키 메시지**로 줄을 골라 엔터로 연다 — 점검에서 포커스 없이도 아래 화살표가 목록 고르기를 옮겼다.

# 방을 여는 길 — config openWay: keys · click 은 그대로, auto(기본)는 키보드 — 단 세 회차 연달아 ① 엔터로 방이 안 열렸거나
# ② 연 방이 고른 줄과 달라 이름을 하나도 못 얻었으면 하루 동안 줄 누르기(0.9.2 길)
function Get-OpenWay($cfg, $ex) {
  $w = "$($cfg.openWay)".Trim().ToLower()
  if ($w -eq 'click' -or $w -eq 'keys') { return $w }
  if ([int]$ex.way.keysFail -ge 3 -or [int]$ex.way.lost -ge 3) {
    try { if (((Get-Date) - [datetime]$ex.way.at).TotalHours -lt 24) { return 'click' } } catch { }
    $ex.way.keysFail = 0; $ex.way.lost = 0                           # 하루가 지났다 — 다시 키보드부터
  }
  return 'keys'
}

# 줄마다 목록 번호(맨 위 = 0)를 붙인다 — 번호 = 높이(목록 픽셀) ÷ 줄 간격, 칸은 **잰 자리(위상)를 가운데로** 나눈다(앞뒤 반 줄씩 여유).
# 줄 간격 = 장 안 이웃 줄 간격 가운데 작은 쪽 4분의 1 값 근처의 평균(글자 인식이 놓친 줄 = 두 배 간격은 빠진다).
# 장 사이 거리 = 앞 장과 이 장에 한 번씩만 나온 같은 방(열쇠)의 높이 차 — 서로 안 맞거나 · 같은 방이 없거나 · 안 내려갔으면 그 장부터는 번호를 안 붙인다.
# 위상 = 모든 줄의 (높이 ÷ 줄 간격) 소수 부분의 원 평균 — 목록 맨 위에 무엇이 있든(빈칸 · 머리 칸) 줄 가운데가 칸 가운데에 오게 한다.
# ★ 글자 인식이 한 줄을 놓쳐도 번호는 자리로 매기므로 아래 줄 번호가 밀리지 않는다. 첫 장(맨 위)에 줄이 없으면 번호를 안 붙인다.
# $zHint = 지난 회차에 맞았던 0번 칸 가운데 자리(줄 단위 · ex.way.z) — 맨 위 칸 경계를 그 ±0.5 에 둔다(회차마다 번호가 같게).
function Index-Rows($rows, $zHint = $null) {
  $byPage = [ordered]@{}
  foreach ($r in $rows) {
    $k = [string]$r.pn
    if (-not $byPage.Contains($k)) { $byPage[$k] = New-Object System.Collections.ArrayList }
    [void]$byPage[$k].Add($r)
  }
  if (-not $byPage.Contains('1')) { return @{ ok = $false; why = '첫 장에서 줄을 못 읽어 번호를 못 붙임'; pages = $byPage.Count; placed = 0 } }
  $gaps = New-Object System.Collections.ArrayList
  foreach ($k in $byPage.Keys) {
    $l = @($byPage[$k] | Sort-Object { $_.yL })
    for ($i = 1; $i -lt $l.Count; $i++) { $g = $l[$i].yL - $l[$i - 1].yL; if ($g -gt 8) { [void]$gaps.Add($g) } }
  }
  if ($gaps.Count -lt 3) { return @{ ok = $false; why = '줄이 적어 줄 간격을 못 잼'; pages = $byPage.Count; placed = 0 } }
  $sq = @($gaps | Sort-Object)
  $q = $sq[[math]::Floor(($sq.Count - 1) / 4)]
  $near = @($sq | Where-Object { $_ -ge $q * 0.8 -and $_ -le $q * 1.25 })
  $sum = 0.0; foreach ($g in $near) { $sum += $g }
  $pitch = $sum / $near.Count                                        # ⚠ $p 같은 이름은 쓰지 않는다 — 이름은 대소문자를 안 가린다
  $off = [ordered]@{}; $prev = $null; $placed = 0
  foreach ($k in $byPage.Keys) {
    if ($null -eq $prev) { $off[$k] = 0.0; $prev = $k; $placed++; continue }
    $na = @{}; foreach ($r in $byPage[$prev]) { $na[$r.key] = 1 + [int]$na[$r.key] }
    $nb = @{}; foreach ($r in $byPage[$k]) { $nb[$r.key] = 1 + [int]$nb[$r.key] }
    $d = New-Object System.Collections.ArrayList
    foreach ($r in $byPage[$k]) {
      if ($nb[$r.key] -ne 1 -or $na[$r.key] -ne 1 -or ($r.key -split '\|')[0].Length -lt 2) { continue }
      foreach ($pr in $byPage[$prev]) { if ($pr.key -eq $r.key) { [void]$d.Add($pr.yL - $r.yL); break } }
    }
    if (-not $d.Count) { break }
    $ds = @($d | Sort-Object); $med = $ds[[math]::Floor(($ds.Count - 1) / 2)]
    $agree = @($ds | Where-Object { [math]::Abs($_ - $med) -le $pitch * 0.3 })
    if (($ds.Count -gt 1 -and $agree.Count * 2 -le $ds.Count) -or $med -lt 1) { break }   # 과반이 안 맞거나(둘 중 하나 = 우연히 같은 글자일 수 있다) · 앞 장보다 안 내려간 장(바닥의 마지막 굴림은 몇 픽셀일 수 있다 — 그건 받는다)
    $sum = 0.0; foreach ($x in $agree) { $sum += $x }
    $off[$k] = $off[$prev] + $sum / $agree.Count
    $prev = $k; $placed++
  }
  $sn = 0.0; $cs = 0.0
  foreach ($k in $off.Keys) { foreach ($r in $byPage[$k]) { $a = 2 * [math]::PI * (($off[$k] + $r.yL) / $pitch); $sn += [math]::Sin($a); $cs += [math]::Cos($a) } }
  $ph = [math]::Atan2($sn, $cs) / (2 * [math]::PI)
  if ($ph -lt 0) { $ph += 1 }
  foreach ($k in $off.Keys) {
    foreach ($r in $byPage[$k]) { $r.idx = [int][math]::Floor(($off[$k] + $r.yL) / $pitch - $ph + 0.5) }
  }
  # 0번 칸 — 첫 장 줄만으로 정한다: a1 = 첫 장 줄들의 (높이 ÷ 줄 간격 − 번호) 평균 = 지금 번호 매김에서 0번 칸 줄 가운데의 자리(줄 단위).
  # 처음엔 0.2~1.2 줄이면 0번(위쪽 여백이 조금 있어도) · 지난번 맞은 자리(zHint)가 있으면 그 ±0.5 줄. 그보다 아래(위에 칸이 있는 목록)는 첫 방이 맞춘다(way.base).
  # ★ 전체 위상으로 정하지 않는다 — 줄 간격의 작은 오차가 아래 장으로 쌓여 회차마다 ±0.1 흔들리고, 맨 위 줄을 읽었는지에 따라서도 달라진다(그러면 번호가 회차마다 바뀌어 1:1 방을 연다).
  $a1 = 0.0; foreach ($r in $byPage['1']) { $a1 += $r.yL / $pitch - $r.idx }
  $a1 = $a1 / $byPage['1'].Count
  $z0 = 0.7
  if ($null -ne $zHint -and "$zHint" -ne '') { try { $z0 = [math]::Max(0.2, [math]::Min(1.2, [double]$zHint)) } catch { } }
  $sh = [int][math]::Floor($a1 - $z0 + 0.5)
  if ($sh) { foreach ($k in $off.Keys) { foreach ($r in $byPage[$k]) { $r.idx = $r.idx + $sh } } }
  return @{ ok = $true; pitch = [math]::Round($pitch, 1); phase = [math]::Round($ph, 2); pages = $byPage.Count; placed = $placed; z = [math]::Round($a1 - $sh, 3) }
}

# 연 방 창 제목이 그 줄의 방인가(느슨) — Title-Fits(단체방 이름) 또는, 4자 안 되는 짧은 이름(1:1 「김철수」)은 글자가 똑같을 때. 자리 맞추기에만 쓴다.
function Same-Row([string]$title, $r) {
  $t = Clean-Title $title $r.members
  if (Title-Fits $t $r.name) { return $true }
  $a = Strip-Name $t; $b = Strip-Name $r.name
  return ($b.Length -ge 2 -and $b.Length -lt 4 -and $a -eq $b)
}
# 연 방 창 제목이 그 줄의 방인가(엄격) — 글자가 똑같거나, 목록이 「…」 로 자른 이름이면 제목이 보이는 글자로 **그대로** 시작한다.
# 고른 줄이 아닌 이웃 줄로 자리를 다시 맞출 때는 이것만 받는다(한두 자 다른 비슷한 이름의 이웃에 엉뚱한 이름이 붙지 않게).
function Strict-Row([string]$title, $r) {
  $t = Strip-Name (Clean-Title $title $r.members)
  $b = Strip-Name $r.name
  if ($b.Length -lt 2) { return $false }
  if ($r.name -match '(…|\.{2,})\s*$') { return $t.StartsWith($b) }
  return ($t -eq $b)
}
# 글자가 통째로 똑같은가 — 「…」 로 자른 이름의 앞부분 맞음은 안 친다(같은 단체 · 날짜로 시작하는 다른 방이 흔하다). 이웃으로 자리를 다시 맞출 때 쓴다.
function Exact-Row([string]$title, $r) {
  $b = Strip-Name $r.name
  return ($b.Length -ge 2 -and (Strip-Name (Clean-Title $title $r.members)) -eq $b)
}
# 자리를 확인할 길이 없는 제목(직원이 열어 둔 창 · 엔터가 아무것도 안 바꿨는데 앞에 떠 있는 창)이 그 번호의 줄인가 —
# 그 번호의 단체방 줄에 **엄격히** 맞고, 다른 **어느** 줄(번호 없는 줄 포함 — 멀리 있는 비슷한 이름의 방)에도 느슨하게조차 안 맞을 때만.
function Test-OnlyRow([string]$title, $ti, $byIdx, $rows) {
  if (-not @($byIdx[$ti] | Where-Object { $_.eligible -and (Strict-Row $title $_) }).Count) { return $false }
  return (-not @($rows | Where-Object { $_.idx -ne $ti -and (Same-Row $title $_) }).Count)
}
# 맞는지 확인 못 한 줄은 쉬게 한다 — 한 번이면 12시간, 연달아 두 번 넘게면 7일(Test-Missed · 줄 누르기 길과 같다)
function Note-Miss($ex, [string]$key, [string]$now) {
  $m0 = $ex.miss[$key]
  $ex.miss[$key] = @{ at = $now; n = $(if ($m0) { [int]$m0.n + 1 } else { 1 }) }
}
# 한 목록 번호의 줄들(여러 장에 나온 같은 방)에 정확한 이름을 붙인다 — **그 줄 글자가 제목에 맞는 단체방 줄만**($strict 면 엄격하게).
# 한 회차에 같은 제목이 다른 줄 글자에 붙으려 하면 버리고 그 줄은 쉬게 한다. 제목에 안 맞은 열 줄(그 장에서 글자를 잘못 읽은 같은 방)도 쉬게 한다 —
# 안 그러면 그 글자가 회차마다 열 줄로 남아 같은 방을 또 연다(줄 누르기 길의 「안 맞아 버림」 과 같다). → 붙였나
function Name-Rows($rows, [string]$got, $st, $ex, [string]$now, [bool]$strict) {
  $any = $false
  foreach ($r in $rows) {
    if (-not $r.eligible) { continue }
    $tt = Clean-Title $got $r.members
    $ok = if ($strict) { Strict-Row $got $r } else { Title-Fits $tt $r.name }
    if (-not $ok) { if ($r.cand) { Note-Miss $ex $r.key $now }; continue }
    if ($st.given.ContainsKey($tt) -and $st.given[$tt] -ne $r.key) { $st.conflict++; Note-Miss $ex $r.key $now; continue }
    $ex.names[$r.key] = @{ t = $tt; n = $r.name; m = $r.members; read = $now; at = $now }
    [void]$ex.miss.Remove($r.key)
    $st.given[$tt] = $r.key
    $r.page['titles'] = @(@($r.page['titles']) | Where-Object { $null -ne $_ -and $_.k -ne $r.key }) + @([ordered]@{ y = $r.yImg; t = $tt; k = $r.key })
    $any = $true
  }
  return $any
}

# 열 방을 키보드로 골라 연다 — 찍기가 끝나고 목록을 맨 위로 올린 뒤(Invoke-Scan). 목록 창에만 키 메시지를 보낸다(창을 앞으로 안 가져온다):
# 고르기를 0번으로(위 화살표 넉넉히 · 아래 하나 · 다시 위 넉넉히) → 아래 화살표로 그 번호까지 → 엔터 → 창 제목 → 닫기.
# ★ 그림 자리를 누르지 않는다 — 목록이 가려져도 · 다른 화면에 있어도 · 광고 그림이 줄을 덮어도 된다.
# ★ 여는 앞에 맨 위 장의 줄 모양이 찍을 때(첫 장)와 같은지 본다 — 새 메시지는 방을 맨 위로 올려 번호를 민다. 다르면 이번 회차는 안 연다(다음 회차가 새로 찍는다).
# ★ 직원이 열어 둔 방(최소화 포함)은 엔터를 안 누르고 그 창 제목을 읽는다(앞으로 가져오지도 · 닫지도 않는다) — 자리 증거가 없으니
#   그 줄에 엄격히 맞고 다른 어느 줄에도 안 맞는 제목만(Test-OnlyRow). 엔터가 아무것도 안 바꿨는데 앞에 떠 있는 방 창도 같다.
# ★ 연 방이 정말 그 줄인지 창 제목으로 확인한다:
#   · 고른 줄 글자가 제목에 맞고(Title-Fits) ±3 이웃은 안 맞으면(또는 고른 줄은 엄격히 맞고 이웃은 엄격히는 안 맞으면) 그 줄 — 그 줄에만 이름을 붙인다.
#     「…」 로 앞부분이 같은 두 방이 이웃이면 둘 다 엄격히 맞으므로 받지 않는다(한 칸 어긋난 자리에서 쌍둥이 방 제목이 붙지 않게).
#   · 고른 줄은 안 맞고 이웃 **하나만 글자가 통째로 똑같으면**(Exact-Row), 회차의 첫 방일 때만 자리를 다시 맞춘다(목록 맨 위 칸 · 번호 어긋남) —
#     원래 줄을 고친 번호로 한 번 더 열어 맞으면 그때 이웃 줄에도 이름을 붙이고, 고친 번호를 기억한다(ex.way.base — 다음 회차부터 처음부터 맞는 줄).
#     기억은 회차 끝에 목록을 맨 위로 올려 줄 모양이 찍을 때와 같을 때만(그새 새 메시지로 순서가 바뀐 것을 번호 어긋남으로 배우지 않게).
#   · 그 밖(안 맞음 · 비슷한 이름 둘 · 첫 방이 아닌데 이웃 · 고친 번호로도 안 맞음)은 그 줄을 쉬게 하고(12시간) 이번 회차는 멈춘다 — 엉뚱한 방을 이어서 열지 않게.
# ★ 단체방 줄에만 이름을 붙인다(D-148 과 같다).
# $toTop = 목록을 맨 위로 올리는 스크립트 블록(Invoke-Scan 의 $backTop) — 고친 번호를 기억하기 전에 줄 모양을 견주려고.
function Open-ByKeys($top, $list, $st, $ex, $cfg, [bool]$topSure, $toTop = $null) {
  $cands = @($st.rows | Where-Object { $_.cand })
  if (-not $cands.Count) { return }
  $done = @{}
  try { Open-ByKeysIn $top $list $st $ex $cfg $topSure $toTop $cands $done }
  finally {
    # 열려던 방 가운데 못 끝낸 것 — 어디서 멈췄든(맨 위 확인 못 함 · 번호 못 붙임 · 사람이 돌아옴 · 안 맞아 멈춤) 「다음 회차로」 에 센다
    foreach ($c in $cands) { if ($null -eq $c.idx -or -not $done.ContainsKey([int]$c.idx)) { $st.skipK[$c.key] = 1 } }
  }
}

function Open-ByKeysIn($top, $list, $st, $ex, $cfg, [bool]$topSure, $toTop, $cands, $done) {
  if (-not $topSure) { $st.keysWhy = '맨 위를 확인 못 해 안 엶'; return }
  $ix = Index-Rows $st.rows $ex.way.z
  if (-not $ix.ok) { $st.keysWhy = $ix.why; return }
  if ($ix.placed -lt $ix.pages) { $st.keysWhy = "번호를 못 붙인 장 $($ix.pages - $ix.placed)" }
  $byIdx = @{}
  foreach ($r in $st.rows) {
    if ($null -eq $r.idx) { continue }
    if (-not $byIdx.ContainsKey($r.idx)) { $byIdx[$r.idx] = New-Object System.Collections.ArrayList }
    [void]$byIdx[$r.idx].Add($r)
  }
  $targets = @($cands | Where-Object { $null -ne $_.idx } | ForEach-Object { [int]$_.idx } | Sort-Object -Unique)
  $st.keysTargets = $targets.Count
  if (-not $targets.Count -or -not (Test-OpenOk $st)) { return }
  $now = (Get-Date).ToString('o')
  # 직원이 열어 둔 방 — 그 줄에 엄격히 맞고 다른 어느 줄에도 안 맞는 창 제목이 하나면 그것을 쓴다(아니면 엔터로 연다 — 직원 창은 앞으로만 온다)
  $keepT = New-Object System.Collections.ArrayList
  foreach ($h in @($st.keep)) { $kt = [MotmotKakaoWin]::Title([IntPtr][long]$h); if ($kt) { [void]$keepT.Add($kt) } }
  foreach ($ti in $targets) {
    $hk = @($keepT | Where-Object { Test-OnlyRow $_ $ti $byIdx $st.rows })
    if ($hk.Count -ne 1) { continue }
    if (Name-Rows $byIdx[$ti] $hk[0] $st $ex $now $true) { $st.already++; $done[$ti] = 1 }
  }
  $queue = New-Object System.Collections.ArrayList
  foreach ($ti in $targets) { if (-not $done.ContainsKey($ti)) { [void]$queue.Add($ti) } }
  if (-not $queue.Count) { return }
  $st.keysTried = $true
  # 고르기를 0번으로 — 위로 넉넉히(맨 위에서는 더 안 올라간다) · 아래로 하나 · 다시 위로 넉넉히.
  # 가운데 아래 화살표는 고른 줄이 없을 때를 위한 것이다(위 화살표가 아무것도 안 고르고, 아래 화살표가 보이는 첫 줄을 고르는 목록이어도 0번으로 간다).
  # 넉넉히 = 읽은 줄 수 + 40(번호를 못 붙인 장이 있어도 · 직원이 고르기를 맨 아래에 두었어도 맨 위까지).
  $maxIdx = 0; foreach ($k in $byIdx.Keys) { if ($k -gt $maxIdx) { $maxIdx = $k } }
  $nUp = [math]::Max($maxIdx, $st.rows.Count) + 40
  foreach ($pass in 1, 2) {
    for ($k = 0; $k -lt $nUp; $k++) { [void][MotmotKakaoWin]::PostKey($list, 0x26) }
    if ($pass -eq 1) { [void][MotmotKakaoWin]::PostKey($list, 0x28) }
    Start-Sleep -Milliseconds ([math]::Min(3000, 500 + 5 * $nUp))
  }
  $sel = 0; $nNamed = 0                                              # 지금 고른 줄의 진짜 자리(0 = 맨 위) · 엔터로 얻은 이름 수(finally 가 읽는다)
  try {
    # 찍은 뒤 목록이 바뀌었나 — 고른 줄의 옅은 배경 · 오른쪽 안 읽음 표시는 줄 모양에 안 걸린다(InkOf)
    # 고르기를 옮기다 목록이 굴러갔을 수 있다(맨 위 줄 위에 칸이 있는 목록 · 맨 위에서 위 화살표가 맨 아래로 가는 목록) — 그러면 목록만 맨 위로 올려 한 번 더 본다(고르기는 그대로)
    # 목록만 올려 같아졌으면 고르기가 정말 0번인지 위 화살표를 한 번 더 넉넉히 보내 본다 — 0번이면 목록이 안 움직이고, 고르기가 멀리 있거나
    # 맨 위에서 위 화살표가 맨 아래로 가는 목록이면 목록이 따라 굴러가 다시 달라진다(그러면 안 연다 — 0번이 아닌 데서 걸으면 엉뚱한 방을 연다).
    # 그새 사람이 왔으면(목록을 만졌을 수 있다) 바뀐 것으로 안 친다 — 멈추기만 한다.
    $inkOk = ($null -ne $st.topInk -and [MotmotKakaoWin]::SameInkTo($st.topInk, [MotmotKakaoWin]::RowInk($top, $list), @($st.topInk).Length))
    if (-not $inkOk -and -not (Test-OpenOk $st)) { return }
    if (-not $inkOk -and $null -ne $st.topInk -and $toTop) {
      & $toTop
      Start-Sleep -Milliseconds 300
      if ([MotmotKakaoWin]::SameInkTo($st.topInk, [MotmotKakaoWin]::RowInk($top, $list), @($st.topInk).Length)) {
        for ($k = 0; $k -lt $nUp; $k++) { [void][MotmotKakaoWin]::PostKey($list, 0x26) }
        Start-Sleep -Milliseconds ([math]::Min(3000, 500 + 5 * $nUp))
        $inkOk = [MotmotKakaoWin]::SameInkTo($st.topInk, [MotmotKakaoWin]::RowInk($top, $list), @($st.topInk).Length)
      }
    }
    if (-not $inkOk) {
      if (-not (Test-OpenOk $st)) { return }
      $st.keysStale = $true; $st.keysWhy = '찍은 뒤 목록이 바뀌어 이번 회차는 안 엶'; return
    }
    $base = [math]::Max(-3, [math]::Min(3, [int]$ex.way.base))      # 맨 위 줄(진짜 0번)의 목록 번호
    $confirmed = 0; $retry = @{}; $nNamed = 0
    $pend = $null                                                    # 자리를 다시 맞춘 첫 방 — 원래 줄이 고친 번호로 맞으면 그때 이름을 붙인다
    while ($queue.Count) {
      $ti = [int]$queue[0]; $queue.RemoveAt(0)
      if ($done.ContainsKey($ti)) { continue }
      if ($st.tried -ge [int]$cfg.openMax -or -not (Test-OpenOk $st)) { break }
      $real = $ti - $base
      if ($real -lt 0) {                                             # 맨 위보다 위 — 번호가 어긋난 줄이다(고르지 않는다)
        if ($null -ne $pend -and $pend.ti -eq $ti) { $pend = $null; $st.keysWhy = '고친 줄 번호를 확인 못 해 멈춤'; break }   # 고친 번호를 확인할 길이 없다 — 그 번호로 더 걷지 않는다
        continue
      }
      $steps = $real - $sel
      $vk = if ($steps -ge 0) { 0x28 } else { 0x26 }
      for ($k = 0; $k -lt [math]::Abs($steps); $k++) { [void][MotmotKakaoWin]::PostKey($list, $vk) }
      $sel = $real
      Start-Sleep -Milliseconds ([math]::Min(1500, 250 + 20 * [math]::Abs($steps)))
      $row = @($byIdx[$ti] | Where-Object { $_.cand })[0]
      if ($null -eq $row) { $row = $byIdx[$ti][0] }
      $st.movedNow = $false; $st.fgHit = $false; $a0 = $st.already
      $got = Open-Title $top $list 0 0 $row.name $row.members $st $null 0 'keys'
      $wasOpen = ($st.already -gt $a0)                               # 엔터가 이미 떠 있던 방 창을 앞으로 가져왔다(Open-Title 이 「이미 열린 방」 으로 셌다)
      if ($got -and $st.fgHit) {
        # 엔터로는 아무것도 안 바뀌었고 앞에 떠 있던 방 창이 그 줄 이름에 가깝다 — 그 방이 이미 앞에 있었던 것일 수도, 엔터가 안 먹은 것일 수도 있다
        if ((Test-OnlyRow $got $ti $byIdx $st.rows) -and (Name-Rows $byIdx[$ti] $got $st $ex $now $true)) { $st.already++; $done[$ti] = 1; continue }
        $got = $null
      }
      if (-not $got -and @($keepT | Where-Object { $v = $_; @($byIdx[$ti] | Where-Object { $_.eligible -and (Same-Row $v $_) }).Count }).Count) {
        # 이 줄은 직원이 열어 둔 방일 수 있다(그 줄에 가까운 직원 창 제목) — 엔터는 그 창을 앞으로만 가져오거나(앞에 못 오면) 아무것도 안 바꾼다.
        # 엔터가 안 먹는다고 세지 않고, 이 줄은 쉬게 하고(회차마다 여기서 막히지 않게) 다음 줄로. 고르기는 그대로 이 줄에 있다.
        foreach ($r in $byIdx[$ti]) { if ($r.cand) { Note-Miss $ex $r.key $now } }
        $done[$ti] = 1
        continue
      }
      if (-not $got) {
        if (-not $st.keysWin) { $st.keysNoWin = $true }               # 이번 회차 첫 엔터부터 창이 안 떴다 — 세 회차 연달아면 줄 누르기로(Get-OpenWay)
        $st.keysWhy = '엔터로 방 창이 안 뜸'
        break
      }
      # 어느 줄의 방이 열렸나
      $fitT = @($byIdx[$ti] | Where-Object { Same-Row $got $_ })
      $strictT = @($byIdx[$ti] | Where-Object { Strict-Row $got $_ })
      $near = New-Object System.Collections.ArrayList; $strictN = New-Object System.Collections.ArrayList; $exactN = New-Object System.Collections.ArrayList
      for ($dd = -3; $dd -le 3; $dd++) {
        $j = $ti + $dd
        if ($dd -eq 0 -or -not $byIdx.ContainsKey($j)) { continue }
        if (@($byIdx[$j] | Where-Object { Same-Row $got $_ }).Count) { [void]$near.Add($j) }
        if (@($byIdx[$j] | Where-Object { Strict-Row $got $_ }).Count) { [void]$strictN.Add($j) }
        if (@($byIdx[$j] | Where-Object { Exact-Row $got $_ }).Count) { [void]$exactN.Add($j) }
      }
      $at = $null
      # 엔터가 이미 떠 있던 창(직원 창)을 앞으로 가져왔으면 자리 증거가 약하다(그 창이 딴 까닭으로 앞에 왔을 수도) — 다른 어느 줄에도 안 맞을 때만
      $farFit = $wasOpen -and @($st.rows | Where-Object { $_.idx -ne $ti -and (Same-Row $got $_) }).Count
      if ($fitT.Count -and -not $farFit -and (-not $near.Count -or ($strictT.Count -and -not $strictN.Count))) { $at = $ti }
      elseif (-not $fitT.Count -and -not $wasOpen -and $strictN.Count -eq 1 -and $exactN.Count -eq 1 -and $confirmed -eq 0) { $at = [int]$exactN[0] }
      if ($null -eq $at -and $null -ne $pend) { $pend = $null }        # 고친 번호로도 원래 줄이 안 맞았다 — 이웃 줄 이름도 버린다
      if ($null -eq $at) {
        # 확인 못 함 — 그 줄 글자를 쉬게 하고(다음 회차에 같은 자리에서 막히지 않게) 이번 회차는 멈춘다(고른 자리를 믿을 수 없다)
        foreach ($r in $byIdx[$ti]) { if ($r.cand) { Note-Miss $ex $r.key $now } }
        $st.keysLost++
        $st.keysWhy = $(if ($fitT.Count -or $strictN.Count -or $near.Count) { '연 방이 고른 줄인지 가릴 수 없어 멈춤(비슷한 이름 · 목록이 움직임)' } else { '연 방이 고른 줄과 안 맞아 멈춤' })
        break
      }
      $confirmed++
      if ($at -ne $ti) {
        # 회차의 첫 방이 이웃으로 열렸다 — 번호가 어긋났다(목록 맨 위 칸): 고친 번호로 원래 줄을 한 번 더. 이웃 줄 이름은 그게 맞을 때까지 미룬다.
        $st.keysShift++
        $base = $at - $sel
        [void]$st.clicked.Add(@{ n = $byIdx[$at][0].name; m = $byIdx[$at][0].members })   # 그 방 창이 늦게 떠도 우리 것으로 닫게
        $pend = @{ at = $at; got = $got; ti = $ti }
        $done[$at] = 1
        if (-not $retry.ContainsKey($ti)) { $retry[$ti] = 1; $queue.Insert(0, $ti) }
        continue
      }
      if ($null -ne $pend) {
        # 고친 번호로 원래 줄이 맞았다 — 미뤄 둔 이웃 줄에도 이름을 붙이고, 고친 번호는 회차 끝에(목록이 그대로면) 기억한다
        if ($pend.ti -eq $ti -and (Name-Rows $byIdx[$pend.at] $pend.got $st $ex $now $true)) { $st.opened++; $nNamed++ }
        if ($pend.ti -eq $ti) { $st.baseNew = $base }
        $pend = $null
      }
      if ($confirmed -eq 1 -and $null -eq $st.baseNew) { $ex.way.z = $ix.z }   # 이 번호 매김이 맞았다 — 다음 회차도 같은 쪽으로(Index-Rows $zHint)
      if (Name-Rows $byIdx[$ti] $got $st $ex $now ($near.Count -gt 0)) { if (-not $wasOpen) { $st.opened++ }; $nNamed++ }
      $done[$ti] = 1
      if ($nNamed -and $nNamed % 5 -eq 0) { Save-Exact $ex }        # 다섯 방마다 — 중간에 꺼져도 연 방을 다시 안 열게
    }
  } finally {
    $st.keysNamed = $nNamed
    $upDone = $false
    if (-not $st.userBack -and -not $script:Stopping -and $st.how -ne 'off') {
      for ($k = 0; $k -lt $sel + 5; $k++) { [void][MotmotKakaoWin]::PostKey($list, 0x26) }   # 고르기를 다시 맨 위로(사람이 돌아왔으면 건드리지 않는다)
      $upDone = $true
    }
  }
  # 고친 번호 기억 — 목록을 맨 위로 올려 줄 모양이 찍을 때와 같을 때만(걷는 사이 새 메시지로 한 칸 밀린 것을 「목록 맨 위 칸」 으로 배우지 않게)
  if ($null -ne $st.baseNew -and $upDone -and (Test-OpenOk $st)) {
    if ($toTop) { & $toTop }
    Start-Sleep -Milliseconds 400
    if ([MotmotKakaoWin]::SameInkTo($st.topInk, [MotmotKakaoWin]::RowInk($top, $list), @($st.topInk).Length)) { $ex.way.base = $st.baseNew; $ex.way.z = $ix.z }
    else { $st.keysWhy = '고친 줄 번호는 목록이 바뀌어 기억 안 함' }
  }
}

# 이 회차의 방 수를 **방마다 한 번**으로 — 장끼리 겹쳐 찍어 한 방을 두세 번 읽는다(2026-10-19 검토: 세면 두세 배로 부풀었다).
# 이번에 연 방은 「기억」 · 「다음 회차로」 에서 빼고, 기억으로 붙인 방은 「다음 회차로」 에서 뺀다.
function Finish-Counts($st) {
  foreach ($k in @($st.openK.Keys)) { [void]$st.cachedK.Remove($k); [void]$st.skipK.Remove($k) }
  foreach ($k in @($st.cachedK.Keys)) { [void]$st.skipK.Remove($k) }
  $st.cached = $st.cachedK.Count; $st.skipped = $st.skipK.Count; $st.notGray = $st.grayK.Count
}

# 키보드 길의 결과를 기억한다 — 엔터로 연 방에서 이름을 하나라도 얻었으면 둘 다 0(직원 창 제목만 읽은 것은 엔터가 먹는다는 증거가 아니다). 아니면 ① 첫 엔터부터 창이 안 떴거나 ② 연 방이 고른 줄과 달라 멈췄으면 하나 더.
# 셋이면 auto 는 하루 동안 줄 누르기(Get-OpenWay). 찍은 뒤 목록이 바뀌어 안 연 회차는 따로 세어 열 회차 연달아면 같다.
# 「지금 한 번」 깃발이 「방도 열어」 인가 — 실행기 0.9.6 은 'open <시각>' 을 쓴다(옛 실행기는 시각만 → 예전처럼 1분 규칙).
# 이 수집기가 뜬 뒤에 꽂혔고 · 10분 안이고 · 앞날짜가 아닌 것만 믿는다 — 끄고 켜는 사이(카톡만 끄기 · 새 판 · 다시 켜기) 남은 부탁이 사람 없는 때 방을 열지 않게.
function Test-OpenNowFlag {
  try {
    if ($null -eq $script:Born -or -not (Test-Path $NowFlag)) { return $false }
    $wt = (Get-Item $NowFlag).LastWriteTime
    if ($wt -lt $script:Born -or $wt -gt (Get-Date).AddMinutes(1) -or ((Get-Date) - $wt).TotalMinutes -gt 10) { return $false }
    return ((Get-Content -Raw $NowFlag) -match '^\s*open\b')
  } catch { return $false }
}

# 방 열기 결과 — 서버로 보내 휴면방 화면에 한 줄로 보인다(D-164). 숫자 · 참거짓 · 정해진 짧은 글만(방 이름은 안 싣는다).
function Open-Report($st, $ex, [bool]$on) {
  if (-not $on) { return [ordered]@{ on = $false } }
  return [ordered]@{
    on = $true; now = [bool]$script:OpenNow; way = $(if ($st.keys) { 'keys' } else { 'click' })
    busy = [bool]$st.busy; back = [bool]$st.userBack; fail = [bool]($st.how -eq 'off' -and $st.failed -ge 3); bad = [bool]$ex.bad
    cached = [int]$st.cached; opened = [int]$st.opened; already = [int]$st.already; mismatch = [int]$st.mismatch; skipped = [int]$st.skipped
    moved = [int]$st.moved; notGray = [int]$st.notGray
    keysTargets = [int]$st.keysTargets; keysWin = [int]$st.keysWin; keysNamed = [int]$st.keysNamed; keysLost = [int]$st.keysLost; keysNoWin = [bool]$st.keysNoWin
    why = "$($st.keysWhy)"
  }
}

# 관리자 화면 「지금 읽기」 부탁이 있나 — 쉬는 동안 30초마다 서버에 묻는다(D-172 · /api/push?op=kakao_poll · supabase-134).
# 서버가 안 받으면(옛 서버 · 망 끊김 · 열쇠 틀림) 5분 동안 안 묻는다 — 기록은 연달아 실패한 것의 첫 번째만(30초마다 기록이 쌓이지 않게).
$script:PollNext = [datetime]::MinValue; $script:PollFail = 0
function Test-ReadRequest($cfg) {
  if ((Get-Date) -lt $script:PollNext) { return $false }
  $url = "$($cfg.endpoint)"
  if ($url -notmatch 'op=kakao_push' -or -not "$($cfg.secret)") { $script:PollNext = (Get-Date).AddMinutes(60); return $false }
  $url = $url -replace 'op=kakao_push', 'op=kakao_poll'
  try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $r = Invoke-RestMethod -Uri $url -Method Get -Headers @{ 'x-kakao-secret' = "$($cfg.secret)" } -TimeoutSec 15
    $script:PollFail = 0; $script:PollNext = (Get-Date).AddSeconds(30)
    if ($r.now) { Write-Log '관리자 화면에서 「지금 읽기」 를 부탁했습니다 — 바로 읽습니다(PC 를 쓰는 중이면 손을 뗄 때까지 기다림)'; return $true }
    return $false
  } catch {
    if ($script:PollFail -eq 0) { Write-Log ('관리자 화면 「지금 읽기」 부탁을 묻지 못했습니다(5분 뒤 다시): ' + $_.Exception.Message) }
    $script:PollFail++; $script:PollNext = (Get-Date).AddMinutes(5)
    return $false
  }
}

# 그 프로그램을 띄운 윈도우 사용자(SID) — C# 로 못 읽으면 WMI 로 한 번 더(권한이 다를 때). 못 읽으면 $null.
function Get-ProcOwnerSid([uint32]$procId) {
  $sid = [MotmotKakaoWin]::OwnerSid($procId)
  if ($sid) { return $sid }
  try {
    $p = Get-CimInstance -ClassName Win32_Process -Filter ("ProcessId=" + $procId) -ErrorAction Stop
    if (-not $p) { return $null }
    $o = Invoke-CimMethod -InputObject $p -MethodName GetOwnerSid -ErrorAction Stop
    if ($o.ReturnValue -ne 0 -or -not $o.Sid) { return $null }
    return "$($o.Sid)"
  } catch { return $null }
}

# 업무 카톡 창 고르기(D-175) — 사장님(2026-10-22) 「내 개인 계정까지 들어간듯」 · 「톡을 여러개 켜놓는 경우가 있어서」 · 「혼동하지 않게 셋팅 필요할 듯」.
# 개인 카톡은 샌드박스 · 다른 윈도우 사용자로 띄운다 → **이 수집기와 같은 윈도우 사용자이고 · 샌드박스 밖인** 카톡만 업무 카톡.
# 그런 카톡이 하나뿐일 때만 그 창 — 없거나 둘 넘으면 이번 회차는 읽지도 열지도 않는다(고른 것: 「그 회차는 안 읽기」).
# 모르는 것은 업무 카톡으로 안 본다 — 사용자를 못 읽음 · 샌드박스인지 못 읽음(검토 2026-10-22: 샌드박스 카톡은 사용자가 같아 이것만이 가른다).
$script:KakaoSeen = ''
function Find-OurKakao($cfg) {
  $me = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
  $wins = @([MotmotKakaoWin]::MainWindows("$($cfg.windowTitle)"))
  if (-not $wins.Count) { return @{ error = '카카오톡 창을 찾지 못했습니다 — 카카오톡이 켜져 있고 로그인돼 있는지 확인해 주세요' } }
  $ours = @(); $other = 0; $box = 0; $unknown = 0
  foreach ($w in $wins) {
    $h = [IntPtr][long]$w
    if ([MotmotKakaoWin]::SandboxMark($h)) { $box++; continue }          # 창에 샌드박스 표시(갈래 이름 · [#])
    $procId = [MotmotKakaoWin]::PidOf($h)
    if ((Get-ProcOwnerSid $procId) -ne $me) { $other++; continue }
    $sb = [MotmotKakaoWin]::InSandbox($procId)
    if ($sb -eq 1) { $box++; continue }
    if ($sb -ne 0) { $unknown++; continue }
    $ours += $w
  }
  $seen = '{0}/{1}/{2}/{3}/{4}' -f $wins.Count, $ours.Count, $other, $box, $unknown   # 여러 개 켜짐 기록은 갈래가 바뀔 때만
  if ($seen -ne $script:KakaoSeen) {
    $script:KakaoSeen = $seen
    if ($wins.Count -gt 1) { Write-Log ("카톡이 {0}개 켜져 있습니다 — 이 윈도우 사용자 · 샌드박스 밖 {1} · 다른 윈도우 사용자 {2} · 샌드박스 {3} · 샌드박스인지 모름 {4}" -f $wins.Count, $ours.Count, $other, $box, $unknown) }
  }
  if ($ours.Count -eq 1) { return @{ top = [IntPtr][long]$ours[0] } }
  if (-not $ours.Count) {
    $why = "업무 카톡을 못 찾았습니다 — 켜진 카톡 {0}개가 다른 윈도우 사용자({1}) · 샌드박스({2}) · 샌드박스인지 모름({3})뿐입니다. 개인 톡방을 건드리지 않게 이번 회차는 안 읽었습니다" -f $wins.Count, $other, $box, $unknown
    if ($unknown) { $why += ' — 업무 카톡을 관리자 권한으로 켰으면 보통으로 다시 켜 주세요' }
    return @{ error = $why }
  }
  return @{ error = ("이 윈도우 사용자로 샌드박스 밖에서 켜진 카톡이 {0}개라 어느 것이 업무 카톡인지 모릅니다 — 개인 카톡은 샌드박스 · 다른 윈도우 사용자로 띄워 주세요. 이번 회차는 안 읽었습니다" -f $ours.Count) }
}

function Note-KeysWay($ex, $st, $cfg) {
  if (-not $st.keysTried) { return }
  $auto = ("$($cfg.openWay)".Trim().ToLower() -notin @('keys', 'click'))
  if ($st.keysStale) {
    # 「찍은 뒤 목록이 바뀜」 이 열 회차 연달아 — 손님 대화가 잦아서가 아니라 목록 맨 위가 늘 달라 보이는 것(움직이는 칸 등)이다. 줄 누르기로(그쪽은 장마다 견준다)
    $ex.way.stale = [int]$ex.way.stale + 1
    if ([int]$ex.way.stale -ge 10) {
      $ex.way.stale = 0; $ex.way.keysFail = 3; $ex.way.at = (Get-Date).ToString('o')
      if ($auto) { Write-Log '찍은 뒤 목록이 바뀌어 열 회차 연달아 키보드로 못 열었습니다 — 하루 동안 예전 방식(목록 줄 누르기)으로 엽니다' }
    }
    return
  }
  $ex.way.stale = 0
  if ([int]$st.keysNamed) { $ex.way.keysFail = 0; $ex.way.lost = 0; return }
  if ($st.keysNoWin) {
    $ex.way.keysFail = [int]$ex.way.keysFail + 1; $ex.way.at = (Get-Date).ToString('o')
    if ($auto -and [int]$ex.way.keysFail -eq 3) { Write-Log '키보드(엔터)로 방이 세 회차 연달아 안 열렸습니다 — 하루 동안 예전 방식(목록 줄 누르기)으로 엽니다' }
  } elseif ($st.keysLost) {
    $ex.way.lost = [int]$ex.way.lost + 1; $ex.way.at = (Get-Date).ToString('o')
    if ($auto -and [int]$ex.way.lost -eq 3) { Write-Log '키보드로 연 방이 세 회차 연달아 고른 줄과 달랐습니다 — 하루 동안 예전 방식(목록 줄 누르기)으로 엽니다' }
  }
}

# 직원이 최소화해 둔 방 창이 엔터로 되살아났으면 다시 최소화한다(7 = SW_SHOWMINNOACTIVE — 앞으로 가져오지 않는다 · 닫지 않는다).
# 아직 떠 있는 카톡 방 창일 때만(그새 닫혔으면 손대지 않는다).
function Restore-Minimized($top, $wins) {
  if (-not @($wins).Count) { return }
  $now = @([MotmotKakaoWin]::ChatWindows($top))
  foreach ($h in @($wins)) { if ($now -contains [long]$h) { [void][MotmotKakaoWin]::ShowWindow([IntPtr][long]$h, 7) } }
}

# ── 한 번 찍어 읽기 ──────────────────────────────────────
function Invoke-Scan($cfg, $engine) {
  # 업무 카톡 하나만(D-175) — 카톡을 여러 개 켜 둔 PC 에서 개인 카톡을 읽거나 열지 않게
  $pick = Find-OurKakao $cfg
  if ($pick.error) { return @{ error = $pick.error } }
  $top = $pick.top

  # 최소화 · 트레이로 숨김이면 잠깐 (앞으로 가져오지 않고) 펼쳤다가 끝나면 되돌린다
  $wasIconic = [MotmotKakaoWin]::IsIconic($top)
  $wasHidden = -not [MotmotKakaoWin]::IsWindowVisible($top)
  $fgStart = [MotmotKakaoWin]::GetForegroundWindow()
  $keepWins = $null; $keepIconic = @(); $st = $null; $ex = $null
  if ($wasIconic -or $wasHidden) { [void][MotmotKakaoWin]::ShowWindow($top, 4); Start-Sleep -Milliseconds 800 }   # 4 = SW_SHOWNOACTIVATE

  try {
    $list = [MotmotKakaoWin]::FindList($top)
    if ($list -eq [IntPtr]::Zero) { return @{ error = '카카오톡 채팅 목록을 찾지 못했습니다 — 카톡 창을 「채팅」 탭에 두어 주세요' } }

    $tmp = Join-Path $env:TEMP 'motmot-kakao-idle'
    if (-not (Test-Path $tmp)) { [void](New-Item -ItemType Directory $tmp) }

    $shot = {
      param([int]$i)
      # ★ 2배로 키운다(2026.10.15-4 에 못 박음). 앞 판은 0(= 2~4배 자동)을 넘겼지만 MaxImageDimension 은 **정적 속성**이라 인스턴스로 읽으면 비어
      #   늘 2배였다 — 누가 그 버그를 「고쳐」 조용히 4배(느려짐 · 다른 글자 인식)로 바뀌지 않게 지금 도는 값을 그대로 적는다(I-177).
      $bmp = [MotmotKakaoWin]::Snap($top, $list, 2, 0)
      if ($null -eq $bmp) { return $null }
      $ink = [MotmotKakaoWin]::LastInk                              # 이 그림과 같은 순간의 줄 모양 — 방을 열기 전에 목록이 움직였나 견준다
      try {
        if ([MotmotKakaoWin]::IsBlank($bmp)) { return @{ blank = $true } }
        $png = Join-Path $tmp ("p{0:D3}.png" -f $i)
        $bmp.Save($png, [System.Drawing.Imaging.ImageFormat]::Png)
        $hash = (Get-FileHash -Algorithm MD5 $png).Hash
        return @{ png = $png; hash = $hash; w = $bmp.Width; h = $bmp.Height; ink = $ink }
      } finally { $bmp.Dispose() }
    }
    $scroll = {
      param([int]$clicks)
      if ($cfg.scrollMode -eq 'vscroll') {
        $code = if ($clicks -gt 0) { 0 } else { 1 }
        for ($k = 0; $k -lt [math]::Abs($clicks) * 3; $k++) { [MotmotKakaoWin]::VScroll($list, $code) }
      } else { [MotmotKakaoWin]::Wheel($list, $clicks) }
      Start-Sleep -Milliseconds ([int]$cfg.settleMs)
    }

    # 1) 맨 위로 — 그림이 더 안 바뀔 때까지 위로 굴린다
    if ($cfg.scrollMode -eq 'vscroll') { [MotmotKakaoWin]::VScroll($list, 6); Start-Sleep -Milliseconds ([int]$cfg.settleMs) }
    # ★ 한 번 같은 그림으로는 맨 위라고 안 본다 — 굴림이 한 번 안 먹었거나 그림이 늦으면 목록 가운데서 시작해 위쪽 방을 통째로 빠뜨린다(검토).
    #   같은 그림 두 번 뒤에도 다른 길(WM_VSCROLL 맨 위)로 한 번 더 올려 보고, 60번을 다 써도 멈추지 않았으면 맨 위를 못 본 것으로 친다.
    $prev = ''; $flat = 0; $topSure = $false
    for ($k = 0; $k -lt 150; $k++) {                # 한 번에 정해진 만큼만 움직이는 목록이면 오래 걸린다(150방 · 바닥에서 시작 → 70번)
      & $scroll 15
      $s = & $shot 0
      if ($null -eq $s) { return @{ error = '카카오톡 창을 찍지 못했습니다(창 크기 0)' } }
      if ($s.blank) { return @{ error = '카카오톡 화면이 비어 찍혔습니다 — PC 가 잠겨 있거나 화면이 꺼져 그리지 않는 중일 수 있습니다' } }
      if ($s.hash -eq $prev) {
        $flat++
        if ($flat -ge 2) {
          [MotmotKakaoWin]::VScroll($list, 6)
          Start-Sleep -Milliseconds (2 * [int]$cfg.settleMs)
          & $scroll 15
          $s2 = & $shot 0
          if ($null -ne $s2 -and -not $s2.blank -and $s2.hash -ne $prev) { $flat = 0; $prev = $s2.hash; continue }
          $topSure = $true; break
        }
        Start-Sleep -Milliseconds ([int]$cfg.settleMs); continue
      }
      $flat = 0
      $prev = $s.hash
    }
    if (-not $topSure) { Write-Log '맨 위까지 올렸는지 확인하지 못했습니다(150번 올려도 그림이 계속 바뀜) — 이번 회차는 끝까지 읽은 것으로 치지 않습니다' }

    # 2) 내려 가며 찍고 읽는다 — 줄마다 정확한 이름(방 창 제목)도 붙인다(openRooms)
    $ex = Load-Exact
    $keepWins = [MotmotKakaoWin]::ChatWindowsAll($top)            # 원래 떠 있던 방 창(최소화된 직원 창까지)
    $keepIconic = @($keepWins | Where-Object { [MotmotKakaoWin]::IsIconic([IntPtr][long]$_) })   # 그중 최소화된 것 — 엔터로 되살아나면 끝에 다시 최소화
    $openOn = Test-On $cfg.openRooms $true
    # cfgTime 은 비워 둔다 — 첫 방을 열기 전에 설정 파일을 한 번 다시 읽는다(기다리는 사이 「끔」 으로 바꿨을 수 있다)
    $st = @{ how = 'off'; wait = [int]$cfg.openWaitMs; mark = [MotmotKakaoWin]::Tick(); cfgTime = $null
             ours = (New-Object System.Collections.ArrayList); clicked = (New-Object System.Collections.ArrayList); given = @{}; keySeen = @{}; ambig = @{}
             tried = 0; opened = 0; cached = 0; failed = 0; mismatch = 0; skipped = 0; moved = 0; already = 0; covered = 0; dup = 0; conflict = 0; notGray = 0
             cachedK = @{}; skipK = @{}; grayK = @{}; openK = @{}
             postOk = $false; postFail = 0; mouseOk = $false; userBack = $false; busy = $false; movedNow = $false; keep = $null
             keys = $false; rows = (New-Object System.Collections.ArrayList); pageSeq = 0
             keysTried = $false; keysTargets = 0; keysWin = 0; keysShift = 0; keysLost = 0; keysNoWin = $false; keysStale = $false; keysWhy = ''; topInk = $null
             keysNamed = 0; fgHit = $false; baseNew = $null }
    $st.keep = $keepWins
    $st.keys = ((Get-OpenWay $cfg $ex) -eq 'keys')
    if ($openOn -and -not $ex.bad) {
      # 사람이 1분 안에 만졌으면 이번 회차는 안 연다(-Once · 10분 기다려도 계속 쓰는 중일 때) — 방 창이 손 밑에서 뜨면 안 된다
      # 「지금 한 번 읽기」(OpenNow)는 누른 사람이 열라고 한 것이라 연다(D-164) — 그래도 회차 도중 만지면 멈춘다(Test-OpenOk · mark 는 위에서 잼)
      # 기억 파일을 못 읽었으면 안 연다 — 저장도 못 하니 연 방을 다음 회차에 또 연다
      if ($script:OpenNow -or [MotmotKakaoWin]::IdleMs() -ge 60000) { $st.how = 'on' } else { $st.busy = $true }
    }
    $pages = New-Object System.Collections.ArrayList
    $clicks = [int]$cfg.wheelClicksPerPage
    $complete = $false
    $endWhy = 'max'                                 # 왜 멈췄나 — bottom(끝) · stuck(목록이 안 움직임) · unsure(끝 확인 못 함) · gap · blank · stop · max — 기록 · 상태 · 서버로
    $retried = 0; $backoffs = 0; $gaps = 0; $goodRun = 0
    $lastHash = ''
    $prevTexts = $null
    $prevOv = $null
    $prevRk = $null
    for ($i = 1; $i -le [int]$cfg.maxPages; $i++) {
      if ($script:Stopping -or (Test-Path $StopFlag)) { $script:Stopping = $true; $endWhy = 'stop'; break }   # 실행기가 끄라 했다 — 정리하고 나간다
      $s = & $shot $i
      if ($null -eq $s -or $s.blank) { $endWhy = 'blank'; break }
      if ($s.hash -eq $lastHash) {
        # ★ 앞 장과 같은 그림 = 끝일 **수도** 있다(2026-10-15 실측 — 17방에서 「끝까지 읽음」). 굴림이 안 먹었거나 그림이 늦었을 수 있으니
        #   ① 더 기다렸다 다시 찍고 ② 한 번 더 굴리고 ③ 다른 길(WM_VSCROLL)로 내려 본다. 그래도 같으면 **양쪽**으로 확인한다 —
        #   위로 한 칸 올려 그림이 바뀌고(목록은 움직인다) → 올린 것보다 더 많이 내려 **같은 그림으로 돌아와야**(더 못 내려간다) 끝.
        #   더 내려가면 끝이 아니었다 — 그 장부터 이어 읽는다. 위로도 안 바뀌면 목록이 굴림을 안 받는 것이라 끝까지 읽은 것으로 치지 않는다.
        $next = $null; $blankHit = $false
        for ($t = 1; $t -le 3 -and $null -eq $next; $t++) {
          if ($t -eq 2) { & $scroll (-$clicks) }
          elseif ($t -eq 3) { for ($q = 0; $q -lt $clicks * 3; $q++) { [MotmotKakaoWin]::VScroll($list, 1) } }
          Start-Sleep -Milliseconds ([int]$cfg.settleMs)
          $s2 = & $shot $i
          if ($null -eq $s2 -or $s2.blank) { $blankHit = $true; break }
          if ($s2.hash -ne $lastHash) { $next = $s2; $hit = $t }
        }
        if ($blankHit) { $endWhy = 'blank'; break }      # 그림이 비었다 — 끝을 확인할 수 없다
        if ($null -eq $next) {
          # 목록이 화면 한 장에 다 들어가면(아래에 빈 자리) 내려갈 데가 없다 — 위로도 안 움직이는 것이 맞다
          $ink = if ($null -ne $s.ink) { @($s.ink) } else { @() }; $tail = 0      # ⚠ @($null) 은 한 칸짜리다
          for ($q = $ink.Count - 1; $q -ge 0 -and $ink[$q] -eq 0; $q--) { $tail++ }
          $shortList = $ink.Count -gt 0 -and $tail -ge [math]::Max(48, [int]($ink.Count * 0.1))
          if (-not $ink.Count -and $pages.Count) {              # 줄 모양을 못 쟀으면 글자 위치로 — 마지막 글자가 장의 85% 위에서 끝나면 빈 자리
            $lowest = 0
            foreach ($ln in $pages[$pages.Count - 1].lines) { foreach ($wd in $ln.words) { if (($wd.y + $wd.h) -gt $lowest) { $lowest = $wd.y + $wd.h } } }
            $shortList = $lowest -gt 0 -and $lowest -lt $pages[$pages.Count - 1].h * 0.85
          }
          & $scroll 1
          $up = $null
          for ($t = 0; $t -lt 3; $t++) {                 # 그림이 늦을 수 있다 — 두 번까지 더 기다렸다 찍는다
            if ($t) { Start-Sleep -Milliseconds (2 * [int]$cfg.settleMs) }
            $up = & $shot $i
            if ($null -eq $up -or $up.blank -or $up.hash -ne $lastHash) { break }
          }
          if ($null -ne $up -and -not $up.blank -and $up.hash -ne $lastHash) {
            # 올린 것보다 **더 많이** 내린다(굴림 둘 — 한 번에 정해진 만큼만 움직이는 목록도 더 내려가게).
            # 같은 그림으로 돌아오면 끝 · 더 내려가면 끝이 아니었다 · 올린 그림 그대로면 확인 못 함(그 사이 목록이 바뀜 · 아래로 안 받음)
            & $scroll (-$clicks); & $scroll (-1)
            $dn = $null
            for ($t = 0; $t -lt 3; $t++) {
              if ($t) { Start-Sleep -Milliseconds (2 * [int]$cfg.settleMs) }
              $dn = & $shot $i
              if ($null -eq $dn -or $dn.blank -or $dn.hash -ne $up.hash) { break }
            }
            if ($null -ne $dn -and -not $dn.blank -and $dn.hash -eq $lastHash) { $complete = $true; $endWhy = 'bottom'; break }
            elseif ($null -ne $dn -and -not $dn.blank -and $dn.hash -ne $up.hash) { $next = $dn; $hit = 4 }
            else { $endWhy = 'unsure'; Write-Log '맨 아래인지 확인하지 못했습니다(그 사이 목록이 바뀜) — 끝까지 읽은 것으로 치지 않습니다'; break }
          }
          elseif ($shortList -and $i -le 2) { $complete = $true; $endWhy = 'bottom'; break }   # 한 장짜리 목록
          else { $endWhy = 'stuck'; Write-Log '목록이 더 내려가지도 위로 움직이지도 않습니다 — 끝까지 읽은 것으로 치지 않습니다(카톡 창이 가려졌거나 굴림을 안 받음)'; break }
        }
        $retried++
        Write-Log "목록이 늦게 내려갔습니다($hit 번째 다시 보기에 움직임) — 이어서 읽습니다"
        $s = $next
      }
      $page = Read-Page $engine $s.png $s.w $s.h
      # 겹침 확인 — 앞 장과 **흔하지 않은** 같은 줄이 둘 이상 있어야 사이에 빠진 방이 없다(Overlap-Texts). 없으면 한 칸 덜 내려 다시.
      $ov = Overlap-Texts $page
      $rk = Row-Keys $page
      if ($null -ne $prevOv) {
        # ① 방 열쇠가 양쪽 둘 이상이면 방으로 센다(한 장 방이 넷 이하면 하나만 같아도 된다) ② 아니면 흔하지 않은 줄 ③ 그것도 모자라면 예전처럼 줄 글자 그대로
        $same = 0; $need = 2
        if ($rk.Count -ge 2 -and $prevRk.Count -ge 2) {
          foreach ($k in $rk) { if ($prevRk.Contains($k)) { $same++ } }
          if ([math]::Min($rk.Count, $prevRk.Count) -le 4) { $need = 1 }
        }
        elseif ($ov.Count -ge 2 -and $prevOv.Count -ge 2) { foreach ($tx in $ov) { if ($prevOv.Contains($tx)) { $same++ } } }
        else {
          foreach ($ln in $page.lines) { if ($prevTexts.Contains((($ln.words | ForEach-Object { $_.t }) -join ' '))) { $same++ } }
        }
        if ($same -lt $need) {
          $goodRun = 0
          if ($clicks -gt 1) {
            & $scroll 1                                 # 한 칸 되돌려 (앞 장 + 줄인 칸 수) 자리로
            $clicks = $clicks - 1
            $backoffs++
            Write-Log "겹침 부족 — 한 장에 $clicks 칸씩으로 줄여 다시 찍습니다"
            $i--
            continue
          }
          $gaps++                                       # 한 칸씩인데도 겹치는 줄이 모자란다 — 사이에 빠진 방이 있을 수 있다
          Write-Log "겹침 부족 — 한 칸씩인데도 앞 장과 겹치는 줄이 모자랍니다($i 번째 장) · 사이 방이 빠졌을 수 있어 끝까지 읽은 것으로 치지 않습니다"
        } elseif ($clicks -lt [int]$cfg.wheelClicksPerPage) {
          $goodRun++
          if ($goodRun -ge 3) { $clicks++; $goodRun = 0 }   # 세 장 잘 겹치면 다시 넓힌다(한 번 흔들림으로 끝까지 느려지지 않게)
        }
      }
      if ($st.how -ne 'off' -or $ex.names.Count) {
        try { Add-Titles $page $s $i $prevTexts $top $list $ex $st $cfg } catch { Write-Log ('정확한 이름 붙이기 오류: ' + $_.Exception.Message) }
        if ($st.tried) { Save-Exact $ex }                            # 장마다 — 중간에 멈춰도 연 방을 다시 안 열게
      }
      if ($pages.Count -eq 0) { $st.topInk = $s.ink }                # 맨 위 장의 줄 모양 — 키보드로 열기 전에 목록이 그대로인가 견준다(D-160)
      [void]$pages.Add($page)
      $prevTexts = Page-Texts $page
      $prevOv = $ov
      $prevRk = $rk
      $lastHash = $s.hash
      & $scroll (-$clicks)
    }
    if ($gaps) { $complete = $false; if ($endWhy -eq 'bottom') { $endWhy = 'gap' } }
    if (-not $topSure) { $complete = $false; if ($endWhy -eq 'bottom') { $endWhy = 'top' } }

    # 다시 맨 위로(사람이 볼 때 늘 보던 모습으로) — 방을 열었으면 읽음 표시가 지워져 맨 위 그림이 처음과 다를 수 있다
    $backTop = {
      $p3 = ''
      for ($k = 0; $k -lt $(if ($script:Stopping) { 10 } else { 150 }); $k++) { & $scroll 15; $t = & $shot 999; if ($null -eq $t -or $t.blank -or $t.hash -eq $prev -or $t.hash -eq $p3) { break }; $p3 = $t.hash }
    }

    # 2-1) 키보드로 열기(D-160) — 찍기가 끝난 뒤, 목록을 맨 위로 올리고 목록 번호 순서대로. 연 방 이름은 그 줄이 나온 장의 titles 에 붙는다.
    if ($st.keys -and $st.how -ne 'off' -and -not $script:Stopping -and @($st.rows | Where-Object { $_.cand }).Count) {
      & $backTop
      try { Open-ByKeys $top $list $st $ex $cfg $topSure $backTop } catch { Write-Log ('키보드로 방 열기 오류: ' + $_.Exception.Message) }
      Note-KeysWay $ex $st $cfg
    }

    # 같은 글자인데 서로 다른 자리에서 나온 줄(다른 방일 수 있다)은 모든 장에서 이름을 뗀다 · 열쇠 칸(k)은 보내지 않는다
    foreach ($pg in $pages) {
      $pg['titles'] = @(@($pg['titles']) | Where-Object { $null -ne $_ -and -not $st.ambig.ContainsKey($_.k) } | ForEach-Object { [ordered]@{ y = $_.y; t = $_.t } })
    }
    Save-Exact $ex
    Finish-Counts $st
    if ($openOn) {
      $how = @()
      if ($st.postOk) { $how += '메시지' }; if ($st.mouseOk) { $how += '마우스' }; if ($st.keysWin) { $how += '키보드' }
      $kt = ''
      if ($st.keys) {
        if ($st.keysTargets -or $st.keysWhy) {
          $kt = " · 키보드(열 방 $($st.keysTargets) · 연 방 $($st.keysWin)"
          if ($st.keysShift) { $kt += " · 자리 다시 맞춤 $($st.keysShift)" }
          if ($st.keysLost) { $kt += " · 자리 잃음 $($st.keysLost)" }
          if ($st.keysNoWin) { $kt += " · 엔터로 안 열림 $([int]$ex.way.keysFail)/3" }
          if ($st.keysWhy) { $kt += " · $($st.keysWhy)" }
          $kt += ')'
        }
      } elseif ("$($cfg.openWay)".Trim().ToLower() -ne 'click') { $kt = ' · 줄 누르기(키보드로 안 열려 하루 쉬는 중)' }
      Write-Log ("정확한 이름 — 기억 {0} · 새로 연 방 {1} · 이미 열린 방 {2} · 안 맞아 버림 {3} · 다음 회차로 {4}{5}{6}{7}{8}" -f
        $st.cached, $st.opened, $st.already, $st.mismatch, $st.skipped,
        ($(if ($st.moved) { " · 목록이 움직여 멈춤 $($st.moved)" } else { '' }) + $(if ($st.notGray) { " · 인원수가 이름과 같은 색이라 안 엶 $($st.notGray)" } else { '' })),
        $(if ($st.busy) { ' · 사람이 PC 를 쓰는 중이라 안 염' } elseif ($st.userBack) { ' · 사람이 돌아와 멈춤' } elseif ($st.how -eq 'off' -and $st.failed -ge 3) { ' · 방 열기 실패' } else { '' }),
        $(if ($how.Count) { ' · ' + ($how -join '+') } else { '' }), $kt)
    }

    # 3) 다시 맨 위로
    & $backTop
    Remove-Item -Force -ErrorAction SilentlyContinue (Join-Path $tmp '*.png')

    return @{ pages = @($pages); complete = $complete; end = [ordered]@{ why = $endWhy; retried = $retried; backoffs = $backoffs; gaps = $gaps }; open = (Open-Report $st $ex $openOn) }
  } finally {
    Save-Exact $ex
    # 이번 회차가 연 방 창은 닫는다. 사람이 그새 안 돌아왔으면 늦게 뜬 새 창도 닫고, 앞에 있던 창을 다시 앞으로.
    # 사람이 돌아왔으면 우리가 연 창만 닫는다 — 그 사람이 연 방 · 지금 쓰는 창은 건드리지 않는다.
    if ($null -ne $keepWins -and $null -ne $st -and $st.tried) {
      Start-Sleep -Milliseconds 300
      $back = $st.userBack -or [MotmotKakaoWin]::InputSince([uint32]$st.mark)
      foreach ($h in @([MotmotKakaoWin]::ChatWindows($top))) {
        if ($st.ours -contains $h) { [MotmotKakaoWin]::Close([IntPtr][long]$h); continue }
        # 늦게 뜬 창 — 사람이 없고, 이번 회차에 누른 줄의 방일 때만(그 밖의 창 · 걸려 온 전화 창은 건드리지 않는다)
        if (-not $back -and $keepWins -notcontains $h -and (Test-Clicked ([MotmotKakaoWin]::Title([IntPtr][long]$h)) $st '')) {
          [MotmotKakaoWin]::Close([IntPtr][long]$h)
        }
      }
      if (-not $back) { Restore-Minimized $top $keepIconic }
      if (-not $back -and $fgStart -ne [IntPtr]::Zero -and [MotmotKakaoWin]::GetForegroundWindow() -ne $fgStart) { [void][MotmotKakaoWin]::SetForegroundWindow($fgStart) }
    }
    if ($wasHidden) { [void][MotmotKakaoWin]::ShowWindow($top, 0) }          # 0 = SW_HIDE (트레이로)
    elseif ($wasIconic) { [void][MotmotKakaoWin]::ShowWindow($top, 7) }      # 7 = SW_SHOWMINNOACTIVE
  }
}

function Send-Scan($cfg, $payload) {
  $json = $payload | ConvertTo-Json -Depth 12 -Compress
  try { Set-Content -Path $LastScanPath -Value $json -Encoding UTF8 } catch { }
  if ($DryRun) { Write-Log "DryRun — 보내지 않았습니다. 읽은 것은 $LastScanPath"; return @{ sent = $false; ok = $true; dry = $true } }
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  $bytes = [Text.Encoding]::UTF8.GetBytes($json)
  try {
    $r = Invoke-RestMethod -Uri $cfg.endpoint -Method Post -Body $bytes -ContentType 'application/json; charset=utf-8' `
      -Headers @{ 'x-kakao-secret' = "$($cfg.secret)" } -TimeoutSec 90
    if ($r.short) { Write-Log ("서버: 끝까지 읽었다는데 방이 평소({0}방)보다 훨씬 적어({1}방) 끝까지 못 읽은 회차로 남겼습니다" -f $r.short.usual, $r.short.rooms) }
    if ($r.gaps) { Write-Log ("서버: 이웃한 장끼리 같은 방이 하나도 안 겹친 곳이 {0}군데 — 사이 방이 빠졌을 수 있어 끝까지 못 읽은 회차로 남겼습니다" -f $r.gaps) }
    # 방 창 제목(정확한 이름)을 보냈는데 서버가 안 썼다 — 서버 표에 그 칸이 아직 없다(supabase-128). 한 번만 적는다.
    $sentTitles = @($payload.pages | Where-Object { $_ -and $_['titles'] -and @($_['titles']).Count }).Count
    if ($sentTitles -and $r.PSObject.Properties['exact'] -and -not $r.exact -and -not $script:SaidNoExact) {
      $script:SaidNoExact = $true
      Write-Log '서버가 방 창 제목(정확한 이름)을 안 씁니다 — Supabase 에서 supabase-128-kakao-exact-names.sql 을 돌려야 「…」 로 잘린 이름이 정확한 이름으로 바뀝니다'
    }
    if ($r.ok) { Write-Log ("보냄 — {0}방 · {1}장 · 시각 읽은 줄 {2} · 겹친 줄 {3}" -f $r.rooms, $r.pages, $r.anchors, $r.dup); return @{ sent = $true; ok = $true; rooms = $r.rooms; short = [bool]$r.short } }
    Write-Log ("서버가 받았지만 문제를 알렸습니다: {0}" -f $r.error)
    return @{ sent = $true; ok = $false; rooms = $r.rooms; error = "$($r.error)" }
  } catch {
    $msg = $_.Exception.Message
    try { $msg += ' · ' + (New-Object IO.StreamReader($_.Exception.Response.GetResponseStream())).ReadToEnd() } catch { }
    Write-Log "보내기 실패: $msg"
    return @{ sent = $false; ok = $false; error = ('보내기 실패: ' + $msg) }
  }
}

# ── 맨 위만 자주 보기 (D-183) ─────────────────────────────
# 사장님(2026-10-23): 「새로운 톡방이 생기면, 바로 읽어야 하는데」 · 「지금은 그게 안되니까 어렵다」 → 고른 것 「맨 위만 자주 보기」.
# 쉬는 동안 peekSeconds(기본 60초)마다 업무 카톡 목록에서 **지금 보이는 한 화면**만 찍어 읽는다 — 굴리지도 누르지도 않는다(PC 를 쓰는 사람을 방해하지 않는다).
# 마지막 회차가 읽은 방(아는 방)에 없는 줄이 보이면 바로 보통 회차를 돈다 — 그 회차는 목록을 끝까지 굴리므로 사람이 PC 를 쓰는 중이면 손 뗄 때까지(최대 10분) 기다린다.
# ★ 카톡 창이 최소화 · 트레이면 안 본다 — 찍으려면 창을 펼쳐야 해서 1분마다 깜빡인다(다른 창 뒤에 가려진 것은 괜찮다 — PrintWindow). 그때는 예전처럼 주기마다만 읽는다.
# ★ 사람이 목록을 내려 둔 채면 맨 위가 아니라 그 자리를 본다 — 회차가 끝나면 맨 위로 올려 둔다(Invoke-Scan backTop).
# ★ 새 방으로 친 줄은 그 회차 뒤 아는 방에 넣고 · peekGapMinutes 안에는 다시 안 돈다 — 글자 인식이 한 번 달리 읽은 줄로 회차를 거듭 돌지 않게.
$script:KnownNames = @(); $script:PeekNew = $null; $script:PeekRoundNext = Get-Date; $script:PeekState = ''

# 장들의 줄(글자 인식 · Find-Rows — 맨 위 보기와 같은 잣대) → [{ n 이름, m 인원(없으면 $null) }]
function Get-RowNames($pages) {
  $names = New-Object System.Collections.ArrayList
  foreach ($p in @($pages)) { if ($null -eq $p) { continue }; foreach ($row in (Find-Rows $p)) { [void]$names.Add([pscustomobject]@{ n = [string]$row.name; m = $row.members }) } }
  return ,$names
}

# 아는 방인가 — 이름이 (빈칸 · 문장부호 빼고) 같거나 · 한쪽이 「…」 로 잘렸거나 · 한두 자만 다르면(Title-Fits — 방 창 제목을 줄에 견주는 잣대) 같은 방으로 본다.
# ★ 인원 — 이 줄에 인원이 보이는데 이름이 맞는 아는 줄이 모두 인원 없는 줄(1:1 대화)이면 새 방이다: 예약 양식 이름으로 저장한 담당자 1:1 방이 있고
#   같은 이름의 단톡방을 새로 만든 경우(D-183 검토 — 한국교통안전공단). 인원 수가 달라진 것은 같은 방(누가 들고 난다).
# 두 자가 안 되는 줄(글자 인식 찌꺼기)은 새 방으로 안 친다.
function Test-KnownName($row, $known) {
  $name = [string]$row.n
  $a = Strip-Name $name
  if ($a.Length -lt 2) { return $true }
  foreach ($k in @($known)) {
    if ($null -ne $row.m -and $null -eq $k.m) { continue }
    if ($a -eq (Strip-Name $k.n)) { return $true }
    if ((Title-Fits $k.n $name) -or (Title-Fits $name $k.n)) { return $true }
  }
  return $false
}

# 한 화면 보기 → @{ new = @(새 방 이름) } · 못 봤으면 @{ skip = 까닭 }(nokakao · hidden · nolist · blank)
function Invoke-Peek($cfg, $engine) {
  $pick = Find-OurKakao $cfg
  if ($pick.error) { return @{ skip = 'nokakao' } }
  $top = $pick.top
  if ([MotmotKakaoWin]::IsIconic($top) -or -not [MotmotKakaoWin]::IsWindowVisible($top)) { return @{ skip = 'hidden' } }
  $list = [MotmotKakaoWin]::FindList($top)
  if ($list -eq [IntPtr]::Zero) { return @{ skip = 'nolist' } }
  $bmp = [MotmotKakaoWin]::Snap($top, $list, 2, 0)                  # 회차와 같은 배율(I-177) — 같은 글자로 읽혀야 견줄 수 있다
  if ($null -eq $bmp) { return @{ skip = 'nolist' } }
  $tmp = Join-Path $env:TEMP 'motmot-kakao-idle'
  if (-not (Test-Path $tmp)) { [void](New-Item -ItemType Directory $tmp) }
  $png = Join-Path $tmp 'peek.png'
  try {
    if ([MotmotKakaoWin]::IsBlank($bmp)) { return @{ skip = 'blank' } }
    $bmp.Save($png, [System.Drawing.Imaging.ImageFormat]::Png)
    $w = $bmp.Width; $h = $bmp.Height
  } finally { $bmp.Dispose() }
  try { $page = Read-Page $engine $png $w $h } finally { Remove-Item -Force -ErrorAction SilentlyContinue $png }
  $names = Get-RowNames @($page)                                     # ⚠ 변수에 받은 뒤 흘린다 — 함수가 돌려준 목록(,$names)을 바로 흘리면 통째로 한 덩이로 간다
  return @{ new = @($names | Where-Object { -not (Test-KnownName $_ $script:KnownNames) }) }
}

# 맨 위 보기의 상태가 바뀔 때만 기록 — 1분마다 쌓이지 않게
function Note-Peek($pk) {
  $state = if ($pk.skip) { "$($pk.skip)" } else { 'ok' }
  if ($state -eq $script:PeekState) { return }
  $prev = $script:PeekState; $script:PeekState = $state
  if ($state -eq 'hidden') { Write-Log '카톡 창이 최소화 · 트레이에 있어 「맨 위만 자주 보기」 를 쉽니다 — 창을 열어 두면(다른 창 뒤에 가려져도 됨) 새 방을 1~2분 안에 읽습니다' }
  elseif ($state -eq 'error') { Write-Log ('「맨 위만 자주 보기」 오류(다음에 다시): ' + $pk.msg) }
  elseif ($state -eq 'ok' -and $prev -in @('hidden', 'error')) { Write-Log '「맨 위만 자주 보기」 를 다시 합니다' }   # 잠금 화면(blank) · 카톡 꺼짐은 회차가 따로 알린다
}

# 쉬는 동안 부른다 — 새 방이 보여 바로 회차를 돌 것이면 $true
# ★ 아는 방이 없어도(첫 회차 실패 · 카톡이 늦게 뜸 · 「친구」 탭이던 회차) 본다 — 그때 읽힌 줄은 모두 새 방이라 회차를 돈다(D-183 검토 — 예전에는 그동안 꺼졌다).
function Test-PeekRound($cfg, $engine) {
  if ([int]$cfg.peekSeconds -le 0) { return $false }
  $pk = $null
  try { $pk = Invoke-Peek $cfg $engine } catch { $pk = @{ skip = 'error'; msg = $_.Exception.Message } }
  if ($null -eq $pk) { $pk = @{ skip = 'error'; msg = '답 없음' } }
  Note-Peek $pk
  $new = @($pk.new | Where-Object { $null -ne $_ })                # ⚠ @($null) 은 한 칸짜리다
  if ($pk.skip -or -not $new.Count) { return $false }
  if ((Get-Date) -lt $script:PeekRoundNext) { return $false }
  $script:PeekRoundNext = (Get-Date).AddMinutes([math]::Max(1, [int]$cfg.peekGapMinutes))
  $script:PeekNew = $new
  $more = if ($new.Count -gt 1) { ' 외 ' + ($new.Count - 1) + '곳' } else { '' }
  Write-Log ("목록 맨 위에 새 방이 보입니다(「{0}」{1}) — 바로 읽습니다(PC 를 쓰는 중이면 손을 뗄 때까지 기다림)" -f $new[0].n, $more)
  return $true
}

function Run-Once($cfg, $engine) {
  # 사람이 이 PC 를 쓰는 중이면(1분 안 입력) 최대 10분 기다린다 — 목록이 혼자 움직이면 놀란다.
  # -Once(사람이 손으로 시험 삼아 돌릴 때)는 기다리지 않는다 — 돌린 사람이 바로 그 사람이다.
  # 10분을 기다려도 계속 쓰는 중이면 찍기는 하되 방은 안 연다(Invoke-Scan). 기다리는 사이에도 「끄기」 깃발을 본다.
  # 「지금 한 번 읽기」(OpenNow)도 안 기다린다 — 누른 사람이 지금 읽고 열라고 했다.
  # 기다리는 사이 「지금 한 번 읽기」(방도 열기)를 누르면 바로 그 회차로 돈다(깃발은 여기서 거둔다 — 다음 회차가 또 받지 않게).
  for ($k = 0; -not $Once -and -not $script:OpenNow -and $k -lt 300 -and [MotmotKakaoWin]::IdleMs() -lt 60000; $k++) {
    if (Test-Path $StopFlag) { $script:Stopping = $true; return }
    if (Test-OpenNowFlag) { $script:OpenNow = $true; Remove-Item -Force -ErrorAction SilentlyContinue $NowFlag; break }
    Start-Sleep -Seconds 2
  }
  # 기다리는 사이 실행기에서 설정을 바꿨을 수 있다(방 열기 끔 · 열쇠) — 찍기 직전에 다시 읽는다
  try { $cfg = Read-Config } catch { }
  $at = (Get-Date).ToUniversalTime().ToString('o')
  $agent = [ordered]@{ host = $env:COMPUTERNAME; ver = $VER }
  if ($script:OpenNow) { Write-Log '「지금 한 번 읽기」 — 1분 규칙 없이 단체방도 엽니다(도중에 키보드 · 마우스를 만지면 방 열기를 멈춥니다)' }
  Write-Status ([ordered]@{ scanning = $true; at = $at })
  try {
    $r = Invoke-Scan $cfg $engine
  } catch {
    $r = @{ error = ('수집기 오류: ' + $_.Exception.Message) }
  }
  if ($script:Stopping) {
    Write-Log '실행기가 끄라 해서 이번 회차는 보내지 않고 끝냅니다'
    Write-Status ([ordered]@{ scanning = $false; at = $at; ok = $true; stopped = $true })
    return
  }
  if ($r.error) {
    Write-Log $r.error
    $s = Send-Scan $cfg ([ordered]@{ v = 1; capturedAt = $at; complete = $false; error = $r.error; agent = $agent; pages = @() })
    Write-Status ([ordered]@{ scanning = $false; at = $at; ok = $false; error = $r.error; sent = [bool]$s.sent })
    return
  }
  $why = @{ bottom = '내림'; stuck = '못 내림(목록이 안 움직임)'; unsure = '못 내림(맨 아래인지 확인 못 함)'; gap = '못 내림(장 사이가 안 겹침)'; top = '못 내림(맨 위를 확인 못 함)'; blank = '못 내림(화면이 비어 찍힘)'; max = '못 내림(maxPages)' }[$r.end.why]
  Write-Log ("찍음 — {0}장 · 끝까지 {1} · 늦게 내려감 {2} · 줄여 다시 {3}" -f $r.pages.Count, $why, $r.end.retried, $r.end.backoffs)
  # 맨 위 보기가 견줄 아는 방(D-183) — 줄을 하나라도 읽은 회차만(「친구」 탭 · 좁은 창 회차가 아는 방을 비우지 않게).
  # 맨 위 보기가 새 방으로 친 줄도 그때 넣는다 — 회차가 달리 읽었어도 같은 줄로 회차를 거듭 돌지 않게. 회차가 실패하면 안 넣는다(다음 맨 위 보기가 다시 찾는다 · 검토).
  try {
    $known = Get-RowNames $r.pages
    if ($known.Count) { $script:KnownNames = @($known) + @($script:PeekNew | Where-Object { $null -ne $_ }) }
  } catch { }
  $s = Send-Scan $cfg ([ordered]@{ v = 1; capturedAt = $at; complete = [bool]$r.complete; end = $r.end; agent = $agent; open = $r.open; pages = $r.pages })
  Write-Status ([ordered]@{ scanning = $false; at = $at; ok = [bool]$s.ok; pages = $r.pages.Count; complete = ([bool]$r.complete -and -not $s.short); end = $r.end.why;
    rooms = $s.rooms; sent = [bool]$s.sent; dry = [bool]$s.dry; error = $s.error })
}

# ── 시작 ─────────────────────────────────────────────────
$mutex = New-Object System.Threading.Mutex($false, 'Local\MotmotKakaoIdleCollector')
if (-not $mutex.WaitOne(0)) {
  # 이미 계속 도는 수집기가 있으면 -Once 는 그쪽에 「지금 한 번」 깃발만 꽂는다(실행기 화면의 「지금 읽기」)
  # -OpenNow 면 깃발에 'open' 을 붙인다 — 도는 수집기가 그 회차는 1분 규칙 없이 방을 연다(D-164)
  if ($Once) {
    $flag = (Get-Date).ToString('o'); if ($OpenNow) { $flag = 'open ' + $flag }
    try { Set-Content -Path $NowFlag -Value $flag } catch { }
    Write-Log $(if ($OpenNow) { '도는 수집기에 「지금 한 번 읽기」(방도 열기)를 부탁했습니다' } else { '도는 수집기에 「지금 한 번 읽기」 를 부탁했습니다' })
  }
  else { Write-Log '이미 다른 수집기가 돌고 있습니다 — 이건 끝냅니다' }
  exit 0
}
try {
  if (-not $Once) { Set-Content -Path $PidPath -Value $PID }
  # 「카톡만 끄기」 깃발이 있으면 돌지 않는다 — 옛 「시작프로그램」 바로가기는 그것을 모르고 띄운다(「카톡 켜기」 · ON 은 깃발을 먼저 치운다).
  # 실행기 OFF 는 **우리가 뜨기 시작한 뒤에** 눌렀을 때만 — 뜨는 사이(C# 붙이기 · 엔진 — 느린 PC 는 수십 초) 실행기는 잠금 전이라 끌 수집기를 못 본다.
  #   (OFF 인 채로 「카톡 켜기」 를 누른 것은 사람이 켠 것이다 — 그 깃발은 그보다 오래다.) 「지금 한 번 읽기」(-Once)는 사람이 누른 것이라 그대로 읽는다.
  if (-not $Once -and $StateDir) {
    $offFlag = Join-Path (Split-Path -Parent $Base) 'off.flag'
    $born = $script:Born
    $offNew = $false; try { $offNew = ($null -ne $born) -and (Test-Path $offFlag) -and ((Get-Item $offFlag).LastWriteTime -ge $born) } catch { }
    if ((Test-Path (Join-Path $Base 'paused.flag')) -or $offNew) {
      Write-Log $(if ($offNew) { '뜨는 사이 실행기 OFF 를 눌러 수집기를 시작하지 않습니다' } else { '「카톡만 끄기」 상태라 수집기를 시작하지 않습니다' })
      return
    }
  }
  Remove-Item -Force -ErrorAction SilentlyContinue $StopFlag        # 앞서 남은 「끄기」 깃발 — 이 수집기 것이 아니다(여기까지 왔으면 다른 수집기는 없다)
  $cfg = Read-Config
  $engine = New-OcrEngine
  Write-Log ("수집기 시작 (판 {0} · {1}분마다{2}{3})" -f $VER, $cfg.intervalMinutes, $(if ([int]$cfg.peekSeconds -gt 0) { ' · 맨 위는 ' + [math]::Max(20, [int]$cfg.peekSeconds) + '초마다' } else { '' }), $(if ($DryRun) { ' · DryRun' } else { '' }))
  while ($true) {
    # 도는 수집기는 회차마다 「지금 한 번」 깃발을 보고 정한다 — 'open' 이면 이번 회차만 1분 규칙 없이 방을 연다(D-164)
    if (-not $Once) { $script:OpenNow = Test-OpenNowFlag }
    Remove-Item -Force -ErrorAction SilentlyContinue $NowFlag
    # 설정은 회차마다 다시 읽는다 — 실행기에서 열쇠 · 주기 · 방 열기를 바꿔도 껐다 켤 필요가 없다
    # ★ 설정 파일 시각은 **읽기 전에** 적어 둔다 — 회차 도중(기다리는 10분 · 찍는 동안)에 바꾼 설정을 쉬는 동안 알아보게(검토 2026.10.15-4:
    #   예전에는 회차가 끝난 뒤 시각을 적어, 그 사이 바꾼 주기를 한 번 쉬는 내내 옛 주기로 쉬었다).
    $cfgTime = $null; try { $cfgTime = (Get-Item $Config).LastWriteTimeUtc } catch { }
    try { $cfg = Read-Config } catch { Write-Log ('설정을 다시 읽지 못해 앞 설정으로 돕니다: ' + $_.Exception.Message) }
    $null = Run-Once $cfg $engine                                    # 흘러나온 값을 화면으로 안 보낸다(콘솔 없는 수집기에서 화면 쓰기는 실패한다)
    $script:PeekNew = $null                                           # 회차가 읽었으면 Run-Once 가 아는 방에 넣었다 · 실패했으면 버린다(다음 맨 위 보기가 다시 찾는다)
    if ($Once -or $script:Stopping) { break }
    # 쉬는 동안 2초마다 「지금 한 번」 · 「끄기」 깃발을 보고, 30초마다 관리자 화면 「지금 읽기」 부탁을 묻는다. 주기를 바꾸면 쉬는 시간도 바로 바뀐다.
    $rest = Get-Date
    $peekNext = (Get-Date).AddSeconds([math]::Max(20, [int]$cfg.peekSeconds))
    while (-not (Test-Path $NowFlag)) {
      if (Test-Path $StopFlag) { $script:Stopping = $true; break }
      try {
        $wt = (Get-Item $Config).LastWriteTimeUtc
        if ($wt -ne $cfgTime) { $cfgTime = $wt; $cfg = Read-Config }
      } catch { }
      if ((Get-Date) -ge $rest.AddMinutes([int]$cfg.intervalMinutes)) { break }
      if (-not $DryRun -and (Test-ReadRequest $cfg)) { break }        # 관리자 화면 「지금 읽기」(D-172) — 보통 회차로
      if ((Get-Date) -ge $peekNext) {                                  # 맨 위만 자주 보기(D-183) — 새 방이면 보통 회차로
        $peekNext = (Get-Date).AddSeconds([math]::Max(20, [int]$cfg.peekSeconds))
        if (Test-PeekRound $cfg $engine) { break }
      }
      Start-Sleep -Seconds 2
    }
    if ($script:Stopping) { break }
  }
  if ($script:Stopping) {
    Write-Log '실행기가 수집기를 껐습니다'
    Remove-Item -Force -ErrorAction SilentlyContinue $StopFlag
  }
} catch {
  Write-Log ('멈춤: ' + $_.Exception.Message)
  Write-Status ([ordered]@{ scanning = $false; at = (Get-Date).ToUniversalTime().ToString('o'); ok = $false; error = ('수집기가 멈췄습니다: ' + $_.Exception.Message) })
  exit 1
} finally {
  if (-not $Once) { Remove-Item -Force -ErrorAction SilentlyContinue $PidPath }
  $mutex.ReleaseMutex()
}
