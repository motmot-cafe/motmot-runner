﻿<#
  ============================================================
  카톡 휴면방 수집기 — 서버 PC 에서 돈다 (D-134)

  하는 일
    1) 켜져 있는 PC 카카오톡의 「채팅」 목록 창을 찍는다(창을 앞으로 가져오지 않는다 · PrintWindow).
    2) 윈도우에 들어 있는 글자 인식(Windows.Media.Ocr, 한국어)으로 글자와 위치를 읽는다.
    3) 목록을 맨 위부터 끝까지 조금씩 내려 가며 1~2 를 되풀이한다(장끼리 겹치게).
    4) 읽은 글자 조각을 그대로 https://motmot.co.kr/api/push?op=kakao_push 로 보낸다.
       「방 이름 · 마지막 대화 날짜」 로 바꾸는 판정은 **서버**가 한다(api/_kakao.mjs) —
       카톡 화면이 바뀌어도 이 PC 는 손대지 않고 서버만 고치면 되게.
    5) 목록을 맨 위로 돌려 놓고, 정한 분(기본 30분)만큼 쉰다.

  ★ 대화 내용(미리보기)은 서버로 가기는 하지만 서버가 **버린다** — 표에는 방 이름과 날짜만 남는다.
  ★ 사람이 이 PC 를 만지고 있으면(1분 안에 키보드 · 마우스 입력) 최대 10분 기다렸다가 찍는다(-Once 는 바로).

  실행
    powershell -NoProfile -ExecutionPolicy Bypass -File collect.ps1           # 계속 돈다(시작프로그램용)
    powershell -NoProfile -ExecutionPolicy Bypass -File collect.ps1 -Once     # 한 번만
    powershell -NoProfile -ExecutionPolicy Bypass -File collect.ps1 -Once -DryRun   # 보내지 않고 last-scan.json 만
  설정: 같은 폴더 config.json (config.example.json 을 복사해 열쇠를 넣는다 · 저장소에 안 들어간다)
  기록: 같은 폴더 collect.log · 마지막으로 읽은 것: last-scan.json (둘 다 이 PC 에만)

  ⚠ 이 파일은 **UTF-8 BOM** 으로 저장돼 있어야 한다 — 윈도우 PowerShell 5.1 은 BOM 이 없으면
    한글(「카카오톡」 창 이름 등)을 깨뜨려 창을 못 찾는다.
  ============================================================
#>
param(
  [switch]$Once,
  [switch]$DryRun,
  [string]$Config = "",
  [string]$StateDir = ""      # 기록 · 상태를 둘 곳. 실행기 화면이 띄울 때는 pension-sync\state\kakao-idle (업데이트가 안 덮는 자리)
)

$ErrorActionPreference = 'Stop'
$VER = '2026.10.14-2'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $Config) { $Config = Join-Path $Here 'config.json' }
$Base = if ($StateDir) { $StateDir } else { $Here }
if (-not (Test-Path $Base)) { [void](New-Item -ItemType Directory -Force $Base) }
$LogPath = Join-Path $Base 'collect.log'
$LastScanPath = Join-Path $Base 'last-scan.json'
# 실행기 화면(실행기.exe 「카톡 휴면방」)이 읽는 자리 — 지금 상태 · 도는 수집기 번호 · 「지금 한 번」 깃발
$StatusPath = Join-Path $Base 'status.json'
$PidPath = Join-Path $Base 'collector.pid'
$NowFlag = Join-Path $Base 'now.flag'

function Write-Status($h) {
  $h['ver'] = $VER
  $h['pid'] = $PID
  $h['loop'] = -not $Once
  try { Set-Content -Path $StatusPath -Value (($h | ConvertTo-Json -Depth 4 -Compress)) -Encoding UTF8 } catch { }
}

function Write-Log([string]$msg) {
  $line = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') + '  ' + $msg
  Write-Host $line
  try {
    if ((Test-Path $LogPath) -and ((Get-Item $LogPath).Length -gt 1MB)) {
      Move-Item -Force $LogPath ($LogPath + '.old')
    }
    Add-Content -Path $LogPath -Value $line -Encoding UTF8
  } catch { }
}

# ── 설정 ──────────────────────────────────────────────────
function Read-Config {
  if (-not (Test-Path $Config)) {
    throw "설정 파일이 없습니다: $Config — config.example.json 을 config.json 으로 복사하고 secret 을 넣어 주세요."
  }
  $c = Get-Content -Raw -Encoding UTF8 $Config | ConvertFrom-Json
  $d = @{
    endpoint          = 'https://motmot.co.kr/api/push?op=kakao_push'
    secret            = ''
    intervalMinutes   = 30
    wheelClicksPerPage = 3
    maxPages          = 80
    settleMs          = 450
    scrollMode        = 'wheel'
    windowTitle       = '카카오톡'
  }
  foreach ($k in @($d.Keys)) {
    if ($null -ne $c.$k -and "$($c.$k)" -ne '') { $d[$k] = $c.$k }
  }
  if (-not $DryRun -and ("$($d.secret)").Length -lt 16) {
    throw "config.json 의 secret 이 비었거나 짧습니다(16자 이상) — Vercel 환경변수 KAKAO_AGENT_SECRET 과 같은 값을 넣어 주세요."
  }
  return $d
}

# ── 윈도우 창 다루기 ───────────────────────────────────────
Add-Type -ReferencedAssemblies System.Drawing -TypeDefinition @"
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Text;

public static class MotmotKakaoWin {
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
  [StructLayout(LayoutKind.Sequential)] struct LASTINPUTINFO { public uint cbSize; public uint dwTime; }
  delegate bool EnumProc(IntPtr h, IntPtr l);

  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern IntPtr FindWindow(string cls, string title);
  [DllImport("user32.dll")] static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr l);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder sb, int n);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int cmd);
  [DllImport("user32.dll")] static extern bool PrintWindow(IntPtr h, IntPtr hdc, uint flags);
  [DllImport("user32.dll")] static extern bool PostMessage(IntPtr h, uint msg, IntPtr w, IntPtr l);
  [DllImport("user32.dll")] static extern bool GetLastInputInfo(ref LASTINPUTINFO p);

  /* 카톡 채팅 목록 = 보이는 EVA_VH_ListControl* 중 가장 큰 것.
     「친구」 목록도 같은 종류지만 「채팅」 탭에서는 숨어 있다(안 보인다). */
  public static IntPtr FindList(IntPtr top) {
    IntPtr best = IntPtr.Zero; long bestArea = 0;
    EnumChildWindows(top, (h, l) => {
      var sb = new StringBuilder(256);
      GetClassName(h, sb, 256);
      if (sb.ToString().StartsWith("EVA_VH_ListControl") && IsWindowVisible(h)) {
        RECT r; GetWindowRect(h, out r);
        long a = (long)(r.Right - r.Left) * (r.Bottom - r.Top);
        if (a > bestArea) { bestArea = a; best = h; }
      }
      return true;
    }, IntPtr.Zero);
    return best;
  }

  /* 큰 창을 통째로 찍고(가려져 있어도 된다 · 2 = PW_RENDERFULLCONTENT) 목록 자리만 오려 scale 배로 키운다.
     키우는 까닭: 윈도우 글자 인식은 작은 글씨(9~10pt)에서 자주 틀린다. */
  public static Bitmap Snap(IntPtr top, IntPtr list, int scale) {
    RECT w, a; GetWindowRect(top, out w); GetWindowRect(list, out a);
    int ww = w.Right - w.Left, wh = w.Bottom - w.Top;
    if (ww <= 0 || wh <= 0) return null;
    using (var full = new Bitmap(ww, wh, PixelFormat.Format32bppArgb)) {
      using (var g = Graphics.FromImage(full)) {
        IntPtr dc = g.GetHdc();
        try { PrintWindow(top, dc, 2); } finally { g.ReleaseHdc(dc); }
      }
      var crop = new Rectangle(a.Left - w.Left, a.Top - w.Top, a.Right - a.Left, a.Bottom - a.Top);
      crop.Intersect(new Rectangle(0, 0, ww, wh));
      if (crop.Width <= 0 || crop.Height <= 0) return null;
      var outBmp = new Bitmap(crop.Width * scale, crop.Height * scale, PixelFormat.Format32bppArgb);
      using (var g2 = Graphics.FromImage(outBmp)) {
        g2.InterpolationMode = InterpolationMode.HighQualityBicubic;
        g2.DrawImage(full, new Rectangle(0, 0, outBmp.Width, outBmp.Height), crop, GraphicsUnit.Pixel);
      }
      return outBmp;
    }
  }

  /* 한 가지 색뿐인 그림 = 못 찍은 것(잠금 화면 · 최소화 · 그리기 전) */
  public static bool IsBlank(Bitmap b) {
    Color c0 = b.GetPixel(0, 0);
    int stepX = Math.Max(1, b.Width / 40), stepY = Math.Max(1, b.Height / 80);
    for (int y = 0; y < b.Height; y += stepY)
      for (int x = 0; x < b.Width; x += stepX)
        if (b.GetPixel(x, y).ToArgb() != c0.ToArgb()) return false;
    return true;
  }

  /* 휠 굴리기 — 목록 창에 직접 보낸다(앞으로 가져오지 않는다). clicks > 0 = 위로, < 0 = 아래로 */
  public static void Wheel(IntPtr list, int clicks) {
    RECT r; GetWindowRect(list, out r);
    int x = (r.Left + r.Right) / 2, y = (r.Top + r.Bottom) / 2;
    uint wp = ((uint)(ushort)(short)(clicks * 120)) << 16;
    uint lp = (((uint)(ushort)(short)y) << 16) | (uint)(ushort)(short)x;
    PostMessage(list, 0x020A, (IntPtr)unchecked((int)wp), (IntPtr)unchecked((int)lp));
  }
  /* 휠이 안 먹는 판을 위한 다른 길(scrollMode = vscroll) — WM_VSCROLL. code 0 = 한 줄 위 · 1 = 한 줄 아래 · 6 = 맨 위 */
  public static void VScroll(IntPtr list, int code) {
    PostMessage(list, 0x0115, (IntPtr)code, IntPtr.Zero);
  }

  public static uint IdleMs() {
    var p = new LASTINPUTINFO(); p.cbSize = (uint)Marshal.SizeOf(p);
    if (!GetLastInputInfo(ref p)) return uint.MaxValue;
    return unchecked((uint)Environment.TickCount - p.dwTime);
  }
}
"@
[void][MotmotKakaoWin]::SetProcessDPIAware()

# ── 글자 인식 (Windows.Media.Ocr) ───────────────────────────
Add-Type -AssemblyName System.Runtime.WindowsRuntime
[void][Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
[void][Windows.Globalization.Language, Windows.Foundation, ContentType = WindowsRuntime]
[void][Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics, ContentType = WindowsRuntime]
[void][Windows.Graphics.Imaging.SoftwareBitmap, Windows.Graphics, ContentType = WindowsRuntime]
[void][Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
[void][Windows.Storage.Streams.IRandomAccessStream, Windows.Storage.Streams, ContentType = WindowsRuntime]

$script:AsTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
  $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
  $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]

function Await($op, [Type]$type) {
  $task = $script:AsTask.MakeGenericMethod($type).Invoke($null, @($op))
  [void]$task.Wait(-1)
  return $task.Result
}

function New-OcrEngine {
  $lang = New-Object Windows.Globalization.Language 'ko'
  $eng = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($lang)
  if ($null -eq $eng) {
    throw "윈도우 한국어 글자 인식이 설치돼 있지 않습니다. 관리자 PowerShell 에서: Add-WindowsCapability -Online -Name 'Language.OCR~~~ko-KR~0.0.1.0'"
  }
  return $eng
}

# 그림 파일 하나 → { w, h, lines:[{ words:[{t,x,y,w,h}] }] }
function Read-Page($engine, [string]$png, [int]$w, [int]$h) {
  $file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($png)) ([Windows.Storage.StorageFile])
  $stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
  try {
    $decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
    $soft = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
    $res = Await ($engine.RecognizeAsync($soft)) ([Windows.Media.Ocr.OcrResult])
  } finally { $stream.Dispose() }
  $lines = New-Object System.Collections.ArrayList
  foreach ($ln in $res.Lines) {
    $words = New-Object System.Collections.ArrayList
    foreach ($wd in $ln.Words) {
      $r = $wd.BoundingRect
      [void]$words.Add([ordered]@{ t = $wd.Text; x = [math]::Round($r.X, 1); y = [math]::Round($r.Y, 1); w = [math]::Round($r.Width, 1); h = [math]::Round($r.Height, 1) })
    }
    if ($words.Count) { [void]$lines.Add([ordered]@{ words = @($words) }) }
  }
  return [ordered]@{ w = $w; h = $h; lines = @($lines) }
}

function Page-Texts($page) {
  $set = New-Object 'System.Collections.Generic.HashSet[string]'
  foreach ($ln in $page.lines) { [void]$set.Add((($ln.words | ForEach-Object { $_.t }) -join ' ')) }
  return ,$set
}

# ── 한 번 찍어 읽기 ──────────────────────────────────────
function Invoke-Scan($cfg, $engine) {
  $top = [MotmotKakaoWin]::FindWindow('EVA_Window_Dblclk', $cfg.windowTitle)
  if ($top -eq [IntPtr]::Zero) { $top = [MotmotKakaoWin]::FindWindow($null, $cfg.windowTitle) }
  if ($top -eq [IntPtr]::Zero) { return @{ error = '카카오톡 창을 찾지 못했습니다 — 카카오톡이 켜져 있고 로그인돼 있는지 확인해 주세요' } }

  # 최소화 · 트레이로 숨김이면 잠깐 (앞으로 가져오지 않고) 펼쳤다가 끝나면 되돌린다
  $wasIconic = [MotmotKakaoWin]::IsIconic($top)
  $wasHidden = -not [MotmotKakaoWin]::IsWindowVisible($top)
  if ($wasIconic -or $wasHidden) { [void][MotmotKakaoWin]::ShowWindow($top, 4); Start-Sleep -Milliseconds 800 }   # 4 = SW_SHOWNOACTIVATE

  try {
    $list = [MotmotKakaoWin]::FindList($top)
    if ($list -eq [IntPtr]::Zero) { return @{ error = '카카오톡 채팅 목록을 찾지 못했습니다 — 카톡 창을 「채팅」 탭에 두어 주세요' } }

    $tmp = Join-Path $env:TEMP 'motmot-kakao-idle'
    if (-not (Test-Path $tmp)) { [void](New-Item -ItemType Directory $tmp) }

    $shot = {
      param([int]$i)
      $bmp = [MotmotKakaoWin]::Snap($top, $list, 2)
      if ($null -eq $bmp) { return $null }
      try {
        if ([MotmotKakaoWin]::IsBlank($bmp)) { return @{ blank = $true } }
        $png = Join-Path $tmp ("p{0:D3}.png" -f $i)
        $bmp.Save($png, [System.Drawing.Imaging.ImageFormat]::Png)
        $hash = (Get-FileHash -Algorithm MD5 $png).Hash
        return @{ png = $png; hash = $hash; w = $bmp.Width; h = $bmp.Height }
      } finally { $bmp.Dispose() }
    }
    $scroll = {
      param([int]$clicks)
      if ($cfg.scrollMode -eq 'vscroll') {
        $code = if ($clicks -gt 0) { 0 } else { 1 }
        for ($k = 0; $k -lt [math]::Abs($clicks) * 3; $k++) { [MotmotKakaoWin]::VScroll($list, $code) }
      } else { [MotmotKakaoWin]::Wheel($list, $clicks) }
      Start-Sleep -Milliseconds ([int]$cfg.settleMs)
    }

    # 1) 맨 위로 — 그림이 더 안 바뀔 때까지 위로 굴린다
    if ($cfg.scrollMode -eq 'vscroll') { [MotmotKakaoWin]::VScroll($list, 6); Start-Sleep -Milliseconds ([int]$cfg.settleMs) }
    $prev = ''
    for ($k = 0; $k -lt 60; $k++) {
      & $scroll 15
      $s = & $shot 0
      if ($null -eq $s) { return @{ error = '카카오톡 창을 찍지 못했습니다(창 크기 0)' } }
      if ($s.blank) { return @{ error = '카카오톡 화면이 비어 찍혔습니다 — PC 가 잠겨 있거나 화면이 꺼져 그리지 않는 중일 수 있습니다' } }
      if ($s.hash -eq $prev) { break }
      $prev = $s.hash
    }

    # 2) 내려 가며 찍고 읽는다
    $pages = New-Object System.Collections.ArrayList
    $clicks = [int]$cfg.wheelClicksPerPage
    $complete = $false
    $lastHash = ''
    $prevTexts = $null
    for ($i = 1; $i -le [int]$cfg.maxPages; $i++) {
      $s = & $shot $i
      if ($null -eq $s -or $s.blank) { break }
      if ($s.hash -eq $lastHash) { $complete = $true; break }     # 더 안 내려간다 = 끝
      $page = Read-Page $engine $s.png $s.w $s.h
      # 겹침 확인 — 앞 장과 같은 줄이 둘 이상 있어야 사이에 빠진 방이 없다. 없으면 한 칸 덜 내려 다시.
      if ($null -ne $prevTexts -and $clicks -gt 1) {
        $same = 0
        foreach ($ln in $page.lines) { if ($prevTexts.Contains((($ln.words | ForEach-Object { $_.t }) -join ' '))) { $same++ } }
        if ($same -lt 2) {
          & $scroll 1                                   # 한 칸 되돌려 (앞 장 + 줄인 칸 수) 자리로
          $clicks = $clicks - 1
          Write-Log "겹침 부족 — 한 장에 $clicks 칸씩으로 줄여 다시 찍습니다"
          $i--
          continue
        }
      }
      [void]$pages.Add($page)
      $prevTexts = Page-Texts $page
      $lastHash = $s.hash
      & $scroll (-$clicks)
    }

    # 3) 다시 맨 위로(사람이 볼 때 늘 보던 모습으로)
    for ($k = 0; $k -lt 30; $k++) { & $scroll 15; $t = & $shot 999; if ($null -eq $t -or $t.blank -or $t.hash -eq $prev) { break } }
    Remove-Item -Force -ErrorAction SilentlyContinue (Join-Path $tmp '*.png')

    return @{ pages = @($pages); complete = $complete }
  } finally {
    if ($wasHidden) { [void][MotmotKakaoWin]::ShowWindow($top, 0) }          # 0 = SW_HIDE (트레이로)
    elseif ($wasIconic) { [void][MotmotKakaoWin]::ShowWindow($top, 7) }      # 7 = SW_SHOWMINNOACTIVE
  }
}

function Send-Scan($cfg, $payload) {
  $json = $payload | ConvertTo-Json -Depth 12 -Compress
  try { Set-Content -Path $LastScanPath -Value $json -Encoding UTF8 } catch { }
  if ($DryRun) { Write-Log "DryRun — 보내지 않았습니다. 읽은 것은 $LastScanPath"; return @{ sent = $false; ok = $true; dry = $true } }
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  $bytes = [Text.Encoding]::UTF8.GetBytes($json)
  try {
    $r = Invoke-RestMethod -Uri $cfg.endpoint -Method Post -Body $bytes -ContentType 'application/json; charset=utf-8' `
      -Headers @{ 'x-kakao-secret' = "$($cfg.secret)" } -TimeoutSec 90
    if ($r.ok) { Write-Log ("보냄 — {0}방 · {1}장" -f $r.rooms, $r.pages); return @{ sent = $true; ok = $true; rooms = $r.rooms } }
    Write-Log ("서버가 받았지만 문제를 알렸습니다: {0}" -f $r.error)
    return @{ sent = $true; ok = $false; rooms = $r.rooms; error = "$($r.error)" }
  } catch {
    $msg = $_.Exception.Message
    try { $msg += ' · ' + (New-Object IO.StreamReader($_.Exception.Response.GetResponseStream())).ReadToEnd() } catch { }
    Write-Log "보내기 실패: $msg"
    return @{ sent = $false; ok = $false; error = ('보내기 실패: ' + $msg) }
  }
}

function Run-Once($cfg, $engine) {
  # 사람이 이 PC 를 쓰는 중이면(1분 안 입력) 최대 10분 기다린다 — 목록이 혼자 움직이면 놀란다.
  # -Once(사람이 손으로 시험 삼아 돌릴 때)는 기다리지 않는다 — 돌린 사람이 바로 그 사람이다.
  for ($k = 0; -not $Once -and $k -lt 10 -and [MotmotKakaoWin]::IdleMs() -lt 60000; $k++) { Start-Sleep -Seconds 60 }
  $at = (Get-Date).ToUniversalTime().ToString('o')
  $agent = [ordered]@{ host = $env:COMPUTERNAME; ver = $VER }
  Write-Status ([ordered]@{ scanning = $true; at = $at })
  try {
    $r = Invoke-Scan $cfg $engine
  } catch {
    $r = @{ error = ('수집기 오류: ' + $_.Exception.Message) }
  }
  if ($r.error) {
    Write-Log $r.error
    $s = Send-Scan $cfg ([ordered]@{ v = 1; capturedAt = $at; complete = $false; error = $r.error; agent = $agent; pages = @() })
    Write-Status ([ordered]@{ scanning = $false; at = $at; ok = $false; error = $r.error; sent = [bool]$s.sent })
    return
  }
  Write-Log ("찍음 — {0}장 · 끝까지 {1}" -f $r.pages.Count, $(if ($r.complete) { '내림' } else { '못 내림(maxPages)' }))
  $s = Send-Scan $cfg ([ordered]@{ v = 1; capturedAt = $at; complete = [bool]$r.complete; agent = $agent; pages = $r.pages })
  Write-Status ([ordered]@{ scanning = $false; at = $at; ok = [bool]$s.ok; pages = $r.pages.Count; complete = [bool]$r.complete;
    rooms = $s.rooms; sent = [bool]$s.sent; dry = [bool]$s.dry; error = $s.error })
}

# ── 시작 ─────────────────────────────────────────────────
$mutex = New-Object System.Threading.Mutex($false, 'Local\MotmotKakaoIdleCollector')
if (-not $mutex.WaitOne(0)) {
  # 이미 계속 도는 수집기가 있으면 -Once 는 그쪽에 「지금 한 번」 깃발만 꽂는다(실행기 화면의 「지금 읽기」)
  if ($Once) { try { Set-Content -Path $NowFlag -Value (Get-Date).ToString('o') } catch { }; Write-Log '도는 수집기에 「지금 한 번 읽기」 를 부탁했습니다' }
  else { Write-Log '이미 다른 수집기가 돌고 있습니다 — 이건 끝냅니다' }
  exit 0
}
try {
  if (-not $Once) { Set-Content -Path $PidPath -Value $PID }
  $cfg = Read-Config
  $engine = New-OcrEngine
  Write-Log ("수집기 시작 (판 {0} · {1}분마다{2})" -f $VER, $cfg.intervalMinutes, $(if ($DryRun) { ' · DryRun' } else { '' }))
  while ($true) {
    Remove-Item -Force -ErrorAction SilentlyContinue $NowFlag
    Run-Once $cfg $engine
    if ($Once) { break }
    # 쉬는 동안 10초마다 「지금 한 번」 깃발을 본다 — 있으면 바로 다시 읽는다
    $until = (Get-Date).AddMinutes([int]$cfg.intervalMinutes)
    while ((Get-Date) -lt $until -and -not (Test-Path $NowFlag)) { Start-Sleep -Seconds 10 }
  }
} catch {
  Write-Log ('멈춤: ' + $_.Exception.Message)
  Write-Status ([ordered]@{ scanning = $false; at = (Get-Date).ToUniversalTime().ToString('o'); ok = $false; error = ('수집기가 멈췄습니다: ' + $_.Exception.Message) })
  exit 1
} finally {
  if (-not $Once) { Remove-Item -Force -ErrorAction SilentlyContinue $PidPath }
  $mutex.ReleaseMutex()
}
