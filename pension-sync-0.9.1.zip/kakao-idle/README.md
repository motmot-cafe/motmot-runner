# 카톡 휴면방 수집기 — 사용법 (D-134)

서버 PC 에 켜 둔 **카카오톡 PC판**의 「채팅」 목록을 30분마다 찍어 읽고,
관리자 콘솔 **접수 · 정산 → 「카톡 휴면방」** 에 「며칠째 대화가 없는 방」 목록을 올립니다.
직원(관리자 계정)은 누구나 보기만 할 수 있고, 영업사원 계정에는 보이지 않습니다.

```
[서버 PC 카카오톡] → collect.ps1 (찍기 · 윈도우 글자 인식) → /api/push?op=kakao_push
                                                               → api/_kakao.mjs (방 이름 · 날짜 판정)
                                                               → Supabase kakao_rooms · kakao_scans
                                                               → admin.html 「카톡 휴면방」 (assets/admin-kakao-idle.js)
```

- **판정은 서버가 합니다.** 이 PC 는 글자 조각만 보냅니다. 카톡 화면이 바뀌어 읽는 규칙을 고쳐야 하면 서버만 배포합니다.
- **대화 내용은 남기지 않습니다.** 표에는 방 이름, 마지막 대화 날짜, 마지막으로 본 때만 들어갑니다.
- 카카오가 대화 목록을 꺼내 주는 공식 길(API)은 없습니다. 그래서 **화면을 읽습니다**(사장님 결정 2026-10-14 · A안).

## ★ 실행기(실행기.exe 0.9.1~)에서 쓰기 — 이쪽이 쉽다 (D-135)

실행기가 도는 PC 라면 아래 「처음 한 번」 의 4~7번(설정 파일 · PowerShell 명령)을 할 필요가 없다.

1. 실행기를 0.9.1 로 업데이트(화면 맨 위 「지금 업데이트」).
2. 실행기 화면 아래 작은 단추 줄의 **「카톡 휴면방」** → **열쇠** 「바꾸기」 → Vercel `KAKAO_AGENT_SECRET` 과 같은 값 → 저장.
3. 카톡을 켜고 「채팅」 탭에 둔 뒤 **「지금 한 번 읽기」** — 진행이 화면에 흐르고 「됐습니다 — N방」 이 나오면 된 것.
4. **「켜기」** + 「윈도우 켤 때 저절로 켜기」 **켬**.

설정 · 기록은 `pension-sync\state\kakao-idle*` 에 있다(업데이트가 안 덮는다). 아래 직접 설치와 **같이 쓰지 않는다** — 바로가기 이름이 같아 마지막에 넣은 쪽이 남는다.

## 처음 한 번 (서버 PC · 실행기 없이 따로)

1. **Supabase** 에서 `supabase-123-kakao-idle.sql` 을 돌립니다(표 둘).
2. **Vercel** 환경변수에 `KAKAO_AGENT_SECRET` = 아무 긴 글자(16자 이상)를 넣고 다시 배포합니다.
   - 확인: `https://motmot.co.kr/api/env-check` 에 `KAKAO_AGENT_SECRET` 이 「있음」.
3. 이 폴더(`tools/kakao-idle`)를 서버 PC 에 둡니다(저장소를 받아 두었으면 그 안의 것을 그대로).
4. `config.example.json` 을 **`config.json`** 으로 복사하고 `secret` 에 2번 값을 넣습니다.
   - `config.json` 은 저장소에 안 올라갑니다(.gitignore).
5. 카카오톡을 켜고 로그인한 뒤 **「채팅」 탭**을 열어 둡니다. 창은 최소화해도, 다른 창에 가려도 됩니다.
6. 시험 삼아 한 번 — PowerShell 을 열고 이 폴더에서:
   ```
   powershell -NoProfile -ExecutionPolicy Bypass -File collect.ps1 -Once -DryRun
   ```
   `last-scan.json` 이 생기고, `collect.log` 에 「찍음 — N장 · 끝까지 내림」 이 남으면 찍기 · 읽기는 되는 것입니다.
   그다음 `-DryRun` 을 빼고 한 번 더 돌리면 서버로 보냅니다(로그에 「보냄 — N방」).
7. 늘 돌게 하기:
   ```
   powershell -NoProfile -ExecutionPolicy Bypass -File install.ps1
   ```
   시작프로그램에 들어가 로그인할 때마다 켜집니다(창은 숨김). 빼려면 `install.ps1 -Uninstall`.

## 설정 (`config.json`)

| 칸 | 기본 | 뜻 |
|---|---|---|
| `endpoint` | `https://motmot.co.kr/api/push?op=kakao_push` | 보낼 곳 |
| `secret` | (필수) | Vercel `KAKAO_AGENT_SECRET` 과 같은 값 |
| `intervalMinutes` | 30 | 몇 분마다 찍나 |
| `wheelClicksPerPage` | 3 | 한 장 찍고 휠을 몇 칸 내리나 — 겹침이 모자라면 수집기가 알아서 줄인다 |
| `maxPages` | 80 | 최대 몇 장까지 내리나(방이 아주 많으면 늘린다) |
| `settleMs` | 450 | 내린 뒤 그림이 멈출 때까지 기다리는 시간 |
| `scrollMode` | `wheel` | 휠이 안 먹는 카톡 판이면 `vscroll` |
| `windowTitle` | `카카오톡` | 카톡 큰 창 이름 |

## 안 될 때

| 증상 (`collect.log` · 콘솔 탭 위 알림) | 까닭 · 할 일 |
|---|---|
| 카카오톡 창을 찾지 못했습니다 | 카톡이 꺼졌거나 로그아웃. 켜고 로그인 |
| 채팅 목록을 찾지 못했습니다 / 방을 하나도 못 읽었습니다 | 카톡이 「친구」 탭에 있음 → 「채팅」 탭으로. 창이 너무 좁으면 넓힘 |
| 화면이 비어 찍혔습니다 | PC 가 **잠김** · 화면 꺼짐. 서버 PC 는 잠금 화면 없이 로그인된 채로 둔다(절전 · 화면 보호기 잠금 끄기) |
| 한국어 글자 인식이 설치돼 있지 않습니다 | 관리자 PowerShell: `Add-WindowsCapability -Online -Name 'Language.OCR~~~ko-KR~0.0.1.0'` |
| 수집기 열쇠가 맞지 않습니다 | `config.json` 의 `secret` 과 Vercel 값이 다름 |
| 표가 없습니다 | `supabase-123-kakao-idle.sql` 미실행 |
| 콘솔에 「끝까지 내리지 못했습니다」 | 휠이 안 먹음 → `scrollMode: "vscroll"`, 또는 방이 많아 `maxPages` 를 늘림 |
| 콘솔에 「N시간째 소식이 없습니다」 | 서버 PC 꺼짐 · 수집기 꺼짐 → PC 확인 후 `install.ps1` 다시 |

## 알아 둘 것 (I-172)

- 글자 인식이라 방 이름이 **한두 글자 틀릴 수 있습니다**(특히 이모지 · 특수문자).
- 단체방 이름 뒤 **인원수는 떼어** 같은 방으로 묶습니다. 그래서 이름이 숫자로 끝나는 방(「동창회 2024」)은 숫자가 떼어 보입니다.
- **이름이 똑같은 방이 둘**이면 하나로 보입니다(최근 대화가 있는 쪽).
- 사람이 이 PC 를 만지는 중이면(1분 안 입력) 최대 10분 기다렸다 찍습니다. 찍는 동안 목록이 위아래로 움직입니다.
