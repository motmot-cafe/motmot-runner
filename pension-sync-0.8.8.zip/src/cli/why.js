#!/usr/bin/env node
/* 왜 이런가 — **어떤 날 어떤 방이 왜 그 상태인지**를 한 장으로 찍는다.

   왜 있나 (2026-09-17 소유자: "202호가 왜 마감인지 로그 뜯어보던지 이유 설명해"):
     판매현황의 `마감` 은 세 곳에서 온다 — 우리가 막았거나, 사장님이 파트너센터에서 직접 막았거나,
     손막음(`npm run hold`)이다. 로그는 **우리가 한 일**만 남기므로 나머지 둘은 로그에 아예 없다.
     그래서 "예약도 없는데 왜 마감이냐" 는 로그를 아무리 뒤져도 답이 안 나온다.
     이 명령은 그 날의 네 가지를 한 줄에 나란히 놓는다:
       우리 원장이 뭐라 하나 · 파트너센터가 뭐라 하나 · 우리가 막았다고 기억하나 · 그래서 다음 주기에 뭘 하나

     npm run why -- yeogi 2026-10-04            그 하루
     npm run why -- yeogi 2026-10-04 --days 3   그 날부터 사흘
     npm run why -- yeogi                       오늘
     npm run why -- yanolja 2026-09-28 --days 34 --diff
                                                어긋난 칸만(v3.1 — 10월 말까지 한 번에 대 보기)

   ★ v3.1: 채널에 객실 매핑이 아직 없으면(야놀자) **이름으로 맞춰 본다** — 파트너센터 객실명의 괄호를 떼고 띄어쓰기를 뺀 것이
     우리 객실의 손님용 이름(public_name)·이름과 **하나씩만** 같을 때만 짝짓는다. 이 짝은 이 명령의 표시에만 쓰고,
     확정은 함께 찍는 SQL 을 사장님이 돌려서 한다(쓰기는 여전히 매핑표만 본다).

   읽기만 한다. 막지도, 열지도, 저장하지도 않는다.
   예약자 이름·연락처·금액은 한 글자도 안 찍는다(BR-020) — 그대로 붙여 넣어도 된다. */
import { loadEnvFile, loadConfig } from '../lib/config.js';
import { createLogger, redactSecret, scrubSecrets } from '../lib/log.js';
import { ChannelSession } from '../browser/session.js';
import { loadSpec } from '../adapters/spec.js';
import { JsonAdapter } from '../adapters/json-adapter.js';
import { DashboardClient } from '../dashboard/client.js';
import { LocalState } from '../engine/state.js';
import { heldByOther } from '../lib/lock.js';
import { blockedDates, closedByRate } from '../engine/calendar.js';
import { roomLabeler } from '../engine/room-label.js';
import { addDays, eachDate, isYmd, todayKst } from '../lib/kst.js';
import { handoff, handoffNote } from '../lib/handoff.js';

/** 판매현황 한 칸을 사람 말로. */
export const CELL_WORD = { open: '판매중', closed: '마감', sold: '예약완료', unknown: '모르는 문구' };

/** 채널 코드 → 사장님이 부르는 이름. 모르면 코드 그대로. */
export const CHANNEL_WORD = { yeogi: '여기어때', yanolja: '야놀자', naver: '네이버', airbnb: '에어비앤비' };
export const channelWord = (code) => CHANNEL_WORD[code] || String(code || '채널');

/**
 * --diff 에서 보일 칸인가 — 사람이 볼 일이 있는 칸만 짧은 표시를 돌려준다(없으면 null). 순수 계산.
 *   원장 예약 + 채널 판매중 → 이중판매 위험 / 채널 예약 + 원장 비었다 → 원장에 없는 채널 예약(붙여넣기·유입 필요)
 *   원장 비었다 + 마감(손막음 아님) → 팔 수 있는데 막혀 있다 / 못 알아본 문구·없는 날 → 확인 필요
 */
export function attention({ want, cell, held }) {
  if (cell === undefined) return '판매현황에 없다';
  if (cell === 'unknown') return '문구 확인 필요';
  if (cell === 'sold') return want ? null : '원장에 없는 채널 예약';
  if (want) return cell === 'open' ? '이중판매 위험' : null;
  if (cell === 'closed' && !held) return '비었는데 막혀 있다';
  return null;
}

/** 파트너센터 객실명 → 맞춰 볼 글자. 괄호 안(부대시설 설명)을 떼고 띄어쓰기를 뺀다. '펜션 더블룸A(개별바베큐)' → '펜션더블룸a' */
export function roomNameKey(name) {
  return String(name ?? '').replace(/\([^)]*\)/g, '').replace(/\s+/g, '').toLowerCase();
}

/**
 * 매핑이 없는 채널을 **이름으로만** 짝짓는다(표시용). 한쪽에 같은 글자가 둘 이상이면 그 이름은 짝짓지 않는다 — 추측하지 않는다.
 * @param {{roomKey:string,name:string}[]} rooms 파트너센터 객실
 * @param {object[]} resources 우리 객실 [{id, name, public_name}]
 * @returns {{pairs: Map<string,string[]>, unmatched: {roomKey:string,name:string}[]}}
 */
export function pairsByName(rooms = [], resources = []) {
  const ours = new Map();
  for (const r of resources || []) {
    const keys = new Set([roomNameKey(r.public_name), roomNameKey(r.name)].filter(Boolean));
    for (const k of keys) {
      if (!ours.has(k)) ours.set(k, new Set());
      ours.get(k).add(String(r.id));
    }
  }
  const theirs = new Map();
  for (const room of rooms || []) {
    const k = roomNameKey(room.name);
    if (!k) continue;
    theirs.set(k, (theirs.get(k) || 0) + 1);
  }
  const pairs = new Map();
  const unmatched = [];
  const used = new Set();
  for (const room of rooms || []) {
    const k = roomNameKey(room.name);
    const ids = ours.get(k);
    if (!k || !ids || ids.size !== 1 || theirs.get(k) !== 1) { unmatched.push(room); continue; }
    const id = [...ids][0];
    if (used.has(id)) { unmatched.push(room); continue; }
    used.add(id);
    pairs.set(id, [String(room.roomKey)]);
  }
  return { pairs, unmatched };
}

/**
 * 대 볼 짝을 정한다(표시용) — 매핑표가 이미 있으면 그것이 먼저다. 순수 계산.
 *   ① 매핑 줄의 열쇠가 파트너센터 객실 번호(roomKey)면 그대로 쓴다.
 *   ② 번호가 아니라 **객실 이름** 줄뿐이면(야놀자 붙여넣기가 만든 줄 — 서버 mapRoom 이 이름으로 짝짓는다) 그 이름으로 파트너센터 객실을 찾아
 *      번호로 바꿔 대 본다. 이름 줄은 그대로 둔다(붙여넣기용) — 번호 줄을 **옆에 더하는** SQL 을 찍는다(I-112 병렬 줄과 같은 모양).
 *   ③ 매핑 줄이 아예 없는 객실은 pairsByName 으로 맞춰 본다.
 * @returns {{pairs: Map<string,string[]>, add: Map<string,string[]>, unmatched: object[]}} add = SQL 로 더할 (객실 → 번호) 짝
 */
export function resolvePairs({ mapped = new Map(), rooms = [], resources = [] }) {
  const keySet = new Set(rooms.map((r) => String(r.roomKey)));
  const byNameKey = new Map();
  for (const r of rooms) {
    const k = roomNameKey(r.name);
    if (!k) continue;
    byNameKey.set(k, byNameKey.has(k) ? null : r);   // 같은 이름이 둘이면 null — 추측하지 않는다
  }
  const pairs = new Map();
  const add = new Map();
  const used = new Set();
  for (const [rid, keys] of mapped) {
    const direct = keys.map(String).filter((k) => keySet.has(k));
    if (direct.length) { pairs.set(rid, direct); direct.forEach((k) => used.add(k)); continue; }
    const hits = [...new Set(keys.map((k) => byNameKey.get(roomNameKey(k))).filter(Boolean))];
    if (hits.length === 1 && !used.has(String(hits[0].roomKey))) {
      const k = String(hits[0].roomKey);
      pairs.set(rid, [k]); add.set(rid, [k]); used.add(k);
    }
  }
  const restRooms = rooms.filter((r) => !used.has(String(r.roomKey)));
  const restRes = (resources || []).filter((r) => !mapped.has(String(r.id)) && !pairs.has(String(r.id)));
  const byName = pairsByName(restRooms, restRes);
  for (const [rid, keys] of byName.pairs) { pairs.set(rid, keys); add.set(rid, keys); }
  return { pairs, add, unmatched: byName.unmatched };
}

/** 이름으로 맞춘 짝을 확정하는 SQL — 사장님이 Supabase SQL 편집기에서 돌린다. 이미 있으면 건너뛴다. */
export function mappingSql(channel, pairs, nameOf = new Map(), propertyId = 'motmot') {
  const q = (v) => `'${String(v).replace(/'/g, "''")}'`;
  const rows = [];
  for (const [resourceId, keys] of pairs) {
    for (const k of keys) rows.push(`  (${q(propertyId)}, ${q(channel)}, ${q(k)}, ${q(resourceId)}, true)  -- ${String(nameOf.get(String(k)) || '').replace(/[\r\n]/g, ' ')}`);
  }
  if (!rows.length) return [];
  return [
    'insert into public.channel_room_map (property_id, channel_code, channel_room_key, resource_id, active) values',
    rows.map((l, i) => (i < rows.length - 1 ? l.replace(/\)  --/, '),  --') : l)).join('\n'),
    'on conflict (property_id, channel_code, channel_room_key) do nothing;',
  ];
}

/** 그 방 그 날에 손막음이 걸려 있나. holds 는 `channel|roomKey|from` 로 들어 있다(state.js). */
export function heldOn(holds, channel, roomKey, date) {
  for (const [k, h] of Object.entries(holds || {})) {
    if (!k.startsWith(`${channel}|${roomKey}|`)) continue;
    if (h && h.from <= date && date < h.to) return h;
  }
  return null;
}

/**
 * 한 칸의 판정 — 순수 계산이라 그대로 시험한다.
 * @param {object} o
 *   want        우리 원장이 "막아야 할 날" 이라 했나
 *   rateClosed  그 막을 이유가 만실(rate_calendar.closed)인가
 *   cell        파트너센터 판매현황 상태 (open|closed|sold|unknown|undefined)
 *   closedByUs  우리가 막았다고 기억하나
 *   held        손막음이 걸려 있나
 * @returns {{verdict:string, next:string}} verdict = 왜 그런가 · next = 다음 주기에 무엇을 하나
 */
export function judgeCell({ want, rateClosed, cell, closedByUs, held, chan = '여기어때' }) {
  if (cell === undefined) return { verdict: '판매현황에 이 날이 없다 — 매핑이나 판매기간을 볼 것(I-021)', next: '아무것도 안 한다' };
  if (cell === 'sold') return { verdict: `${chan}에 예약이 들어 있다`, next: '손대지 않는다 — 채널 예약이 든 날은 어떤 경우에도 안 건드린다(BR-018)' };
  if (cell === 'unknown') return { verdict: '상태 문구를 못 알아봤다', next: '건드리지 않는다(BR-015)' };
  if (want) {
    const because = rateClosed ? '원장에 만실이 걸려 있다' : '원장에 예약이 있다';
    return cell === 'closed'
      ? { verdict: `${because} — 막혀 있는 것이 맞다`, next: '그대로 둔다' }
      : { verdict: `${because} — 아직 열려 있다`, next: '다음 주기에 막는다' };
  }
  if (cell === 'open') return { verdict: '원장이 비어 있고 팔고 있다', next: '그대로 둔다' };
  /* ★ 사유(`held.why`)는 **찍지 않는다.** 사장님이 "김훈 객실변경" 처럼 손님 이름을 적어 두는 자리라
     이 출력(붙여 넣어도 된다고 말하는 글)에 실리면 안 된다(BR-020). 사유는 `npm run hold -- list` 에서 본다. */
  if (held) return { verdict: '손막음이다 — 사유는 npm run hold -- list 에서 본다', next: '사람이 풀기 전까지 안 연다 (npm run hold -- release)' };
  if (closedByUs) return { verdict: '우리가 막았는데 원장이 비었다', next: '다음 주기에 원장을 두 번 읽고 다시 연다' };
  return {
    verdict: '우리가 막은 것이 아니다 — 파트너센터에서 직접 막혔거나, 막은 기억이 지워졌다',
    next: '열지 않는다(BR-018) — 팔려면 파트너센터에서 직접 열어야 한다',
  };
}

const pad = (s, n) => String(s ?? '').padEnd(n - [...String(s ?? '')].filter((c) => /[가-힣]/.test(c)).length);

export async function whyCli(argv = process.argv.slice(2), { out = console.log } = {}) {
  loadEnvFile();
  const cfg = loadConfig();
  const bare = argv.filter((a) => !a.startsWith('--'));
  const channel = bare.find((a) => !isYmd(a)) || cfg.channels[0];
  const from = bare.find((a) => isYmd(a)) || todayKst();
  const at = argv.indexOf('--days');
  const days = at >= 0 && argv[at + 1] ? Math.max(1, Number(argv[at + 1])) : 1;
  /* ★ 틀린 인자를 조용히 넘기지 않는다. 날짜를 잘못 적으면 '오늘' 을 조사해 놓고 사장님은
     그 날을 본 줄 안다 — 틀린 답을 자신 있게 주는 것이 가장 나쁘다(2026-09-18 검토). */
  if (!Number.isFinite(days)) { out(`✗ --days 는 숫자여야 합니다 — 받은 값: ${argv[at + 1]}`); return 2; }
  const stray = bare.filter((a) => a !== channel && !isYmd(a));
  if (stray.length) { out(`✗ 날짜는 2026-10-04 꼴로 적어 주세요 — 못 알아본 값: ${stray.join(', ')}`); return 2; }
  const to = addDays(from, days);
  const headed = argv.includes('--headed');
  const diffOnly = argv.includes('--diff');

  const log = createLogger('왜', { level: cfg.logLevel });
  const spec = loadSpec(channel);
  const lines = [];
  const say = (s) => { lines.push(s); out(s); };
  const finish = (code) => {
    say('');
    say('이 출력에는 예약자 이름·연락처·금액이 들어 있지 않다 — 그대로 붙여 넣어도 된다.');
    for (const line of handoffNote(handoff(`why-${channel}-${from}`, lines.join('\n'), { dir: cfg.paths.artifactsDir }))) out(line);
    return code;
  };

  const chan = channelWord(channel);
  say(`# ${spec.name || channel} — ${from}${days > 1 ? ` ~ ${addDays(to, -1)}` : ''} 이 왜 이런가 (읽기만 했다)${diffOnly ? ' — 어긋난 칸만' : ''}`);

  /* ★ 상주가 돌고 있으면 파트너센터를 같이 못 연다 — 브라우저 프로필이 하나뿐이라 한쪽이 실패한다(I-064).
     자물쇠를 **잡지는 않는다**(잡으면 상주가 다음에 못 뜬다). 보기만 하고 물러난다. */
  const running = heldByOther(cfg.paths.stateDir);
  if (running.held) {
    say(`✗ 실행기가 지금 돌고 있습니다(pid ${running.pid}) — 전원을 잠깐 끄고 다시 돌려 주세요.`);
    say('  (파트너센터 로그인 자리가 하나라, 둘이 같이 열면 한쪽이 실패합니다)');
    return finish(2);
  }

  const dashboard = new DashboardClient(cfg.dashboard, { log });
  await dashboard.init();
  let pairs = new Map();
  for (const m of await dashboard.roomMap(channel)) {
    if (!pairs.has(m.resource_id)) pairs.set(m.resource_id, []);
    pairs.get(m.resource_id).push(m.channel_room_key);
  }
  const resources = await dashboard.resources().catch(() => []);
  /* v3.1: 매핑이 없으면 파트너센터 객실 목록을 읽은 뒤 이름으로 맞춰 본다(아래). 그래도 없으면 그때 멈춘다. */
  const mapped = pairs.size > 0;
  let label = roomLabeler(resources, pairs);

  const book = await dashboard.bookings(from, to);
  if (!book.ok) { say(`✗ 원장을 못 읽었다 — ${book.why}`); return finish(1); }
  const rateCal = await dashboard.rateCalendar(from, to).catch(() => []);
  const want = blockedDates({ bookings: book.rows, cols: book.cols, rateCal, from, to });
  const rate = closedByRate({ rateCal, from, to });

  const session = new ChannelSession({ channel, stateDir: cfg.paths.stateDir, secret: cfg.stateSecret, headless: !headed, browser: cfg.browser, log });
  const page = await session.open({ headless: !headed });
  const creds = session.loadCreds();
  if (creds) { redactSecret(creds.password); redactSecret(creds.loginId); }
  const adapter = new JsonAdapter({ spec, page, log, artifactsDir: cfg.paths.artifactsDir, creds });
  const state = new LocalState(cfg.paths.stateDir);
  const holds = state.holds();

  try {
    if (!(await adapter.ensureLoggedIn())) { say(`✗ 로그인이 안 돼 있다 — 먼저: npm run pair -- ${channel}`); return finish(1); }
    /* 상품 이름은 파트너센터에만 있다(매핑표에는 코드뿐이다). 사장님이 보는 화면의 이름과
       맞춰 보려면 이것이 있어야 한다 — "펜션 더블룸C 가 어느 방이냐" 가 이 명령의 절반이다. */
    let roomsErr = null;
    const rooms = await adapter.listRooms().catch((e) => { roomsErr = e; return []; });
    const nameOf = new Map(rooms.map((r) => [String(r.roomKey), r.name]));
    /* v3.1: 매핑 줄이 번호가 아니라 이름뿐이거나(야놀자 붙여넣기 줄) 아예 없으면, 파트너센터 객실 이름으로 번호를 찾아 대 본다(표시용). */
    const resolved = resolvePairs({ mapped: pairs, rooms, resources });
    pairs = resolved.pairs;
    label = roomLabeler(resources, pairs);
    if (!pairs.size) {
      say(`✗ 대 볼 객실이 없다 — 매핑 줄 ${mapped ? '은 있지만 파트너센터 객실과 안 맞고' : '이 없고'}, 이름으로도 못 맞췄다. 파트너센터 객실 ${rooms.length}개` +
        (rooms.length ? `: ${rooms.map((r) => `${r.name}(${r.roomKey})`).join(', ')}`
          : ` (객실 목록을 못 읽었다${roomsErr ? ` — ${scrubSecrets(roomsErr.message).slice(0, 400)}` : ''})`));
      return finish(1);
    }
    if (resolved.add.size) {
      say(`※ ${chan} 객실 ${resolved.add.size}개는 매핑표에 파트너센터 번호 줄이 없어 **이름으로 맞춰 봤다**. 아래 표는 이 짝으로 대 본 것이다 — 확정은 맨 아래 SQL.`);
    }
    const cells = await adapter.readAvailability({ from, to });
    const byKey = new Map();
    for (const c of cells) {
      if (!byKey.has(c.roomKey)) byKey.set(c.roomKey, new Map());
      byKey.get(c.roomKey).set(c.date, c.state);
    }

    /* 못 알아본 문구는 **정해진 값처럼 생긴 것만** 그대로 보여 준다(SOLD_OUT·예약완료 같은 것). 그 밖은 글자 수만. */
    const rawOf = new Map();
    for (const c of cells) {
      if (c.state !== 'unknown') continue;
      const t = String(c.raw?.state ?? '').trim();
      const shown = /^[A-Z][A-Z0-9_]{1,30}$/.test(t) || /^[가-힣 ]{1,8}$/.test(t) ? t : `${t.length}자`;
      rawOf.set(`${c.roomKey}|${c.date}`, shown);
    }
    const tally = new Map();
    for (const date of eachDate(from, to)) {
      const rows = [];
      for (const [resourceId, keys] of pairs) {
        for (const roomKey of keys) {
          const cell = (byKey.get(String(roomKey)) || new Map()).get(date);
          const w = (want.get(resourceId) || new Set()).has(date);
          const rateClosed = (rate.get(resourceId) || new Set()).has(date);
          const held = heldOn(holds, channel, roomKey, date);
          const flag = attention({ want: w, cell, held });
          if (flag) tally.set(flag, (tally.get(flag) || 0) + 1);
          if (diffOnly && !flag) continue;
          const j = judgeCell({ want: w, rateClosed, cell, closedByUs: state.wasClosedByUs(channel, roomKey, date), held, chan });
          const word = cell === 'unknown' ? `모르는 문구(${rawOf.get(`${roomKey}|${date}`) || '?'})` : (CELL_WORD[cell] || '없다');
          rows.push(`  ${pad(label.forResource(resourceId), 14)}${pad(`${nameOf.get(String(roomKey)) || '?'}(${roomKey})`, 22)}` +
            `${pad(w ? (rateClosed ? '만실' : '예약') : '비었다', 8)}${pad(word, 10)}${flag ? `[${flag}] ` : ''}${j.verdict}`);
          rows.push(`  ${' '.repeat(54)}→ ${j.next}`);
        }
      }
      if (!rows.length) continue;
      say('');
      say(`## ${date}`);
      say(`  ${pad('우리 객실', 14)}${pad(`${chan} 상품`, 22)}${pad('원장', 8)}${pad('판매현황', 10)}판정`);
      for (const l of rows) say(l);
    }
    say('');
    say(tally.size
      ? `# 어긋난 칸 ${[...tally.values()].reduce((a, b) => a + b, 0)}개 — ${[...tally].map(([k, n]) => `${k} ${n}`).join(' · ')}`
      : `# 어긋난 칸 없음 — ${days}일 × ${[...pairs.values()].flat().length}개 객실이 원장과 맞다`);

    const unmapped = rooms.filter((r) => ![...pairs.values()].flat().some((k) => String(k) === String(r.roomKey)));
    if (unmapped.length) say(`\n매핑 안 된 채널 상품 ${unmapped.length}개 — ${unmapped.map((r) => `${r.name}(${r.roomKey})`).join(', ')} (이 상품들은 우리가 아예 안 건드린다)`);
    if (resolved.add.size) {
      const sql = mappingSql(channel, resolved.add, nameOf, cfg.dashboard?.propertyId || 'motmot');
      say('');
      say(`# ${chan} 객실 매핑 확정 SQL — 위 짝이 맞으면 Supabase SQL 편집기에서 돌린다(이미 있으면 건너뛴다)`);
      for (const l of sql) say(l);
    }
    return finish(0);
  } catch (e) {
    say(`✗ ${scrubSecrets(e.message)}`);
    return finish(1);
  } finally {
    await session.close().catch(() => {});
  }
}

/* ★ 다른 CLI 와 **같은 방식**으로 검사한다. `import.meta.url` 은 URL(`file:///C:/...`)이고
   `process.argv[1]` 은 OS 경로(`C:\...`)라, 윈도우에서는 둘이 절대 같지 않아
   `왜.cmd`·`npm run why` 가 아무 말도 없이 끝났다(2026-09-18 검토). */
if (process.argv[1] && /cli[\\/]why\.js$/.test(process.argv[1])) {
  whyCli().then((c) => process.exit(c)).catch((e) => { console.error(scrubSecrets(e.message)); process.exit(1); });
}
