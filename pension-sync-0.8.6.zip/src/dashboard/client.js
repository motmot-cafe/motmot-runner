/* 대시보드(motmot.co.kr) 와 말하는 유일한 창구.
   - 표 읽기/쓰기는 supabase-js 로, 판단이 필요한 동작(paste·reconcile·todo_done·inventory)은 서버 /api/ota 로 (BR-001).
   - 예약표(bookings) 는 절대 직접 쓰지 않는다. manual_close_todos.status 도 직접 바꾸지 않는다(BR-003).
   - 계약의 근거는 docs/DOMAIN_KNOWLEDGE.md. 서버 표 스키마는 추정이 섞여 있어, 없는 열은 빼고 다시 넣는다. */
import { createClient } from '@supabase/supabase-js';
import { createLogger } from '../lib/log.js';
import { addDays, nowIso } from '../lib/kst.js';
import { deadline } from '../lib/deadline.js';

const HEARTBEAT_CONFLICT = 'property_id,channel_code';

function iso(d) {
  return d instanceof Date ? d.toISOString() : new Date(d).toISOString();
}

/** 콘솔과 같은 기준으로 "채널에 내놓는 객실" 만 남긴다(BR-009). */
export function channelTargetRooms(resources) {
  return (resources || []).filter((r) => r.kind === 'room' && r.active !== false && !r.special && r.audience !== 'group');
}

/* 예약표(bookings) 의 열 이름 후보. 대시보드 서버가 비공개라 실제 이름을 모르므로
   한 줄을 받아 이 목록으로 알아본다. 앞의 것이 우선이다. */
const BOOKING_COLS = {
  resourceId: ['resource_id', 'room_id', 'resourceId', 'roomId'],
  /* ★ 실계정의 bookings 는 `starts_at`/`ends_at` 이었다(2026-09-09 실측). 이름이 없어 캘린더 대조가
       통째로 건너뛰어졌다 — 그 동안 대시보드 예약이 여기어때에 반영되지 않았다(I-023 해소). */
  checkIn: ['check_in', 'checkin', 'check_in_date', 'start_date', 'from_date', 'stay_from', 'starts_at', 'start_at', 'checkIn', 'startDate', 'fromDate', 'startsAt'],
  checkOut: ['check_out', 'checkout', 'check_out_date', 'end_date', 'to_date', 'stay_to', 'ends_at', 'end_at', 'checkOut', 'endDate', 'toDate', 'endsAt'],
  status: ['status', 'state', 'booking_status', 'reservation_status'],
  /* ★ 예약자 이름. **화면에 보여 주려고만** 읽는다 — 막을 날을 정하는 데는 안 쓴다.
       '풀빌라 101호 품절처리' 만 보면 어느 예약 때문인지 알 수가 없다(2026-09-16 소유자).
       ★ 그냥 `name` 은 안 본다 — 예약표에 객실 이름이 `name` 으로 들어 있는 판이 있어서,
         그것을 예약자로 읽으면 화면이 조용히 거짓말을 한다. */
  guestName: ['guest_name', 'guestName', 'customer_name', 'booker_name', 'reserver_name', 'visitor_name', 'guest', 'customer', '예약자'],
  /* ★ 단체 예약은 **단체명만** 적는다(2026-09-16 소유자). 단체 하나에 예약이 여러 줄이라
       개인 이름을 다 늘어놓으면 화면이 이름 목록이 된다 — 그것도 손님 정보다.
       실계정 예약표에는 `group_id` 만 있고 단체명 칸은 없었다(2026-09-09 실측). 이름 칸이 생기면
       그것을 쓰고, 없으면 `단체` 라고만 적는다 — 개인 이름으로 대신하지 않는다. */
  groupName: ['group_name', 'groupName', 'org_name', 'organization', 'company_name', 'company', 'team_name', '단체명'],
  groupId: ['group_id', 'groupId'],
  /* 상태 칸을 못 읽었을 때만 보는 취소 흔적. 실계정에 `cancel_by`·`cancel_reason` 이 있다. */
  cancelBy: ['cancel_by', 'canceled_by', 'cancelled_by'],
  cancelReason: ['cancel_reason', 'canceled_reason', 'cancelled_reason'],
  propertyId: ['property_id'],
  /* ★ 아래는 **화면의 '방금 한 일' 에 예약 상태를 붙이려고만** 읽는다(bookingStatusLabel) — 막을 날·열 날을
       정하는 데는 한 칸도 안 쓴다(2026-09-23 사장님: "이런거도 구분할 수 있으면 좋을 듯 — 결제완료, 임시품절,
       결제취소 등"). 사장님이 시험으로 넣은 예약이 '품절처리 · 이름' 으로만 찍혀 진짜 손님과 구분이 안 됐다.
       실계정 bookings 에 paid_at·hold_until·kind·channel·memo·cancelled_at 이 있다. 칸이 없는 판이면
       라벨이 비어 지금과 똑같이 보일 뿐이다. */
  paidAt: ['paid_at', 'paidAt'],
  holdUntil: ['hold_until', 'holdUntil'],
  kind: ['kind', 'booking_kind'],
  channel: ['channel', 'channel_code'],
  memo: ['memo'],
  cancelledAt: ['cancelled_at', 'canceled_at'],
};

/** 예약표 한 줄을 보고 어느 열이 무엇인지 정한다. 못 정한 것은 undefined. */
export function detectBookingColumns(row) {
  const out = {};
  for (const [logical, names] of Object.entries(BOOKING_COLS)) {
    out[logical] = names.find((n) => Object.prototype.hasOwnProperty.call(row || {}, n));
  }
  return out;
}

/** 예약이 살아 있는가 — 취소·거절·노쇼는 방을 막지 않는다. */
export function bookingIsLive(row, cols) {
  const c = cols || {};
  const s = String((c.status ? row[c.status] : row.status) ?? '').trim().toLowerCase();
  if (s) return !/취소|거절|노쇼|환불|cancel|reject|no.?show|refund|void|expired/.test(s);
  /* 상태 칸이 없거나 비었을 때만 취소 흔적을 본다 — 취소한 사람·사유가 적혀 있으면 끝난 예약이다.
     둘 다 없으면 살아 있는 것으로 본다(막는 쪽이 안전하다 — 잘못 열면 그 밤이 곧바로 이중으로 팔린다). */
  const marked = (k) => c[k] && row[c[k]] != null && String(row[c[k]]).trim() !== '';
  return !(marked('cancelBy') || marked('cancelReason'));
}

/* 예약 상태를 화면에 뭐라고 붙일까 — '결제완료'·'확정'·'임시품절'·'차단'·'차단해제'·'결제취소'·'예약취소', 시험 예약이면 앞에 '테스트·'.
   왜(2026-09-23 사장님: "이런거도 구분할 수 있으면 좋을 듯 — 결제완료, 임시품절, 결제취소 등"):
     사장님이 시험으로 만든 예약(가예약)이 '품절처리 · 이름' 으로만 찍혀 진짜 손님과 구분이 안 됐다.
   ★ **표시 전용이다.** 막을지·열지는 bookingIsLive 가 정한다 — 이 함수는 그 판정을 읽기만 하고 바꾸지 않는다.
     여기 결과로 무엇을 막거나 여는 코드를 쓰면 안 된다.
   ★ **던지지 않는다.** 어떤 줄(null 칸·숫자 status·이상한 날짜)이 와도 '' 로 떨어진다 — 라벨 하나 때문에
     캘린더 대조가 통째로 멈추면 막아야 할 밤을 못 막는다.
   ★ **모르면 '' 다.** 틀린 라벨(진짜 손님에게 '임시품절', 미결제에 '결제완료')이 빈 라벨보다 나쁘다 — 추측하지 않는다.
   ⚠ 채널 예약은 paid_at 이 **항상 NULL** 이다(돈을 채널이 받는다). paid_at 으로만 가르면 여기어때·야놀자 예약이
     전부 '확정'(미결제처럼)으로 찍힌다 — 돈을 받아 정산해 주는 채널(PAYING_CHANNELS)이면 결제완료로 본다.
     ★ (2026-09-23 검토) 'direct 가 아니면 전부' 가 아니다 — naver·ddangyanolja 는 현장 결제일 수 있어
       paid_at 으로 가른다. 대시보드가 수수료 떼고 정산해 준다고 보는 채널(COMMISSION_CHANNELS)과 같게 둔다.
   ⚠ 메모 글은 절대 돌려주지 않는다 — '★테스트' 로 시작하는지만 본다(손님 정보일 수 있다, BR-020).
   nowMs 는 지금은 라벨을 바꾸지 않는다 — hold_until 이 지난 가예약도 서버가 풀기 전까지는 방을 막고 있으므로
   '임시품절' 그대로 둔다. 자리만 잡아 둔다(시각에 따라 달라지는 표시를 더할 때 시험에서 고정하려고). */
export function bookingStatusLabel(row, cols, nowMs = Date.now()) {
  void nowMs;
  try {
    return statusLabelOf(row, cols || {});
  } catch {
    return '';
  }
}

/* 칸 값을 글자로 — **글자일 때만** 믿는다. 숫자·객체·null 은 '' (모르는 값으로 본다). */
function textOf(row, col) {
  if (!col) return '';
  const v = row[col];
  return typeof v === 'string' ? v.trim() : '';
}

/* 값이 "있다" — 비지 않은 글자, 유한한 숫자, 올바른 Date 만. 그 밖(객체·NaN·빈 글자)은 없는 것으로 본다. */
function present(row, col) {
  if (!col) return false;
  const v = row[col];
  if (typeof v === 'string') return v.trim() !== '';
  if (typeof v === 'number') return Number.isFinite(v);
  if (v instanceof Date) return !Number.isNaN(v.getTime());
  return false;
}

/* 돈을 **채널이 받아** 수수료 떼고 정산해 주는 채널 — 대시보드 api/_ota/core/stats.mjs COMMISSION_CHANNELS 와
   admin.html CH_EXTERNAL 이 같은 목록이다. 여기 없는 채널(naver·ddangyanolja…)은 돈을 누가 받았는지 몰라
   paid_at 으로만 가른다 — 현장 결제 예약에 '결제완료' 를 붙이면 거짓말이다. */
const PAYING_CHANNELS = new Set(['yeogi', 'yanolja', 'airbnb']);

/* 결제 흐름이 스스로 끝냈다는 흔적 — 대시보드 pay.mjs·book.mjs 가 cancel_by 'us' 로 취소할 때 적는 사유들
   ('결제 시간 초과'·'입금 기한 초과'·'결제 승인 실패'·'같이 예약한 객실 중 하나가 만료되어…'·'가상계좌 발급 실패…',
   관리자 '입금 미확인'). ⚠ 사유 글은 **맞는지 보기만** 하고 돌려주지 않는다. */
const PAY_FLOW_REASON = /결제|입금|승인|만료|시간 ?초과|기한|같이|계좌|선점/;

function statusLabelOf(row, c) {
  if (!row || typeof row !== 'object') return '';
  /* 상태 칸을 못 알아본 판에서는 아무것도 붙이지 않는다 — 그 판의 다른 칸 뜻도 믿을 수 없다. */
  if (!c.status) return '';
  let base = '';
  const ch = textOf(row, c.channel).toLowerCase();
  const direct = !ch || ch === 'direct';                   // 채널 칸이 비면 직접 예약으로 본다
  if (textOf(row, c.kind).toLowerCase() === 'block') {
    /* 차단(사장님이 막아 둔 줄)은 status 가 confirmed 여도 손님 예약이 아니다 — 결제완료로 붙이면 거짓말이다.
       ★ (2026-09-23 검토) 취소된 차단은 '차단해제' — '다시 열기 · 차단' 은 거꾸로 읽힌다(차단을 풀어서 연 것이다). */
    base = bookingIsLive(row, c) ? '차단' : '차단해제';
  } else if (!bookingIsLive(row, c)) {
    /* 결제 흐름이 스스로 끝낸 것(시간 초과·승인 실패 — cancel_by us, 돈 기록 없음)만 '결제취소'.
       손님·채널·관리자 취소, 결제 뒤 환불은 '예약취소'. paid_at 칸을 모르면 결제취소라고 단정하지 않는다.
       ★ (2026-09-23 검토) 'us + paid_at 없음' 만으로는 모자란다 — 채널 예약은 paid_at 이 늘 비어 있고,
         전화 예약도 돈 기록이 없다. 관리자가 그런 예약을 취소하며 'us' 를 고르면 결제취소로 찍혔다.
         그래서 **직접 예약이고 결제 흐름 흔적(가예약 기한·결제/입금 사유)이 있을 때만** 결제취소다. */
    const byUs = textOf(row, c.cancelBy).toLowerCase() === 'us';
    const payFlow = present(row, c.holdUntil) || PAY_FLOW_REASON.test(textOf(row, c.cancelReason));
    base = byUs && direct && payFlow && c.paidAt && !present(row, c.paidAt) ? '결제취소' : '예약취소';
  } else {
    const s = typeof row[c.status] === 'string' ? row[c.status].trim().toLowerCase() : '';
    /* 대기·보류를 먼저 본다 — '결제대기' 는 '결제' 가 들어 있어도 가예약이다. */
    if (!s) base = '';
    else if (/tentative|pending|hold|wait|가예약|임시|대기|보류/.test(s)) {
      /* ⚠ (2026-09-23 검토) 채널 줄이 가예약으로 남는 길이 있다 — 관리자 새 예약 창에서 채널 yeogi·'가예약(입금대기)'
           로 넣은 줄을 채널 예약이 나중에 이어받으면 상태는 안 바뀐다(ota.mjs 갱신은 날짜·이름·인원만).
           진짜 채널 손님에게 '임시품절' 은 거짓말이다 — 채널 줄의 가예약은 단정하지 않는다(''). */
      base = direct ? '임시품절' : '';
    }
    else if (/^paid$|결제완료/.test(s)) base = '결제완료';   // 상태 글자 자체가 결제를 말한다
    else if (/^(confirmed?|checked[_ -]?in|checked[_ -]?out|completed?)$|확정|완료|입실|퇴실/.test(s)) {
      if (PAYING_CHANNELS.has(ch)) base = '결제완료';       // 채널이 돈을 받았다(paid_at 은 늘 비어 있다)
      else if (present(row, c.paidAt)) base = '결제완료';
      else base = '확정';                                  // 전화·현장·관리자 확정, 돈을 누가 받았는지 모르는 채널
    }
  }
  /* 사장님 시험 예약 — 메모 앞머리만 본다. 상태를 못 읽었어도 '테스트' 인 것은 확실하므로 그것만 적는다. */
  if (textOf(row, c.memo).startsWith('★테스트')) return base ? `테스트·${base}` : '테스트';
  return base;
}

/** PostgREST 오류에서 "없는 열" 이름을 뽑는다. 못 뽑으면 null. */
export function missingColumnFrom(message) {
  const m = String(message || '').match(/Could not find the '([A-Za-z0-9_]+)' column|column "?([A-Za-z0-9_]+)"? (?:of relation "[^"]+" )?does not exist/i);
  return m ? (m[1] || m[2]) : null;
}

export class DashboardClient {
  /**
   * @param {object} opts  cfg.dashboard (supabaseUrl, anonKey, email, password, serviceRoleKey, writeMode, apiBase, propertyId)
   * @param {object} deps  테스트용 주입: log, fetchImpl, createClient, auth(세션 클라이언트), db(쓰기 클라이언트)
   */
  constructor(opts, deps = {}) {
    this.opts = { ...opts };
    this.log = deps.log || createLogger('dashboard');
    this.fetch = deps.fetchImpl || ((...a) => globalThis.fetch(...a));
    /* ★ supabase 클라이언트가 쓰는 fetch 에 시간제한을 건다. 이 한 줄이 표 읽기·쓰기·
         생존 신호·토큰 갱신까지 전부를 덮는다 — 어디 한 곳이라도 안 끝나면 줄이 통째로
         멈춘다(2026-09-14, 76분). 부르는 쪽이 이미 신호를 줬으면 그것을 존중한다. */
    this.timedFetch = (u, init = {}) => this.fetch(u, { ...init, signal: init.signal ?? AbortSignal.timeout(30000) });
    this.createClient = deps.createClient || createClient;
    this.auth = deps.auth || null;
    this.db = deps.db || null;
    this.writeMode = null;
    this.columnsMissing = new Set();
  }

  get propertyId() { return this.opts.propertyId; }

  /** anon 키 확보 → 로그인 → 쓰기 클라이언트 결정. 실패하면 던진다. */
  async init() {
    const o = this.opts;
    if (!o.anonKey) o.anonKey = await this.fetchAnonKey();
    if (!this.auth) {
      this.auth = this.createClient(o.supabaseUrl, o.anonKey, { auth: { persistSession: false, autoRefreshToken: true }, global: { fetch: this.timedFetch } });
    }
    await this.login();
    this.writeMode = o.writeMode === 'auto' ? (o.serviceRoleKey ? 'service_role' : 'session') : o.writeMode;
    if (!this.db) {
      this.db = this.writeMode === 'service_role'
        ? this.createClient(o.supabaseUrl, o.serviceRoleKey, { auth: { persistSession: false, autoRefreshToken: false }, global: { fetch: this.timedFetch } })
        : this.auth;
    }
    this.log.info(`대시보드 연결 — 숙소 ${o.propertyId}, 쓰기 방식 ${this.writeMode}`);
    return this;
  }

  async login() {
    const { data, error } = await this.auth.auth.signInWithPassword({ email: this.opts.email, password: this.opts.password });
    if (error) throw new Error('대시보드 로그인 실패: ' + error.message);
    return data.session;
  }

  /** 콘솔이 쓰는 공개 설정 파일에서 anon 키를 읽는다(공개 키라 괜찮다). */
  async fetchAnonKey() {
    const res = await this.fetch(`${this.opts.apiBase}/assets/supabase-config.js`);
    const text = await res.text();
    const m = text.match(/anonKey:\s*"([^"]+)"/);
    if (!m) throw new Error('supabase-config.js 에서 anonKey 를 찾지 못했다 — MOTMOT_SUPABASE_ANON_KEY 를 직접 넣을 것');
    return m[1];
  }

  async accessToken() {
    return (await this.ensureSession()).access_token;
  }

  /** 로그인 상태를 보장한다. 세션이 사라졌으면 다시 로그인한다.
      ★ 이걸 안 하면 표 읽기가 anon 키로 나가고, RLS 가 0행을 돌려준다 — 오류가 아니라
        "할 일 0건·매핑 0건" 으로 보여서 실행기가 조용히 아무 일도 안 하게 된다. */
  async ensureSession() {
    const { data } = await this.auth.auth.getSession();
    const s = data && data.session;
    // 만료 1분 전이면 미리 다시 받는다(refresh 가 실패해도 여기서 걸린다)
    const soon = s && s.expires_at && s.expires_at * 1000 - Date.now() < 60000;
    if (s && s.access_token && !soon) return s;
    this.log.info('대시보드 세션이 없거나 곧 만료된다 — 다시 로그인한다');
    return this.login();
  }

  /** POST /api/ota?op=<op>&property=<id>[&query…] — 콘솔의 chCallApi 와 같은 모양. 응답은 항상 객체({ok, …}). */
  async ota(op, { query, body } = {}) {
    const tok = await this.accessToken();
    const u = new URL(`${this.opts.apiBase}/api/ota`);
    u.searchParams.set('op', op);
    u.searchParams.set('property', this.opts.propertyId);
    for (const [k, v] of Object.entries(query || {})) if (v != null && v !== '') u.searchParams.set(k, String(v));
    /* ★ 시간제한을 건다. 노드의 fetch 는 아무것도 안 오면 5분까지 붙들고 있는데,
         유입 주기가 2분이라 그 사이 다음 판이 줄에 쌓인다. 60초면 넉넉하다. */
    const init = { method: 'POST', headers: { Authorization: `Bearer ${tok}` }, signal: AbortSignal.timeout(60000) };
    if (body) { init.headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(body); }
    const res = await this.fetch(u.toString(), init);
    let json;
    try { json = await res.json(); } catch { json = null; }
    if (!json || typeof json !== 'object') return { ok: false, error: `HTTP ${res.status}` };
    if (!res.ok && json.ok !== true) json = { ...json, ok: false, error: json.error || `HTTP ${res.status}` };
    return json;
  }

  // ── 서버 동작 ─────────────────────────────────────────────
  pastePreview(channel, text) { return this.ota('paste', { body: { property: this.propertyId, channel, text } }); }
  pasteCommit(channel, text) { return this.ota('paste', { body: { property: this.propertyId, channel, text, commit: true } }); }
  sync() { return this.ota('sync'); }
  reconcile() { return this.ota('reconcile'); }
  todoDone(id) { return this.ota('todo_done', { body: { property: this.propertyId, id } }); }
  inventory(query) { return this.ota('inventory', { query }); }

  // ── 읽기(콘솔도 사용자 세션으로 읽는 표) ─────────────────────
  /* 읽기 전에 세션을 보장한다. 세션 없이 읽으면 RLS 가 오류 대신 빈 목록을 주기 때문에,
     "일이 없다" 와 "볼 권한이 없다" 가 구분되지 않는다. */
  async #rows(build, what) {
    await deadline(this.ensureSession(), 45000, '대시보드 세션 확인');
    /* ★ postgrest 는 503·520 을 받으면 서버가 준 Retry-After 를 **초 단위 그대로** 잔다
         (상한이 없다). 그 낮잠은 signal 이 있어야만 깬다 — abortSignal 한 줄이 요청과
         낮잠을 함께 끊는다. Promise.race 로 감싸면 요청이 취소되지 않고 뒤에 남는다.
         (시험용 가짜 대역에는 abortSignal 이 없을 수 있으므로 있을 때만 건다.) */
    const q = build();
    const r = typeof q?.abortSignal === 'function'
      ? await q.abortSignal(AbortSignal.timeout(45000))
      : await deadline(q, 45000, `${what} 읽기`);
    if (r.error) throw new Error(`${what} 읽기 실패: ${r.error.message}`);
    return r.data || [];
  }
  channelAccounts() {
    return this.#rows(() => this.auth.from('channel_accounts').select('*').eq('property_id', this.propertyId), '채널 계정');
  }
  async roomMap(channel) {
    const rows = await this.#rows(
      () => this.auth.from('channel_room_map').select('*').eq('property_id', this.propertyId).eq('channel_code', channel), '객실 매핑');
    return rows.filter((m) => m.active !== false);
  }
  async resources() {
    const rows = await this.#rows(() => this.auth.from('resources').select('*').order('sort_order'), '객실');
    return rows.filter((r) => !r.property_id || r.property_id === this.propertyId);
  }
  openTodos(channel) {
    return this.#rows(
      () => this.auth.from('manual_close_todos').select('*').eq('property_id', this.propertyId).eq('status', 'open')
        .eq('channel_code', channel).order('from_date'), '수동 마감 할 일');
  }
  /** 객실 매핑 추가 — 콘솔의 매핑 화면이 넣는 것과 같은 행. */
  async insertRoomMap({ channel, channelRoomKey, resourceId }) {
    const r = await this.auth.from('channel_room_map')
      .insert({ property_id: this.propertyId, channel_code: channel, channel_room_key: channelRoomKey, resource_id: resourceId, active: true });
    if (r.error) throw new Error('객실 매핑 추가 실패: ' + r.error.message);
    return true;
  }
  ratePlans() {
    return this.#rows(() => this.auth.from('rate_plans').select('*').eq('property_id', this.propertyId), '기본 요금');
  }
  /* ── 예약표 읽기 (쓰지는 않는다, BR-003) ───────────────────────
     대시보드 서버 소스가 비공개라 `bookings` 의 열 이름을 우리가 정확히 모른다(I-001).
     그래서 한 줄을 먼저 받아 **열 이름을 알아본 뒤** 그 이름으로 조회한다. 못 알아보면
     추측해서 읽지 않고 이유를 돌려준다 — 잘못 읽은 점유는 방을 잘못 막거나 잘못 연다(D-004). */
  async bookings(from, to) {
    const sample = await this.#rows(() => this.auth.from('bookings').select('*').limit(1), '예약표');
    /* ★ 0줄은 "예약이 없다" 가 아니라 **"볼 수 없다" 일 수도 있다**(RLS 정책이 좁아졌다·담당자 명부에서
         빠졌다·뷰로 갈아 끼워졌다). 둘을 구별할 방법이 없으므로 0건으로 믿지 않는다 — 믿으면
         캘린더 대조가 "예약이 하나도 없다" 로 보고 **우리가 막았던 밤을 앞으로 180일치 전부 다시 연다.**
         그 밤들은 실제 손님이 든 밤이다(BR-019 를 원장 읽기 쪽에 적용). 못 읽으면 아무것도 안 하는 쪽이 맞다(D-004). */
    if (!sample.length) {
      return { ok: false, why: '예약표에서 한 줄도 못 읽었다 — 정말 0건인지, 볼 권한이 없는 건지 구분되지 않는다(BR-019)', cols: null, empty: true };
    }
    const cols = detectBookingColumns(sample[0]);
    if (!cols.checkIn || !cols.checkOut || !cols.resourceId) {
      return { ok: false, why: `예약표의 열을 알아보지 못했다 — 본 열: ${Object.keys(sample[0]).slice(0, 20).join(', ')}`, cols };
    }
    /* ★ 날짜 칸이 타임스탬프(starts_at)면 경계 하루가 시간대 때문에 잘려 나간다. 앞뒤로 하루씩 더
         받아 오고, 실제로 막을 밤은 blockedDates 가 창 안으로 다시 자른다(넉넉히 읽고 좁게 쓴다). */
    const rows = await this.#rows(() => {
      let q = this.auth.from('bookings').select('*').lt(cols.checkIn, addDays(to, 1)).gte(cols.checkOut, addDays(from, -1));
      if (cols.propertyId) q = q.eq(cols.propertyId, this.propertyId);
      return q;
    }, '예약표');
    return { ok: true, rows, cols };
  }

  rateCalendar(from, to) {
    return this.#rows(
      () => this.auth.from('rate_calendar').select('*').eq('property_id', this.propertyId).gte('on_date', from).lt('on_date', to), '날짜 요금');
  }

  // ── 쓰기(콘솔은 읽기만 하는 표 — 세션 또는 service_role) ───────
  /** 이 실행기를 가리키는 이름. 표가 `agent_id` 를 반드시 요구한다(실계정에서 드러났다).
   *  채널마다 하나씩, 다시 켜도 같은 값이어야 한다 — 그래야 줄이 쌓이지 않고 갱신된다.
   *  `.env` 의 `AGENT_ID` 로 바꿀 수 있다(한 숙소에 PC 가 둘이면 서로 다르게 둘 것). */
  agentId(channel) {
    return (this.opts.agentId || 'pension-sync') + ':' + channel;
  }

  /** 생존 신호. 콘솔은 30분 안에 갱신되면 "실행기 연결됨"(BR-007). */
  async heartbeat(channel, at = new Date()) {
    const row = { property_id: this.propertyId, channel_code: channel, agent_id: this.agentId(channel), last_seen_at: iso(at) };
    const up = await this.db.from('agent_heartbeats').upsert(row, { onConflict: HEARTBEAT_CONFLICT });
    if (!up.error) return true;
    // unique 제약이 없어 upsert 가 안 되면 update → insert 로 간다
    const u = await this.db.from('agent_heartbeats').update({ last_seen_at: row.last_seen_at })
      .eq('property_id', this.propertyId).eq('channel_code', channel).select('channel_code');
    if (!u.error && u.data && u.data.length) return true;
    const i = await this.db.from('agent_heartbeats').insert(row);
    if (i.error) throw new Error('생존 신호 기록 실패: ' + i.error.message);
    return true;
  }

  /** 동기화 기록. kind 는 우리가 정한 어휘(inbound|outbound|rates|rooms). */
  /* 동기화 기록(일지). ★ 이것이 실패해도 **한 일을 실패로 만들지 않는다.**
     실계정에서 RLS 가 `sync_runs` 쓰기를 막자, 객실 목록을 멀쩡히 읽고도 "객실 목록 실패" 로 뒤집혔다 —
     그래서 사장님은 읽어 온 객실 이름을 보지도 못했다. 일지는 곁다리이고, 못 쓰면 로그로 알린다.
     같은 표에 계속 막히면 10분에 한 줄만 남긴다(1분마다 도는 작업이라 그러지 않으면 로그가 덮인다). */
  async recordRun({ channel, kind, startedAt, finishedAt = new Date(), ok, detail = null }) {
    try {
      return await this.#insertDroppingUnknownColumns('sync_runs', {
        channel_code: channel, kind, started_at: iso(startedAt), finished_at: iso(finishedAt), ok: !!ok,
        property_id: this.propertyId, detail,
      });
    } catch (e) {
      this.#warnOccasionally('sync_runs', `동기화 기록을 남기지 못했다(한 일에는 영향 없다) — ${e.message}`);
      return false;
    }
  }

  /** 같은 자리에서 되풀이되는 경고는 10분에 한 번만 남긴다. */
  #warnOccasionally(key, msg) {
    const now = Date.now();
    if (!this._warnedAt) this._warnedAt = {};
    if (this._warnedAt[key] && now - this._warnedAt[key] < 10 * 60000) return;
    this._warnedAt[key] = now;
    this.log?.warn(msg);
  }

  async #insertDroppingUnknownColumns(table, row) {
    const r = { ...row };
    for (const k of Object.keys(r)) if (this.columnsMissing.has(`${table}.${k}`)) delete r[k];
    for (let attempt = 0; attempt < 4; attempt++) {
      const res = await this.db.from(table).insert(r);
      if (!res.error) return true;
      const col = missingColumnFrom(res.error.message);
      if (!col || !(col in r)) throw new Error(`${table} 기록 실패: ${res.error.message}`);
      this.columnsMissing.add(`${table}.${col}`);
      delete r[col];
      this.log.warn(`${table} 에 ${col} 열이 없다 — 빼고 다시 넣는다`);
    }
    throw new Error(`${table} 기록 실패: 열을 너무 많이 뺐다`);
  }

  /** 열린 경보. channel·source 를 주면 detail 이 그것과 같은 것만. */
  async openAlerts({ kind, channel, source } = {}) {
    let q = this.db.from('channel_alerts').select('*').eq('property_id', this.propertyId).is('resolved_at', null);
    if (kind) q = q.eq('kind', kind);
    const rows = await this.#rows(() => q, '경보');
    return rows.filter((a) => {
      const d = a.detail || {};
      if (channel && d.channel !== channel) return false;
      if (source && d.source !== source) return false;
      return true;
    });
  }

  /** 경보를 연다. 같은 종류·채널·객실·날짜·대상의 열린 경보가 있으면 그것을 돌려주고 새로 열지 않는다. */
  async openAlert({ kind, channel, detail = {}, resourceId = null, onDate = null }) {
    /* ★ roomKey 까지 봐야 한다. 안 보면 미매핑 객실이 둘 이상일 때 첫 객실만 경보가 열리고
         나머지는 콘솔에 영영 안 뜬다(둘 다 resource_id 가 null 인 경우가 있다). */
    const same = (await this.openAlerts({ kind, channel })).find((a) =>
      (a.resource_id || null) === resourceId &&
      (a.on_date || null) === onDate &&
      ((a.detail && a.detail.roomKey) || null) === (detail.roomKey || null));
    if (same) return same;
    const row = { property_id: this.propertyId, kind, resource_id: resourceId, on_date: onDate, detail: { channel, ...detail }, opened_at: nowIso() };
    const r = await this.db.from('channel_alerts').insert(row).select('*');
    if (r.error) throw new Error('경보 기록 실패: ' + r.error.message);
    return (r.data && r.data[0]) || row;
  }

  /** 종류·채널(·낸 곳)이 맞는 열린 경보를 모두 닫는다. 닫은 수를 돌려준다.
      source 를 주면 그것이 낸 경보만 닫는다 — 유입이 성공했다고 반영·요금 경보까지 지우면 안 된다.
      ★ keep 을 주면 **그 객실의 경보만 남기고** 나머지를 닫는다. 미매핑 경보는 한 번 열리면
        스스로 안 닫혀서, 매핑을 넣거나 "안 파는 객실" 로 적어 둔 뒤에도 카드가 콘솔에 남는다.
        그러면 사장님은 고쳐도 안 고쳐진 것으로 본다(2026-09-11). */
  async resolveAlerts({ kind, channel, source, keep }) {
    let rows = await this.openAlerts({ kind, channel, source });
    if (keep) rows = rows.filter((a) => !keep.has(a.resource_id) && !keep.has(a.detail && a.detail.roomKey));
    for (const a of rows) {
      const r = await this.db.from('channel_alerts').update({ resolved_at: nowIso() }).eq('id', a.id);
      if (r.error) throw new Error('경보 닫기 실패: ' + r.error.message);
    }
    return rows.length;
  }

  /** 그 (종류, 방, 밤) 이 「자체 해결」(channel_alert_mutes)로 덮여 있나 — 교차 검사(engine/crosscheck.js)가 경보를 열기 전에 본다.
      ★ 못 읽으면 **던진다**(부르는 쪽은 '모름' 으로 보고 이번 판은 경보를 안 연다). 0줄 = 안 덮임.
      overbook 의 서버 열쇠는 방+날짜뿐이라(ota.mjs keyOf) 채널·객실키로 거르지 않는다. 읽기 정책은 is_admin — 실행기 계정은 관리자다. */
  async alertMuted({ kind, resourceId, onDate }) {
    const rows = await this.#rows(() => {
      let q = this.db.from('channel_alert_mutes').select('id').eq('property_id', this.propertyId).eq('kind', kind);
      q = resourceId == null ? q.is('resource_id', null) : q.eq('resource_id', resourceId);
      q = onDate == null ? q.is('on_date', null) : q.eq('on_date', onDate);
      return q;
    }, '자체 해결 목록');
    return rows.length > 0;
  }

  /** 경보 **한 줄만** 닫는다(id). 교차 검사가 자기가 연 줄(detail.source='crosscheck')을 닫을 때만 쓴다.
      ★ resolveAlerts({kind:'overbook'}) 는 날짜를 못 가르고 서버가 연 것까지 전부 닫으므로 쓰지 않는다.
        여기서도 source 를 한 번 더 걸어 서버가 연 줄은 DB 쪽에서도 안 닫힌다. 닫은 줄 수를 돌려준다. */
  async resolveAlertById(id) {
    if (id == null) return 0;
    const r = await this.db.from('channel_alerts').update({ resolved_at: nowIso() })
      .eq('id', id).eq('property_id', this.propertyId).is('resolved_at', null).eq('detail->>source', 'crosscheck').select('id');
    if (r.error) throw new Error('경보 닫기 실패: ' + r.error.message);
    return (r.data || []).length;
  }
}
