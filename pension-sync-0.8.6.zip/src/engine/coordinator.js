/* 두 타워 교차 — (가) 즉시 교차 잠금 코디네이터 (2026-09-23).

   사장님 그림: "클라이언트 하나에 두 컨트롤타워, 클라이언트가 최종 체크 후 대시보드와 연결".
     타워 = 채널 워커(여기어때·야놀자) — 저마다 브라우저 하나, 줄 하나.
     클라이언트 = 이 프로세스. 코디네이터가 두 타워를 잇고, 동시 판매 검사 보드(crosscheck.js)가 최종 체크를 한다.
     대시보드(원장)와 이어지는 길은 지금 그대로다 — 유입(paste·reconcile)과 경보.

   한 줄: **원장을 거쳐서만 두 타워가 서로를 깨운다.**
     한 타워의 유입이 원장에 새 예약·취소를 옮기면(reconcile 건수) 10초를 모았다가 **모든** 타워의 캘린더 대조를 앞당긴다.
     파트너센터를 막을지 열지는 지금처럼 각 타워의 runCalendar 가 원장을 읽고 정한다.
   ★ 지름길 금지 — A 채널에 팔린 것이 보인다고 B 를 곧바로 setClosed·markClosedByUs 하지 않는다.
     원장에 이유가 없는 막음은 다음 판 diffRoom 이 다시 열어(calendar.js) 막음→엶→막음으로 깜빡이고, 그 사이에 팔린다.
     안 적으면 취소 뒤에도 영영 안 열린다. 그래서 코디네이터는 **캘린더 판을 앞당기기만** 한다(D-005 원장은 대시보드).
   ★ 잠긴 채널은 건드리지 않는다 — 앞당김·강제 유입·스냅샷 대상이 아니다. onEvent·board 도 안 단다.
     writesLocked 는 워커를 만들 때 한 번 정해지고 바뀌지 않는다(spec 을 한 번만 읽는다).
   ★ 쓸 수 있는 타워가 둘 미만이면 만들지 않는다(null) — 여기어때 혼자, 여기어때 + 잠긴 야놀자(지금)가 여기 든다.
     CROSS_KICK=off + CROSSCHECK=off 여도 null. null 이면 워커는 기준판과 같은 경로로 돈다.
   ★ 무작위 지연·흔들기(jitter)·사람 흉내는 넣지 않는다. 부하는 고정 간격·상한·합치기로만 줄인다.
   ⚠ 로그에는 건수와 채널 이름만 — 예약번호·이름·전화·객실 원문은 안 적는다(BR-020).

   | 항목 | 기본 | 까닭 |
   | 모으기 CROSS_DEBOUNCE_SEC | 10초 | 붙여넣기 커밋·관리자 단체 입력이 몇 초에 걸쳐 쓴다 |
   | 같은 타워 캘린더 시작 사이 CROSS_MIN_GAP_SEC | 여기어때 60·야놀자 120초 | 야놀자는 한 판이 페이지 약 8번 적재(봇 탐지·Cloudflare) |
   | 앞당김 상한 CROSS_MAX_PER_HOUR | 타워당 한 시간 10판 | 기준 부하(12판/시)를 넘기지 않는다 |
   | 정기 판 건너뛰기 CROSS_TIMER_SKIP_SEC | ok 로 끝난 앞당김 판 뒤 120초 | 앞당긴 판이 정기 판을 대신해 순증이 거의 없다 |
   | 유입·정기 캘린더 주기 | 여기어때 120·300 그대로, 야놀자 300·900(config.js) | 줄이지 않는다 — 변화는 앞당김이 부른다 |
   ⚠ 야놀자 900·300 은 앞당김이 붙은 타워만 쓴다(crossPaced). 앞당김은 **이 실행기 유입이 원장에 옮긴 변화**만 부른다 —
     관리자 입력·홈페이지 예약·서버 크론이 바꾼 원장은 정기 판까지 기다린다(config.js CHANNEL_DEFAULT_SEC 머리말).

   검토 반영(2026-09-23):
   · dirty 는 **마지막** 트리거 뒤에 시작한 판만 지운다(triggerAt). 30분 버리기는 첫 트리거(dirtySince)로 잰다 —
     판이 도는 중에 둘째 변화가 오면 그 판은 둘째 변화 전 원장을 읽었으므로 한 판을 더 불러야 한다.
   · 트리거 뒤에 시작한 판이 아직 **도는 중**이면 더 부르지 않는다(running) — 그 판이 끝나며 dirty 를 지운다.
   · 콘솔 계정 '멈춤'(consolePaused)도 사람을 기다리는 상태로 친다 — 헛돌며 상한을 쓰지 않는다.
   · CROSS_KICK=off 면 동시 판매 검사의 다시 읽기 부탁(requestCalendar)도 안 부른다 — 앞당긴 판이 하나도 없다. */
import { ledgerChange } from './inbound.js';
import { SoldBoard } from './crosscheck.js';

const TICK_MS = 15000;              // dirty 타워를 다시 보는 간격
const DIRTY_MAX_MS = 30 * 60000;    // 이만큼 못 앞당기면 버린다(정기 판이 받친다)
const URGENT_MS = 10 * 60000;       // 새 예약이면 이만큼 요금 판이 줄을 비켜 준다(캘린더 판이 시작하면 풀린다)
const HOUR_MS = 3600000;

/**
 * 조건이 맞으면 코디네이터를 만들어 워커에 붙인다. 안 맞으면 null — 아무것도 붙이지 않는다.
 * @param o { workers, cfg, dashboard, log }
 */
export function createCoordinator({ workers, cfg, dashboard, log }) {
  const kick = cfg?.cross?.kick !== false;
  const mode = cfg?.crosscheck?.mode || 'log';
  if (!kick && mode === 'off') return null;
  const eligible = (workers || []).filter((w) => w && !w.writesLocked && !w.previewOnly && cfg?.calendar?.enabled);
  if (eligible.length < 2) return null;
  return new Coordinator({ eligible, cfg, dashboard, log, kick, mode });
}

export class Coordinator {
  constructor({ eligible, cfg, dashboard, log, kick, mode }) {
    this.cfg = cfg;
    this.dashboard = dashboard;
    this.log = log;
    this.kickOn = kick;
    this.workers = eligible;
    this.byChannel = new Map(eligible.map((w) => [w.channel, w]));
    /* 타워마다 코디네이터 쪽 기억 — 워커에 칸을 늘리지 않는다. */
    /* dirtySince = 첫 트리거(30분 버리기의 기준), triggerAt = 마지막 트리거(이 뒤에 시작한 ok 판만 dirty 를 지운다). */
    this.st = new Map(eligible.map((w) => [w, { dirtySince: null, triggerAt: null, kicks: [], capWarnAt: null }]));
    this.pendingKick = null;
    this.debounceTimer = null;
    this.retryTimer = null;
    this.retrying = false;
    this.stopped = false;
    this.board = mode !== 'off'
      ? new SoldBoard({
        cfg, dashboard, log, workers: this.byChannel,
        requestCalendar: (ch, why) => this.requestCalendar(ch, why),
        freshSecOf: (ch) => this.freshSecOf(ch),
      })
      : null;
    for (const w of eligible) {
      w.onEvent = (ch, kind, r, meta) => this.onEvent(ch, kind, r, meta);
      if (this.board) w.board = this.board;
      /* 앞당김이 붙은 타워만 채널별 기본 주기(야놀자 900·300)를 쓴다 — start() 앞이라 타이머가 이 값으로 걸린다. */
      if (kick) w.crossPaced = true;
    }
    /* unref 하지 않는다(worker.start 와 같은 까닭) — 정지는 stop() 이 한다. */
    this.tickTimer = setInterval(() => this.tick(), TICK_MS);
    this.log.info(`교차: 켰다 — 타워 ${eligible.map((w) => w.channel).join('·')} · 앞당김 ${kick ? 'on' : 'off'} · 동시 판매 검사 ${mode}`);
  }

  minGapSec(ch) {
    const c = this.cfg?.cross || {};
    return c.minGapByChannel?.[ch] ?? c.minGapSec ?? 60;
  }

  /* 스냅샷 신선도 — CROSSCHECK_FRESH_SEC 가 있으면 그것, 없으면 2 × 그 타워의 정기 캘린더 주기(여기어때 600·야놀자 1800). */
  freshSecOf(ch) {
    const v = this.cfg?.crosscheck?.freshSec;
    if (Number.isFinite(v)) return v;
    const w = this.byChannel.get(ch);
    const cal = (typeof w?.intervals === 'function' ? w.intervals().calendarSec : null) ?? this.cfg?.intervals?.calendarSec ?? 300;
    return 2 * cal;
  }

  /** 워커가 유입·캘린더 한 판을 끝낼 때마다 부른다(worker #emit). */
  onEvent(ch, kind, r, meta) {
    if (this.stopped) return;
    const w = this.byChannel.get(ch);
    /* 이중 안전 — 잠긴·미리보기·모르는 워커가 무엇을 내도 무시한다. */
    if (!w || w.writesLocked || w.previewOnly) return;
    if (kind === 'inbound') {
      if (!r || typeof r !== 'object' || !this.kickOn) return;
      if (r.change === 'new' || r.change === 'cancel') this.kick({ from: ch, change: r.change, ledger: r.ledger, urgent: r.change === 'new' });
      if (r.reconcileFailed === true) this.#retryReconcile(ch);
      return;
    }
    if (kind === 'calendar') {
      const s = this.st.get(w);
      const startedAt = meta?.startedAt;
      /* ★ **마지막** 트리거 뒤에 시작한 판만 지운다 — 앞에 시작한 판은 옛 원장을 읽었을 수 있다. 정기 판이 해내도 지워진다.
           (첫 트리거로 재면, 도는 중에 온 둘째 변화를 그 판이 지워 버려 둘째 변화의 판이 영영 안 돈다 — 검토 2026-09-23)
           skipped('객실 매핑이 없다')도 지운다 — 다시 불러도 할 일이 없는데 dirty 로 두면 30분 동안 상한까지 헛돈다. */
      if (s && s.dirtySince != null && Number.isFinite(startedAt) && startedAt >= (s.triggerAt ?? s.dirtySince) && r && r.ok !== false && !r.locked) {
        s.dirtySince = null;
        s.triggerAt = null;
      }
    }
  }

  /** 원장 변화 → 모았다가(10초) 모든 타워의 캘린더를 앞당긴다. */
  kick({ from, change, ledger, urgent }) {
    if (!this.kickOn || this.stopped) return;
    if (!this.pendingKick) {
      this.pendingKick = { urgent: false, by: new Map() };
      this.debounceTimer = setTimeout(() => this.#fire(), (this.cfg?.cross?.debounceSec ?? 10) * 1000);
    } else {
      this.log.debug(`교차: 원장 변화를 모으는 중 — ${from} ${change === 'new' ? '새 예약' : '취소'} 합침`);
    }
    const p = this.pendingKick;
    p.urgent = p.urgent || !!urgent;
    const e = p.by.get(from) || { created: 0, cancelled: 0 };
    e.created += (Number(ledger?.created) || 0) + (Number(ledger?.restored) || 0);
    e.cancelled += Number(ledger?.cancelled) || 0;
    p.by.set(from, e);
  }

  #fire() {
    const p = this.pendingKick;
    this.pendingKick = null;
    this.debounceTimer = null;
    if (!p || this.stopped) return;
    const now = Date.now();
    /* ★ 보낸 타워도 넣는다 — reconcile 은 숙소 전체를 옮기므로 보낸 채널 쪽에도 막을 밤이 생길 수 있다. */
    for (const w of this.workers) {
      const s = this.st.get(w);
      if (s.dirtySince == null) s.dirtySince = now;
      s.triggerAt = now;
      /* 취소(여는 쪽)는 급하지 않다 — 새 예약(막는 쪽)만 요금 판을 비켜 세운다. */
      if (p.urgent && this.cfg?.cross?.urgent !== false) w.urgentUntil = Math.max(w.urgentUntil || 0, now + URGENT_MS);
    }
    const what = [...p.by].map(([ch, e]) => `${ch} 새 예약 ${e.created}·취소 ${e.cancelled}`).join(', ');
    this.log.info(`교차: 원장 변화(${what}) → ${this.workers.map((w) => w.channel).join('·')} 캘린더 앞당김`);
    for (const w of this.workers) this.#trySchedule(w, now);
  }

  /* 걸리면 dirty 로 두고 끝낸다 — 15초 틱이 다시 본다. 돌려받은 promise 는 기다리지 않는다(합쳐지면 줄 꼬리가 온다). */
  #trySchedule(w, now = Date.now()) {
    const s = this.st.get(w);
    if (!s || s.dirtySince == null) return 'clean';
    if (w.stopped) { s.dirtySince = null; s.triggerAt = null; return 'stopped'; }
    /* 사람이 필요한 상태·콘솔 계정 멈춤·세션 비켜 주는 중에는 파트너센터를 두드리지 않는다(상한도 안 쓴다). */
    if (w.paused || w.consolePaused || (w.adapter?.yieldMsLeft?.() || 0) > 0) return 'paused';
    /* 마지막 트리거 뒤에 시작한 판이 아직 돈다 — 그 판이 최신 원장을 읽었고, 끝나면 dirty 를 지운다. 또 줄 세우면 헛판이다.
       (트리거 **앞**에 시작한 판이 도는 중이면 지나간다 — 옛 원장을 읽었으니 뒤에 한 판을 세워야 한다.) */
    const running = w.calRunningSince;
    if (running != null && running >= (s.triggerAt ?? s.dirtySince)) return 'running';
    /* 이미 줄에 서 있다 — 그 판은 시작할 때 최신 원장을 읽으므로 끝나면 dirty 가 지워진다. */
    if (w.pending?.has?.('calendar')) return 'queued';
    if (now - (w.calStartedAt || 0) < this.minGapSec(w.channel) * 1000) return 'gap';
    s.kicks = s.kicks.filter((t) => now - t < HOUR_MS);
    const cap = this.cfg?.cross?.maxPerHour ?? 10;
    if (s.kicks.length >= cap) {
      if (s.capWarnAt == null || now - s.capWarnAt >= HOUR_MS) {
        s.capWarnAt = now;
        this.log.warn(`교차: ${w.channel} 캘린더 앞당김이 한 시간 ${cap}판에 닿았다 — 이번 시간은 더 안 부른다(정기 판이 받친다)`);
      }
      return 'cap';
    }
    s.kicks.push(now);
    this.log.debug(`교차: ${w.channel} 캘린더 앞당김`);
    try {
      const p = w.calendar({ reason: 'kick' });
      if (p && typeof p.catch === 'function') p.catch(() => {});
    } catch (e) {
      this.log.debug(`교차: ${w.channel} 캘린더를 못 불렀다 — ${e.message}`);
    }
    return 'called';
  }

  tick() {
    if (this.stopped) return;
    const now = Date.now();
    for (const w of this.workers) {
      const s = this.st.get(w);
      if (!s || s.dirtySince == null) continue;
      if (now - s.dirtySince > DIRTY_MAX_MS) {
        this.log.warn(`교차: ${w.channel} 캘린더 앞당김을 30분 동안 못 했다 — 버린다(정기 판이 받친다)`);
        s.dirtySince = null;
        s.triggerAt = null;
        continue;
      }
      this.#trySchedule(w, now);
    }
  }

  /** 동시 판매 검사가 묵은 쪽을 다시 읽게 부탁한다 — dirty·최소 간격·상한을 그대로 탄다. 급하지 않다.
      ★ CROSS_KICK=off 면 부르지 않는다 — 스위치를 끈 사람은 앞당긴 판이 하나도 없기를 기대한다(검토 2026-09-23).
        그때 보드는 받침 규칙(두 판이 모두 의심 뒤에 읽힘)으로 정기 판만 가지고 확정한다. */
  requestCalendar(ch, why = 'crosscheck') {
    if (this.stopped) return false;
    if (!this.kickOn) { this.log.debug(`교차: ${ch} 다시 읽기 부탁을 안 부른다 — 앞당김 off(정기 판으로 확인한다)`); return false; }
    const w = this.byChannel.get(ch);
    if (!w || w.writesLocked || w.previewOnly) return false;
    const s = this.st.get(w);
    const now = Date.now();
    if (s.dirtySince == null) s.dirtySince = now;
    s.triggerAt = now;
    this.log.debug(`교차: ${ch} 캘린더를 다시 읽는다(${why})`);
    this.#trySchedule(w);
    return true;
  }

  /* 유입이 저장했는데 reconcile 응답에서 원장 변화를 못 읽었다(실패·옛 서버) — retrySec 뒤 한 번만 다시 묻는다.
     ★ 유입은 reconcile 이 실패해도 해시를 저장해서 다음 판은 reconcile 을 다시 안 부른다 — 그 틈을 메운다.
     서버 호출뿐이라 파트너센터 요청은 0건이다. 동시에 하나만, 실패하면 더 안 부른다(15분 크론이 받친다). */
  #retryReconcile(ch) {
    const sec = this.cfg?.cross?.reconcileRetrySec ?? 45;
    if (!(sec > 0) || this.retrying || this.stopped) return;
    this.retrying = true;
    this.log.debug(`교차: ${ch} 유입 뒤 reconcile 응답에서 원장 변화를 못 읽었다 — ${sec}초 뒤 한 번 더 묻는다`);
    this.retryTimer = setTimeout(async () => {
      this.retryTimer = null;
      try {
        if (this.stopped) return;
        const lc = ledgerChange(await this.dashboard.reconcile());
        if (lc.change === 'new' || lc.change === 'cancel') this.kick({ from: ch, change: lc.change, ledger: lc.ledger, urgent: lc.change === 'new' });
        else this.log.debug(`교차: reconcile 재시도 — 원장 변화 없음${lc.reconcileFailed ? '(여전히 못 읽음, 15분 크론이 받친다)' : ''}`);
      } catch (e) {
        this.log.debug(`교차: reconcile 재시도 실패 — ${e.message}`);
      } finally {
        this.retrying = false;
      }
    }, sec * 1000);
  }

  /** 상태 줄 한 줄(main.js 가 1분마다 남긴다). */
  statusLine() {
    const dirty = this.workers.filter((w) => this.st.get(w)?.dirtySince != null).map((w) => w.channel);
    return `교차 — 앞당김 ${this.kickOn ? 'on' : 'off'}${dirty.length ? `(대기 ${dirty.join('·')})` : ''} · ${this.board ? this.board.statusText() : '검사 off'}`;
  }

  /** 타이머를 다 끄고 워커에서 뗀다 — 멈춘 뒤 남는 타이머가 없어야 한다. */
  stop() {
    this.stopped = true;
    clearInterval(this.tickTimer);
    if (this.debounceTimer) clearTimeout(this.debounceTimer);
    if (this.retryTimer) clearTimeout(this.retryTimer);
    this.debounceTimer = null;
    this.retryTimer = null;
    this.pendingKick = null;
    this.board?.stop();
    for (const w of this.workers) {
      w.onEvent = null;
      w.board = null;
      w.crossPaced = false;   // 이미 걸린 타이머는 그대로다(정지 때만 부른다)
    }
  }
}
