/* 캘린더 대조 — 대시보드 캘린더와 파트너센터 판매현황을 **매 주기 맞춘다**(양방향 동기화의 닫는 쪽).
   반영(outbound)은 대시보드 서버가 만들어 준 할 일(manual_close_todos)을 처리한다. 그 길은 서버 크론이
   15분마다 도는 것에 매여 있고, 다른 경로로 들어온 예약(전화·워크인·다른 OTA)은 할 일이 안 만들어질 수도 있다.
   여기서는 **원장을 직접 보고** 차이를 메운다 — 사람이 아무것도 누르지 않아도 된다는 요구가 이 파일이다.

   무엇을 막는가:  대시보드에 예약이 있는 날 + rate_calendar.closed 인 날(만실 걸기, I-006)
   무엇을 여는가:  **우리가 막았던 날인데** 대시보드에서 그 이유가 사라진 날(취소·기간 변경)
   무엇을 안 건드리는가:
     · 파트너센터가 'sold'(예약완료)로 표시한 날 — 그 채널에 든 예약이다. 우리가 열면 곧바로 오버부킹이다.
     · 사장님이 파트너센터에서 직접 막아 둔 날 — 우리 기록에 없으므로 열지 않는다(공사·개인 사용).
   원장을 못 읽으면(열 이름을 못 알아보면) 아무것도 하지 않고 경보만 남긴다 — 잘못 읽고 막거나 여는 것보다 낫다(D-004). */
import { addDays, dayKst, eachDate, todayKst } from '../lib/kst.js';
import { forDashboard } from '../lib/log.js';
import { bookingIsLive } from '../dashboard/client.js';
/* ★ 예약 상태 라벨(bookingStatusLabel)은 **이름공간으로** 가져온다(2026-09-23 검토).
     `import { bookingStatusLabel }` 처럼 이름을 집어 가져오면, client.js 가 옛 판(0.8.5)인 채 이 파일만 덮어썼을 때
     ESM 연결 단계에서 SyntaxError 가 나서 main.js → worker.js → calendar.js 가 **통째로 안 뜬다** —
     화면 라벨 하나 때문에 유입·반영·캘린더(막기·열기)가 다 멈추면 그대로 오버부킹이다.
     이름공간은 없는 이름이 undefined 일 뿐 연결에 실패하지 않는다 — 그때는 라벨만 비고 예전 화면 그대로 돈다(statusLabel). */
import * as dashClient from '../dashboard/client.js';
import { NeedsHumanError, SKIP_NOT_FOUND } from '../adapters/json-adapter.js';
import { loadRoomLabels } from './room-label.js';

/** 예약·만실에서 "막아야 할 날" 을 뽑는다. @returns Map<resourceId, Set<date>> */
export function blockedDates({ bookings, cols, rateCal, from, to }) {
  const want = new Map();
  const add = (rid, date) => {
    if (!rid || date < from || date >= to) return;
    if (!want.has(rid)) want.set(rid, new Set());
    want.get(rid).add(date);
  };
  for (const b of bookings || []) {
    if (!bookingIsLive(b, cols)) continue;
    /* ★ 앞 열 자를 그냥 자르면 안 된다 — 예약표가 시각까지 들고 있으면(starts_at) UTC 기준으로
         하루가 밀린다. KST 하루로 옮겨 읽는다(dayKst). */
    const ci = dayKst(b[cols.checkIn]);
    const co = dayKst(b[cols.checkOut]);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(ci)) continue;
    /* 묵는 밤만 막는다 — 퇴실일은 비어 있다. 대실(입실 == 퇴실)은 그 하루를 막는다(BR-016). */
    const end = /^\d{4}-\d{2}-\d{2}$/.test(co) && co > ci ? co : addDays(ci, 1);
    for (const d of eachDate(ci, end)) add(b[cols.resourceId], d);
  }
  for (const r of rateCal || []) {
    if (r && r.closed) add(r.resource_id, dayKst(r.on_date));
  }
  return want;
}

/* 그 방 그 날을 **만실 걸기**(rate_calendar.closed)로 막았나. 예약이 아니라 사장님이 걸어 둔 것이라
   예약자가 있을 수 없다 — 화면에 빈칸으로 두면 "이름을 못 읽었나?" 로 보인다. `만실` 이라고 적는다. */
export function closedByRate({ rateCal, from, to }) {
  const m = new Map();
  for (const r of rateCal || []) {
    if (!r || !r.closed) continue;
    const d = dayKst(r.on_date);
    if (!d || d < from || d >= to) continue;
    if (!m.has(r.resource_id)) m.set(r.resource_id, new Set());
    m.get(r.resource_id).add(d);
  }
  return m;
}

/** 이 날들이 **전부** 만실로 막은 날인가. */
export function allFromRate(rate, resourceId, dates) {
  const s = rate && rate.get ? rate.get(resourceId) : null;
  if (!s || !dates.length) return false;
  return dates.every((d) => s.has(d));
}

/* 한 예약을 화면에 뭐라고 적을까.
   ★ **단체는 단체명만** 적는다 — 단체 하나에 예약이 여러 줄이라 개인 이름을 다 늘어놓으면
     화면이 이름 목록이 되고, 그것도 손님 정보다. 단체명 칸이 없는 판이면 `단체` 라고만 적는다.
     개인 이름으로 대신하지 않는다. */
export function guestLabel(row, cols) {
  const c = cols || {};
  const group = c.groupName ? String(row[c.groupName] ?? '').trim() : '';
  if (group) return group;
  if (c.groupId && row[c.groupId] != null && String(row[c.groupId]).trim() !== '') return '단체';
  return c.guestName ? String(row[c.guestName] ?? '').trim() : '';
}

/* 이름 칸에 예약 상태를 접어 넣는다 — '이름(라벨)', 이름이 없으면 '라벨', 라벨이 없으면 '이름'(예전과 같다).
   왜 이름 칸인가(2026-09-23 사장님 요청 "결제완료, 임시품절, 결제취소 등" 구분):
     화면은 실행기.exe(Go, 소스 없음)가 그리고, 줄을 [기간, 방+동작, guestName] 으로만 잇는다 — status 칸은 버린다.
     exe 를 다시 빌드하지 않고 상태를 보이게 하는 자리가 guestName 뿐이다. */
export function nameWithStatus(name, label) {
  const n = typeof name === 'string' ? name.trim() : '';
  const l = typeof label === 'string' ? label.trim() : '';
  if (n && l) return `${n}(${l})`;
  return n || l;
}

/* 예약 상태 라벨 — client.js 의 bookingStatusLabel 을 **이름공간으로** 찾아 부른다(위 import 머리말).
   client.js 가 옛 판이라 그 이름이 없으면 '' — 라벨만 비고 막기·열기·화면은 예전 그대로 돈다. 던지지 않는다. */
function statusLabel(row, cols, nowMs) {
  try {
    const f = dashClient.bookingStatusLabel;
    if (typeof f !== 'function') return '';
    const l = f(row, cols, nowMs);
    return typeof l === 'string' ? l : '';
  } catch {
    return '';
  }
}

const YMD = /^\d{4}-\d{2}-\d{2}$/;

/* 한 방 한 날에 적을 것을 더한다. 한 줄이면 글자, 같은 날 줄이 둘 이상이면 배열로 둔다.
   ★ 예전에는 마지막 줄 이름으로 덮었다 — 같은 날 차단과 예약이 겹치면 하나가 조용히 사라졌다.
     한 줄일 때 모양(글자)은 그대로라 예전 읽는 쪽도 그대로 돈다(stayGuests 를 읽는 곳은 guestsFor 뿐이다). */
function addWho(m, d, name) {
  const prev = m.get(d);
  if (prev === undefined) m.set(d, name);
  else if (Array.isArray(prev)) { if (!prev.includes(name)) prev.push(name); }
  else if (prev !== name) m.set(d, [prev, name]);
}

/* stayGuests 가 돌려준 Map → Map<접은 글자, {name, label}>. 반환 모양(날 → 글자)은 그대로 두고
   이름과 라벨을 따로 기억해 둔다 — guestsFor 가 **한 사람을 한 번만** 세려고 쓴다(아래 mergeByName).
   ★ 이 PC 의 메모리에만 있다 — 파일·로그로 안 나간다. */
const WHO_PARTS = new WeakMap();

/* 그 방 그 날을 **누구 때문에** 막는가 — 화면에 보여 주려고만 쓴다(막을 날을 정하는 데는 안 쓴다).
   이름은 이 PC 의 화면 기록에만 남는다. 로그·보고서·클라우드로는 안 나간다(state.js 머리말).
   ★ 2026-09-23: 예약 상태 라벨을 이름에 접어 넣는다(nameWithStatus). 이름이 없는 줄도 라벨이 있으면 적는다 —
     차단 줄은 이름이 없어서 예전에는 빈칸이었다. 이름 칸이 없어도 상태 칸이 있으면 라벨만이라도 낸다.
   ★ **던지지 않는다.** 이상한 줄 하나는 그 줄만 건너뛴다 — 여기서 던지면 runCalendar 가 통째로 실패해
     막아야 할 밤을 못 막는다. 막을 날은 blockedDates 가 따로 정한다. */
export function stayGuests({ bookings, cols, from, to }) {
  const who = new Map();
  if (!cols || !(cols.guestName || cols.groupName || cols.groupId || cols.status)) return who;
  const parts = new Map();
  WHO_PARTS.set(who, parts);
  try {
    for (const b of bookings || []) {
      try {
        if (!bookingIsLive(b, cols)) continue;
        const guest = guestLabel(b, cols);
        const lab = statusLabel(b, cols);
        const name = nameWithStatus(guest, lab);
        if (!name) continue;
        const ci = dayKst(b[cols.checkIn]);
        const co = dayKst(b[cols.checkOut]);
        if (!YMD.test(ci)) continue;
        const end = YMD.test(co) && co > ci ? co : addDays(ci, 1);
        const rid = b[cols.resourceId];
        if (!rid) continue;
        if (!who.has(rid)) who.set(rid, new Map());
        if (!parts.has(name)) parts.set(name, { name: guest, label: lab });
        /* ★ 창(from~to) 안으로 잘라서 돈다(2026-09-23 검토) — 퇴실일이 9999-12-31 같은 줄 하나가 수백만 날을
             동기로 세며 실행기 전체(심장박동·다른 방의 막기)를 몇 초씩 세웠다. 적는 날은 자르기 전과 같다. */
        const lo = typeof from === 'string' && YMD.test(from) && from > ci ? from : ci;
        const hi = typeof to === 'string' && YMD.test(to) && to < end ? to : end;
        if (!(lo < hi)) continue;
        for (const d of eachDate(lo, hi)) {
          if (d < from || d >= to) continue;
          addWho(who.get(rid), d, name);
        }
      } catch { /* 표시 전용 — 이 줄만 빼고 간다 */ }
    }
  } catch { /* 표시 전용 — 여기까지 모은 것으로 간다 */ }
  return who;
}

/* 같은 사람은 한 번만 — 이름이 같으면 라벨을 '/' 로 합친다('Kim(결제완료/임시품절)').
   ★ (2026-09-23 검토) 이름+라벨 글자로 겹침을 없애면 한 손님이 상태가 다른 줄 둘로 두 자리를 다 차지해
     다른 손님이 '외 N명' 뒤로 숨었다(예전: 'Kim, Lee' → 'Kim(결제완료), Kim(임시품절) 외 1명').
   이름 없는 줄(차단 등)은 라벨끼리만 합친다. 들어온 순서를 지킨다. */
function mergeByName(entries) {
  const order = [];
  const byKey = new Map();
  for (const e of entries) {
    const name = e && typeof e.name === 'string' ? e.name.trim() : '';
    const label = e && typeof e.label === 'string' ? e.label.trim() : '';
    if (!name && !label) continue;
    const key = name ? `n:${name}` : `l:${label}`;
    let g = byKey.get(key);
    if (!g) { g = { name, labels: [] }; byKey.set(key, g); order.push(g); }
    if (label && !g.labels.includes(label)) g.labels.push(label);
  }
  return order.map((g) => (g.name ? nameWithStatus(g.name, g.labels.join('/')) : g.labels[0]));
}

/* 이름 목록을 한 줄로. 둘까지 적고 나머지는 세어서 줄인다. */
function joinGuests(names) {
  if (!names.length) return '';
  return names.length <= 2 ? names.join(', ') : `${names.slice(0, 2).join(', ')} 외 ${names.length - 2}명`;
}

/** 그 날들을 막게 한 예약자들을 한 줄로. 둘까지 적고 나머지는 세어서 줄인다. */
export function guestsFor(who, resourceId, dates) {
  const m = who && who.get ? who.get(resourceId) : null;
  if (!m) return '';
  const folded = [...new Set(dates.flatMap((d) => { const v = m.get(d); return Array.isArray(v) ? v : [v]; }).filter(Boolean))];
  /* stayGuests 가 만든 Map 이 아니면(예전 모양 — 날 → 이름 글자) 글자를 그대로 이름으로 본다. */
  const parts = who instanceof Map ? WHO_PARTS.get(who) : undefined;
  return joinGuests(mergeByName(folded.map((f) => (parts && parts.get(f)) || { name: String(f), label: '' })));
}

/* ── 다시 연 까닭(최근 취소) ──
   다시 열기 줄은 그 예약이 사라진 뒤라 누구였는지 몰라 빈칸이었다. 원장(book.rows)에는 취소 줄도 들어 있으므로
   (bookings() 는 상태로 거르지 않는다) 그 방·그 밤과 겹치는 **최근 취소**를 찾아 '이름(결제취소)' 처럼 적는다.
   ★ **최근(기본 24시간 안) 취소만** 적는다. cancelled_at 이 없거나 오래됐으면 아무것도 안 적는다 —
     같은 방·날에 옛 취소 줄이 남아 있기 쉬워서, 그것을 적으면 엉뚱한 사람의 취소를 까닭으로 보여 준다.
     다시 연 진짜 까닭이 만실 해제·기간 변경일 수도 있다. 모르면 빈칸이 낫다.
   ⚠ (2026-09-23 검토) **채널 예약의 cancelled_at 은 취소한 때가 아니다.** 대시보드 ota.mjs promoteToBookings 가
     15분마다(reconcile 크론) 취소된 채널 예약을 퇴실일까지 **다시** 취소로 덮어쓰며 cancelled_at 을 지금으로 찍는다
     (cancel_reason '채널에서 취소(자동)'). 그래서 몇 주 전 취소도 늘 '방금 취소' 로 보인다.
     서버가 고쳐지기(`status=neq.cancelled` 조건) 전까지 이런 줄은 cancelled_at 만으로 믿지 않고,
     **이 실행기가 24시간 안에 그 예약이 살아 있는 것을 직접 본 경우에만** 적는다(seenLive — rememberLive 가 채운다).
     실행기를 다시 켜서 기억이 없으면 빈칸이다(모르면 빈칸).
   ★ 늦게 취소된 것부터 적는다 — 진짜 까닭이 '외 N명' 안에 숨지 않게.
   ★ 표시 전용 — 무엇을 열지는 diffRoom·confirmOpen 이 이미 정했다. 여기는 **던지지 않는다.**
   nowMs 는 시험에서 고정하려고 받는다. 시계가 조금 어긋난 것(서버가 몇 분 앞섬)은 봐준다. */
export const RECENT_CANCEL_MS = 24 * 3600000;
const CLOCK_SKEW_MS = 10 * 60000;
const AUTO_CANCEL_MARK = '채널에서 취소(자동)';   // 대시보드 api/ota.mjs AUTO_CANCEL_MARK 와 같은 글자

function cancelledMs(v) {
  if (v instanceof Date) return Number.isNaN(v.getTime()) ? null : v.getTime();
  if (typeof v !== 'string' || !v.trim()) return null;
  const t = Date.parse(v);
  return Number.isNaN(t) ? null : t;
}

function textAt(b, col) {
  const v = col ? b[col] : undefined;
  return typeof v === 'string' ? v.trim() : '';
}

/* cancelled_at 을 믿을 수 없는 줄 — 채널 자동 취소 표시가 있거나, 채널 예약이다(채널 예약의 cancelled_at 을
   쓰는 곳은 위의 되찍기뿐이다: 대시보드에서 cancelled_at 을 쓰는 곳은 book.mjs·pay.mjs(직접 예약)와 ota.mjs 하나). */
function restampedCancel(b, c) {
  if (textAt(b, c.cancelReason).includes(AUTO_CANCEL_MARK)) return true;
  const ch = textAt(b, c.channel).toLowerCase();
  return !!ch && ch !== 'direct';
}

/* 예약 하나를 가리키는 열쇠 — id 가 있으면 id, 없으면 방·입실·퇴실. ★ 이름은 넣지 않는다(메모리에도 손님 정보를 안 둔다). */
function liveKey(b, c) {
  const id = b.id;
  if ((typeof id === 'string' && id.trim()) || (typeof id === 'number' && Number.isFinite(id))) return `id:${id}`;
  return `k:${b[c.resourceId]}|${dayKst(b[c.checkIn])}|${dayKst(b[c.checkOut])}`;
}

/* 이번에 살아 있는 예약을 '봤다' 고 적어 둔다(열쇠 → 본 시각). 24시간 넘은 것은 지운다.
   ★ 이 PC 의 메모리에만 있다 — executor-state.json·로그로 안 나간다. 실행기를 다시 켜면 비어서 시작한다.
   ★ 표시 전용 — 무엇을 막고 여는지에는 안 쓴다. 던지지 않는다. */
export function rememberLive({ seenLive, bookings, cols, nowMs = Date.now(), withinMs = RECENT_CANCEL_MS }) {
  try {
    if (!(seenLive instanceof Map) || !cols || typeof nowMs !== 'number' || !Number.isFinite(nowMs)) return;
    for (const b of bookings || []) {
      try {
        if (!b || typeof b !== 'object' || !bookingIsLive(b, cols)) continue;
        seenLive.set(liveKey(b, cols), nowMs);
      } catch { /* 표시 전용 — 이 줄만 빼고 간다 */ }
    }
    for (const [k, t] of seenLive) if (nowMs - t > withinMs) seenLive.delete(k);
  } catch { /* 표시 전용 */ }
}

/* state 하나(= 실행기 하나)마다 '살아 있는 것을 본' 기록. state 가 없으면 기억하지 않는다. */
const LIVE_SEEN = new WeakMap();
function liveMemory(state) {
  try {
    if (!state || (typeof state !== 'object' && typeof state !== 'function')) return null;
    let m = LIVE_SEEN.get(state);
    if (!m) { m = new Map(); LIVE_SEEN.set(state, m); }
    return m;
  } catch {
    return null;
  }
}

export function recentCancelGuests({ bookings, cols, resourceId, dates, nowMs = Date.now(), withinMs = RECENT_CANCEL_MS, seenLive }) {
  try {
    const c = cols || {};
    if (!c.cancelledAt || !c.resourceId || !c.checkIn || !Array.isArray(dates) || !dates.length) return '';
    if (typeof nowMs !== 'number' || !Number.isFinite(nowMs)) return '';
    const nights = dates.filter((d) => typeof d === 'string' && YMD.test(d));
    const hits = [];
    for (const b of bookings || []) {
      try {
        if (!b || b[c.resourceId] !== resourceId) continue;
        if (bookingIsLive(b, c)) continue;
        const t = cancelledMs(b[c.cancelledAt]);
        if (t == null || nowMs - t > withinMs || t - nowMs > CLOCK_SKEW_MS) continue;
        const ci = dayKst(b[c.checkIn]);
        const co = dayKst(b[c.checkOut]);
        if (!YMD.test(ci)) continue;
        const end = YMD.test(co) && co > ci ? co : addDays(ci, 1);
        /* 밤을 늘어놓지 않고 구간으로 본다(YYYY-MM-DD 는 글자 비교가 곧 날짜 비교) — 먼 퇴실일에도 금방 끝난다. */
        if (!nights.some((d) => d >= ci && d < end)) continue;
        if (restampedCancel(b, c)) {
          const seen = seenLive instanceof Map ? seenLive.get(liveKey(b, c)) : undefined;
          if (typeof seen !== 'number' || nowMs - seen > withinMs || seen - nowMs > CLOCK_SKEW_MS) continue;
        }
        hits.push({ t, name: guestLabel(b, c), label: statusLabel(b, c, nowMs) });
      } catch { /* 표시 전용 — 이 줄만 빼고 간다 */ }
    }
    hits.sort((a, b) => b.t - a.t);
    return joinGuests(mergeByName(hits));
  } catch {
    return '';
  }
}

/**
 * 한 객실의 차이를 낸다.
 * @param {object} o { want:Set<date>, have:Map<date,state>, dates:string[], wasClosedByUs:(date)=>boolean }
 * @returns {{toClose:string[], toOpen:string[], sold:string[], notFound:string[]}}
 */
export function diffRoom({ want, have, dates, wasClosedByUs }) {
  const toClose = [], toOpen = [], sold = [], notFound = [];
  for (const d of dates) {
    const state = have.get(d);
    if (state === undefined) { notFound.push(d); continue; }
    if (state === 'sold') { sold.push(d); continue; }        // 채널에 든 예약 — 손대지 않는다
    if (state === 'unknown') { notFound.push(d); continue; }  // 못 알아본 상태 문구 — 건드리지 않는다(BR-015)
    if (want.has(d)) { if (state === 'open') toClose.push(d); continue; }
    if (state === 'closed' && wasClosedByUs(d)) toOpen.push(d);
  }
  return { toClose, toOpen, sold, notFound };
}

/* 날짜를 달별로 묶는다. `setClosed` 는 반영 뒤 확인하려고 **첫 날~끝 날 전체**를 다시 읽으므로,
   9월 3일과 이듬해 2월 1일을 한 번에 넘기면 여섯 달 치를 두 번 읽는다. 달별로 나눠 부른다. */
export function byMonth(dates) {
  const groups = new Map();
  for (const d of dates) {
    const k = d.slice(0, 7);
    if (!groups.has(k)) groups.set(k, []);
    groups.get(k).push(d);
  }
  return [...groups.values()];
}

/**
 * @param board  교차 검사 보드(engine/crosscheck.js SoldBoard) — 코디네이터가 붙인 워커만 넘긴다. 없으면 예전과 한 줄도 다르지 않다.
 * @returns {Promise<{ok:boolean, closed:number, opened:number, rooms:number, skipped?:string, error?:string}>}
 */
export async function runCalendar({ channel, adapter, dashboard, log, state, cfg, now = new Date(), board }) {
  const startedAt = now;
  const today = todayKst(now);
  const horizon = cfg?.calendar?.horizonDays ?? 180;
  const from = today;
  const to = addDays(today, horizon);
  const out = { ok: true, closed: 0, opened: 0, rooms: 0 };
  try {
    const map = new Map();
    for (const m of await dashboard.roomMap(channel)) {
      if (!map.has(m.resource_id)) map.set(m.resource_id, []);
      map.get(m.resource_id).push(m.channel_room_key);
    }
    if (!map.size) return { ...out, skipped: '객실 매핑이 없다' };
    /* 일은 코드로 하고 **보여 주는 것만 이름으로** 한다(room-label.js 머리말).
       621393 이 어느 방인지는 사장님이 알 수 없다 — 화면에도 로그에도 이름을 붙인다. */
    const label = await loadRoomLabels(dashboard, map);
    /* 화면에 이미 적혀 있는 옛 줄도 이름으로 고친다 — 이름은 적힐 때 붙어서, 새 판을 깔아도
       옛 줄은 코드 그대로 남아 있었다(2026-09-16). 여기가 주기마다 도는 자리라 곧 다 고쳐진다. */
    state.relabelRecent?.((v) => label.forKey(v));

    const book = await dashboard.bookings(from, to);
    if (!book.ok) {
      log.error(`${channel}: 캘린더 대조를 건너뛴다 — ${book.why}`);
      await dashboard.openAlert({ kind: 'sync_stale', channel,
        detail: { reason: book.why.slice(0, 200), source: 'calendar' } }).catch(() => {});
      return { ...out, ok: false, skipped: book.why };
    }
    const rateCal = await dashboard.rateCalendar(from, to).catch((e) => { log.warn(`${channel}: 날짜 요금을 못 읽었다 — ${e.message}`); return []; });
    const want = blockedDates({ bookings: book.rows, cols: book.cols, rateCal, from, to });
    const who = stayGuests({ bookings: book.rows, cols: book.cols, from, to });
    /* 다시 열기 줄의 까닭을 가리려고 '지금 살아 있는 예약' 을 이 PC 메모리에 적어 둔다(recentCancelGuests 머리말).
       표시 전용 — 막고 여는 판단에는 안 쓴다. 던지지 않는다. */
    const seenLive = liveMemory(state);
    rememberLive({ seenLive, bookings: book.rows, cols: book.cols, nowMs: now.getTime() });
    const rate = closedByRate({ rateCal, from, to });
    /* ★ 이름 칸을 못 알아봤으면 **한 번 말한다.** 안 그러면 화면에 이름이 영영 안 뜨는데
         사장님은 왜인지 알 수가 없다(2026-09-16 실제로 그랬다). 값은 안 찍는다 — 칸 이름만. */
    if (book.rows?.length && !book.cols?.guestName && !book.cols?.groupName) {
      const seen = Object.keys(book.rows[0] || {}).join(', ');
      if (!state.saidBefore?.('bookingGuestCol', seen)) {
        log.warn(`${channel}: 예약표에서 예약자 이름 칸을 못 알아봤다 — 화면의 '품절처리' 줄에 이름이 안 나온다.` +
          ` 줄에 있던 칸 이름: ${seen}`);
      }
    }

    /* 판매현황은 한 번만 읽는다(달마다 한 번씩 부른다). 객실 수만큼 다시 읽으면 주기를 넘긴다. */
    const cells = await adapter.readAvailability({ from, to });
    const byKey = new Map();
    for (const c of cells) {
      if (!byKey.has(c.roomKey)) byKey.set(c.roomKey, new Map());
      byKey.get(c.roomKey).set(c.date, c.state);
    }
    /* ★ 두 타워 교차 검사(2026-09-23) — 방금 읽은 판매현황을 **막기·열기보다 먼저** 보드에 맡긴다.
         보드는 받아 두기만 하고 곧바로 돌아온다(비교·경보는 브라우저 줄 밖에서 돈다) — 이 판을 늦추지 않는다.
         보드가 하는 일은 대 보고 알리는 것뿐이다 — 다른 채널을 막거나(setClosed) 우리가 막았다고 적지(markClosedByUs) 않는다.
         스냅샷은 **보드 쪽에서** 만든다(crosscheck.js soldSnapshot) — 이 파일이 새 파일을 import 하면, 이 파일만 덮어쓴
         반쪽 배포에서 연결이 깨져 캘린더(막기·열기)가 통째로 안 뜬다. 던져도 이 판은 그대로 간다. */
    if (board && typeof board.put === 'function') {
      try {
        board.put({ channel, cells, map, book, from, to, readAt: Date.now(), ledgerAt: startedAt.getTime(), states: adapter.spec?.availability?.states,
          roomName: (rid) => label.forResource(rid) });
      } catch (e) {
        log.debug(`${channel}: 교차 검사 스냅샷 실패 — ${e.message}`);
      }
    }
    const dates = eachDate(from, to);

    /* ★ **다시 여는 것만** 한 번 더 확인한다.
         막는 쪽은 틀려도 그 밤을 못 파는 것으로 끝나지만, 여는 쪽은 틀리면 **그 밤이 또 팔린다**(오버부킹).
         원장을 한 번 짧게 읽으면(조회가 흔들리거나 한 페이지만 오면) 예약이 사라진 것처럼 보이는데,
         지금까지는 그대로 열었다 — 유입에는 있는 '갑자기 줄었으면 멈춘다' 가 여기엔 없었다(2026-09-15).

         그래서 열기 직전에 **원장을 한 번 더 읽어** 정말 사라졌는지 본다. 한 주기에 한 번만 읽고
         (열 것이 있을 때만) 그 결과를 돌려 쓴다. 두 번째 읽기가 "아직 막을 날" 이라고 하면 이번 판은
         안 열고 경보를 남긴다 — 다음 주기가 새로 읽어 다시 판단하므로 정상 취소가 막히지는 않는다.
         두 번째 읽기 자체가 실패해도 안 연다. 확인 못 한 것을 여는 것이 가장 나쁘다(D-004). */
    let recheck;   // undefined = 아직 안 읽음 · false = 못 읽음 · Map = 두 번째로 읽은 '막을 날'
    const confirmOpen = async (resourceId, wantOpen) => {
      if (recheck === undefined) {
        const again = await dashboard.bookings(from, to).catch((e) => ({ ok: false, why: e.message }));
        if (!again || !again.ok) recheck = false;
        else {
          const rc = await dashboard.rateCalendar(from, to).catch(() => []);
          recheck = blockedDates({ bookings: again.rows, cols: again.cols, rateCal: rc, from, to });
        }
      }
      if (recheck === false) return { ok: false, why: '원장을 다시 읽지 못했다' };
      const still = wantOpen.filter((x) => (recheck.get(resourceId) || new Set()).has(x));
      if (still.length) {
        return { ok: false, why: `다시 읽은 원장에는 ${still.length}일이 아직 막을 날이다(${still.slice(0, 3).join(', ')})` };
      }
      return { ok: true };
    };

    for (const [resourceId, roomKeys] of map) {
      const w = want.get(resourceId) || new Set();
      for (const roomKey of roomKeys) {
        const have = byKey.get(roomKey);
        if (!have || !have.size) { log.warn(`${channel}: ${label.both(roomKey)} 가 파트너센터 판매현황에 없다 — 매핑을 확인할 것(I-021)`); continue; }
        out.rooms++;
        const d = diffRoom({ want: w, have, dates, wasClosedByUs: (date) => state.wasClosedByUs(channel, roomKey, date) });
        if (d.toClose.length) {
          let applied = 0;
          for (const chunk of byMonth(d.toClose)) {
            const r = await adapter.setClosed({ roomKey, dates: chunk, closed: true });
            // 파트너센터에서 못 찾은 날은 "우리가 막았다" 로 기억하지 않는다 — 나중에 그 날을 열어 버리면 안 된다
            state.markClosedByUs(channel, roomKey, chunk.filter((x) => !r.skipped.some((s) => s.date === x && s.why === SKIP_NOT_FOUND)));
            applied += r.applied;
          }
          out.closed += applied;
          /* 화면의 '방금 한 일' 목록 — 대시보드 → 여기어때 방향(이 PC 에만 남는다, state.js 머리말).
             2026-09-23: who 에는 예약 상태가 접혀 들어 있다 — 'Hyeonjun Park(임시품절)', 이름 없는 차단은 '차단'.
             ⚠ 이름·라벨은 이 화면 기록에만 간다 — 아래 log.info 에는 넣지 않는다(BR-020). */
          if (applied) {
            const by = guestsFor(who, resourceId, d.toClose)
              || (allFromRate(rate, resourceId, d.toClose) ? '만실' : '');
            state.addRecentOutbound?.(channel, [{ roomName: label.forKey(roomKey), dates: d.toClose,
              guestName: by, action: '품절처리' }]);
          }
          log.info(`${channel}: ${label.both(roomKey)} ${applied}일 막음 (대시보드에 예약·만실) — ${d.toClose.slice(0, 5).join(', ')}${d.toClose.length > 5 ? ` 외 ${d.toClose.length - 5}일` : ''}`);
        }
        if (d.toOpen.length) {
          /* 여기서만 두 번 읽는다 — 되돌리기 어려운 쪽이라서다(위 머리말). */
          const sure = await confirmOpen(resourceId, d.toOpen);
          if (!sure.ok) {
            log.warn(`${channel}: ${label.both(roomKey)} ${d.toOpen.length}일을 다시 열지 않았다 — ${sure.why}` +
              ' (잘못 열면 그 밤이 또 팔린다. 다음 주기에 새로 읽어 다시 본다)');
            await dashboard.openAlert({ kind: 'sync_stale', channel, resourceId, onDate: d.toOpen[0],
              detail: { reason: `다시 열기를 멈췄다 — ${sure.why}`, source: 'calendar' } }).catch(() => {});
            continue;
          }
          const opening = d.toOpen;
          let applied = 0;
          for (const chunk of byMonth(opening)) {
            const r = await adapter.setClosed({ roomKey, dates: chunk, closed: false });
            state.forgetClosedByUs(channel, roomKey, chunk);
            applied += r.applied;
          }
          out.opened += applied;
          /* 다시 연 까닭 — 최근 취소가 있으면 '이름(결제취소)' 처럼 적는다(표시 전용, 2026-09-23 사장님 요청).
             ⚠ 이름·라벨은 이 화면 기록에만 간다 — 아래 log.info 에는 넣지 않는다(BR-020). */
          if (applied) {
            const why = recentCancelGuests({ bookings: book.rows, cols: book.cols, resourceId, dates: opening, nowMs: now.getTime(), seenLive });
            state.addRecentOutbound?.(channel, [{ roomName: label.forKey(roomKey), dates: opening, guestName: why, action: '다시 열기' }]);
          }
          log.info(`${channel}: ${label.both(roomKey)} ${applied}일 다시 열었다 (대시보드에서 사라진 예약 — 원장을 두 번 읽어 확인했다) — ${opening.slice(0, 5).join(', ')}${opening.length > 5 ? ` 외 ${opening.length - 5}일` : ''}`);
        }
      }
    }
    state.pruneClosedByUs(today);
    if (out.closed || out.opened) {
      await dashboard.recordRun({ channel, kind: 'outbound', startedAt, finishedAt: new Date(), ok: true,
        detail: { mode: 'calendar', closed: out.closed, opened: out.opened, rooms: out.rooms } }).catch(() => {});
    }
    return out;
  } catch (e) {
    const human = e instanceof NeedsHumanError;
    log.error(`${channel}: 캘린더 대조 실패 — ${e.message}`);
    await dashboard.recordRun({ channel, kind: 'outbound', startedAt, finishedAt: new Date(), ok: false,
      detail: { mode: 'calendar', error: String(e.message).slice(0, 300) } }).catch(() => {});
    await dashboard.openAlert({ kind: 'sync_stale', channel,
      detail: { reason: human ? '2단계 인증 필요 — 페어링 다시' : forDashboard(e.message), source: 'calendar' } }).catch(() => {});
    return { ...out, ok: false, error: e.message, needsHuman: human };
  }
}
