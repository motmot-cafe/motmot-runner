/* 두 타워 동시 판매 검사 — (나) (2026-09-23).

   사장님 그림: "클라이언트 하나에 두 컨트롤타워, 클라이언트가 최종 체크 후 대시보드와 연결".
     타워 = 채널 워커(여기어때·야놀자). 각 타워의 캘린더 판이 이미 읽은 파트너센터 판매현황을 이 보드에 맡기고,
     보드(클라이언트의 최종 체크)가 타워끼리 대 본다. 대시보드와는 **경보로만** 이어진다.

   ★ 새 파트너센터 읽기가 없다. 캘린더 판이 막기·열기 전에 읽은 것(cells)을 그대로 받는다.
   ★ 쓰는 것은 경보뿐이다. 다른 채널을 막거나(setClosed) '우리가 막았다'(markClosedByUs·closedByUs)를 적지 않는다.
     그 지름길은 원장을 건너뛴다 — 다음 판 diffRoom 이 원장에 이유가 없다며 다시 열어 막음→엶→막음으로 깜빡이고,
     그 사이에 팔린다. 막을지 열지는 지금처럼 각 타워의 runCalendar 만 정한다(D-005 원장은 대시보드).
   ★ 원장을 먼저 채운다. 한쪽에만 팔린 밤이 원장에 없으면, 빠진 채널의 유입을 한 번 앞당겨(채널당 30분에 한 번)
     원장에 넣는다. 둘 다 원장에 들어가면 서버 findOverbookings 가 경보를 연다 — 서버 몫이다.
   ★ 잠긴 채널은 검사에 들지 않는다. 코디네이터가 잠긴 워커에는 보드를 안 달아 스냅샷이 안 올라온다
     (안전 패치: 잠긴 동안 상주는 판매현황도 안 읽는다). 그래서 지금(야놀자 잠금)은 비교가 한 번도 안 돈다.
   ★ 기본 모드는 log(warn 한 줄). alert 는 **서버 선행 패치(api/ota.mjs byRunner) 뒤에만** 켠다 — 없으면 서버가
     2~15분마다 닫고 우리가 다시 열어 새 id·새 푸시가 반복된다. 자동 차단기가 그것을 보면 스스로 log 로 내린다.
   ⚠ 손님 정보(이름·전화·예약번호·메모)는 스냅샷·로그·경보 detail 어디에도 없다(BR-020). 원장은 **건수와 채널 코드만** 센다.
     스냅샷은 이 프로세스 메모리에만 있다 — 디스크·클라우드·로그로 안 나간다.

   검토 반영(2026-09-23):
   ★ 확정한 (방, 밤)은 기억한다(confirmed, 6시간 — warn 되풀이 막기와 같은 길이). 그동안은 다시 읽기 부탁·강제 유입을 안 한다.
     안 그러면 두 채널이 같은 밤을 계속 sold 로 보여 주는 동안(여기어때 재고 0, 두 파트너센터 수기 예약, 미매핑 — 부록 '오탐')
     여기어때 판(5분)마다 야놀자를 다시 읽게 해 야놀자 캘린더가 15분 → 5분으로 돌아가고, 30분마다 두 채널 유입을 찔렀다.
     한쪽에서 clear(명시적으로 열림·막힘)로 보이거나 6시간이 지나면 잊는다 — 그 뒤 다시 sold 면 처음부터 확인한다.
   ★ 다시 읽기 부탁은 의심 하나에 한 번이다(의심을 새로 적을 때만). 그 뒤는 받침 규칙이 정기 판으로 확정한다.
   ★ 원장을 채우는 찌르기는 inbound() — force 없이. 목록이 지난 저장 때와 같으면(해시) 원장에 다시 쓰지 않는다
     (같은 목록을 다시 보내도 원장에 없는 예약이 생기지 않는다). 목록 읽기만 앞당긴다.
   ★ alert 모드는 처음 비교 때 열린 우리 경보(detail.source 'crosscheck')를 한 번 읽어 기억에 넣는다 —
     재시작 전에 연 경보도 풀리면 닫는다(기억이 메모리에만 있어 영영 안 닫히던 것). */
import { bookingIsLive } from '../dashboard/client.js';
import { addDays, dayKst, todayKst } from '../lib/kst.js';

const YMD = /^\d{4}-\d{2}-\d{2}$/;
const HOUR_MS = 3600000;
const SIX_HOURS_MS = 6 * HOUR_MS;
/* 결제가 안 되면 풀리는 가예약. 방은 실제로 잡혀 있어 경보는 열되 label·states 로 구분되게 남긴다. */
const PENDING_WORDS = new Set(['PAYMENT_PENDING', '입금대기']);

/* 판매현황 원문(raw.state) → spec 의 sold 목록 **낱말 자체**. 원문의 다른 글자는 복사하지 않는다. 못 맞추면 'sold'. */
export function soldWord(raw, states) {
  const text = String(raw?.state ?? '').trim();
  const list = states && Array.isArray(states.sold) ? states.sold.filter((w) => typeof w === 'string' && w.trim()) : [];
  if (!text) return 'sold';
  const up = text.toUpperCase();
  for (const w of list) if (w.trim().toUpperCase() === up) return w;
  /* 부분 문자열로 읽는 채널(여기어때 — exact 아님)은 normalizeState 처럼 긴 낱말부터. */
  if (states?.exact !== true) {
    for (const w of [...list].sort((a, b) => b.length - a.length)) if (text.includes(w)) return w;
  }
  return 'sold';
}

function put2(m, a, b, v) {
  if (!m.has(a)) m.set(a, new Map());
  m.get(a).set(b, v);
}
function add2(m, a, b) {
  if (!m.has(a)) m.set(a, new Set());
  m.get(a).add(b);
}

/**
 * 캘린더 한 판이 읽은 판매현황 → 비교용 스냅샷(순수 함수).
 * @param o { channel, cells:[{roomKey,date,state,raw}], map:Map<resourceId, roomKey[]>, book:{ok,rows,cols}, from, to, readAt, states, roomName? }
 * @returns { channel, readAt, from, to, cellCount, soldCount, dupKeys:string[], ledgerKnown,
 *            sold: Map<rid, Map<date, {word, remain?, keys}>>, clear: Map<rid, Set<date>>,
 *            ledger: Map<rid, Map<date, {live, channels}>>, names: Map<rid, 객실명> }
 * ★ sold: 그 방에 매핑된 키 중 **하나라도** sold 면 sold — 같은 채널의 여러 상품(연박·조식)은 한 번만 센다.
 * ★ clear: 그 방의 모든 키가 명시적으로 open 또는 closed 로 읽힌 날. undefined·unknown 은 clear 가 아니다.
 * ★ 키 하나가 방 둘 이상에 붙어 있으면 그 키를 뺀다(dupKeys — 보드가 로그로 알린다).
 * ⚠ 예약 줄(book.rows)에서는 건수·채널 코드만 꺼낸다. 이름·연락처·예약번호·메모는 담지 않는다(BR-020).
 */
export function soldSnapshot({ channel, cells, map, book, from, to, readAt, ledgerAt, states, roomName }) {
  const pairs = map instanceof Map ? [...map] : [...(map || [])];
  const ridsOfKey = new Map();
  for (const [rid, keys] of pairs) for (const k of new Set((keys || []).map(String))) add2(ridsOfKey, k, String(rid));
  const dupKeys = [...ridsOfKey].filter(([, s]) => s.size > 1).map(([k]) => k).sort();
  const dup = new Set(dupKeys);

  const byKey = new Map();
  let cellCount = 0;
  let soldCount = 0;
  for (const c of cells || []) {
    if (!c || typeof c.date !== 'string' || !YMD.test(c.date)) continue;
    if ((from && c.date < from) || (to && c.date >= to)) continue;
    cellCount++;
    if (c.state === 'sold') soldCount++;
    put2(byKey, String(c.roomKey ?? ''), c.date, c);
  }

  const sold = new Map();
  const clear = new Map();
  const names = new Map();
  for (const [ridRaw, keysRaw] of pairs) {
    const rid = String(ridRaw);
    const keys = [...new Set((keysRaw || []).map(String))].filter((k) => !dup.has(k));
    if (!keys.length) continue;
    const days = new Set();
    for (const k of keys) for (const d of byKey.get(k)?.keys() || []) days.add(d);
    for (const d of [...days].sort()) {
      const at = keys.map((k) => byKey.get(k)?.get(d));
      const soldAt = keys.filter((k, i) => at[i] && at[i].state === 'sold');
      if (soldAt.length) {
        const cellsSold = at.filter((c) => c && c.state === 'sold');
        const words = cellsSold.map((c) => soldWord(c.raw, states));
        /* 예약완료가 하나라도 있으면 그것 — 입금대기보다 센 증거다. */
        const word = words.find((w) => !PENDING_WORDS.has(w)) ?? words[0];
        const remains = cellsSold.map((c) => c.raw?.remain).filter((v) => Number.isFinite(v));
        const e = { word, keys: soldAt };
        if (remains.length) e.remain = Math.min(...remains);
        put2(sold, rid, d, e);
        if (!names.has(rid)) {
          let n = rid;
          try { n = typeof roomName === 'function' ? String(roomName(rid) || rid) : rid; } catch { n = rid; }
          names.set(rid, n);
        }
      } else if (at.every((c) => c && (c.state === 'open' || c.state === 'closed'))) {
        add2(clear, rid, d);
      }
    }
  }

  /* 원장 건수 — sold 인 (방, 밤)만 센다. 원장을 못 읽은 판이면 ledgerKnown:false(모름 ≠ 0건, BR-019). */
  const ledger = new Map();
  const ledgerKnown = !!(book && book.ok !== false && Array.isArray(book.rows) && book.cols);
  if (ledgerKnown && sold.size) {
    const c = book.cols;
    const byRid = new Map();
    for (const b of book.rows) {
      try {
        if (!b || typeof b !== 'object' || !bookingIsLive(b, c)) continue;
        const rid = String(b[c.resourceId] ?? '');
        if (!sold.has(rid)) continue;
        const ci = dayKst(b[c.checkIn]);
        if (!YMD.test(ci)) continue;
        const co = dayKst(b[c.checkOut]);
        const end = YMD.test(co) && co > ci ? co : addDays(ci, 1);
        const chRaw = c.channel ? b[c.channel] : undefined;
        const ch = typeof chRaw === 'string' ? chRaw.trim().toLowerCase() : '';
        if (!byRid.has(rid)) byRid.set(rid, []);
        byRid.get(rid).push({ ci, end, ch });
      } catch { /* 이상한 줄 하나는 그 줄만 뺀다 */ }
    }
    for (const [rid, dm] of sold) {
      for (const d of dm.keys()) {
        const hits = (byRid.get(rid) || []).filter((x) => d >= x.ci && d < x.end);
        put2(ledger, rid, d, { live: hits.length, channels: [...new Set(hits.map((x) => x.ch).filter(Boolean))].sort() });
      }
    }
  }

  /* ledgerAt — 원장(book)을 읽기 시작한 시각(캘린더 판 시작). 강제 유입이 끝난 **뒤에** 읽은 원장인지 가를 때 쓴다. */
  return { channel, readAt, ledgerAt: Number.isFinite(ledgerAt) ? ledgerAt : readAt, from, to, cellCount, soldCount, dupKeys, ledgerKnown, sold, clear, ledger, names };
}

/**
 * 타워끼리 스냅샷을 대 보는 보드. 코디네이터(coordinator.js)가 만들어 잠기지 않은 워커에만 단다.
 * put() 은 받아 두기만 하고 곧바로 돌아온다 — 비교·경보는 setImmediate 로 브라우저 줄 **밖**에서 돈다.
 */
export class SoldBoard {
  /**
   * @param o { cfg, dashboard, log, workers:Map<channel, worker>, requestCalendar(ch, why), freshSecOf(ch), now?, defer? }
   */
  constructor({ cfg, dashboard, log, workers, requestCalendar, freshSecOf, now = () => Date.now(), defer }) {
    const cc = cfg?.crosscheck || {};
    this.cfg = cfg || {};
    this.dashboard = dashboard;
    this.log = log;
    this.workers = workers instanceof Map ? workers : new Map();
    this.requestCalendar = requestCalendar || (() => false);
    this.freshSecOf = freshSecOf || (() => (cc.freshSec ?? 600));
    this.now = now;
    this.defer = defer || ((fn) => setImmediate(fn));
    this.mode = cc.mode === 'alert' ? 'alert' : cc.mode === 'off' ? 'off' : 'log';
    this.confirmGapMs = (cc.confirmGapSec ?? 180) * 1000;
    this.pokeMs = (cc.inboundPokeMin ?? 30) * 60000;
    this.sanityMax = cc.sanityMax ?? 10;
    this.snaps = new Map();       // channel → { cur, prev }
    this.suspect = new Map();     // 'rid|date' → 의심을 적은 시각
    this.alerted = new Map();     // 'rid|date' → { id, ours, rid, date, channels }
    this.confirmed = new Map();   // 'rid|date' → 확정한 시각(이 동안은 다시 읽기·찌르기 안 함)
    this.mutedAt = new Map();     // 'rid|date' → 「자체 해결」로 덮인 것을 본 시각(한 시간은 덮개 목록을 다시 안 읽는다)
    this.confirmTtlMs = SIX_HOURS_MS;
    this.seeded = false;          // alert: 열린 우리 경보를 한 번 읽어 기억에 넣었나
    this.pokes = new Map();       // channel → { at: 강제 유입을 부른 시각, doneAt: 그 유입이 끝난 시각(null = 도는 중) }
    this.said = new Map();        // 로그 열쇠 → 마지막으로 남긴 시각(되풀이 막기)
    this.staleSaid = new Set();
    this.closedByOthers = [];     // 우리 경보가 조건 그대로인데 남에게 닫힌 시각들(자동 차단기)
    this.chain = Promise.resolve();
    this.queued = 0;
    this.stopped = false;
  }

  /** 캘린더 판이 읽은 것을 맡긴다. 스냅샷을 만들어 두고 곧바로 돌아온다. */
  put(input) {
    if (this.stopped || this.mode === 'off') return null;
    const snap = soldSnapshot(input || {});
    const ch = snap.channel;
    if (!ch) return null;
    for (const k of snap.dupKeys) {
      this.#sayEvery(`dup|${ch}|${k}`, SIX_HOURS_MS, 'warn',
        `교차 검사: ${ch} 객실 코드 ${k} 가 우리 방 둘 이상에 매핑돼 있어 동시 판매 검사에서 뺀다 — 매핑을 확인할 것(이 경우 서버 오버부킹 경보도 가짜일 수 있다)`);
    }
    const slot = this.snaps.get(ch);
    this.snaps.set(ch, { cur: snap, prev: slot ? slot.cur : null });
    this.queued++;
    this.defer(() => {
      this.queued--;
      if (this.stopped) return;
      this.chain = this.chain.then(() => this.compare(ch)).catch((e) => this.log.debug(`교차 검사 실패 — ${e.message}`));
    });
    return snap;
  }

  /** 시험·정지용 — 맡겨 둔 비교가 모두 끝날 때까지 기다린다. */
  async flush() {
    for (let i = 0; i < 1000 && this.queued > 0; i++) await new Promise((r) => setImmediate(r));
    await this.chain;
  }

  stop() { this.stopped = true; }

  statusText() {
    return `검사 ${this.mode}${this.alerted.size ? ` · 교차 경보 ${this.alerted.size}` : ''}`;
  }

  #sayEvery(key, everyMs, level, msg) {
    const now = this.now();
    const last = this.said.get(key);
    if (last != null && now - last < everyMs) return false;
    this.said.set(key, now);
    this.log[level]?.(msg);
    return true;
  }

  #fresh(S, now) {
    return !!S && now - S.readAt <= this.freshSecOf(S.channel) * 1000;
  }

  /* 두 창이 겹치는 날 중 오늘 이후, 같은 방(resourceId)이 두 채널에서 모두 sold 인 (방, 밤). */
  #candidates(X, Y, today) {
    const lo = [X.from, Y.from, today].filter(Boolean).sort().pop();
    const hi = [X.to, Y.to].filter(Boolean).sort()[0];
    const out = [];
    for (const [rid, dx] of X.sold) {
      const dy = Y.sold.get(rid);
      if (!dy) continue;
      for (const [d, ex] of dx) {
        if (d < lo || (hi && d >= hi)) continue;
        const ey = dy.get(d);
        if (!ey) continue;
        out.push({ key: `${rid}|${d}`, rid, date: d, x: ex, y: ey });
      }
    }
    return out.sort((a, b) => (a.key < b.key ? -1 : a.key > b.key ? 1 : 0));
  }

  /* 판 단위 읽기 고장 — 칸의 절반 넘게 sold 면 모르는 문구가 sold 로 걸렸을 가능성이 크다. */
  #broken(S) {
    return S.cellCount > 0 && S.soldCount > S.cellCount / 2;
  }

  /* 두 판 중 **나중에 읽은** 원장. at = 그 원장을 읽기 시작한 시각. */
  #ledgerOf(X, Y, rid, date) {
    const order = [X, Y].sort((a, b) => b.readAt - a.readAt);
    for (const S of order) if (S.ledgerKnown) return { ...(S.ledger.get(rid)?.get(date) || { live: 0, channels: [] }), at: S.ledgerAt };
    return null;
  }

  #roomOf(X, Y, rid) {
    return X.names.get(rid) || Y.names.get(rid) || rid;
  }

  /** 채널 X 의 새 스냅샷을 다른 채널들의 최신 스냅샷과 대 본다. */
  async compare(chX) {
    if (this.stopped || this.mode === 'off') return;
    const X = this.snaps.get(chX)?.cur;
    if (!X) return;
    const now = this.now();
    const today = todayKst(new Date(now));
    /* 기억 정리 — 사라진 후보의 의심·오래된 로그 열쇠가 상주 내내 쌓이지 않게(의심은 한 시간이면 두 판을 넉넉히 다시 읽는다). */
    for (const [k, at] of this.suspect) if (now - at > HOUR_MS) this.suspect.delete(k);
    for (const [k, at] of this.said) if (now - at > 2 * SIX_HOURS_MS) this.said.delete(k);
    for (const [k, at] of this.confirmed) if (now - at >= this.confirmTtlMs) this.confirmed.delete(k);
    for (const [k, at] of this.mutedAt) if (now - at >= HOUR_MS) this.mutedAt.delete(k);
    /* 확정한 밤이 이 채널에서 clear 로 보이면 잊는다 — 다시 sold 가 되면 새 일이라 처음부터 확인한다. */
    for (const k of [...this.confirmed.keys()]) {
      const i = k.lastIndexOf('|');
      if (X.clear.get(k.slice(0, i))?.has(k.slice(i + 1))) this.confirmed.delete(k);
    }
    if (this.mode === 'alert' && !this.seeded) await this.#seed();
    await this.#reviewAlerted(now);
    for (const [chY, slotY] of this.snaps) {
      if (chY === chX) continue;
      const Y = slotY.cur;
      if (!Y) continue;
      if (!this.#fresh(Y, now) || !this.#fresh(X, now)) {
        const stale = !this.#fresh(Y, now) ? Y : X;
        if (!this.staleSaid.has(stale.channel)) {
          this.staleSaid.add(stale.channel);
          this.log.debug(`교차 검사: ${stale.channel} 판매현황이 ${Math.round((now - stale.readAt) / 1000)}초 묵어 대 보지 않는다`);
        }
        continue;
      }
      this.staleSaid.delete(X.channel);
      this.staleSaid.delete(Y.channel);
      const cands = this.#candidates(X, Y, today);
      if (!cands.length) continue;
      if (this.#broken(X) || this.#broken(Y) || cands.length > this.sanityMax) {
        const bad = this.#broken(Y) && !this.#broken(X) ? Y : X;
        this.#sayEvery(`sanity|${bad.channel}`, SIX_HOURS_MS, 'warn',
          `교차 검사: ${bad.channel} 판매현황 읽기가 이상하다(칸 ${bad.cellCount} 중 sold ${bad.soldCount}, 겹치는 후보 ${cands.length}) — ` +
          '읽기 고장으로 보고 이번 판 후보를 전부 버린다(경보 안 연다). 판매현황 문구가 바뀌었는지 볼 것');
        continue;
      }
      for (const c of cands) await this.#handle(c, X, Y, now);
    }
  }

  /* 후보 하나(rid|date)의 차례 — 원장을 먼저 채운다(설계 3-3). */
  async #handle(c, X, Y, now) {
    const room = this.#roomOf(X, Y, c.rid);
    const L = this.#ledgerOf(X, Y, c.rid, c.date);
    if (!L) { this.log.debug(`교차 검사: ${room} ${c.date} — 원장을 못 읽은 판이라 대 보지 않는다`); return; }
    /* 1. 원장이 이미 안다 → 서버 findOverbookings 가 경보를 연다. 우리는 아무것도 안 한다. */
    if (L.live >= 2) {
      this.suspect.delete(c.key);
      this.confirmed.delete(c.key);
      this.log.debug(`교차 검사: ${room} ${c.date} — 원장에 ${L.live}건, 서버 몫`);
      return;
    }
    /* 이미 경보가 열려 있다(우리 것·서버 것) — 다시 읽기·찌르기를 되풀이할 까닭이 없다. 풀림은 #reviewAlerted 가 본다. */
    if (this.alerted.has(c.key)) { this.suspect.delete(c.key); return; }
    /* 이미 확정했다(6시간) — 다시 읽기·강제 유입을 되풀이하지 않는다(야놀자 캘린더를 5분마다 불러 사장님 15분을 무너뜨렸다).
       alert 면 닫혀 있을 때만 다시 연다 — 사장님이 ✕ 로 닫았는데 여전히 둘 다 sold 면 다시 뜬다(3-5, 덮개는 #openCross 가 본다). */
    const conf = this.confirmed.get(c.key);
    if (conf != null && now - conf < this.confirmTtlMs) {
      this.suspect.delete(c.key);
      if (this.mode === 'alert') await this.#openCross(c, X, Y, L, room, now);
      return;
    }
    /* 2. 원장이 모른다 → 원장 채널 목록에 없는 쪽 채널의 유입을 한 번 앞당긴다(채널마다 N분에 한 번).
         ★ 그 유입이 **끝나고 그 뒤에 읽은 원장**이 올 때까지 확정을 미룬다(hold). 한 판에 비교가 채널마다 한 번씩 돌므로,
           '이번 비교만 미룸' 이면 다른 채널의 비교가 곧바로 확정해 버린다 — 원장을 먼저 채운다는 뜻이 사라진다. */
    let hold = false;
    for (const ch of [X.channel, Y.channel]) if (!L.channels.includes(ch) && this.#poke(ch, now, L.at) === 'hold') hold = true;
    /* 3. 시각 차 — 두 판이 가까이 읽혔으면 확정 후보. 아니면 묵은 쪽을 다시 읽게 부탁하고 다음 판에 본다. */
    let confirmed = Math.abs(X.readAt - Y.readAt) <= this.confirmGapMs;
    if (!confirmed) {
      const s = this.suspect.get(c.key);
      /* 받침: 두 판이 모두 의심을 적은 뒤에 읽혔는데 여전히 둘 다 sold 면 확정(비켜 주기로 찌르기가 안 돌 때도 잡힌다). */
      if (s != null && X.readAt > s && Y.readAt > s) confirmed = true;
      else {
        /* 다시 읽기 부탁은 의심을 **새로 적을 때 한 번**만 — 그 뒤는 받침 규칙이 정기 판으로 확정한다. */
        if (s == null) {
          this.suspect.set(c.key, now);
          const older = X.readAt <= Y.readAt ? X : Y;
          this.log.debug(`교차 검사: ${room} ${c.date} 두 판의 시각 차 ${Math.round(Math.abs(X.readAt - Y.readAt) / 1000)}초 — ${older.channel} 를 다시 읽어 확인한다`);
          try { this.requestCalendar(older.channel, 'crosscheck'); } catch { /* 코디네이터 쪽 실패로 검사를 멈추지 않는다 */ }
        }
        return;
      }
    }
    if (hold) {
      this.log.debug(`교차 검사: ${room} ${c.date} — 원장을 먼저 채운다(강제 유입이 끝난 뒤 읽은 원장으로 다시 본다)`);
      return;
    }
    this.suspect.delete(c.key);
    this.confirmed.set(c.key, now);
    /* 4. 확정됐는데 원장은 여전히 모른다(날짜·객실이 바뀐 같은 번호, 미매핑, 수기 예약 …) — 서버가 못 보는 경우다. */
    if (this.mode === 'alert') await this.#openCross(c, X, Y, L, room, now);
    else {
      this.#sayEvery(`log|${c.key}`, SIX_HOURS_MS, 'warn',
        `교차 검사: 동시 판매 의심 — ${room} ${c.date} · ${X.channel} ${c.x.word} · ${Y.channel} ${c.y.word} · 원장 ${L.live}건` +
        ` — 경보는 안 연다(CROSSCHECK=log). 두 파트너센터에서 이 방·이 밤을 확인할 것`);
    }
  }

  /* 'hold' = 강제 유입을 지금 불렀거나 아직 그 결과가 원장 읽기에 안 들어왔다 · 'go' = 더 기다릴 것 없다(찌를 수 없거나 이미 반영). */
  #poke(ch, now, ledgerAt) {
    const w = this.workers.get(ch);
    if (!w || w.writesLocked || w.previewOnly || w.stopped) return 'go';
    if (this.cfg.dashboard?.inboundOn === false) return 'go';
    const p = this.pokes.get(ch);
    if (p && now - p.at < this.pokeMs) {
      /* 이 창 안에서는 다시 안 찌른다. 부른 유입이 끝났고 그 뒤에 읽은 원장이면 기다릴 것 없다. */
      return p.doneAt != null && Number.isFinite(ledgerAt) && ledgerAt >= p.doneAt ? 'go' : 'hold';
    }
    const mine = { at: now, doneAt: null };
    this.pokes.set(ch, mine);
    this.log.info(`교차 검사: ${ch} 판매현황에 팔린 밤이 원장에 없다 — ${ch} 유입을 한 번 앞당긴다(원장을 먼저 채운다, ${Math.round(this.pokeMs / 60000)}분에 한 번)`);
    /* 유입 줄은 마감(300초)이 있어 반드시 끝난다 — 실패해도 끝난 것으로 적는다(영영 기다리지 않는다).
       ★ force 없이 부른다 — 목록이 지난 저장과 같으면(해시) 원장에 다시 쓰지 않는다(같은 것을 다시 보내도 원장이 달라지지 않는다).
         새 예약이 목록에 들어와 있으면 해시가 달라 평소처럼 저장·reconcile 한다. */
    Promise.resolve().then(() => w.inbound()).catch(() => null).then(() => { mine.doneAt = this.now(); });
    return 'hold';
  }

  /* 경보 열기(설계 3-4). channel 은 반드시 비운다 — 서버가 연 같은 (방, 밤) 줄을 돌려받고, 유일 색인·서버 keyOf 와 같아진다. */
  async #openCross(c, X, Y, L, room, now) {
    if (this.alerted.has(c.key)) return;   // 한 번만 부른다 — 열려 있는 동안은 다시 안 부른다
    /* 한 시간 안에 「자체 해결」로 덮인 것을 봤다 — 덮개 목록을 판마다 다시 읽지 않는다. */
    const m = this.mutedAt.get(c.key);
    if (m != null && now - m < HOUR_MS) return;
    let muted;
    try {
      muted = typeof this.dashboard?.alertMuted === 'function'
        ? await this.dashboard.alertMuted({ kind: 'overbook', resourceId: c.rid, onDate: c.date })
        : null;
    } catch { muted = null; }
    if (muted === true) { this.mutedAt.set(c.key, now); this.log.debug(`교차 검사: ${room} ${c.date} — 「자체 해결」로 덮여 있어 경보를 안 연다`); return; }
    if (muted !== false) {
      this.#sayEvery('mutes-unknown', HOUR_MS, 'warn', '교차 검사: 「자체 해결」 목록을 못 읽어 이번 판은 경보를 안 연다(다음 판이 다시 본다)');
      return;
    }
    const detail = crossDetail(c, X, Y, L);
    let row;
    try {
      row = await this.dashboard.openAlert({ kind: 'overbook', channel: undefined, resourceId: c.rid, onDate: c.date, detail });
    } catch (e) {
      /* 서버가 사이에 같은 줄을 넣었으면(23505) 그 줄로 합쳐진 것으로 친다. */
      if (/23505|duplicate key|unique/i.test(String(e && e.message))) {
        const rows = await this.dashboard.openAlerts({ kind: 'overbook' }).catch(() => []);
        row = (rows || []).find((a) => String(a.resource_id) === c.rid && dayKst(a.on_date) === c.date) || null;
        if (!row) return;
      } else {
        this.#sayEvery(`open-fail|${c.key}`, HOUR_MS, 'warn', `교차 검사: ${room} ${c.date} 경보를 못 열었다 — ${String(e && e.message).slice(0, 160)}`);
        return;
      }
    }
    const ours = row?.detail?.source === 'crosscheck';
    this.alerted.set(c.key, { id: row?.id ?? null, ours, rid: c.rid, date: c.date, channels: [X.channel, Y.channel] });
    this.log.info(ours
      ? `교차 검사: 동시 판매 경보를 열었다 — ${room} ${c.date} · ${X.channel} ${c.x.word} · ${Y.channel} ${c.y.word} · 원장 ${L.live}건`
      : `교차 검사: ${room} ${c.date} 는 같은 방·밤 오버부킹 경보가 이미 열려 있다(서버) — 그 줄을 쓴다`);
  }

  /* alert — 열린 우리 경보(detail.source 'crosscheck')를 한 번 읽어 기억에 넣는다. 재시작 전에 연 것도 풀리면 닫게.
     못 읽으면 다음 비교가 다시 해 본다. 서버 줄(source 없음)은 넣지 않는다 — 원장이 아는 건 서버가 닫는다. */
  async #seed() {
    let rows;
    try { rows = await this.dashboard.openAlerts({ kind: 'overbook' }); } catch (e) {
      this.#sayEvery('seed-fail', HOUR_MS, 'debug', `교차 검사: 열린 경보를 못 읽었다 — ${String(e && e.message).slice(0, 120)} (다음 판이 다시 본다)`);
      return;
    }
    this.seeded = true;
    let n = 0;
    for (const a of rows || []) {
      if (!a || a.detail?.source !== 'crosscheck' || a.id == null || a.resource_id == null) continue;
      const rid = String(a.resource_id);
      const date = dayKst(a.on_date);
      if (!YMD.test(date)) continue;
      const key = `${rid}|${date}`;
      if (this.alerted.has(key)) continue;
      const chs = Array.isArray(a.detail.channels) ? a.detail.channels.filter((x) => typeof x === 'string' && this.workers.has(x)) : [];
      const channels = chs.length >= 2 ? chs : [...this.workers.keys()];
      this.alerted.set(key, { id: a.id, ours: true, rid, date, channels });
      n++;
    }
    if (n) this.log.info(`교차 검사: 앞서 연 동시 판매 경보 ${n}건을 이어받았다 — 풀리면 닫는다`);
  }

  /* 우리가 기억하는 경보를 본다 — 남에게 닫혔나(자동 차단기), 풀렸나(3-5). 기억이 없으면 대시보드를 안 읽는다. */
  async #reviewAlerted(now) {
    if (!this.alerted.size) return;
    let rows;
    try { rows = await this.dashboard.openAlerts({ kind: 'overbook' }); } catch { return; }
    const openIds = new Set((rows || []).map((a) => a.id));
    for (const [key, a] of [...this.alerted]) {
      if (openIds.has(a.id)) continue;
      this.alerted.delete(key);
      if (!a.ours) continue;
      /* 조건이 그대로인데(두 채널 최신 판에 여전히 둘 다 sold) 닫혔다 = 남(서버·사람)이 닫았다. */
      const still = a.channels.every((ch) => this.snaps.get(ch)?.cur?.sold.get(a.rid)?.has(a.date));
      if (!still) continue;
      this.closedByOthers = this.closedByOthers.filter((t) => now - t < HOUR_MS);
      this.closedByOthers.push(now);
      if (this.mode === 'alert' && this.closedByOthers.length >= 2) {
        this.mode = 'log';
        this.log.warn('교차 검사: 우리가 연 동시 판매 경보가 한 시간에 두 번 조건 그대로 닫혔다(서버가 닫았는지 사람이 ✕ 로 닫았는지는 못 가른다) —' +
          ' log 모드로 내린다(닫힘·다시 열림·푸시 반복을 막는다). 서버 선행 패치(ota.mjs byRunner)가 없다면 올린 뒤 실행기를 다시 켤 것.' +
          ' 사람이 끄려던 것이면 「자체 해결」로 덮는 것이 맞다(덮인 것은 다시 안 연다)');
      }
    }
    /* 풀림 — 우리 경보(source:'crosscheck')만. 두 채널 모두 신선하고, 적어도 한쪽이 연속 두 판 clear 일 때만. */
    for (const [key, a] of [...this.alerted]) {
      const slots = a.channels.map((ch) => this.snaps.get(ch));
      if (!slots.every((s) => s && this.#fresh(s.cur, now))) continue;
      const cleared = slots.some((s) => s.prev && s.cur.clear.get(a.rid)?.has(a.date) && s.prev.clear.get(a.rid)?.has(a.date));
      if (!cleared) continue;
      if (!a.ours) { this.alerted.delete(key); continue; }   // 서버 줄은 절대 안 닫는다 — 기억만 지운다
      try {
        await this.dashboard.resolveAlertById(a.id);
        this.alerted.delete(key);
        this.suspect.delete(key);
        this.log.info(`교차 검사: 동시 판매가 풀렸다(두 판 연속 확인) — 우리가 연 경보를 닫았다 ${a.date}`);
      } catch (e) {
        this.log.debug(`교차 검사: 경보를 못 닫았다 — ${e.message} (다음 판이 다시 본다)`);
      }
    }
  }
}

/* 경보 detail — 채널·낱말·시각·키·건수만. 손님 정보는 없다(BR-020). 서버 refs 의 label 에는 이름이 들어가지만 우리는 안 넣는다. */
export function crossDetail(c, X, Y, L) {
  const ref = (S, e) => ({ ref: `${S.channel}:${e.keys[0]}`, channel: S.channel, origin: 'channel', label: `판매현황 ${PENDING_WORDS.has(e.word) ? '입금대기' : '예약완료'}` });
  const detail = {
    source: 'crosscheck', count: 2, channels: [X.channel, Y.channel],
    refs: [ref(X, c.x), ref(Y, c.y)],
    states: { [X.channel]: c.x.word, [Y.channel]: c.y.word },
    seenAt: { [X.channel]: new Date(X.readAt).toISOString(), [Y.channel]: new Date(Y.readAt).toISOString() },
    keys: { [X.channel]: [...c.x.keys], [Y.channel]: [...c.y.keys] },
    ledger: { live: L.live, channels: [...L.channels] },
    evidence: L.live === 0 ? 'ledger-none' : 'ledger-one',
  };
  const remain = {};
  if (Number.isFinite(c.x.remain)) remain[X.channel] = c.x.remain;
  if (Number.isFinite(c.y.remain)) remain[Y.channel] = c.y.remain;
  if (Object.keys(remain).length) detail.remain = remain;
  return detail;
}
