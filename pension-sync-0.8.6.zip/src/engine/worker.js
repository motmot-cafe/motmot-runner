/* 채널 하나를 맡는 일꾼. 브라우저 하나, 작업은 줄 세워 하나씩(BR-011).
   주기: 생존 신호 → 객실 확인(드물게) → 유입 → 반영(할 일) → 캘린더 대조 → 요금. 새 할 일을 보면 반영을 앞당긴다.
   반영과 캘린더 대조는 둘 다 '방을 막는' 쪽이다 — 앞은 서버가 만든 할 일을 처리하고, 뒤는 원장을 직접 보고 차이를 메운다(D-008). */
import { redactSecret } from '../lib/log.js';
import { loadSpec, writesLocked, writesLockReason, onlyTasks, maxTodosPerPass } from '../adapters/spec.js';
import { JsonAdapter, NeedsHumanError, SessionYieldError } from '../adapters/json-adapter.js';
import { ChannelSession } from '../browser/session.js';
import { runInbound } from './inbound.js';
import { runOutbound } from './outbound.js';
import { runCalendar } from './calendar.js';
import { runRates } from './rates.js';
import { runRooms } from './rooms.js';
import { deadline, soft } from '../lib/deadline.js';
import { gapSince } from './state.js';

const RESTART_BROWSER_EVERY = 40;   // 작업 N번마다 브라우저를 새로 띄운다(메모리)
/* 사람이 필요한 상태(2단계 인증·페어링 안 됨)에서 다시 로그인해 보는 간격.
   매 주기(60초)마다 시도하면 파트너센터가 인증 문자를 계속 보내고 계정이 잠긴다. */
const RETRY_WHEN_PAUSED_MS = 15 * 60000;

/** 칸 결과 하나 → 사람이 읽는 낱말. 상태 줄(statusLine)과 --once 요약(main.js)이 같이 쓴다.
    ★ 쓰기 잠금으로 건너뛴 칸(locked·writeLocked)은 '정상' 이 아니라 '잠금' 이다. '정상' 으로 보이면
      리모컨·상태 줄을 보는 사람이 야놀자 방막기가 돌고 있다고 믿는다. 잠금 표시가 없는 결과(여기어때)는 예전 그대로다. */
export function kindWord(v) {
  if (!v) return '못 돎';
  /* v3: 채널 JSON only 로 **일부러 안 돌리는** 칸 — '정상' 으로 보이면 야놀자 예약도 읽는 줄 안다. */
  if (v.notRun) return '안 씀';
  if (v.ok === false) return '실패';
  return v.locked || v.writeLocked ? '잠금' : '정상';
}

export class NotPairedError extends Error {
  constructor(channel) { super(`${channel}: 파트너센터 로그인이 안 돼 있다 — npm run pair -- ${channel}`); this.name = 'NotPairedError'; this.channel = channel; }
}

export class ChannelWorker {
  /* ★ 두 타워 교차(2026-09-23, engine/coordinator.js) 자리 — 코디네이터가 붙인 워커만 채운다. 기본은 비어 있다.
       **#private 로 둔다.** 워커의 자기 칸(Object.keys)을 늘리지 않아야 코디네이터가 없는 판(여기어때 혼자·잠긴 야놀자와 둘)이
       기준판과 모양까지 같다 — 불변 시험이 그것을 본다. 코디네이터는 아래 접근자로만 읽고 쓴다.
       onEvent(channel, kind, result, meta) — 유입·캘린더 한 판이 끝날 때 한 번(#emit).
       board — 교차 검사 보드(crosscheck.js). 캘린더가 읽은 판매현황을 맡긴다.
       calStartedAt — 마지막 캘린더 판이 **시작한** 시각(최소 간격·dirty 지우기의 기준).
       kickedCalOkAt — ok 로 끝난 앞당김 판이 시작한 시각(바로 뒤 정기 판 건너뛰기).
       urgentUntil — 이 시각까지 요금 판이 줄을 비켜 준다(새 예약 → 급한 캘린더).
       calRunningSince — 지금 **도는** 캘린더 판이 시작한 시각(없으면 null). 코디네이터가 '트리거 뒤에 시작한 판이
         아직 도는 중' 이면 한 판을 더 줄 세우지 않는다(검토 2026-09-23 — 판이 최소 간격보다 길면 트리거 하나에 두 판이 돌았다).
       crossPaced — 앞당김(CROSS_KICK)이 붙은 타워만 true. 이때만 채널별 기본 주기(야놀자 900·300)를 쓴다 — intervals(). */
  #onEvent = null;
  #board = null;
  /* v3(D-080) — 채널 JSON 의 only·writes 배열에서 한 번 정한다. #private 로 둔다(위와 같은 까닭: 여기어때 워커의
     자기 칸 모양이 기준판과 같아야 한다). 없는 채널(여기어때)은 null·false 라 동작이 한 글자도 안 바뀐다. */
  #only = null;
  #setClosedLocked = false;
  #saidNotRun = new Set();
  #calStartedAt = 0;
  #calRunningSince = null;
  #kickedCalOkAt = 0;
  #urgentUntil = 0;
  #crossPaced = false;
  /** 이 채널에서 돌릴 칸(null = 전부). v3 only. */
  get only() { return this.#only; }
  /** 방막기·방열기가 잠겼는가 — writes 가 true 거나 ["setClosed"] 면 false. 요금·캘린더는 writesLocked(전부) 로 본다. */
  get setClosedLocked() { return this.#setClosedLocked; }
  get onEvent() { return this.#onEvent; }
  set onEvent(f) { this.#onEvent = typeof f === 'function' ? f : null; }
  get board() { return this.#board; }
  set board(b) { this.#board = b || null; }
  get calStartedAt() { return this.#calStartedAt; }
  /* 마감(480초)을 넘긴 판은 줄이 이미 버렸다 — 배경에서 끝나지 않고 걸려 있어도 '도는 중' 으로 치지 않는다. */
  get calRunningSince() {
    const v = this.#calRunningSince;
    return v != null && Date.now() - v < (ChannelWorker.DEADLINE_MS.calendar ?? 480000) ? v : null;
  }
  get kickedCalOkAt() { return this.#kickedCalOkAt; }
  get urgentUntil() { return this.#urgentUntil; }
  set urgentUntil(t) { this.#urgentUntil = Number.isFinite(t) ? t : 0; }
  get crossPaced() { return this.#crossPaced; }
  set crossPaced(v) { this.#crossPaced = v === true; }
  /* 콘솔 채널 계정이 '멈춤'(isLive 가 false 로 읽은 뒤) — 이때 부른 판은 withAdapter 가 곧바로 '사람을 기다리는 중' 으로 끝난다.
     코디네이터가 이것을 보고 앞당김을 안 부른다(헛돌며 시간당 상한만 써 버렸다 — 검토 2026-09-23). */
  get consolePaused() { return this._live === false; }

  /** @param {object} o { channel, cfg, dashboard, log, state, spec?, baseUrl?, playwright?, onEvent?, board? } */
  constructor(o) {
    this.channel = o.channel;
    this.cfg = o.cfg;
    this.dashboard = o.dashboard;
    this.log = o.log.child ? o.log.child(o.channel) : o.log;
    this.state = o.state;
    this.spec = o.spec || loadSpec(o.channel);
    this.baseUrl = o.baseUrl || this.spec.baseUrl;
    this.session = new ChannelSession({
      channel: o.channel, stateDir: o.cfg.paths.stateDir, secret: o.cfg.stateSecret, headless: o.cfg.headless,
      browser: o.cfg.browser, log: this.log, playwright: o.playwright,
    });
    this.adapter = null;
    this.queue = Promise.resolve();
    this.pending = new Set();
    this.runs = 0;
    this.timers = [];
    this.stopped = false;
    this.paused = null;   // 사람이 필요한 상태면 이유
    /* 첫 설치 확인용 — 켜면 예약 목록을 읽어 서버가 읽는지까지만 보고 저장하지 않는다.
       상태 문구·객실명이 어긋난 채로 원장에 들어가는 것이 가장 되돌리기 어렵다. */
    this.previewOnly = !!o.previewOnly;
    /* ★ 쓰기 잠금(채널 JSON "writes": false, D-075). 켜지면 반영·캘린더·요금은 파트너센터를 안 열고 건너뛰고,
         유입은 서버 미리보기까지만 하고 원장에 저장하지 않는다. 칸이 없는 채널(여기어때)은 false — 그대로 돈다. */
    this.writesLocked = writesLocked(this.spec);
    /* v3: 방막기·방열기만 따로 본다("writes": ["setClosed"]). 캘린더·요금·원장 저장·자동 매핑은 위 writesLocked 그대로 —
       그래서 코디네이터·교차 검사도 이 채널을 '쓸 수 있는 타워' 로 안 본다(캘린더를 앞당기지 않는다). */
    this.#setClosedLocked = writesLocked(this.spec, 'setClosed');
    this.#only = onlyTasks(this.spec);
    this.lastResults = {};
    /* ★ 마지막으로 **무언가를 끝낸** 시각. 죽은 사람 스위치(main.js)가 이것만 본다.
         "살아 있다" 가 아니라 "나아가고 있다" 를 재야 한다 — 2026-09-14 에 프로세스는
         멀쩡히 살아 있으면서 76분 동안 한 칸도 못 끝냈다. */
    this.lastProgressAt = Date.now();
    if (o.onEvent) this.onEvent = o.onEvent;
    if (o.board) this.board = o.board;
  }

  /* 교차 알림은 이 한 자리에서만 낸다. 코디네이터 쪽 버그가 워커(유입·캘린더 줄)를 깨지 않게 감싼다. */
  #emit(kind, r, meta) {
    try { this.#onEvent?.(this.channel, kind, r, meta); } catch (e) { this.log.debug(`교차 알림 실패 — ${e.message}`); }
  }

  /* 이 채널의 유입·정기 캘린더 주기(초). 여기어때는 언제나 공통값(유입 120·캘린더 300)이다.
     ★ 채널별 **기본값**(야놀자 캘린더 900·유입 300)은 앞당김이 붙은 타워(crossPaced)만 쓴다 — 15분은 원장 변화를
       앞당김이 곧바로 불러 준다는 전제에서만 안전하다. 그래서 잠긴 야놀자(앞당김 대상이 아니다)·되돌리기 스위치
       (CROSS_KICK=off)·야놀자 혼자일 때는 공통값 그대로라 기준판과 같다(검토 2026-09-23).
       `.env` 에 `<CH>_…_INTERVAL_SEC` 로 **적은 값**은 어느 경우에나 이긴다(channelIntervalsAlone 에도 들어 있다). */
  intervals() {
    const iv = this.cfg.intervals || {};
    const table = this.#crossPaced ? this.cfg.channelIntervals : this.cfg.channelIntervalsAlone;
    const own = table?.[this.channel] || {};
    return { ...iv, inboundSec: own.inboundSec ?? iv.inboundSec, calendarSec: own.calendarSec ?? iv.calendarSec };
  }

  /* 칸마다 이만큼 안에는 끝나야 한다. 넘으면 그 판만 버리고 다음 판으로 간다.
     ★ 줄이 직렬이라 한 작업이 안 끝나면 **그 뒤 전부**가 안 돈다(2026-09-14, 76분).
       그래서 개별 호출의 시간제한과 별개로, 칸 단위로도 한 번 더 막아 둔다.
       숫자는 주기의 몇 배 — 죽은 사람 스위치(20분)보다는 짧아야 스스로 풀린다. */
  static DEADLINE_MS = { inbound: 300000, outbound: 300000, calendar: 480000, rooms: 300000, rates: 720000, heartbeat: 60000 };

  /** 같은 종류의 작업이 이미 줄에 있으면 또 넣지 않는다. */
  enqueue(kind, fn) {
    if (this.pending.has(kind)) return this.queue;
    this.pending.add(kind);
    const p = this.queue.then(async () => {
      this.pending.delete(kind);
      if (this.stopped) return null;
      try {
        return await deadline(fn(), ChannelWorker.DEADLINE_MS[kind] ?? 300000, `${kind} 한 판`);
      } catch (e) {
        // 사람을 기다리는 중이라는 것은 고장이 아니다 — 15분마다 한 줄씩만 남긴다
        if (e && e.pausedWaiting) this.log.debug(`${kind}: 사람을 기다리는 중`);
        else this.log.error(`${kind}: ${e.message}`);
        /* ★ 마감으로 버린 작업은 **배경에서 계속 돌고 있다** — 취소할 방법이 없다.
             그대로 두면 다음 판과 같은 브라우저를 놓고 다투다 둘 다 깨진다.
             그래서 브라우저를 닫아 버린다. 다음 판은 새로 띄우고 시작한다. */
        if (e && e.timedOut) await soft(this.session?.close?.(), 10000, null);
        return null;
      } finally {
        // 끝나기만 하면(성공이든 실패든) 나아간 것이다.
        this.lastProgressAt = Date.now();
      }
    });
    this.queue = p.catch(() => {});
    return p;
  }

  /** 브라우저를 열고 로그인을 확인한 뒤 fn(adapter) 를 돈다. 끝나면 세션 백업. */
  async withAdapter(fn) {
    /* ★ 콘솔에서 채널을 '멈춤' 으로 바꾸면 그때부터 파트너센터를 건드리지 않는다(BR-008).
         시작할 때 한 번만 보면, 사장님이 멈춘 뒤에도 계속 조작한다. */
    if (!(await this.isLive())) {
      const err = new Error(`${this.channel}: 계정 상태가 운영 중이 아니다`);
      err.pausedWaiting = true;
      throw err;
    }
    /* ★ 사람이 필요한 상태면 15분에 한 번만 다시 해 본다. 매 주기 시도하면 파트너센터가
         인증 문자를 계속 보내고 계정이 잠긴다. 사장님이 페어링을 다시 하면 자격증명 파일이
         새로 써지므로, 그 시각이 마지막 시도보다 나중이면 기다리지 않고 바로 다시 해 본다. */
    if (this.paused) {
      const since = Date.now() - (this.pausedRetryAt || 0);
      const repaired = this.session.credsChangedAfter(this.pausedRetryAt || 0);
      if (since < RETRY_WHEN_PAUSED_MS && !repaired) {
        const left = Math.ceil((RETRY_WHEN_PAUSED_MS - since) / 60000);
        this.log.debug(`사람이 필요한 상태 — ${left}분 뒤에 다시 해 본다`);
        const err = new NotPairedError(this.channel);
        err.pausedWaiting = true;
        throw err;
      }
      this.pausedRetryAt = Date.now();
    }
    if (this.runs > 0 && this.runs % RESTART_BROWSER_EVERY === 0) await this.session.close();
    /* ★ 브라우저가 아예 안 열리면(설치 안 됨·프로필 잠김·메모리 부족) 지금까지는 로그 한 줄만 남고
         생존 신호는 계속 초록이었다 — 콘솔에는 "정상" 인데 아무 일도 안 하는 상태다. 경보로 올린다. */
    let page;
    try {
      page = await this.session.open();
    } catch (e) {
      await this.needsHuman(`브라우저를 열지 못했다 — ${String(e.message).slice(0, 180)}`);
      throw e;
    }
    if (!this.adapter || this.adapter.page !== page) {
      /* 브라우저를 다시 열어도 "세션을 언제 빼앗겼나" 는 이어 간다 — 안 그러면 5분 비켜 주기가
         브라우저 재시작 때마다 처음부터 시작해 사장님을 계속 밀어낸다. */
      const lostAt = this.adapter?.sessionLostAt || 0;
      const wasIn = !!this.adapter?.wasLoggedIn;
      this.adapter = new JsonAdapter({
        spec: this.spec, page, log: this.log, baseUrl: this.baseUrl, artifactsDir: this.cfg.paths.artifactsDir, creds: this.session.loadCreds(),
        yieldMs: this.cfg.relogin?.yieldMs,
      });
      this.adapter.sessionLostAt = lostAt;
      this.adapter.wasLoggedIn = wasIn;
    }
    // 자격증명은 매번 다시 읽는다 — 사장님이 도는 중에 페어링을 다시 했을 수 있다
    this.adapter.creds = this.loadCreds();
    this.runs++;
    let loggedIn;
    try {
      loggedIn = await this.adapter.ensureLoggedIn();
    } catch (e) {
      /* 비켜 주는 중은 고장이 아니다 — 경보를 열지 않고, 사장님이 알아볼 수 있게 한 줄만 남긴다. */
      if (e instanceof SessionYieldError) { this.log.info(e.message); throw e; }
      if (e instanceof NeedsHumanError) { await this.needsHuman(e.message); throw e; }
      throw e;
    }
    if (!loggedIn) {
      const err = new NotPairedError(this.channel);
      await this.needsHuman(err.message);
      throw err;
    }
    if (this.paused) {
      this.paused = null;
      this.pausedRetryAt = 0;
      this.log.info('로그인이 돌아왔다 — 다시 돈다');
      await this.dashboard.resolveAlerts({ kind: 'sync_stale', channel: this.channel, source: 'worker' }).catch(() => 0);
    }
    try {
      return await fn(this.adapter);
    } finally {
      await this.session.saveStorage().catch(() => {});
    }
  }

  /** 자격증명을 읽고, 로그에 찍히지 않게 가림 목록에 넣는다.
      STATE_SECRET 이 바뀌면 여기서 던지는데, 그것을 삼키면 "생존 신호는 초록인데 아무 일도 안 함" 이 된다. */
  loadCreds() {
    try {
      const c = this.session.loadCreds();
      if (c) { redactSecret(c.password); redactSecret(c.loginId); }
      /* ★ 환경변수로 받은 자격증명이 있으면 그것이 기준이다 — **화면 없는 컨테이너에서 돌리기 위한 자리**다.
           `npm run pair` 는 사람이 브라우저로 들어가는 절차라 클라우드에서는 할 수 없다.
           봉인해 state/ 에 넣어 두면 그 뒤로는 자동 로그인이 알아서 쓴다. 로그에는 안 남는다. */
      const fromEnv = this.cfg.channelCreds && this.cfg.channelCreds[this.channel];
      if (fromEnv) {
        redactSecret(fromEnv.password); redactSecret(fromEnv.loginId);
        if (!c || c.loginId !== fromEnv.loginId || c.password !== fromEnv.password) {
          this.session.saveCreds(fromEnv);
          this.log.info(`파트너센터 자격증명을 환경변수에서 받아 봉인했다 — 페어링 없이 시작한다`);
          return this.session.loadCreds();
        }
      }
      return c;
    } catch (e) {
      this.needsHuman(`저장된 자격증명을 열지 못했다 — STATE_SECRET 이 바뀌었으면 npm run pair -- ${this.channel} --wipe (${e.message})`);
      return null;
    }
  }

  /** 콘솔의 채널 계정 상태(BR-008). 5분 캐시 — 운영 중에 '멈춤' 으로 바꾸면 그때 멈춘다. */
  async isLive(now = Date.now()) {
    if (this._accountsAt && now - this._accountsAt < 5 * 60000) return this._live;
    try {
      const rows = await this.dashboard.channelAccounts();
      const a = rows.find((x) => x.channel_code === this.channel);
      const live = !a || a.status === 'live';       // 줄이 없으면 다룬다(콘솔에 아직 안 넣은 것)
      if (this._accountsAt && live !== this._live) {
        this.log.info(live ? '계정 상태가 운영 중으로 바뀌었다 — 다시 돈다' : `계정 상태가 '${a.status}' 라 멈춘다`);
      }
      this._live = live;
      this._accountsAt = now;
      return live;
    } catch (e) {
      this.log.warn(`채널 계정 상태를 못 읽었다 — 하던 대로 간다 (${e.message})`);
      return this._live !== false;
    }
  }

  async needsHuman(reason) {
    if (this.paused === reason) return;
    this.paused = reason;
    this.pausedRetryAt = Date.now();
    this.log.warn(reason);
    await this.dashboard.openAlert({ kind: 'sync_stale', channel: this.channel, detail: { reason: reason.slice(0, 200), source: 'worker' } }).catch(() => {});
  }

  /** 잠금을 알린다 — **채널당 한 번만.** 매 주기(1·5·15분) 같은 줄이 쌓이면 진짜 경고가 묻힌다.
      손님 정보는 없다: 채널 이름과 건너뛰는 칸 이름뿐이다(BR-020). */
  noteWriteLocked() {
    if (this.saidWriteLocked) return;
    this.saidWriteLocked = true;
    /* v3: 방막기·방열기만 열린 채널이면 '반영' 은 건너뛰는 목록에서 뺀다 — 돌고 있는 칸을 잠겼다고 적으면 거꾸로 읽힌다. */
    const skip = [...(this.#setClosedLocked ? ['반영(outbound)'] : []), '캘린더(calendar)', '요금(rates)'].join('·');
    this.log.warn(`${this.channel}: 쓰기 잠금(${writesLockReason(this.spec) || '채널 JSON'}) — ${skip} 은 건너뛰고` +
      ' 유입(inbound)은 미리보기까지만 한다(원장에 저장 안 함). 객실 자동 매핑도 안 넣는다. 읽기·생존 신호는 돈다. 이 줄은 한 번만 남긴다');
  }

  /** v3: 이 칸을 돌리는가(채널 JSON only). only 가 없으면 늘 true — 예전 그대로. */
  runsTask(kind) { return !this.#only || this.#only.has(kind); }

  /* v3: only 에 없는 칸 — 파트너센터를 **열지 않고** 줄만 한 번 지나간다(lockedPass 와 같은 까닭: 죽은 사람 스위치가
       이 채널을 '멈췄다' 로 읽지 않게). 칸마다 한 번만 알린다. 손님 정보는 없다(BR-020). */
  notRunPass(kind) {
    return this.enqueue(kind, async () => {
      if (!this.#saidNotRun.has(kind)) {
        this.#saidNotRun.add(kind);
        this.log.info(`${this.channel}: ${kind} 은 돌리지 않는다(채널 JSON only=${JSON.stringify([...(this.#only || [])])}) — 파트너센터를 열지 않는다. 이 줄은 한 번만 남긴다`);
      }
      return (this.lastResults[kind] = { ok: true, notRun: true, skipped: '이 채널은 돌리지 않는 칸(only)' });
    });
  }

  /* ★ 잠긴 칸도 **줄(queue)을 한 번 지나가게** 한다. 줄을 안 타고 바로 돌려주면 lastProgressAt 이 안 움직여,
       INBOUND=off 인 판에서는 이 채널이 20분 뒤 '멈췄다' 로 읽혀 죽은 사람 스위치가 **여기어때까지** 끈다(main.js).
       줄을 타면 진짜로 줄이 멈췄을 때는 여전히 잡힌다 — 가짜 진척을 만들지 않는다.
     ⚠ 캘린더를 통째로 건너뛰므로 잠긴 동안 상주는 **판매 현황도 안 읽는다**(누를 일이 없으니 읽을 까닭도 없다).
       잠금을 풀기 전 판매 현황 확인은 scan·why 로 한다 — 둘 다 잠금과 상관없이 읽는다. */
  lockedPass(kind) {
    return this.enqueue(kind, async () => {
      this.noteWriteLocked();
      return (this.lastResults[kind] = { ok: true, locked: true, skipped: '쓰기 잠금(writes:false)' });
    });
  }

  // ── 작업 ──
  /* ★ 생존 신호는 브라우저 큐에 세우지 않는다. 긴 요금 반영(수백 번 클릭) 뒤에 줄을 서면
       30분을 넘겨 콘솔이 "실행기 꺼짐" 으로 본다(BR-007). 대시보드 쓰기 한 번이라 병렬로 안전하다. */
  heartbeat() {
    /* ★ 살아 있다는 것을 이 PC 에도 적는다. 두 가지를 위해서다:
         1) 다음에 켤 때 '얼마나 비었나' 를 말한다(main.js).
         2) **깨어남을 잡는다** — PC 가 자면 프로세스는 그대로 있고 타이머만 안 돈다.
            그래서 화면은 '돌고 있습니다' 인데 실제로는 몇 시간을 아무것도 안 한다.
            30분을 기준으로 삼는다(이 자리는 5분에 한 번만 쓰므로 그만큼은 정상 여유다). */
    const gap = gapSince(this.state.lastAlive?.(), new Date(), 30 * 60000);
    if (gap) {
      this.log.warn(`이 PC 가 ${gap.text} 동안 아무것도 안 돌렸다(마지막 생존 ${gap.at})` +
        ' — 절전이거나 멈춰 있었다. 그 사이 들어온 예약·취소와 파트너센터 변화는 반영되지 않았다');
    }
    this.state.markAlive?.();
    return this.dashboard.heartbeat(this.channel).then((r) => {
      this.state.markHeartbeat?.(this.channel, true);
      return r;
    }).catch((e) => {
      /* 닿았는지를 적어 둔다 — 이 PC 가 도는 것과 콘솔이 그것을 아는 것은 다른 일이다(state.js). */
      this.state.markHeartbeat?.(this.channel, false, e.message);
      this.log.error(`생존 신호 실패 — ${e.message}`);
      return null;
    });
  }
  inbound(force = false) {
    if (!this.runsTask('inbound')) return this.notRunPass('inbound');
    /* 꺼 두면 아무것도 안 한다 — 첫 바퀴도 안 돈다. 끈 이유는 config.js 의 inboundOn 주석에. */
    if (this.cfg.dashboard?.inboundOn === false) {
      if (!this.saidInboundOff) { this.saidInboundOff = true; this.log.warn('유입은 꺼져 있다(.env 의 INBOUND=off) — 반영·캘린더·요금은 그대로 돈다'); }
      return Promise.resolve({ ok: true, skipped: '유입 꺼짐' });
    }
    return this.enqueue('inbound', () => this.withAdapter((adapter) =>
      runInbound({
        channel: this.channel, adapter, dashboard: this.dashboard, cfg: this.cfg, log: this.log,
        state: this.state, force, previewOnly: this.previewOnly,
        /* 잠겨 있으면 저장만 뺀다 — 읽기와 서버 미리보기는 그대로라 "서버가 읽는가" 는 계속 보인다. */
        writeLocked: this.writesLocked,
        /* 코디네이터가 붙은 워커만 원장 변화(건수)를 결과에 싣는다 — 안 붙은 판의 결과 모양은 예전 그대로다. */
        reportLedger: !!this.#onEvent,
      }).then((r) => {
        if (this.writesLocked) this.noteWriteLocked();
        this.lastResults.inbound = r;
        this.#emit('inbound', r, {});
        return r;
      })));
  }
  outbound() {
    if (!this.runsTask('outbound')) return this.notRunPass('outbound');
    /* v3: 반영은 방막기·방열기만 쓴다 — 그것만 열렸는지 본다(writes 배열). 여기어때(칸 없음)는 writesLocked 와 같다. */
    if (this.#setClosedLocked) return this.lockedPass('outbound');
    return this.enqueue('outbound', async () => {
      // 할 일이 없으면 브라우저를 열지 않는다
      const todos = await this.dashboard.openTodos(this.channel).catch((e) => { this.log.error(e.message); return null; });
      if (todos && !todos.length) {
        await this.dashboard.recordRun({ channel: this.channel, kind: 'outbound', startedAt: new Date(), ok: true, detail: { todos: 0 } }).catch(() => {});
        return (this.lastResults.outbound = { ok: true, done: 0, cleaned: 0, failed: 0, skipped: 0, unmapped: [] });
      }
      return this.withAdapter((adapter) =>
        runOutbound({ channel: this.channel, adapter, dashboard: this.dashboard, log: this.log, state: this.state,
        notSold: this.cfg.notSold?.[this.channel] || [],
        /* v3: 한 판 상한(채널 JSON outbound.maxTodosPerPass). 없으면 null — 예전처럼 다 한다. */
        maxTodos: maxTodosPerPass(this.spec) })
          .then((r) => (this.lastResults.outbound = r)));
    });
  }
  /* 대시보드 캘린더를 파트너센터에 맞춘다 — 사람이 아무것도 안 눌러도 도는 쪽(요구 1·2의 닫는 고리).
     reason: 'manual'(인자 없음 — cycle·리모컨 /run) | 'timer'(정기 주기) | 'kick'(교차 앞당김, coordinator.js).
     ★ 순서: 꺼짐 → 쓰기 잠금(lockedPass) → 정기 판 건너뛰기 → 줄. 안전 패치의 두 줄은 그대로 맨 앞이다.
     ★ 건너뛰는 것은 **정기 판뿐**이다 — ok 로 끝난 앞당김 판이 timerSkipSec(120초) 안에 시작했으면 그 판이 이미
       판매현황과 최신 원장을 읽었으므로 정기 판이 같은 일을 또 할 까닭이 없다(야놀자 페이지 적재를 줄인다).
       사람이 누른 판(manual)은 절대 건너뛰지 않는다. 코디네이터가 없으면 kickedCalOkAt 이 0 이라 예전과 똑같다. */
  calendar({ reason = 'manual' } = {}) {
    if (!this.cfg.calendar?.enabled) return Promise.resolve((this.lastResults.calendar = { ok: true, closed: 0, opened: 0, rooms: 0, skipped: '꺼짐(CALENDAR_SYNC=false)' }));
    if (!this.runsTask('calendar')) return this.notRunPass('calendar');
    if (this.writesLocked) return this.lockedPass('calendar');
    if (reason === 'timer' && this.#kickedCalOkAt) {
      const ago = Date.now() - this.#kickedCalOkAt;
      if (ago < (this.cfg.cross?.timerSkipSec ?? 120) * 1000) {
        this.log.debug(`정기 캘린더 대조를 건너뛴다 — ${Math.round(ago / 1000)}초 전에 시작한 앞당김 판이 ok 로 끝났다`);
        return Promise.resolve(this.lastResults.calendar);
      }
    }
    return this.enqueue('calendar', () => {
      const startedAt = Date.now();
      this.#calStartedAt = startedAt;
      this.#calRunningSince = startedAt;
      /* 캘린더 판이 **시작**하면 급함은 풀린다 — 이 판이 최신 원장을 읽는다. 앞당김이 이미 줄에 서 있던 정기 판과
         합쳐졌어도(enqueue 가 합친다) 그 판이 시작하는 순간이 곧 급한 일이 해결되는 순간이다. */
      this.#urgentUntil = 0;
      const board = this.#board;
      return this.withAdapter((adapter) =>
        runCalendar({ channel: this.channel, adapter, dashboard: this.dashboard, log: this.log, state: this.state, cfg: this.cfg, ...(board ? { board } : {}) })
          .then((r) => {
            this.lastResults.calendar = r;
            if (reason === 'kick' && r && r.ok !== false) this.#kickedCalOkAt = startedAt;
            this.#emit('calendar', r, { startedAt, reason });
            return r;
          }))
        /* 이 판이 끝났다(성공·실패·사람 기다림 모두) — 그 사이 다음 판이 시작했으면 그 판 것이라 안 지운다. */
        .finally(() => { if (this.#calRunningSince === startedAt) this.#calRunningSince = null; });
    });
  }
  rates() {
    if (!this.runsTask('rates')) return this.notRunPass('rates');
    if (this.writesLocked) return this.lockedPass('rates');
    return this.enqueue('rates', () => this.withAdapter((adapter) =>
      runRates({
        channel: this.channel, adapter, dashboard: this.dashboard, log: this.log, state: this.state,
        horizonDays: this.cfg.rates?.horizonDays ?? 180, budget: this.cfg.rates?.budgetPerPass ?? 200,
        /* 새 예약으로 급한 캘린더 판이 기다리면 요금 반복문이 비켜 준다(rates.js). 코디네이터가 없으면 urgentUntil 은 늘 0. */
        shouldYield: () => this.#urgentUntil > Date.now(),
      })
        .then((r) => (this.lastResults.rates = r))));
  }
  rooms() {
    /* ★ 잠겨 있으면 객실 자동 매핑(channel_room_map 넣기)도 안 한다 — 제안·미매핑 경보만 남긴다.
         확인 안 된 객실 읽기로 만든 매핑은 사람이 붙여넣는 야놀자 예약(op=paste mapRoom)까지 같은 표로 바꾼다.
         안 잠긴 채널(여기어때)은 예전 그대로다. */
    if (!this.runsTask('rooms')) return this.notRunPass('rooms');
    const autoMapExact = !!this.cfg.rooms?.autoMapExact && !this.writesLocked;
    return this.enqueue('rooms', () => this.withAdapter((adapter) =>
      runRooms({ channel: this.channel, adapter, dashboard: this.dashboard, log: this.log, state: this.state, autoMapExact })
        .then((r) => (this.lastResults.rooms = r))));
  }

  /** 지금 다섯 칸이 어떤지 한 줄로. 사람이 로그에서 읽고, 리모컨 화면이 이 줄을 본다.
   *
   * ★ 상주는 칸마다 주기가 달라서(유입 2분·반영 1분·요금 15분) "한 바퀴" 라는 것이 없다.
   *   그래서 --once 의 요약 줄이 상주 로그에는 영영 안 나온다 — 리모컨이 "아직 한 바퀴를
   *   못 돌았습니다" 를 계속 보여 준 까닭이다(2026-09-14). 아직 차례가 안 온 칸은
   *   '못 돎' 이 아니라 '대기' 다. 그 둘을 섞으면 멀쩡한 것을 고장으로 읽는다. */
  statusLine(kinds = ['rooms', 'inbound', 'outbound', 'calendar', 'rates']) {
    const r = this.lastResults || {};
    return kinds.map((k) => {
      const v = r[k];
      if (v === undefined) return `${k}:대기`;
      return `${k}:${kindWord(v)}`;
    }).join(' ');
  }

  /** 한 바퀴 — --once 와 시작 직후에 쓴다. */
  async cycle() {
    await this.heartbeat();
    await this.rooms();
    await this.inbound();
    /* 미리보기 모드는 읽기만 한다 — 파트너센터를 건드리는 반영·요금은 돌리지 않는다.
       설치 확인이 목적인데 잘못된 매핑으로 방을 막아 버리면 그게 사고다. */
    if (this.previewOnly) {
      this.log.info('미리보기 모드 — 반영·요금은 돌리지 않는다');
      return this.lastResults;
    }
    await this.outbound();
    await this.calendar();
    await this.rates();
    return this.lastResults;
  }

  start() {
    /* 유입·정기 캘린더는 채널별 주기(intervals() — 앞당김이 붙은 야놀자만 300·900, 그 밖은 공통값 그대로). 나머지는 공통값.
       ★ 코디네이터(main.attachCross)가 start() **앞**에 붙어 crossPaced 를 정해 둔다 — 그래서 여기서 읽는 값이 맞다. */
    const iv = this.intervals();
    /* ★ unref() 하지 않는다. 전부 unref 면 이벤트 루프를 잡아 주는 것이 브라우저 자식 프로세스뿐이라,
         브라우저가 죽는 순간 실행기가 로그 한 줄 없이 정상 종료(코드 0)로 사라진다. 실측으로 확인했다.
         정지는 stop() 이 clearInterval 로 한다. */
    const every = (sec, fn) => {
      this.timers.push(setInterval(() => { if (!this.stopped) fn(); }, sec * 1000));
    };
    every(iv.heartbeatSec, () => this.heartbeat());
    every(iv.inboundSec, () => this.inbound());
    every(iv.outboundSec, () => this.outbound());
    every(iv.calendarSec, () => this.calendar({ reason: 'timer' }));
    every(iv.ratesSec, () => this.rates());
    every(6 * 3600, () => this.rooms());
    this.cycle();
  }

  async stop() {
    this.stopped = true;
    for (const t of this.timers) clearInterval(t);
    /* 멈춘 줄을 무한정 기다리지 않는다 — 멈춘 한 판이 곧 멈춘 프로세스가 된다.
       두고 가도 된다: 어차피 이 프로세스는 곧 끝나고, 다음 판이 처음부터 다시 읽는다. */
    await soft(this.queue, 10000, null);
    await soft(this.session.close(), 10000, null);
  }
}
