#!/usr/bin/env node
/* 실행기 진입점.
     npm start                 상주 — 주기마다 유입·반영·요금·생존 신호
     npm run once              한 바퀴만 돌고 끝(설치 확인용)
     node src/main.js --channel yeogi   한 채널만
   준비: .env(env.example 참고) → npm run pair -- <채널> 로 파트너센터 페어링. */
import { loadEnvFile, loadConfig } from './lib/config.js';
import { createLogger, scrubSecrets } from './lib/log.js';
import { DashboardClient } from './dashboard/client.js';
import { LocalState, gapSince } from './engine/state.js';
import { ChannelWorker, kindWord } from './engine/worker.js';
import { SingleInstanceLock } from './lib/lock.js';
import { startControlServer } from './lib/control.js';
import { CloudState } from './lib/cloud-state.js';
import { soft } from './lib/deadline.js';

export function parseArgs(argv) {
  const out = { once: false, channels: null, preview: false };
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--once') out.once = true;
    /* 첫 설치 확인 — 읽기만 하고 대시보드에도 파트너센터에도 쓰지 않는다. --once 를 함께 켠다. */
    else if (argv[i] === '--preview') { out.preview = true; out.once = true; }
    else if (argv[i] === '--channel') out.channels = String(argv[++i] || '').split(',').filter(Boolean);
  }
  return out;
}

/* 공통값과 다른 채널 주기만 한 줄로(예: 'yanolja 유입 300s·캘린더 900s'). 없으면 '' — 여기어때만·잠긴 야놀자와 둘이면 빈 글자.
   워커가 실제로 쓰는 값(w.intervals() — 앞당김이 붙어야 채널 기본값)을 본다. 교차를 붙인 **뒤에** 불러야 맞다. */
export function channelIntervalNote(workers, cfg) {
  const iv = cfg?.intervals || {};
  const parts = [];
  for (const w of workers || []) {
    const own = typeof w?.intervals === 'function' ? w.intervals() : cfg?.channelIntervals?.[w?.channel];
    if (!own) continue;
    const bits = [];
    if (own.inboundSec != null && own.inboundSec !== iv.inboundSec) bits.push(`유입 ${own.inboundSec}s`);
    if (own.calendarSec != null && own.calendarSec !== iv.calendarSec) bits.push(`캘린더 ${own.calendarSec}s`);
    if (bits.length) parts.push(`${w.channel} ${bits.join('·')}`);
  }
  return parts.join(', ');
}

/** 채널 계정 상태로 다룰 채널을 고른다(BR-008). 계정 행이 없으면 경고하고 다룬다. */
export function pickChannels(wanted, accounts, log) {
  if (!accounts) return wanted;
  return wanted.filter((c) => {
    const a = accounts.find((x) => x.channel_code === c);
    if (!a) { log.warn(`${c}: 콘솔 '채널 계정 상태' 에 줄이 없다 — 일단 다룬다`); return true; }
    if (a.status === 'live') return true;
    log.info(`${c}: 계정 상태가 '${a.status}' 라 다루지 않는다(운영 중(live)으로 바꾸면 시작)`);
    return false;
  });
}

/* 상주 프로세스는 스스로 죽지 않는다. 어딘가에서 놓친 프로미스 하나 때문에 두 채널이 통째로
   멈추는 것보다, 남기고 계속 도는 편이 낫다(BR-006 "장애 때 영업이 멈추면 안 된다"). */
export function guardProcess(log) {
  process.on('unhandledRejection', (e) => {
    log.error('받지 못한 실패 — 계속 돈다:', (e && e.stack) || e);
  });
  process.on('uncaughtException', (e) => {
    log.error('잡지 못한 예외 — 계속 돈다:', (e && e.stack) || e);
  });
}

/** 대시보드에 붙는다. 실패하면 2·4·8·16·30초로 늦춰 가며 다시 해 본다(최대 6회). */
export async function connectDashboard(cfg, log, { attempts = 6, sleep = (ms) => new Promise((r) => setTimeout(r, ms)), make } = {}) {
  const build = make || (() => new DashboardClient(cfg.dashboard, { log: log.child('대시보드') }));
  let last;
  for (let i = 0; i < attempts; i++) {
    try {
      return await build().init();
    } catch (e) {
      last = e;
      if (i === attempts - 1) break;
      const wait = Math.min(2000 * 2 ** i, 30000);
      log.warn(`대시보드에 못 붙었다(${i + 1}/${attempts}) — ${Math.round(wait / 1000)}초 뒤 다시: ${e.message}`);
      await sleep(wait);
    }
  }
  throw last;
}

/** 두 타워 교차 코디네이터를 붙인다(engine/coordinator.js). 안 붙으면 null.
    ★ 모듈을 **여기서만** 읽는다 — 끄는 스위치 둘이 다 off 면 읽지도 않아 기준판과 같은 경로이고,
      읽다 깨져도(반쪽 배포) 실행기는 예전처럼 돈다. 교차 하나 때문에 유입·방막기가 멈추면 그대로 오버부킹이다. */
export async function attachCross({ workers, cfg, dashboard, log, load = () => import('./engine/coordinator.js') }) {
  if (cfg?.cross?.kick === false && (cfg?.crosscheck?.mode || 'log') === 'off') return null;
  try {
    const { createCoordinator } = await load();
    return createCoordinator({ workers, cfg, dashboard, log });
  } catch (e) {
    log.error(`교차 코디네이터를 못 붙였다 — ${e.message} (두 타워는 예전처럼 따로 돈다)`);
    return null;
  }
}

export async function main(argv = process.argv.slice(2)) {
  loadEnvFile();
  const cfg = loadConfig();
  const log = createLogger('실행기', { level: cfg.logLevel });
  guardProcess(log);
  const args = parseArgs(argv);

  /* 실행기는 한 PC 에 하나만. 둘이 뜨면 브라우저 프로필이 겹쳐 한쪽이 계속 실패하는데
     생존 신호는 양쪽이 다 써서 콘솔에는 정상으로 보인다. */
  const lock = new SingleInstanceLock(cfg.paths.stateDir);
  const got = lock.acquire();
  if (!got.ok) {
    log.error(`이미 실행기가 돌고 있다(pid ${got.pid}${got.at ? `, ${got.at} 부터` : ''}) — 그것을 끄고 다시 실행할 것`);
    return 1;
  }
  const release = () => lock.release();
  process.once('exit', release);

  /* 부팅 직후에는 네트워크가 아직 안 올라와 대시보드 로그인이 실패한다.
     한 번 실패했다고 끝내면 작업 스케줄러의 재시작에만 기대게 된다 — 여기서 몇 번 기다려 본다. */
  const dashboard = await connectDashboard(cfg, log);
  const accounts = await dashboard.channelAccounts().catch((e) => { log.warn(`채널 계정 상태를 못 읽었다 — ${e.message}`); return null; });
  const wanted = args.channels ? cfg.channels.filter((c) => args.channels.includes(c)) : cfg.channels;
  const channels = pickChannels(wanted, accounts, log);
  if (!channels.length) { log.error('다룰 채널이 없다'); return 1; }
  /* ★ 이 PC 의 state/ 를 읽기 **전에** 클라우드에서 받는다 — 그래야 새 PC 도 페어링 없이 이어진다.
       받다가 잘못되면(열쇠가 다르다·표가 없다) 멈추지 않고 이 PC 것으로 그냥 간다. 안 도는 것보다 낫다. */
  let cloud = null;
  if (cfg.cloudState) {
    try {
      cloud = new CloudState({
        db: dashboard.db, propertyId: cfg.dashboard.propertyId, secret: cfg.stateSecret,
        stateDir: cfg.paths.stateDir, channels, log,
      });
      await cloud.pull();
    } catch (e) {
      log.error(`클라우드 상태를 못 받았다 — ${e.message} (이 PC 의 state/ 로 그냥 간다)`);
      cloud = null;
    }
  }
  const state = new LocalState(cfg.paths.stateDir);
  /* ★ 얼마나 비어 있었나 — 켜자마자 한 줄로 말한다(state.js 의 markAlive 머리말).
       콘솔은 멈춘 동안 경보를 띄우지만, 다시 켜면 그 사실이 어디에도 안 남아 원인을 못 쫓는다. */
  const gap = gapSince(state.lastAlive());
  if (gap) log.warn(`이전 판이 ${gap.text} 동안 멈춰 있었다(마지막 생존 ${gap.at}) — 그 사이 들어온 예약·취소와 파트너센터 변화는 반영되지 않았다. 이번 판이 따라잡는다`);
  state.markAlive();
  state.pruneTodos();
  state.pruneCancelsSent?.();
  const workers = [];
  for (const channel of channels) {
    try {
      workers.push(new ChannelWorker({ channel, cfg, dashboard, log, state, previewOnly: args.preview }));
    } catch (e) {
      // 채널 JSON 이 없거나 깨졌으면 그 채널만 빼고 간다 — 한 채널 때문에 전체가 서면 안 된다
      log.error(`${channel}: 다루지 못한다 — ${e.message}`);
    }
  }
  if (!workers.length) { log.error('돌릴 수 있는 채널이 없다'); return 1; }
  if (args.preview) log.info(`미리보기 — 채널 ${channels.join(', ')} · 읽기만 하고 아무것도 저장하지 않는다`);
  else log.info(`시작 — 채널 ${channels.join(', ')} · 유입 ${cfg.intervals.inboundSec}s · 반영 ${cfg.intervals.outboundSec}s · 요금 ${cfg.intervals.ratesSec}s`);

  if (args.once) {
    let bad = 0;
    for (const w of workers) {
      /* 설치 확인(--once)도 영원히 멈추면 안 된다 — 사람이 화면 앞에서 기다린다. */
      const r = (await soft(w.cycle(), 15 * 60000, null)) || {};
      await w.stop();
      /* ★ 결과가 없는 것(null)도 실패다. 브라우저가 안 열리면 큐가 오류를 삼키고 결과가 비는데,
           그것을 '정상' 으로 세면 설치 확인이 통과해 버린다. */
      const kinds = args.preview ? ['rooms', 'inbound'] : ['rooms', 'inbound', 'outbound', 'calendar', 'rates'];
      /* 쓰기 잠금으로 건너뛴 칸은 '잠금' 으로 적는다(실패로 세지는 않는다 — 정한 일이다). */
      const line = kinds.map((k) => `${k}:${kindWord(r[k])}`).join(' ');
      log.info(`${w.channel} 한 바퀴 — ${line}`);
      if (kinds.some((k) => !r[k] || r[k].ok === false)) bad++;
    }
    if (bad) log.error(`${bad}개 채널이 한 바퀴를 못 돌았다 — 위 줄과 artifacts/ 를 볼 것`);
    if (cloud) await cloud.push().catch((e) => log.warn(`클라우드에 상태를 못 올렸다 — ${e.message}`));
    release();
    return bad ? 1 : 0;
  }

  /* ★ 두 타워 교차(2026-09-23) — 사장님 그림: "클라이언트 하나에 두 컨트롤타워, 클라이언트가 최종 체크 후 대시보드와 연결".
       --once·--preview 에는 안 붙인다(위에서 이미 돌아갔다). 첫 cycle() 의 유입 결과도 받으려면 start() **앞**에 붙여야 한다.
       쓸 수 있는 타워가 둘 미만이면(여기어때 혼자·잠긴 야놀자와 둘) null — 아무것도 안 붙고 예전 경로 그대로다.
       CROSS_KICK=off + CROSSCHECK=off 면 모듈조차 안 읽는다. 붙이다 실패해도 실행기는 예전처럼 돈다. */
  const cross = await attachCross({ workers, cfg, dashboard, log });
  /* 채널별 주기는 교차를 붙인 뒤에야 정해진다(앞당김이 붙은 타워만 채널 기본값) — 공통값과 다를 때만 한 줄. */
  const ivNote = channelIntervalNote(workers, cfg);
  if (ivNote) log.info(`채널별 주기 — ${ivNote}`);
  for (const w of workers) w.start();
  /* ★ 상주도 상태 줄을 남긴다. 안 남기면 로그를 눈으로 훑어도 지금 어떤지 알 수 없고,
       리모컨 화면도 읽을 것이 없다(2026-09-14 에 실제로 그랬다).
       칸마다 주기가 다르므로 "한 바퀴" 가 아니라 지금 상태를 적는다. */
  /* ★ 죽은 사람 스위치.
       2026-09-14: 프로세스는 살아 있는데 **76분 동안 한 줄도 안 썼다.** 줄(queue)이 직렬이라
       어느 한 작업이 시간제한 없이 기다리면 그 뒤의 모든 작업이 영영 안 돈다 — 생존 신호까지.
       그러면 화면에는 '돌고 있음' 으로 보이고, 그 사이 예약이 안 들어온다.
       나아가지 않으면 **스스로 끝낸다.** 작업 스케줄러가 5분 안에 다시 띄운다(IgnoreNew + 반복 시작).
       끝내는 것이 왜 안전한가: 유입은 목록을 매번 처음부터 다시 읽는다 — 빠지는 예약이 없다. */
  const stuckMs = Math.max(5, Number(process.env.STUCK_EXIT_MIN || 20)) * 60000;
  const deadMan = setInterval(async () => {
    /* ★ **가장 늙은** 워커를 본다. 가장 젊은 쪽을 보면 채널 하나만 얼었을 때
         다른 채널이 계속 나아가는 바람에 영영 못 잡는다(지금은 한 채널뿐이지만
         야놀자가 붙는 순간 그대로 구멍이 된다). */
    const oldest = workers.reduce((m, w) => Math.min(m, w.lastProgressAt || 0), Infinity);
    const idle = Date.now() - oldest;
    if (idle < stuckMs) return;
    const stuckOnes = workers.filter((w) => Date.now() - (w.lastProgressAt || 0) >= stuckMs).map((w) => w.channel);
    clearInterval(deadMan);
    log.error(`${stuckOnes.join(', ')}: ${Math.round(idle / 60000)}분 동안 한 칸도 끝내지 못했다 — 어딘가에서 멈춘 것으로 보고 끝낸다(작업 스케줄러가 다시 띄운다)`);
    /* 닫기마저 멈출 수 있다. 10초 뒤에는 무슨 일이 있어도 나간다. */
    const hard = setTimeout(() => process.exit(1), 10000);
    hard.unref?.();
    /* 브라우저를 두고 가면 다음 판이 같은 프로필을 못 연다. 다만 닫는 것도 멈출 수 있으므로 5초만 기다린다. */
    await Promise.race([
      Promise.all(workers.map((w) => w.session?.close?.().catch(() => {}))),
      new Promise((r) => setTimeout(r, 5000)),
    ]);
    release();
    process.exit(1);
  }, 60000);
  deadMan.unref?.();

  const statusTimer = setInterval(() => {
    for (const w of workers) log.info(`${w.channel} 지금 상태 — ${w.statusLine()}`);
    if (cross) log.info(cross.statusLine());
  }, 60000);
  statusTimer.unref?.();
  /* ★ 자물쇠에 "아직 살아 있다" 를 남긴다. 이것이 없으면, 정전·강제 종료로 남은 자물쇠의 pid 를
       윈도우가 다른 프로그램에 물려준 뒤부터 **재부팅할 때마다 '이미 돌고 있다' 로 판정돼 영영 안 뜬다.**
       1분마다 만져 두면 lock.js 의 나이 판정이 죽은 자물쇠를 알아서 치운다. */
  const lockTimer = setInterval(() => lock.touch(), 60000);
  lockTimer.unref?.();
  /* 세션은 주기마다 새로 저장된다(saveStorage). 그것을 10분에 한 번 클라우드에 올려 두면,
     이 PC 가 꺼져도 다른 PC 가 그 자리에서 이어받는다. 바뀐 것이 없으면 올리지 않는다. */
  const cloudTimer = cloud
    ? setInterval(() => cloud.push().catch((e) => log.warn(`클라우드에 상태를 못 올렸다 — ${e.message}`)), 10 * 60000)
    : null;
  /* 대시보드의 "지금 돌려" 버튼이 두드릴 자리(CONTROL_PORT 가 없으면 안 연다). 자세한 것은 lib/control.js. */
  const control = await startControlServer({ port: cfg.control?.port, token: cfg.control?.token, workers, log })
    .catch((e) => { log.error(`조종 창구를 못 열었다 — ${e.message} (실행기는 그대로 돈다)`); return null; });
  await new Promise((resolve) => {
    const stop = async (sig) => {
      log.info(`${sig} — 정리하고 끝낸다`);
      clearInterval(lockTimer);
      clearInterval(deadMan);
      clearInterval(statusTimer);
      cross?.stop();
      if (cloudTimer) clearInterval(cloudTimer);
      if (control) {
        /* 살아 있는 연결이 있으면 close 의 콜백이 영영 안 온다 — 먼저 끊고, 그래도 3초까지만. */
        control.closeAllConnections?.();
        await soft(new Promise((r) => control.close(r)), 3000, null);
      }
      await Promise.all(workers.map((w) => w.stop()));
      /* 끄기 전에 마지막으로 한 번 올린다 — 방금까지의 세션이 다음 PC 로 넘어가게. */
      if (cloud) await cloud.push().catch((e) => log.warn(`클라우드에 상태를 못 올렸다 — ${e.message}`));
      release();
      resolve();
    };
    process.once('SIGINT', () => stop('SIGINT'));
    process.once('SIGTERM', () => stop('SIGTERM'));
  });
  return 0;
}

if (process.argv[1] && /src[\\/]main\.js$/.test(process.argv[1])) {
  main().then((code) => process.exit(code), (e) => { console.error(scrubSecrets(e.stack || e.message)); process.exit(1); });
}
