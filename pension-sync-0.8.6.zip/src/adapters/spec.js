/* 채널 JSON(config/selectors/<channel>.json) 을 읽고 모양을 검사한다.
   이 파일이 곧 "파트너센터를 아는 곳" 이다. 코드는 여기 적힌 단계만 실행한다(BR-013).

   필수 절:
     channel, baseUrl, unit("room"|"count"), login{url, loggedIn{request|selector|urlNotContains}}, reservations{steps, maxDays},
     rooms{steps}, availability{read{steps}, close{steps}, open{steps}, states{open,closed,sold}, ymFormat}
   선택: login.auto(단계), login.twoFactor{selector}, rates{set{steps}}, verified(bool), writes(bool), notes(문자열 배열)

   writes — **false 면 이 채널에는 쓰지 않는다**(쓰기 잠금, D-075). true 면 지금처럼 쓴다. 자세한 판정은 writesLockReason.
     ["setClosed"] 처럼 **배열**이면 그 쓰기만 연다(v3, D-080 — 야놀자는 방막기·방열기만). 나머지 쓰기는 잠금 그대로다.
     ⚠ 배열을 모르는 옛 코드(v2 까지)는 배열을 '잘못 적은 값' 으로 보고 전부 잠근다 — JSON 만 새것이어도 안전 쪽이다.
   only — 이 채널에서 **돌릴 칸만** 적는다(v3). 예: ["outbound"] = 대시보드 할 일만 처리하고, 유입·캘린더·요금·객실 읽기는
     파트너센터를 **아예 열지 않는다.** 없으면 예전처럼 다 돈다(여기어때). 알 수 없는 값이 섞이면 아무 칸도 안 돌린다(모르면 멈춘다).
   outbound.maxTodosPerPass — 반영 한 판에 파트너센터에서 처리할 할 일 수 상한(v3). 남은 것은 다음 판(OUTBOUND_INTERVAL_SEC 뒤).
     ★ 왜 verified 로 안 잠그나: 여기어때 JSON 도 verified:false 인 채로 실제 운영 중이다. verified 로 잠그면
       여기어때 방막기가 같이 멈춰 그대로 오버부킹이 된다. 그래서 **따로** 잠근다. 칸이 없는 여기어때는 예전 그대로다.
   availability.states.exact — true 면 상태 값을 **통째로 같을 때만** 맞춘다(대소문자·앞뒤 공백 무시). 없으면 예전처럼 부분 문자열.

   login.loggedIn 은 셋 중 하나로 판단한다. request 가 있으면 그것을 먼저 쓴다(가장 믿을 만하다):
     "loggedIn": { "request": { "url": "/api/…", "method": "GET", "expect": "body" } }
       로그인해야만 되는 API 를 한 번 불러 4xx 면 로그인 안 된 것으로 본다.
       expect(점 경로)를 주면 200 이어도 그 자리가 비면 안 된 것으로 본다.
     selector / urlNotContains — 화면으로 보는 예전 방식. 로그인 화면에도 있는 요소를 고르면 잘못 읽으니 주의. */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const SELECTORS_DIR = path.resolve(HERE, '../../config/selectors');

export function specPath(channel) {
  return path.join(SELECTORS_DIR, `${channel}.json`);
}

export function loadSpec(channelOrPath) {
  const p = channelOrPath.endsWith('.json') ? channelOrPath : specPath(channelOrPath);
  if (!fs.existsSync(p)) throw new Error(`채널 JSON 이 없다: ${p}`);
  const spec = JSON.parse(fs.readFileSync(p, 'utf8'));
  const problems = validateSpec(spec);
  if (problems.length) throw new Error(`채널 JSON 이 잘못됐다(${p}):\n- ${problems.join('\n- ')}`);
  return spec;
}

function isSteps(v) { return Array.isArray(v) && v.every((s) => s && typeof s === 'object'); }

/** 문제 목록을 돌려준다(비면 정상). */
export function validateSpec(spec) {
  const out = [];
  const need = (cond, msg) => { if (!cond) out.push(msg); };
  need(spec && typeof spec === 'object', 'JSON 객체가 아니다');
  if (!spec || typeof spec !== 'object') return out;
  need(typeof spec.channel === 'string' && spec.channel, 'channel 이 없다');
  need(typeof spec.baseUrl === 'string' && /^https?:\/\//.test(spec.baseUrl), 'baseUrl 은 http(s):// 로 시작해야 한다');
  need(['room', 'count'].includes(spec.unit), 'unit 은 "room" 또는 "count"');
  const L = spec.login || {};
  need(typeof L.url === 'string', 'login.url 이 없다');
  need(L.loggedIn && (L.loggedIn.request || L.loggedIn.selector || L.loggedIn.urlNotContains),
    'login.loggedIn 에 request 또는 selector 또는 urlNotContains 가 있어야 한다');
  if (L.loggedIn && L.loggedIn.request != null) {
    need(typeof L.loggedIn.request.url === 'string' && L.loggedIn.request.url, 'login.loggedIn.request.url 이 없다');
  }
  if (L.auto != null) need(isSteps(L.auto), 'login.auto 는 단계 배열');
  const R = spec.reservations || {};
  need(isSteps(R.steps), 'reservations.steps 가 없다');
  need(Number.isInteger(R.maxDays) && R.maxDays > 0, 'reservations.maxDays 는 양의 정수');
  need(isSteps((spec.rooms || {}).steps), 'rooms.steps 가 없다');
  const A = spec.availability || {};
  need(isSteps((A.read || {}).steps), 'availability.read.steps 가 없다');
  need(isSteps((A.close || {}).steps), 'availability.close.steps 가 없다');
  need(isSteps((A.open || {}).steps), 'availability.open.steps 가 없다');
  need(A.states && ['open', 'closed', 'sold'].every((k) => Array.isArray(A.states[k])), 'availability.states 에 open/closed/sold 배열이 있어야 한다');
  need(['YYYY-MM', 'YYYY.MM', 'YYYYMM'].includes(A.ymFormat || 'YYYY-MM'), 'availability.ymFormat 은 YYYY-MM | YYYY.MM | YYYYMM');
  if (A.states && A.states.exact != null) need(typeof A.states.exact === 'boolean', 'availability.states.exact 는 true 또는 false');
  if (spec.rates != null) need(isSteps((spec.rates.set || {}).steps), 'rates.set.steps 는 단계 배열');
  /* ★ writes 칸은 여기서 **거절하지 않는다.** 불(bool)이 아닌 값(글자 "false"·null·0/1)을 문제로 올리면 loadSpec 이
       던지고, 워커가 안 만들어져(main.js '다루지 못한다') **읽기까지 채널 전체가 선다** — 여기어때라면 유입·방막기가
       통째로 멈춰 그대로 오버부킹이다. 그래서 잘못 적은 값은 '쓰기만 잠금' 으로 받고(writesLockReason),
       워커 경고 한 줄과 doctor ✗ 로 드러낸다. 잠그는 쪽으로 틀리므로 확인 안 된 선택자로 누르는 일은 없다. */
  return out;
}

/* 확인 전 초안이라 **writes 칸이 없어도** 잠그는 채널. 여기어때는 넣지 않는다(칸 없음 = 예전처럼 쓴다).
   ★ 왜: 잠금이 yanolja.json 의 "writes": false 한 줄에만 달려 있으면, 코드만 0.8.5 폴더에 덮어쓰거나
     사장님 PC 에 손본 옛 yanolja.json(discover 뒤 고친 것)이 남아 있을 때 칸이 없어 **쓰기가 다시 켜진다** —
     파싱 안 되던 twoFactor·확인 안 된 막기·열기·요금이 한꺼번에 돌아온다. 그래서 코드 쪽에도 안전망을 둔다.
     실측을 마쳐 verified:true 가 되면 이 안전망은 비킨다(그때는 칸 없음 = 쓴다). */
const LOCK_UNLESS_VERIFIED = new Set(['yanolja']);

/* 배열로 열 수 있는 쓰기(v3). 지금은 방막기·방열기 하나뿐이다 — 요금·원장 저장·객실 자동 매핑·손막음은 배열로 못 연다. */
export const OPENABLE_WRITES = new Set(['setClosed']);
const WRITE_WORD = { setClosed: '방막기·방열기' };

/**
 * 이 채널에 쓰면 안 되는 까닭(한 줄) — 쓰면 되면 null.
 * @param {object} spec
 * @param {string} [kind] 'setClosed' 처럼 **그 쓰기 하나**를 묻는다. 없으면 '모든 쓰기' 를 묻는다(하나라도 잠겼으면 잠금).
 *   "writes": true              → null(쓴다)
 *   "writes": ["setClosed"]     → kind 가 'setClosed' 면 null, 그 밖(또는 kind 없음)은 잠금 (v3, D-080)
 *   "writes": false             → 잠금
 *   "writes": 불이 아닌 값(null·"false"·"true"·0·1…) → 잠금(잘못 적은 것 — 풀림으로 읽지 않는다)
 *   칸 없음                      → 야놀자처럼 확인 전 채널이 verified:true 가 아니면 잠금, 그 밖(여기어때)은 null
 * 잠기면: 파트너센터 방막기·방열기·요금, 대시보드 원장 저장(paste commit)·객실 자동 매핑, 손막음 --yes 를 안 한다.
 * 읽기(로그인·객실·판매 상태·예약)·미리보기·생존 신호는 그대로 돈다. 손님 정보는 담지 않는다(BR-020).
 */
export function writesLockReason(spec, kind) {
  if (!spec || typeof spec !== 'object') return null;
  if (Object.prototype.hasOwnProperty.call(spec, 'writes')) {
    if (spec.writes === true) return null;
    if (spec.writes === false) return '채널 JSON "writes": false';
    if (Array.isArray(spec.writes)) {
      const bad = spec.writes.filter((w) => !OPENABLE_WRITES.has(w));
      /* 모르는 값이 섞였으면 **전부** 잠근다 — "setclosed"·"rates" 같은 오타를 절반만 믿으면 무엇이 열렸는지 아무도 모른다. */
      if (bad.length) return `채널 JSON writes 에 모르는 값(${bad.map((w) => JSON.stringify(w)).join(', ')}) — 잘못 적은 것으로 보고 잠근다`;
      if (kind && spec.writes.includes(kind)) return null;
      const open = spec.writes.map((w) => WRITE_WORD[w] || w).join('·') || '없음';
      return `채널 JSON writes 는 ${open} 만 연다 — ${kind ? (WRITE_WORD[kind] || kind) : '그 밖의 쓰기'} 는 잠금`;
    }
    return `채널 JSON 의 writes 가 true 또는 false 가 아니다(${JSON.stringify(spec.writes) ?? String(spec.writes)}) — 잘못 적은 것으로 보고 잠근다`;
  }
  if (LOCK_UNLESS_VERIFIED.has(spec.channel) && spec.verified !== true) {
    return `${spec.channel}.json 에 writes 칸이 없다(확인 전 초안) — 코드만 덮어쓰고 JSON 은 옛것인 것으로 보고 잠근다`;
  }
  return null;
}

/**
 * 이 채널에 쓰면 안 되는가(쓰기 잠금). 판정은 writesLockReason.
 * ★ 여기어때 JSON 에는 writes 칸이 없고 채널도 안전망 목록 밖이라 false — 동작이 한 글자도 안 바뀐다.
 */
export function writesLocked(spec, kind) {
  return writesLockReason(spec, kind) != null;
}

/* 돌릴 수 있는 칸(v3 only). */
export const TASKS = new Set(['rooms', 'inbound', 'outbound', 'calendar', 'rates']);

/**
 * 이 채널에서 돌릴 칸 — 없으면 null(전부 돈다, 예전 그대로).
 * ★ 모르는 값이 섞였거나 배열이 아니면 **빈 집합**(아무 칸도 안 돈다). 틀린 설정으로 파트너센터를 여는 쪽보다
 *   안 여는 쪽이 안전하다 — 생존 신호는 따로 돌아 콘솔에서 '실행기는 살아 있다' 는 보인다. doctor 가 ✗ 로 드러낸다.
 * @returns {Set<string>|null}
 */
export function onlyTasks(spec) {
  if (!spec || typeof spec !== 'object' || !Object.prototype.hasOwnProperty.call(spec, 'only')) return null;
  const v = spec.only;
  if (!Array.isArray(v) || v.some((t) => !TASKS.has(t))) return new Set();
  return new Set(v);
}

/** only 칸이 잘못 적혔는가(doctor 용). 없으면 false. */
export function onlyTypo(spec) {
  if (!spec || !Object.prototype.hasOwnProperty.call(spec, 'only')) return false;
  return !Array.isArray(spec.only) || spec.only.some((t) => !TASKS.has(t));
}

/** 반영 한 판의 할 일 상한(v3). 칸이 없으면 null(상한 없음 — 예전 그대로, 여기어때).
    ★ 칸이 있는데 잘못 적었으면(0·음수·글자) **1** — 상한을 뜻한 설정을 '상한 없음' 으로 읽으면 한꺼번에 몰아친다. */
export function maxTodosPerPass(spec) {
  const o = spec && spec.outbound;
  if (!o || typeof o !== 'object' || !Object.prototype.hasOwnProperty.call(o, 'maxTodosPerPass')) return null;
  const n = o.maxTodosPerPass;
  return Number.isInteger(n) && n > 0 ? n : 1;
}

/** 'YYYY-MM-DD' → 채널이 쓰는 월 표기. */
export function ymOf(date, format = 'YYYY-MM') {
  const y = date.slice(0, 4), m = date.slice(5, 7);
  if (format === 'YYYY.MM') return `${y}.${m}`;
  if (format === 'YYYYMM') return `${y}${m}`;
  return `${y}-${m}`;
}

/** 채널의 상태 문구 → 'open'|'closed'|'sold'|'unknown'.
    ★ 긴 낱말부터 본다. 짧은 것부터 보면 '판매중지'(마감)가 '판매중'(판매 중)에 걸려
      막힌 날을 열려 있다고 읽고, 재개 할 일이 아무 일도 안 하고 완료된다. */
export function normalizeState(text, states) {
  const s = String(text || '').trim();
  if (!s) return 'unknown';
  /* ★ exact(채널 JSON 이 켰을 때만): 통째로 같은 값만 맞춘다. 부분 문자열이면 'NOT_ON_SALE'·'PRE_SALE' 처럼
       목록에 없는 마감 값이 'SALE'(열림)에 걸려 막힌 날을 열린 날로 읽는다. 못 맞추면 'unknown' — 건드리지 않는다(BR-015).
       켜지 않은 채널(여기어때)은 아래 예전 길을 그대로 탄다. */
  if (states.exact === true) {
    const up = s.toUpperCase();
    for (const k of ['sold', 'closed', 'open']) for (const w of states[k] || []) if (w && String(w).trim().toUpperCase() === up) return k;
    return 'unknown';
  }
  const words = [];
  for (const k of ['sold', 'closed', 'open']) for (const w of states[k] || []) if (w) words.push({ k, w });
  words.sort((a, b) => b.w.length - a.w.length);
  for (const { k, w } of words) if (s.includes(w)) return k;
  return 'unknown';
}
