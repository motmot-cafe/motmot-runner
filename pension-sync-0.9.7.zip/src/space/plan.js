/* 스페이스클라우드 자동 막기(0.9.3) — 순수 도우미. 브라우저·대시보드·파일을 하나도 안 만진다(시험이 이것만 따로 본다).
   사장님(2026-10-15): 예약 상세의 「이 홀은 스페이스클라우드에서도 팝니다 — 호스트센터 「+예약추가」 로 같은 시간을 막고,
     예약자명에 MOTMOT-<예약번호> 를 적어 주세요」 를 보시고 "이런것도 실행기로 자동화 부탁해" → "ㄱㄱ".

   ★ 시각 적는 법은 호스트센터 화면 코드 그대로다(main.370905ae, 2026-10-15 받아 읽음):
       「+예약추가」 창의 시작 칸은 값 v 가 「v+1 시」 로 보이고 보낼 때 v+1 을 보낸다 → SHOUR = 진짜 시작 시각(0~23).
       끝 칸은 값 v 가 「v+1 시」 로 보이고 v 를 그대로 보낸다 → EHOUR = 진짜 끝 시각 − 1(0~23).
       달력은 `shour ~ min(23, ehour)+1` 로 그린다. 그래서 14~18시 = SHOUR "14" · EHOUR "17", 종일(0~24) = "0" · "23".
   ★ 우리 줄은 표식 `MOTMOT-<예약번호>` **하나로만** 알아본다. 이름·메모에 그 글자가 정확히 없으면 남의 줄이다 —
       시각·날짜가 같아도 손대지 않는다(사장님이 손으로 넣은 다른 대관일 수 있다). */
import crypto from 'node:crypto';
import { dayKst } from '../lib/kst.js';

/** 우리 표식. 숫자 뒤에 숫자가 더 붙으면(MOTMOT-2720 ≠ MOTMOT-272) 다른 표식이다. */
export const MARKER_RE = /MOTMOT-(\d{1,12})(?!\d)/;

/** 글자에서 첫 표식을 뽑는다(없으면 null). 브라우저 안의 같은 규칙(hostcenter.js inPage)과 반드시 같아야 한다. */
export function markerOf(text) {
  const m = String(text == null ? '' : text).match(MARKER_RE);
  return m ? `MOTMOT-${m[1]}` : null;
}

/** 서버 줄의 표식이 정말 그 예약번호의 것인가 — 서버가 틀린 표식을 줘도 남의 줄을 지우지 않게 한 번 더 본다. */
export function markerFor(bookingId) {
  const s = String(bookingId == null ? '' : bookingId).trim();
  return /^\d{1,12}$/.test(s) ? `MOTMOT-${s}` : null;
}

/** 시작·끝 시각(정시, KST) → 호스트센터가 받는 SHOUR·EHOUR(글자). 끝 24 → EHOUR "23". 맞지 않으면 던진다. */
export function shourEhour(start, end) {
  const s = Number(start);
  const e = Number(end);
  if (!Number.isInteger(s) || !Number.isInteger(e) || s < 0 || s > 23 || e < 1 || e > 24 || e <= s) {
    throw new Error(`시각이 맞지 않는다: ${start}~${end} (시작 0~23, 끝 1~24, 끝 > 시작)`);
  }
  return { SHOUR: String(s), EHOUR: String(e - 1) };
}

/** 'YYYY-MM-DD' → 'YYYYMMDD'. */
export function compactYmd(date) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(date || ''))) throw new Error(`날짜 형식이 아니다: ${date}`);
  return String(date).replace(/-/g, '');
}

/** 호스트센터 날짜 글자 → 'YYYY-MM-DD'(KST). 'YYYYMMDD' · 'YYYY-MM-DD' · ISO 를 받는다. 모르면 ''.
    ★ symd 모양은 아직 확인 전이다(계약서 1절) — 셋 다 받는다. 시간대가 붙은 ISO 는 KST 로 옮긴 날이다. */
export function normYmd(v) {
  const s = String(v == null ? '' : v).trim();
  if (/^\d{8}$/.test(s)) return `${s.slice(0, 4)}-${s.slice(4, 6)}-${s.slice(6, 8)}`;
  return dayKst(s);
}

/** 정시 글자·숫자 → 정수(못 읽으면 NaN). '14' · 14 · '14:00' 을 받는다. */
export function hourOf(v) {
  if (typeof v === 'number') return Number.isInteger(v) ? v : NaN;
  const m = String(v == null ? '' : v).trim().match(/^(\d{1,2})(?::00(?::00)?)?$/);
  return m ? Number(m[1]) : NaN;
}

/** 달력 주소를 같게 맞춘다 — 서버(api/ota.mjs)와 같은 규칙: 앞뒤 공백 · webcal:// · http:// → https://. */
export function normUrl(u) {
  return String(u == null ? '' : u).trim().replace(/^(webcal|http):\/\//i, 'https://');
}

/** 달력 주소의 지문(sha256 앞 16자). 주소 자체는 비밀이라 지문만 주고받는다.
    브라우저 안에서도 crypto.subtle 로 같은 것을 센다(hostcenter.js) — 이것은 시험·맞대기용이다. */
export function hashUrl(u) {
  return crypto.createHash('sha256').update(normUrl(u), 'utf8').digest('hex').slice(0, 16);
}

/** 우리 표식 메모 — 사람이 호스트센터에서 보고 무엇인지 알게. 손님 정보는 없다. */
export function memoFor(marker) {
  return `${marker} 모토모토 예약(실행기)`;
}

/** 서버 줄 하나가 손대도 되는 모양인가. 아니면 까닭(한국어), 맞으면 null. */
export function rowProblem(row) {
  if (!row || typeof row !== 'object') return '줄이 비었다';
  if (row.op !== 'add' && row.op !== 'remove') return `모르는 동작 ${String(row.op).slice(0, 12)}`;
  const want = markerFor(row.booking_id);
  if (!want || row.marker !== want) return '표식이 예약번호와 다르다 — 손대지 않았다';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(row.date || ''))) return '날짜 형식이 아니다';
  try { shourEhour(row.start_hour, row.end_hour); } catch (e) { return e.message; }
  if (!row.resource_id) return '홀이 비었다';
  return null;
}

/** 「+예약추가」 가 보내는 몸통 그대로(화면 코드 onReservationAdd). 하루짜리 · 반복 없음 · 이름 = 표식 · 연락처 없음. */
export function addBody({ date, startHour, endHour, marker, memo }) {
  if (!markerOf(marker) || markerOf(marker) !== marker) throw new Error('표식이 MOTMOT-<번호> 모양이 아니다');
  const ymd = compactYmd(date);
  const { SHOUR, EHOUR } = shourEhour(startHour, endHour);
  return {
    SDATE: ymd, EDATE: ymd, SHOUR, EHOUR,
    NAME: marker, TEL: '', MEMO: String(memo || memoFor(marker)).slice(0, 100),
    REPEAT_TYPE: '-1', REPEAT_END_DATE: ymd,
  };
}

/** 이 외부예약이 이 예약(표식)의 이 날 줄인가 — 시각은 안 본다. 표식이 **정확히** 같아야 한다. */
export function isOursOnDate(x, row) {
  return !!(x && row && row.marker && x.marker === row.marker && normYmd(x.symd) === row.date);
}

/** 이 외부예약이 이 줄과 **정확히** 같은가 — 표식 · 날 · 시작 · 끝(EHOUR = 끝 − 1; 끝 24 는 23, 혹시 24 로 읽혀도).
    ★ 「ehour === 끝」 너그러움은 없앴다(검토 2026-10-15 [2]): 같은 예약이 끝을 한 시간 늘이거나 줄이면 그 너그러움이
      옛 줄을 새 줄로 · 새 줄을 옛 줄로 읽어, 넣기는 옛 줄을 제 것으로 삼고 풀기는 새 줄까지 지웠다(홀이 비어 팔린다). */
export function isOurs(x, row) {
  if (!isOursOnDate(x, row)) return false;
  const start = Number(row.start_hour);
  const end = Number(row.end_hour);
  const s = hourOf(x.shour);
  const e = hourOf(x.ehour);
  return s === start && (e === end - 1 || (end === 24 && e === 24));
}

/** 첫 「정확히 같은 줄」(없으면 null). */
export function findOurs(externals, row) {
  return (externals || []).find((x) => isOurs(x, row)) || null;
}

/** 이 예약 표식이 그 날에 단 줄 전부(시각 상관없이). */
export function oursOnDate(externals, row) {
  return (externals || []).filter((x) => isOursOnDate(x, row));
}

/** 한 번에 손대는 우리 줄 상한 — 무엇이 잘못돼도 한 판에 이보다 많이 지우지 않는다. */
export const MAX_TOUCH = 5;

/**
 * 막기(add) = 「그 날 그 상품에 이 표식 줄이 **딱 하나**, 시각이 **정확히** 같게」 를 만든다(서버 0.9.3: 예약 × 홀 × 날 하나에 살아 있는 줄 하나).
 * @returns {{ action:'keep'|'put'|'post', keep?:object, put?:object, extra:object[] }}
 *   keep — 정확한 줄이 있다(extra 는 지울 나머지 우리 줄) · put — 우리 줄은 있는데 시각이 다르다(그 줄을 고친다) · post — 하나도 없다(새로 넣는다)
 *   골라 둘 줄은 적어 둔 번호(host_ref)를 먼저 고른다.
 */
export function planAdd(externals, row) {
  const ours = oursOnDate(externals, row);
  const ref = row && row.host_ref != null && row.host_ref !== '' ? String(row.host_ref) : null;
  const pick = (list) => (ref && list.find((x) => x.id === ref)) || list[0];
  const exact = ours.filter((x) => isOurs(x, row));
  if (exact.length) {
    const keep = pick(exact);
    return { action: 'keep', keep, extra: ours.filter((x) => x.id !== keep.id).slice(0, MAX_TOUCH) };
  }
  if (ours.length) {
    const put = pick(ours);
    return { action: 'put', put, extra: ours.filter((x) => x.id !== put.id).slice(0, MAX_TOUCH) };
  }
  return { action: 'post', extra: [] };
}

/** 'fac-hall=123, fac-seminar=456' → { 'fac-hall': '123', … }. 모양이 틀린 칸은 버린다. */
export function parseOverrides(v) {
  if (v && typeof v === 'object') return Object.fromEntries(Object.entries(v).map(([k, p]) => [String(k).trim(), String(p).trim()]).filter(([k, p]) => k && /^\d{1,15}$/.test(p)));
  const out = {};
  for (const part of String(v || '').split(/[,\s;]+/)) {
    const i = part.indexOf('=');
    if (i <= 0) continue;
    const k = part.slice(0, i).trim();
    const p = part.slice(i + 1).trim();
    if (k && /^\d{1,15}$/.test(p)) out[k] = p;
  }
  return out;
}

/**
 * 홀 ↔ 상품 짝 — 자세히. CLI(map · pair)가 이것으로 보여 준다.
 * @returns {Array<{resource_id, name, productId:string|null, how:'override'|'hash'|'ambiguous'|'none', candidates:number}>}
 */
export function matchHalls(halls, productsList, overrides) {
  const ov = parseOverrides(overrides);
  const byHash = new Map();
  for (const sp of productsList || []) {
    for (const p of (sp && sp.products) || []) {
      if (!p || !p.icalHash || p.productId == null) continue;
      const k = String(p.icalHash).toLowerCase();
      if (!byHash.has(k)) byHash.set(k, new Set());
      byHash.get(k).add(String(p.productId));
    }
  }
  return (halls || []).filter((h) => h && h.resource_id).map((h) => {
    const base = { resource_id: String(h.resource_id), name: h.name ? String(h.name).slice(0, 60) : '' };
    /* ★ .env 로 적은 짝이 언제나 이긴다 — 주소 지문이 안 맞는 판(주소를 바꿨다 · 두 상품이 같은 달력)을 사람이 푸는 자리다. */
    if (ov[base.resource_id]) return { ...base, productId: ov[base.resource_id], how: 'override', candidates: 1 };
    const set = h.feed_hash ? byHash.get(String(h.feed_hash).toLowerCase()) : null;
    if (!set || !set.size) return { ...base, productId: null, how: 'none', candidates: 0 };
    /* ⚠ 지문이 같은 상품이 둘 이상이면 고르지 않는다 — 엉뚱한 홀을 막으면 그 홀이 남의 손님에게 안 팔린다. */
    if (set.size > 1) return { ...base, productId: null, how: 'ambiguous', candidates: set.size };
    return { ...base, productId: [...set][0], how: 'hash', candidates: 1 };
  });
}

/** 홀 ↔ 상품 짝 → { resource_id: productId }. 못 맞춘 홀(없음 · 둘 이상)은 빠진다. */
export function resolveProducts(halls, productsList, overrides) {
  const out = {};
  for (const m of matchHalls(halls, productsList, overrides)) if (m.productId) out[m.resource_id] = m.productId;
  /* 서버가 홀 목록을 못 줬어도(달력 주소가 없는 홀) .env 짝은 쓴다. */
  for (const [rid, pid] of Object.entries(parseOverrides(overrides))) if (!out[rid]) out[rid] = pid;
  return out;
}

/** 'YYYY-MM-DD' → { year, month }(숫자). */
export function ymOf(date) {
  const [y, m] = String(date).split('-').map(Number);
  return { year: y, month: m };
}

/** 한 줄을 사람이 읽는 꼴로 — 손님 정보 없음(표식 · 날짜 · 시각 · 홀). */
export function rowLabel(row) {
  return `${row.marker} ${row.date} ${row.start_hour}~${row.end_hour}시 ${row.resource_id}`;
}
