/* 스페이스클라우드 일꾼(0.9.3) — 우리 예약이 홀을 잡으면 호스트센터 「+예약추가」 로 같은 시간을 막고(MOTMOT-번호), 취소되면 푼다.
   사장님(2026-10-15): "이런것도 실행기로 자동화 부탁해" → "ㄱㄱ". 무엇을 막을지는 **서버가** 정한다(op=space_pull) —
   여기서는 서버가 준 줄만 하고(add · remove), 한 줄마다 결과를 보고한다(op=space_report).
   ★ 줄의 뜻(서버 2026-10-15 — 예약 × 홀 × 날 하나에 살아 있는 줄 하나):
       add    = 「그 날 그 상품에 이 표식 줄이 **딱 하나, 시각이 정확히**」 — 없으면 넣고(POST) · 시각만 다르면 그 줄을 고치고(PUT) · 남는 우리 줄은 지운다.
       remove = 「그 날 이 표식 줄이 **하나도 없게**」 — 시각 상관없이 전부 지운다(host_ref 는 참고만).
     어느 쪽이든 쓰고 나면 **다시 읽어** 정한다. 시각이 바뀐 예약에 서버는 풀기를 따로 안 만든다(고치기로 한다).

   ★★ 이 일꾼은 여기어때를 **절대 못 세운다.** 그래서
       · main.js 가 동적 import 를 try/catch 로 감싸 붙인다(이 파일이 깨져도 여기어때는 돈다). 죽은 사람 스위치 · 교차 · 조종 창구에는 안 들어간다.
       · 브라우저 프로필이 따로다(state/spacecloud/profile) — 여기어때 브라우저와 안 겹친다.
       · **할 일이 있을 때만** 브라우저를 연다(그리고 6시간에 한 번 로그인 확인). 판이 끝나면 닫는다 — 띄워 두지 않는다.
       · 한 판은 5분 안에 끝난다(lib/deadline.js). 넘으면 브라우저를 닫고 다음 판이 처음부터 한다.
   ★★ 손님 정보는 안 다룬다 — 페이지 안에서 버린다(hostcenter.js 머리말). 여기까지 오는 것은 번호 · 날짜 · 시각 · 표식뿐이다.
   ★ 남의 줄은 안 건드린다 — 이름이나 메모에 **정확히** 그 줄의 표식(MOTMOT-<예약번호>)이 있는 외부예약만 우리 것이다.
   ★ 주기는 고정이다(무작위 흔들기 없음, D-076). 로그인이 풀리면 15분에 한 번만 다시 본다(사람 확인 화면을 부르지 않게).
   ⚠ 이 일꾼의 로그 줄에는 'rooms:' 와 'inbound:' 를 함께 쓰지 않는다 — 실행기 화면이 그 줄을 여기어때 상태로 읽는다. */
import fs from 'node:fs';
import path from 'node:path';
import { ChannelSession } from '../browser/session.js';
import { deadline, soft } from '../lib/deadline.js';
import { SingleInstanceLock } from '../lib/lock.js';
import { forDashboard, maskPii } from '../lib/log.js';
import { todayKst } from '../lib/kst.js';
import { openHost, listProducts, monthExternals, addExternal, updateExternal, deleteExternal, HostError } from './hostcenter.js';
import { rowProblem, findOurs, oursOnDate, planAdd, MAX_TOUCH, resolveProducts, matchHalls, ymOf, rowLabel, memoFor } from './plan.js';

export const SPACE_VERSION = '0.9.3';
export const CHANNEL = 'spacecloud';
/* ★ 스페이스클라우드 브라우저 프로필 자물쇠(state/spacecloud/profile.lock) — 프로필을 **지금 쓰는 쪽**이 쥔다.
     상주 일꾼은 한 판 동안(서버에 묻기 전부터 브라우저를 닫을 때까지), `npm start -- --space pair|map` 은 도는 내내.
     왜 실행기 자물쇠(executor.lock)가 아닌가: 「호스트센터 로그인」(pair)은 10분까지 걸리고, 그 사이 작업 스케줄러가 상주를 다시 띄운다.
     실행기 자물쇠로 막으면 여기어때까지 그동안 못 뜨거나(pair 가 쥔 경우) pair 가 거절된다(상주가 쥔 경우).
     이 자물쇠면 여기어때는 그대로 돌고, 상주 일꾼은 로그인 창이 열린 동안 **서버에 묻지도 않고**(줄을 안 맡는다) 쉰다. */
export const PROFILE_LOCK = path.join(CHANNEL, 'profile.lock');
/** 한 판의 마감 — 넘으면 브라우저를 닫고 버린다. */
export const PASS_MS = 5 * 60000;
/** 할 일이 없어도 이만큼마다 한 번은 열어 로그인을 본다(상태가 늘 새것이고, 「로그인 필요」 를 일찍 안다). */
export const SESSION_CHECK_MS = 6 * 3600000;
/** 로그인이 풀린 뒤 다시 열어 보는 간격. 페어링을 새로 했으면(storage.json 이 바뀜) 기다리지 않는다. */
export const LOGIN_RETRY_MS = 15 * 60000;
const PRODUCTS_TTL_MS = 6 * 3600000;
/* 짝을 못 찾은 홀의 줄이 있으면, 이만큼 지난 상품 목록은 다시 읽는다(사장님이 방금 상품 · 주소를 바꿨을 수 있다). */
const PRODUCTS_RETRY_MS = 30 * 60000;
/* 브라우저가 사라졌다는 Playwright 의 말들 — 이때는 줄 탓이 아니다. */
const BROWSER_GONE = /has been closed|Target closed|browser has disconnected|Browser closed/i;
/* 켠 뒤 첫 판까지 — 여기어때 첫 바퀴가 먼저 브라우저를 띄우게 비켜 준다(고정값). */
const FIRST_DELAY_MS = 45000;

/** 사람 · 서버가 읽을 짧은 글 — 주소 · 경로 · 전화 · 이메일 · 비밀값을 지우고 줄인다. 상태 파일 · 보고 · 로그가 같이 쓴다. */
export function clean(text, max = 200) {
  const s = String(text == null ? '' : text)
    .replace(/\b(?:https?|webcal|wss?):\/\/\S+/gi, '(주소)')
    .replace(/\b(?:[\w-]+\.)+(?:kr|com|net|org|io|co)(?:\/\S*)?/gi, '(주소)')
    .replace(/\s+/g, ' ').trim();
  return forDashboard(maskPii(s), max);
}

/* .env 값이 이상해도 여기어때를 세우지 않는다 — config.js 가 이미 기본값으로 읽지만 한 번 더 좁힌다. */
function spaceCfg(c = {}) {
  const n = (v, d, lo, hi) => { const x = Number(v); return Number.isFinite(x) ? Math.min(hi, Math.max(lo, Math.round(x))) : d; };
  return {
    enabled: c.enabled !== false,
    intervalSec: n(c.intervalSec, 120, 30, 3600),
    maxPerPass: n(c.maxPerPass, 3, 1, 10),
    remove: c.remove !== false,
    headless: c.headless !== false,
    products: c.products || '',
  };
}

/* 서버에 보낼 「스페이스클라우드가 거절했다」 — 저쪽 글은 빼고 응답 번호만(위 ★).
   ★ 스페이스클라우드가 한 말(HostError.said · 쓰기 결과의 error)은 **이 PC 기록에만** 둔다 — 그 글에 무엇(다른 손님 이름 등)이
     실려 올지 모르고, 사람 이름은 걸러 낼 수가 없다. 서버(직원 화면 · 알림)에는 정해 둔 말과 응답 번호만 간다. */
function hostSaid(what, status) {
  const n = Number(status);
  return `스페이스클라우드가 ${what}${Number.isFinite(n) && n > 0 ? `(HTTP ${n})` : ''} — 까닭은 실행기 화면 로그`;
}

// ── 상태 파일(state/spacecloud/status.json) — 실행기 화면이 읽는다. 손님 정보 · 주소 없음. 일꾼과 명령(pair · map)이 같이 쓴다. ──
export function statusFileOf(stateDir) { return path.join(stateDir, CHANNEL, 'status.json'); }
function readStatusFile(file) {
  try {
    const s = JSON.parse(fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, ''));
    if (s && typeof s === 'object') return s;
  } catch { /* 처음이거나 깨졌다 — 새로 쓴다 */ }
  return { v: 1, login: null, pending: 0, done: 0, failed: 0, halls: {} };
}
/** 앞 상태 + 고칠 칸 → 새 상태. 막음 · 실패 수는 **오늘(KST)** 것이다 — 날이 바뀌면 0 부터. */
export function nextStatus(prev = {}, patch = {}, { now = Date.now(), enabled = true, version = SPACE_VERSION } = {}) {
  const today = todayKst(new Date(now));
  const p0 = prev || {};
  const base = p0.day === today ? p0 : { ...p0, done: 0, failed: 0 };
  const next = {
    v: 1, at: new Date(now).toISOString(), ok: base.ok ?? null, enabled,
    login: base.login ?? null, pending: base.pending ?? 0, done: base.done ?? 0, failed: base.failed ?? 0,
    preview: !!base.preview, lastError: base.lastError ?? null, lastAction: base.lastAction ?? null,
    halls: base.halls && typeof base.halls === 'object' ? base.halls : {}, day: today, version,
    ...patch,
  };
  if (next.lastError != null) next.lastError = clean(next.lastError, 160);
  if (next.lastAction != null) next.lastAction = clean(next.lastAction, 120);
  return next;
}
function saveStatusFile(file, next) {
  fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(next, null, 1));
  fs.renameSync(tmp, file);
}
/** 상태 파일 몇 칸만 고쳐 쓴다(pair · map 이 로그인을 확인한 뒤). 실패해도 던지지 않는다 — 돌려주는 값이 false. */
export function patchStatusFile(stateDir, patch, opts = {}) {
  try {
    const file = statusFileOf(stateDir);
    const next = nextStatus(readStatusFile(file), patch, opts);
    saveStatusFile(file, next);
    return next;
  } catch { return false; }
}

/** 이 PC 에 남길 글 — 우리 말 + 스페이스클라우드가 한 말(있으면). 서버로는 안 보낸다. */
function localText(e) {
  const said = e && e.said ? ` — ${e.said}` : '';
  return clean(`${e && e.message}${said}`);
}

export class SpaceWorker {
  /** @param {object} o { cfg, dashboard, log, session?, playwright?, now?, version?, previewOnly?, settleMs?, passMs? } */
  constructor(o) {
    this.cfg = o.cfg;
    this.sc = spaceCfg(o.cfg?.space);
    this.dashboard = o.dashboard;
    this.log = o.log;
    this.stateDir = o.cfg.paths.stateDir;
    this.dir = path.join(this.stateDir, CHANNEL);
    this.statusFile = statusFileOf(this.stateDir);
    this.session = o.session || new ChannelSession({
      channel: CHANNEL, stateDir: this.stateDir, secret: o.cfg.stateSecret, headless: this.sc.headless,
      browser: o.cfg.browser, log: this.log, playwright: o.playwright, busyLock: PROFILE_LOCK,
    });
    this.profileLock = o.profileLock || new SingleInstanceLock(this.stateDir, { file: PROFILE_LOCK });
    this.now = o.now || (() => Date.now());
    this.version = o.version || SPACE_VERSION;
    this.previewOnly = !!o.previewOnly;
    /* 화면이 스스로 토큰을 바꾸는 동안 기다리는 시간(hostcenter.openHost). 시험은 0. */
    this.settleMs = o.settleMs ?? 15000;
    /* 한 판 마감(기본 5분). 시험만 줄인다. */
    this.passMs = o.passMs ?? PASS_MS;
    this.timers = [];
    this.stopped = false;
    this.running = null;
    this.lastOpenAt = 0;
    this.loginNeededAt = 0;
    this.storageMtimeAtLogin = 0;
    this.products = null;
    this.productsAt = 0;
    this.monthCache = new Map();
    this.said = new Map();
    this.status = this.readStatus();
    /* 켤 때의 세션 백업 시각을 기준으로 둔다 — 그 뒤에 바뀌면(사람이 「호스트센터 로그인」 을 다시 함) 곧바로 다시 본다. */
    this.storageMtimeAtLogin = this.storageMtime();
  }

  // ── 상태 파일(state/spacecloud/status.json) — 실행기 화면이 읽는다. 손님 정보 · 주소 없음. ──
  readStatus() { return readStatusFile(this.statusFile); }
  writeStatus(patch = {}) {
    const next = nextStatus(this.status, patch, { now: this.now(), enabled: this.sc.enabled, version: this.version });
    this.status = next;
    try { saveStatusFile(this.statusFile, next); } catch (e) { this.log.debug(`상태 파일을 못 썼다 — ${clean(e.message)}`); }
    return next;
  }
  bump(kind, n = 1) {
    const today = todayKst(new Date(this.now()));
    const cur = this.status?.day === today ? (this.status[kind] || 0) : 0;
    return cur + n;
  }

  /** 같은 말은 바뀔 때만 한 번 — 2분마다 같은 경고가 쌓이면 진짜 경고가 묻힌다. 바뀌지 않았으면 debug 로. */
  sayOnce(topic, text, level = 'warn') {
    if (this.said.get(topic) === text) { this.log.debug(text); return; }
    this.said.set(topic, text);
    this.log[level](text);
  }

  storageMtime() {
    try { return fs.statSync(this.session.storageFile).mtimeMs; } catch { return 0; }
  }
  /** 로그인이 풀린 뒤 페어링을 새로 했나(storage.json 이 다시 써졌나). */
  storageChanged() {
    const m = this.storageMtime();
    return m > 0 && m !== this.storageMtimeAtLogin;
  }

  // ── 상주 ──
  start() {
    if (this.timers.length) return;
    this.stopped = false;
    const every = this.sc.intervalSec * 1000;
    /* ★ unref 한다 — 이 일꾼 혼자서는 실행기를 붙들지 않는다(여기어때 일꾼의 타이머가 붙든다). */
    const iv = setInterval(() => { if (!this.stopped) this.tick(); }, every);
    const first = setTimeout(() => { if (!this.stopped) this.tick(); }, FIRST_DELAY_MS);
    iv.unref?.();
    first.unref?.();
    this.timers.push(iv, first);
    this.log.info(`시작 — ${this.sc.intervalSec}초마다 서버에 막을 것을 묻는다(한 판 최대 ${this.sc.maxPerPass}줄 · 풀기 ${this.sc.remove ? '켬' : '끔'}) · 할 일이 있을 때만 브라우저를 연다`);
  }
  tick() {
    return this.pass().catch((e) => { this.log.error(`한 판이 깨졌다 — ${clean(e && e.message)}`); return null; });
  }
  async stop() {
    this.stopped = true;
    for (const t of this.timers) { clearInterval(t); clearTimeout(t); }
    this.timers = [];
    if (this.running) await soft(this.running, 10000, null);
    await soft(this.session.close(), 10000, null);
  }

  /** 지금 상태 한 줄(상주 로그 · 리모컨). ⚠ 'rooms:' · 'inbound:' 를 쓰지 않는다. */
  statusLine() {
    const s = this.status || {};
    const login = s.login === true ? '로그인 됨' : s.login === false ? '로그인 필요' : '로그인 모름';
    const halls = Object.entries(s.halls || {});
    const hallNote = halls.length ? ` · 홀 짝 ${halls.filter(([, v]) => v).length}/${halls.length}` : '';
    return `${login} · 막을 것 ${s.pending ?? 0} · 오늘 끝냄 ${s.done ?? 0} · 실패 ${s.failed ?? 0}${hallNote}` +
      (s.ok === false && s.lastError ? ` · 마지막 실패 ${s.lastError}` : '');
  }

  /** 한 판 결과 → 한 줄(--once 요약 · CLI). ⚠ 'rooms:' · 'inbound:' 를 쓰지 않는다. */
  summarize(r) {
    if (!r) return '끝내지 못함(시간 초과)';
    if (r.skipped) return `건너뜀 — ${r.skipped}`;
    if (r.busy) return `쉼 — ${r.busy}`;
    if (r.login === false) return `로그인 필요 — 실행기 화면 「호스트센터 로그인」 또는 npm start -- --space pair${r.rows ? ` (줄 ${r.rows} 은 그대로 둔다)` : ''}`;
    if (r.error) return `실패 — ${clean(r.error, 160)}`;
    const login = r.opened ? (r.login === true ? '로그인 됨' : '로그인 모름') : '브라우저 안 엶(할 일 없음)';
    if (r.preview) {
      const count = {};
      for (const p of r.plans || []) count[p.plan] = (count[p.plan] || 0) + 1;
      const parts = Object.entries(count).map(([k, v]) => `${k} ${v}`);
      return `미리보기(아무것도 안 바꿈) · ${login} · 줄 ${r.rows}${parts.length ? ` · ${parts.join(' · ')}` : ''}`;
    }
    return `${login} · 줄 ${r.rows} · 끝냄 ${r.done} · 실패 ${r.failed}`;
  }

  /**
   * 한 판. preview=true 면 서버가 줄을 맡기지 않고(lease 없음) 우리도 아무것도 쓰지 않는다 — 무엇을 할지만 돌려준다.
   * force=true 면 할 일이 없어도 · 로그인 기다림 중이어도 브라우저를 연다(CLI preview · once).
   * @returns {Promise<{ok:boolean, preview:boolean, rows:number, done:number, failed:number, login:boolean|null, plans:Array}>}
   */
  pass(o = {}) {
    if (this.running) { this.log.debug('지난 판이 아직 도는 중 — 이번 판은 건너뛴다'); return Promise.resolve({ ok: true, skipped: '이미 도는 중', plans: [] }); }
    const opts = { preview: o.preview ?? this.previewOnly, force: !!o.force };
    /* 판마다 손잡이 하나 — 마감으로 버린 판(배경에서 아직 돈다)은 그 뒤로 **아무것도 보고하지 않는다**.
       줄은 맡긴 시간(10분)이 지나면 서버가 다시 내주고, 다음 판이 다시 읽어 판단한다(이미 넣었으면 「이미 있음」). */
    const ctl = { dead: false };
    const p = (async () => {
      try {
        return await deadline(this.#run(opts, ctl), this.passMs, '스페이스클라우드 한 판');
      } catch (e) {
        ctl.dead = true;
        const msg = localText(e);
        this.log.error(`한 판 실패 — ${msg}`);
        /* 마감으로 버린 판은 배경에서 아직 돈다 — 브라우저를 닫아 끊는다(다음 판이 새로 띄운다). */
        if (e && e.timedOut) await soft(this.session.close(), 10000, null);
        this.writeStatus({ ok: false, lastError: msg, preview: opts.preview });
        return { ok: false, error: msg, preview: opts.preview, rows: 0, done: 0, failed: 0, login: this.status.login ?? null, plans: [] };
      }
    })();
    this.running = p;
    p.finally(() => { if (this.running === p) this.running = null; }).catch(() => {});
    return p;
  }

  async #pull(preview) {
    const limit = preview ? 10 : this.sc.maxPerPass;
    let r;
    try {
      r = await this.dashboard.spacePull({ limit, preview, version: this.version });
    } catch (e) {
      return { ok: false, error: `서버에 못 물었다 — ${clean(e && e.message)}` };
    }
    if (!r || r.ok === false) {
      const error = r && r.code === 'no_table'
        ? '서버에 스페이스클라우드 표가 아직 없다 — supabase-129 를 먼저 돌려야 한다'
        : `서버가 막을 것을 못 줬다 — ${clean(r && r.error) || '응답 없음'}`;
      return { ok: false, error };
    }
    const rows = Array.isArray(r.rows) ? r.rows.slice(0, limit) : [];
    return { ok: true, halls: Array.isArray(r.halls) ? r.halls : [], rows };
  }

  async #run(opts, ctl) {
    /* 프로필을 다른 곳(「호스트센터 로그인」 창 · 다른 명령)이 쓰고 있으면 **서버에 묻기 전에** 쉰다 — 줄을 맡았다가 못 하고 버리는 일이 없다.
       경보 · 「로그인 필요」 보고는 안 한다(고장이 아니다). 상태 파일의 시각만 새로 적는다(실행기 화면이 「한동안 기록 없음」 으로 안 보게). */
    let got;
    try { got = this.profileLock.acquire(); } catch (e) { got = { ok: true, noLock: true }; this.log.debug(`프로필 자물쇠를 못 썼다 — ${clean(e && e.message)} (그냥 간다)`); }
    if (!got.ok) {
      const mine = got.pid === process.pid;
      const busy = mine ? '지난 판이 아직 브라우저를 닫는 중' : `호스트센터 브라우저를 다른 곳(pid ${got.pid ?? '?'} — 「호스트센터 로그인」 창일 수 있다)이 쓰는 중`;
      this.sayOnce('busy', `${busy} — 이번 판은 쉬고 다음 판에 다시 본다`, 'info');
      this.writeStatus({ preview: opts.preview });
      return { ok: true, busy, preview: opts.preview, rows: 0, done: 0, failed: 0, login: this.status?.login ?? null, plans: [] };
    }
    this.said.delete('busy');
    try {
      return await this.#runLocked(opts, ctl);
    } finally {
      if (!got.noLock) this.profileLock.release();
    }
  }

  async #runLocked({ preview, force }, ctl) {
    const now = this.now();
    /* 다른 곳(「호스트센터 로그인」 명령)이 상태 파일을 더 새로 썼으면 그것을 받는다 — 안 받으면 이 판이 옛 「로그인 필요」 로 덮는다. */
    const disk = this.readStatus();
    if (disk.at && (!this.status?.at || String(disk.at) > String(this.status.at))) this.status = disk;
    this.monthCache = new Map();
    const res = { ok: true, preview, rows: 0, done: 0, failed: 0, login: this.status?.login ?? null, plans: [] };
    const pull = await this.#pull(preview);
    if (!pull.ok) {
      this.sayOnce('pull', `서버 — ${pull.error}`);
      this.writeStatus({ ok: false, lastError: pull.error, preview });
      return { ...res, ok: false, error: pull.error };
    }
    this.said.delete('pull');
    const { halls, rows } = pull;
    res.rows = rows.length;
    /* 로그인이 풀린 채인데 세션 백업이 새로 써졌다(사람이 다시 로그인했다) → 할 일이 없어도 곧바로 열어 확인한다(검토 [5]). */
    const relogged = (this.loginNeededAt || this.status?.login === false) && this.storageChanged();
    const due = force || relogged || now - this.lastOpenAt >= SESSION_CHECK_MS;
    if (!rows.length && !due) {
      /* 할 일이 없으면 브라우저를 안 연다 — 대부분의 판이 여기서 끝난다. */
      const stillOut = this.status?.login === false;
      this.writeStatus({ pending: 0, preview, ...(stillOut ? {} : { ok: true, lastError: null }) });
      return res;
    }
    /* 로그인 기다림 — 15분 안에는 다시 안 연다. 그 사이 맡은 줄은 곧바로 「로그인 필요」 로 돌려준다(줄 탓이 아니다 — 시도 수가 안 늘어난다). */
    if (this.loginNeededAt && !force && now - this.loginNeededAt < LOGIN_RETRY_MS && !this.storageChanged()) {
      if (!preview) for (const row of rows) await this.#report(ctl, row, { ok: false, code: 'login_needed', error: '호스트센터 로그인 필요' });
      const left = Math.ceil((LOGIN_RETRY_MS - (now - this.loginNeededAt)) / 60000);
      this.log.debug(`로그인 기다림 — ${left}분 뒤 다시 본다(맡은 ${rows.length}줄은 돌려줬다)`);
      this.writeStatus({ ok: false, login: false, pending: rows.length, preview, lastError: '호스트센터 로그인 필요' });
      return { ...res, ok: false, login: false, waiting: true, plans: rows.map((r) => ({ id: r.id, op: r.op, label: safeLabel(r), plan: '로그인 필요' })) };
    }

    let page;
    try {
      page = await this.session.open();
    } catch (e) {
      /* 맡은 줄은 보고하지 않는다 — 10분 뒤 서버가 다시 내준다(시도 수를 안 쓴다). */
      const msg = `브라우저를 열지 못했다 — ${clean(e && e.message, 140)}`;
      this.sayOnce('open', msg, 'error');
      this.writeStatus({ ok: false, lastError: msg, pending: rows.length, preview });
      return { ...res, ok: false, error: msg };
    }
    this.said.delete('open');
    this.lastOpenAt = now;
    res.opened = true;
    let loggedIn = false;
    try {
      const host = await openHost(page, { settleMs: this.settleMs });
      if (!host.loggedIn) {
        if (host.transient) {
          const msg = `호스트센터가 응답하지 않는다 — ${clean(host.why, 120)}`;
          this.sayOnce('host', msg);
          this.writeStatus({ ok: false, lastError: msg, pending: rows.length, preview });
          return { ...res, ok: false, error: msg };
        }
        await this.#loginNeeded(ctl, host.why, rows, preview);
        return { ...res, ok: false, login: false, plans: rows.map((r) => ({ id: r.id, op: r.op, label: safeLabel(r), plan: '로그인 필요' })) };
      }
      loggedIn = true;
      this.said.delete('host');
      await this.#loginBack();
      res.login = true;

      let map = {};
      let i = 0;
      try {
        if (rows.length || (halls.length && now - this.productsAt >= PRODUCTS_TTL_MS)) {
          map = await this.#products(page, halls, rows);
        }
        for (; i < rows.length; i++) {
          const row = rows[i];
          try {
            if (ctl.dead) break;
            const out = await this.#row(ctl, page, row, map, preview);
            res.plans.push({ id: row.id, op: row.op, label: safeLabel(row), plan: out.plan, ...(out.why ? { why: out.why } : {}) });
            if (out.done) res.done++;
            if (out.failed) res.failed++;
          } catch (e) {
            if (e instanceof HostError && e.login) throw e;
            /* 브라우저가 닫혔다(마감 · 사람이 창을 닫음) — 남은 줄을 「실패」 로 태우지 않고 판을 끝낸다(줄은 서버가 다시 준다). */
            if (ctl.dead || BROWSER_GONE.test(String(e && e.message))) throw e;
            const msg = localText(e);
            this.log.error(`${safeLabel(row)}: ${msg}`);
            res.plans.push({ id: row.id, op: row.op, label: safeLabel(row), plan: '실패', why: msg });
            if (!preview && !e.rowReported) {
              /* 서버에는 우리 말만(스페이스클라우드가 한 말은 빼고) — e.message 는 우리가 지은 글이다. */
              await this.#report(ctl, row, { ok: false, code: 'other', error: e instanceof HostError ? e.message : clean(e && e.message) });
            }
            if (!preview) res.failed++;
            this.writeStatus({ lastError: `${safeLabel(row)} — ${msg}` });
          }
        }
      } catch (e) {
        if (!(e instanceof HostError && e.login)) throw e;
        /* 판 도중에 로그인이 풀렸다 — 남은 줄(지금 줄 포함)은 「로그인 필요」 로 돌려준다(줄 탓이 아니다). */
        loggedIn = false;
        /* 지금 줄을 이미 따로 보고했으면(넣은 뒤에 풀림) 그 줄은 빼고 돌려준다. */
        const from = e.rowReported ? i + 1 : i;
        if (e.rowReported && rows[i]) { res.plans.push({ id: rows[i].id, op: rows[i].op, label: safeLabel(rows[i]), plan: '확인 안 됨' }); res.failed++; }
        await this.#loginNeeded(ctl, e.message, rows.slice(from), preview);
        for (const row of rows.slice(from)) res.plans.push({ id: row.id, op: row.op, label: safeLabel(row), plan: '로그인 필요' });
        res.login = false;
        res.ok = false;
      }
      if (res.failed) res.ok = false;
      if (!preview) {
        this.writeStatus({
          ok: res.ok && res.login !== false, login: res.login, preview,
          pending: Math.max(0, rows.length - res.done),
          done: this.bump('done', res.done), failed: this.bump('failed', res.failed),
          ...(res.ok && res.login !== false ? { lastError: null } : {}),
        });
      } else {
        this.writeStatus({ ok: res.login !== false, login: res.login, preview: true, pending: rows.length });
      }
      if (rows.length) {
        this.log.info(`한 판 — 줄 ${rows.length} · 끝냄 ${res.done} · 실패 ${res.failed}${preview ? ' (미리보기 — 아무것도 안 바꿨다)' : ''}`);
      }
      return res;
    } finally {
      /* 로그인된 판만 세션을 남긴다 — 풀린 상태로 백업을 덮으면 좋은 백업을 잃는다. 판이 끝나면 늘 닫는다. */
      if (loggedIn) await soft(this.session.saveStorage(), 20000, false);
      await soft(this.session.close(), 15000, null);
      if (this.loginNeededAt) this.storageMtimeAtLogin = this.storageMtime();
    }
  }

  /* 로그인 풀림 — 맡은 줄은 「로그인 필요」 로 돌려준다(줄 탓이 아니다 — 서버가 횟수를 안 센다).
     ★ 대시보드 경보(channel_alerts)는 **안 연다**(검토 [4] · [6]): 서버 대조(15분)가 그 경보를 곧 닫아 버리고, 알림 글도 객실 재고 이야기다.
       로그인 풀림은 실행기 화면(status.json)과 서버의 막기 알림(「호스트센터 로그인이 풀림」)이 알린다. 여기서는 기록 한 줄만 남긴다. */
  async #loginNeeded(ctl, why, rows, preview) {
    const first = !this.loginNeededAt;
    this.loginNeededAt = this.now();
    this.storageMtimeAtLogin = this.storageMtime();
    const msg = `호스트센터 로그인이 필요하다(${clean(why, 80)}) — 실행기 화면 「호스트센터 로그인」 또는 npm start -- --space pair. 15분마다 다시 본다`;
    if (first) this.log.warn(msg); else this.log.debug(msg);
    if (!preview) for (const row of rows) await this.#report(ctl, row, { ok: false, code: 'login_needed', error: '호스트센터 로그인 필요' });
    this.writeStatus({ ok: false, login: false, pending: rows.length, preview, lastError: '호스트센터 로그인 필요' });
  }

  async #loginBack() {
    if (this.loginNeededAt || this.status?.login === false) this.log.info('호스트센터 로그인이 돌아왔다 — 다시 막는다');
    this.loginNeededAt = 0;
    this.writeStatus({ login: true });
  }

  /** 홀 → 상품 짝(6시간 기억). 짝 없는 홀의 줄이 있으면 30분 지난 목록은 다시 읽는다. */
  async #products(page, halls, rows) {
    const now = this.now();
    const stale = !this.products || now - this.productsAt >= PRODUCTS_TTL_MS;
    let map = stale ? null : resolveProducts(halls, this.products, this.sc.products);
    const missing = map && rows.some((r) => r && r.resource_id && !map[r.resource_id]);
    if (stale || (missing && now - this.productsAt >= PRODUCTS_RETRY_MS)) {
      this.products = await listProducts(page);
      this.productsAt = now;
      map = resolveProducts(halls, this.products, this.sc.products);
    }
    const matched = matchHalls(halls, this.products, this.sc.products);
    const hallsOk = Object.fromEntries(matched.map((m) => [m.resource_id, !!m.productId]));
    for (const rid of Object.keys(map)) if (!(rid in hallsOk)) hallsOk[rid] = true;
    this.writeStatus({ halls: hallsOk });
    const bad = matched.filter((m) => !m.productId).map((m) => `${m.resource_id}(${m.how === 'ambiguous' ? `같은 달력 상품 ${m.candidates}개` : '맞는 상품 없음'})`);
    if (bad.length) this.sayOnce('halls', `호스트센터 상품과 짝을 못 찾은 홀 — ${bad.join(', ')} · npm start -- --space map 으로 확인(.env SPACECLOUD_PRODUCTS=홀=상품번호 로 직접 적을 수 있다)`);
    else this.said.delete('halls');
    return map;
  }

  async #month(page, productId, year, month) {
    const k = `${productId}|${year}-${month}`;
    if (!this.monthCache.has(k)) this.monthCache.set(k, await monthExternals(page, productId, year, month));
    return this.monthCache.get(k);
  }
  #forget(productId, year, month) { this.monthCache.delete(`${productId}|${year}-${month}`); }

  /** 한 줄. → { plan, done?, failed?, why? }. 보고는 여기서 한다(미리보기는 안 한다). */
  async #row(ctl, page, row, map, preview) {
    const label = safeLabel(row);
    const problem = rowProblem(row);
    if (problem) {
      this.log.warn(`${label}: ${problem}`);
      if (!preview) await this.#report(ctl, row, { ok: false, code: 'other', error: problem });
      return { plan: '이상한 줄', why: problem, failed: !preview };
    }
    const pid = map[row.resource_id];
    if (!pid) {
      const why = '이 홀과 짝인 호스트센터 상품을 못 찾았다(달력 주소 지문이 안 맞거나 둘 이상) — npm start -- --space map';
      if (!preview) await this.#report(ctl, row, { ok: false, code: 'space_unknown', error: why });
      return { plan: '상품 모름', why, failed: !preview };
    }
    if (row.op === 'remove' && !this.sc.remove) {
      const why = '풀기 꺼 둠(SPACECLOUD_REMOVE=off)';
      if (!preview) await this.#report(ctl, row, { ok: false, code: 'other', error: why });
      return { plan: '풀기 꺼 둠', why, failed: !preview };
    }
    const { year, month } = ymOf(row.date);
    const ext = await this.#month(page, pid, year, month);
    /* ★ 쓰기(넣기 · 고치기 · 지우기)를 한 번이라도 보냈으면 이 줄은 「들어갔을 수 있다」 — 그 뒤 로그인이 풀려도
         login_needed(= 안 들어감)로 돌려주지 않는다(검토 [3]). 401 로 거절된 쓰기는 안 닿은 것이라 세지 않는다. */
    const st = { touched: false };
    const write = async (fn) => {
      const before = st.touched;
      st.touched = true;
      const r = await fn();
      if (r && r.login && !before) st.touched = false;
      if (r && r.login) throw new HostError('쓰다가 로그인이 풀렸다(401)', { status: 401, login: true });
      return r;
    };
    try {
      return row.op === 'add'
        ? await this.#ensureAdd(ctl, page, row, pid, ext, preview, write)
        : await this.#ensureNone(ctl, page, row, pid, ext, preview, write);
    } catch (e) {
      if (st.touched && !preview && e instanceof HostError && e.login) {
        await this.#report(ctl, row, { ok: false, code: row.op === 'add' ? 'not_confirmed' : 'other', error: '쓰는 도중 로그인이 풀렸다 — 호스트센터에서 바뀌었는지 모른다' });
        e.rowReported = true;
      } else if (st.touched && !preview && !(BROWSER_GONE.test(String(e && e.message)) || ctl.dead)) {
        await this.#report(ctl, row, { ok: false, code: 'other', error: `쓴 뒤 확인을 못 했다 — ${e instanceof HostError ? e.message : clean(e && e.message, 120)}` });
        e.rowReported = true;
      }
      throw e;
    } finally {
      if (st.touched) this.#forget(pid, year, month);
    }
  }

  /** 지울 우리 줄들(이 표식 · 이 날 · 상한 MAX_TOUCH). → { deleted:[id], fail?: { status, refused4xx, error } } */
  async #deleteAll(page, row, pid, list, write) {
    const deleted = [];
    for (const t of list.slice(0, MAX_TOUCH)) {
      const d = await write(() => deleteExternal(page, pid, t.id, { marker: row.marker, date: row.date }));
      if (d.refused) { this.log.warn(`${safeLabel(row)}: 외부예약 ${t.id} — ${d.error} · 손대지 않았다`); continue; }
      if (!d.ok) return { deleted, fail: d };
      deleted.push(t.id);
    }
    return { deleted };
  }

  /* 실패 보고 하나 — 거절이 확실하면(4xx · success:false) rejected, 모르면 other. 스페이스클라우드가 한 말은 로그 · 상태에만. */
  async #failWrite(ctl, row, what, r) {
    const label = safeLabel(row);
    const why = clean(r.error) || `HTTP ${r.status}`;
    const certain = !!r.refused4xx;
    this.log.warn(`스페이스클라우드가 ${what}를 ${certain ? '거절했다' : '끝내지 못했다(들어갔는지 모름)'} — ${label}: ${why}`);
    await this.#report(ctl, row, { ok: false, code: certain ? 'rejected' : 'other', error: hostSaid(certain ? `${what}를 거절` : `${what} 응답이 이상함(들어갔는지 모름)`, r.status) });
    this.writeStatus({ lastError: `${label} ${what} ${certain ? '거절' : '실패'} — ${why}` });
    return { plan: certain ? '거절' : '실패', why, failed: true };
  }

  /**
   * 막기 = 그 날 이 표식 줄이 **딱 하나, 시각이 정확히** 있게 만든다(plan.planAdd).
   *   정확한 줄 있음 → 나머지 우리 줄만 지운다 · 우리 줄은 있는데 시각이 다름 → 그 줄을 고친다(PUT) · 없음 → 넣는다(POST).
   *   그리고 언제나 **다시 읽어** 정한다: 정확한 줄이 보이면 ok(host_ref) · 안 보이면 not_confirmed · 거절이 확실하면 rejected(옛 막기는 그대로 — 안전한 쪽).
   */
  async #ensureAdd(ctl, page, row, pid, ext, preview, write) {
    const label = safeLabel(row);
    const { year, month } = ymOf(row.date);
    const plan = planAdd(ext, row);
    if (preview) {
      return { plan: plan.action === 'post' ? '넣을 것' : plan.action === 'put' ? '시각 고칠 것' : plan.extra.length ? '겹친 줄 지울 것' : '이미 있음' };
    }
    if (plan.action === 'keep' && !plan.extra.length) {
      await this.#report(ctl, row, { ok: true, host_ref: plan.keep.id, already: true });
      this.log.info(`이미 막혀 있다 — ${label} (외부예약 ${plan.keep.id})`);
      this.writeStatus({ lastAction: `${label} 이미 막혀 있음` });
      return { plan: '이미 있음', done: true };
    }
    let w = null;
    let what = '';
    if (plan.action === 'put') {
      what = '시각 고치기';
      const body = { date: row.date, startHour: Number(row.start_hour), endHour: Number(row.end_hour), marker: row.marker, memo: memoFor(row.marker) };
      w = await write(() => updateExternal(page, pid, plan.put.id, body));
      if (w.refused) {
        /* 고치려던 줄이 그 사이 남의 줄이 됐다(표식이 바뀜) — 손대지 않고 다음 판이 다시 읽어 정한다. */
        this.#forget(pid, year, month);
        const why = '고치려던 외부예약에 우리 표식이 없다 — 손대지 않았다';
        await this.#report(ctl, row, { ok: false, code: 'other', error: why });
        return { plan: '실패', why, failed: true };
      }
      /* 거절이 확실하면 옛 줄(옛 시각)은 그대로 둔다 — 지우면 홀이 빈다. */
      if (!w.ok && !w.gone && w.refused4xx) { this.#forget(pid, year, month); return this.#failWrite(ctl, row, what, w); }
    } else if (plan.action === 'post') {
      what = '넣기';
      w = await write(() => addExternal(page, pid, { date: row.date, startHour: Number(row.start_hour), endHour: Number(row.end_hour), marker: row.marker, memo: memoFor(row.marker) }));
    }
    let delFail = null;
    if (plan.extra.length) {
      const d = await this.#deleteAll(page, row, pid, plan.extra, write);
      if (d.fail) delFail = d.fail;
      if (d.deleted.length) this.log.info(`겹친 우리 줄을 지웠다 — ${label} (외부예약 ${d.deleted.join('·')})`);
    }
    this.#forget(pid, year, month);
    const again = await this.#month(page, pid, year, month);
    const got = findOurs(again, row);
    const left = oursOnDate(again, row).filter((x) => !got || x.id !== got.id);
    if (got && !left.length) {
      await this.#report(ctl, row, { ok: true, host_ref: got.id });
      const verb = plan.action === 'put' ? '시각을 고쳤다' : plan.action === 'post' ? '막았다' : '겹친 줄을 정리했다';
      this.log.info(`${verb} — ${label} (외부예약 ${got.id})`);
      this.writeStatus({ lastAction: `${label} ${plan.action === 'put' ? '시각 고침' : '막음'}` });
      return { plan: plan.action === 'put' ? '시각 고침' : plan.action === 'post' ? '막음' : '정리함', done: true };
    }
    if (got) {
      /* 정확한 줄은 있다(홀은 막혀 있다) — 다만 우리 줄이 하나 더 남았다. 다음 판에 다시 정리한다. */
      if (delFail) return this.#failWrite(ctl, row, '겹친 줄 지우기', delFail);
      const why = `우리 줄이 ${left.length}개 더 남아 있다 — 다음 판에 다시 정리`;
      await this.#report(ctl, row, { ok: false, code: 'other', error: why });
      this.writeStatus({ lastError: `${label} — ${why}` });
      return { plan: '확인 안 됨', why, failed: true };
    }
    if (w && !w.ok && !w.gone) return this.#failWrite(ctl, row, what, w);
    const why = `${what || '정리'} 뒤 다시 읽어도 정확한 줄이 안 보인다 — 호스트센터 달력에서 직접 확인`;
    this.log.warn(`${label}: ${why}`);
    await this.#report(ctl, row, { ok: false, code: 'not_confirmed', error: why });
    this.writeStatus({ lastError: `${label} — ${why}` });
    return { plan: '확인 안 됨', why, failed: true };
  }

  /** 풀기 = 그 날 이 표식 줄을 **전부**(시각 상관없이, 상한 MAX_TOUCH) 지운다. host_ref 는 참고일 뿐이다. 다시 읽어 하나도 없으면 ok. */
  async #ensureNone(ctl, page, row, pid, ext, preview, write) {
    const label = safeLabel(row);
    const { year, month } = ymOf(row.date);
    const ours = oursOnDate(ext, row);
    if (!ours.length) {
      if (!preview) {
        await this.#report(ctl, row, { ok: true, already: true });
        this.log.info(`풀 것이 없다(이미 없음) — ${label}`);
      }
      return { plan: '없음', done: !preview };
    }
    if (preview) return { plan: '풀 것' };
    const d = await this.#deleteAll(page, row, pid, ours, write);
    this.#forget(pid, year, month);
    if (d.fail) return this.#failWrite(ctl, row, '지우기', d.fail);
    const again = await this.#month(page, pid, year, month);
    const left = oursOnDate(again, row);
    if (left.length) {
      const why = `지웠는데 다시 읽으니 우리 줄 ${left.length}개가 남아 있다 — 다음 판에 다시`;
      await this.#report(ctl, row, { ok: false, code: 'other', error: why });
      this.writeStatus({ lastError: `${label} — ${why}` });
      return { plan: '확인 안 됨', why, failed: true };
    }
    await this.#report(ctl, row, { ok: true, host_ref: d.deleted[0] || (row.host_ref != null ? String(row.host_ref) : null) });
    this.log.info(`풀었다 — ${label} (외부예약 ${d.deleted.join('·') || '없음'})`);
    this.writeStatus({ lastAction: `${label} 풂` });
    return { plan: '풂', done: true };
  }

  /** 서버에 한 줄 결과. 실패해도 던지지 않는다 — 줄은 맡긴 시간(10분)이 지나면 서버가 다시 내준다. */
  async #report(ctl, row, payload) {
    if (!row || row.id == null) return false;
    if (ctl && ctl.dead) { this.log.debug(`${safeLabel(row)}: 마감으로 버린 판이라 보고하지 않는다`); return false; }
    const body = { id: row.id, ...payload };
    if (body.error != null) body.error = clean(body.error);
    if (body.host_ref != null) body.host_ref = String(body.host_ref).slice(0, 64);
    try {
      const r = await this.dashboard.spaceReport(body);
      if (!r || r.ok === false) {
        if (r && r.code === 'not_leased') this.log.info(`${safeLabel(row)}: 서버가 이 줄을 더는 안 맡긴다(not_leased) — 그대로 둔다`);
        else this.log.warn(`${safeLabel(row)}: 보고를 서버가 안 받았다 — ${clean(r && r.error) || '응답 없음'}`);
        return false;
      }
      return true;
    } catch (e) {
      this.log.warn(`${safeLabel(row)}: 보고 실패 — ${clean(e && e.message)}`);
      return false;
    }
  }
}

/* 줄 이름표 — 서버 줄이 이상해도(빈 칸) 던지지 않는다. 손님 정보는 처음부터 없다. */
function safeLabel(row) {
  try { return clean(rowLabel(row), 80); } catch { return `줄 ${row && row.id}`; }
}
