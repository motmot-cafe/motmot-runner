/* 스페이스클라우드 호스트센터 — 페이지 안에서 하는 일(0.9.3).
   ★ 스페이스클라우드로 가는 요청은 **전부 호스트센터 페이지 안에서**(page.evaluate) 보낸다. 쿠키·CORS 가
     호스트센터 화면이 스스로 보내는 것과 똑같아진다 — 우리가 따로 흉내 낸 요청을 만들지 않는다(D-001).
   ★★ 손님 정보는 **페이지 밖으로 한 글자도 안 나온다**(스페이스클라우드 공지 1269 · 1334). 달력 응답의 예약(reservations) ·
       예약자(user_info)는 페이지 안에서 버리고, 외부예약도 이름 · 연락처 · 메모는 표식(MOTMOT-번호)만 뽑고 버린다.
       Node 로 넘어오는 것은 번호 · 날짜 · 시각 · 표식뿐이다 — 그래서 로그 · 상태 파일 · 서버 어디에도 손님 정보가 갈 길이 없다.
   ★ 달력 내보내기 주소(ical_url)는 비밀이다 — 페이지 안에서 지문(sha256 앞 16자)만 세고 주소는 버린다.
   사실(호스트센터 JS 번들 main.370905ae, 2026-10-15): API https://api.spacecloud.kr · 머리글 Authorization 에 토큰을
     **그대로**("Bearer" 없음) · 토큰은 localStorage["spacecloud__userInfo"].accessToken · 401 이면 GET /partner/users/get_token(쿠키)
     → { token } 으로 바꿔 한 번 더 · 그것도 401 이면 로그인 풀림. */
import { deadline, soft } from '../lib/deadline.js';
import { addBody, memoFor, markerOf } from './plan.js';

export const HOST = 'https://partner.spacecloud.kr';
export const API = 'https://api.spacecloud.kr';
export const CALENDAR_URL = `${HOST}/reservation-calendar`;
export const LOGIN_URL = `${HOST}/auth/login`;

/** 호스트센터가 로그인 화면으로 보냈나. */
export function isLoginUrl(u) {
  return /\/auth\/(?:login|signin)|\/login(?:[/?#]|$)/i.test(String(u || ''));
}

/** 페이지에서 일어난 실패. login=true 면 로그인이 풀린 것이다(줄 탓이 아니다).
    message 는 **우리 말**(서버에 보내도 된다) · said 는 스페이스클라우드가 한 말(이 PC 로그에만 — worker.js hostSaid 머리말). */
export class HostError extends Error {
  constructor(message, { status = 0, login = false, said = '' } = {}) {
    super(message);
    this.name = 'HostError';
    this.status = status;
    this.login = login;
    this.said = said;
  }
}

/**
 * ★ 이 함수는 **브라우저 안에서** 돈다 — page.evaluate 가 글자째 넘긴다. 바깥 이름(import · 모듈 상수)을 하나도 쓰면 안 된다.
 *   (시험은 이 함수를 글자에서 다시 만들어 돌린다 — 바깥 이름을 쓰면 시험에서도 ReferenceError 로 깨진다.)
 * call = { api, op, timeoutMs, … } · 돌려주는 것은 번호 · 날짜 · 시각 · 표식 · 상태 코드 · 짧은 오류 글자뿐이다.
 */
export async function inPage(call) {
  const API = String(call.api || 'https://api.spacecloud.kr');
  const KEY = 'spacecloud__userInfo';
  const cut = (s, n) => String(s == null ? '' : s).replace(/\s+/g, ' ').trim().slice(0, n);
  const readInfo = () => { try { return JSON.parse(localStorage.getItem(KEY) || 'null') || null; } catch (e) { return null; } };
  const token = () => { const i = readInfo(); return i && i.accessToken ? String(i.accessToken) : ''; };
  const markerOf = (t) => { const m = String(t == null ? '' : t).match(/MOTMOT-(\d{1,12})(?!\d)/); return m ? 'MOTMOT-' + m[1] : null; };
  const ymdOf = (v) => {
    const s = String(v == null ? '' : v).trim();
    if (/^\d{8}$/.test(s)) return s.slice(0, 4) + '-' + s.slice(4, 6) + '-' + s.slice(6, 8);
    if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
    if (/^\d{4}-\d{2}-\d{2}[T ]/.test(s) && !/(?:[Zz]|[+-]\d{2}:?\d{2})$/.test(s)) return s.slice(0, 10);
    const t = Date.parse(s);
    return Number.isNaN(t) ? '' : new Date(t + 9 * 3600000).toISOString().slice(0, 10);
  };
  const hourOf = (v) => {
    if (typeof v === 'number') return Number.isInteger(v) ? v : null;
    const m = String(v == null ? '' : v).trim().match(/^(\d{1,2})(?::00(?::00)?)?$/);
    return m ? Number(m[1]) : null;
  };
  const errText = (j) => {
    if (!j || typeof j !== 'object') return '';
    return cut(j.error || j.message || (j.data && (j.data.error || j.data.message)) || '', 160);
  };
  const req = async (method, path, body, tok) => {
    const ctl = typeof AbortController === 'function' ? new AbortController() : null;
    const timer = ctl ? setTimeout(() => ctl.abort(), Number(call.timeoutMs) || 25000) : null;
    try {
      const init = { method, credentials: 'include', headers: { Authorization: tok, 'Content-Type': 'application/json', Accept: 'application/json' } };
      if (ctl) init.signal = ctl.signal;
      if (body != null) init.body = JSON.stringify(body);
      const res = await fetch(API + path, init);
      let json = null;
      let parsed = false;
      try { json = await res.json(); parsed = true; } catch (e) { json = null; }
      return { status: res.status, json, parsed };
    } catch (e) {
      return { status: 0, json: null, net: cut(e && (e.name === 'AbortError' ? '시간 초과' : e.message), 80) };
    } finally { if (timer) clearTimeout(timer); }
  };
  /* 401 → 화면 코드와 같은 길: get_token(쿠키) 으로 새 토큰 → userInfo 에 적고 한 번만 다시. */
  const refresh = async () => {
    const r = await req('GET', '/partner/users/get_token', null, token());
    const t = r.status >= 200 && r.status < 300 && r.json && (r.json.token || r.json.accessToken || (r.json.data && r.json.data.token));
    if (!t) return '';
    try {
      const info = readInfo() || {};
      info.accessToken = String(t);
      localStorage.setItem(KEY, JSON.stringify(info));
    } catch (e) { /* 적지 못해도 이번 요청에는 쓴다 */ }
    return String(t);
  };
  const api = async (method, path, body) => {
    const tok = token();
    if (!tok) return { status: 401, json: null, noToken: true };
    let r = await req(method, path, body, tok);
    if (r.status === 401) {
      const t2 = await refresh();
      if (!t2) return { status: 401, json: null, refreshFailed: true };
      r = await req(method, path, body, t2);
    }
    return r;
  };
  /* 목록 칸을 꺼낸다. 못 찾으면(읽지 못한 몸통 · success:false · 다른 모양) null — **빈 목록으로 치지 않는다**.
     빈 목록으로 치면 「상품 없음 → 홀 짝 없음」 · 「달력 빔 → 이미 없음」 으로 잘못 읽는다(검토 2026-10-15 [0] · [1]). */
  const listOf = (j, key) => {
    if (Array.isArray(j)) return j;
    if (!j || typeof j !== 'object' || j.success === false) return null;
    if (Array.isArray(j[key])) return j[key];
    if (j.data && Array.isArray(j.data[key])) return j.data[key];
    if (Array.isArray(j.data)) return j.data;
    return null;
  };
  const okStatus = (r) => r.status >= 200 && r.status < 300;
  const refusedBody = (r) => !!(r.json && typeof r.json === 'object' && !Array.isArray(r.json) && r.json.success === false);
  const hash16 = async (u) => {
    const s = String(u == null ? '' : u).trim().replace(/^(webcal|http):\/\//i, 'https://');
    if (!s) return null;
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s));
    return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('').slice(0, 16);
  };
  /* 달력 한 달 — 외부예약만 남기고 예약(손님)은 여기서 버린다.
     ★ 모양이 엄격하다: 2xx 라도 몸통을 못 읽었거나 · success:false 거나 · 날 칸(객체) 배열이 아니면 **실패**다 — 빈 달이 아니다.
       빈 달로 치면 풀기는 「이미 없음」 으로 끝나 우리 막기가 영영 남고, 넣기는 같은 줄을 몇 번이고 다시 넣는다(검토 [0]). [] 는 진짜 빈 달이다.
     raw 는 페이지 안에서만 쓴다(시각 고치기가 이름 · 연락처 · 메모를 그대로 두려고) — 바깥으로 돌려줄 때는 뺀다. */
  const month = async (productId, year, mon) => {
    const q = '?year=' + String(year) + '&month=' + String(mon).padStart(2, '0') + '&product_id=' + encodeURIComponent(String(productId));
    const r = await api('GET', '/partner/reservations/calendar' + q, null);
    if (!okStatus(r)) return { status: r.status, error: errText(r.json) || r.net || '', login: r.status === 401 };
    const bad = (why) => ({ status: 0, error: '달력 모양이 아니다(' + why + ')', shape: true });
    if (!r.parsed || r.json == null) return bad('몸통을 못 읽음');
    if (refusedBody(r)) return { status: 0, error: errText(r.json), refused: true, shapeWhy: '달력이 success:false' };
    let days = r.json;
    if (!Array.isArray(days)) {
      if (typeof days !== 'object') return bad('배열이 아님');
      const inner = days.calendar || days.days || days.list || days.data;
      days = Array.isArray(inner) ? inner : Object.values(days);
    }
    if (days.some((d) => !d || typeof d !== 'object' || Array.isArray(d))) return bad('날 칸이 객체가 아님');
    if (days.length && !days.some((d) => Array.isArray(d.external_schedules) || Array.isArray(d.reservations))) return bad('날 칸에 예약 목록이 없음');
    const seen = new Map();
    const raw = new Map();
    let others = 0;
    for (const d of days) {
      const ext = Array.isArray(d.external_schedules) ? d.external_schedules : [];
      for (const x of ext) {
        if (!x || x.id == null) continue;
        const id = cut(x.id, 40);
        if (seen.has(id)) continue;
        const marker = markerOf(x.name) || markerOf(x.memo);   // 이름 · 메모는 표식만 뽑고 버린다
        if (!marker) others++;
        seen.set(id, { id, symd: ymdOf(x.symd), shour: hourOf(x.shour), ehour: hourOf(x.ehour), marker });
        raw.set(id, x);
      }
      /* d.reservations · d.user_info 는 일부러 읽지 않는다 — 손님 정보다. */
    }
    return { status: r.status, externals: Array.from(seen.values()), others, raw };
  };
  /* 쓰기 직전에 **페이지 안에서 한 번 더** 본다 — 그 번호의 줄이 정확히 우리 표식을 달고 있을 때만 손댄다. */
  const ourOne = async (want) => {
    if (!/^MOTMOT-\d{1,12}$/.test(want)) return { stop: { status: 0, ok: false, refused: true, error: 'marker' } };
    const m = await month(call.productId, call.year, call.month);
    if (!m.externals) return { stop: { status: m.status, ok: false, error: m.error || '', login: !!m.login, shape: !!m.shape } };
    const hit = m.externals.find((x) => x.id === String(call.id));
    if (!hit) return { gone: true };
    if (hit.marker !== want) return { stop: { status: 0, ok: false, refused: true, error: 'marker' } };
    return { hit, raw: m.raw.get(hit.id) || {} };
  };
  const wrote = (r) => {
    const ok = okStatus(r) && !refusedBody(r);
    return { status: r.status, ok, refused4xx: !ok && ((r.status >= 400 && r.status < 500 && r.status !== 401) || (okStatus(r) && refusedBody(r))),
      error: ok ? '' : (errText(r.json) || r.net || ''), login: r.status === 401 };
  };

  if (call.op === 'whoami') {
    if (!token()) return { loggedIn: false, why: 'no_token' };
    const r = await api('GET', '/partner/spaces?all=true', null);
    if (okStatus(r)) {
      const list = listOf(r.json, 'spaces');
      /* 200 인데 공간 목록이 아니면 로그인됐다고 못 한다 — 흔들림으로 본다. */
      return list ? { loggedIn: true, spaces: list.length } : { loggedIn: false, transient: true, why: '공간 목록 모양이 아니다' };
    }
    if (r.status === 401) return { loggedIn: false, why: r.refreshFailed ? 'refresh_failed' : 'http_401' };
    return { loggedIn: false, transient: true, why: 'HTTP ' + r.status + (r.net ? ' ' + r.net : '') };
  }
  if (call.op === 'products') {
    /* ★ 공간 하나라도 상품 목록을 못 읽으면 **전체가 실패**다(검토 [1]) — 일부만 읽은 목록으로 짝을 지으면 못 읽은 공간의 홀이
         「짝 없음(space_unknown)」 으로 보고된다. 401(갱신도 실패) = 로그인 풀림 · 그 밖 = 흔들림. */
    const r = await api('GET', '/partner/spaces?all=true', null);
    if (!okStatus(r)) return { status: r.status, error: errText(r.json) || r.net || '', login: r.status === 401 };
    const spaces = listOf(r.json, 'spaces');
    if (!spaces) return { status: 0, error: '공간 목록 모양이 아니다', shape: true };
    const out = [];
    for (const s of spaces.slice(0, 40)) {
      const sid = s && (s.id != null ? s.id : s.SPC_ID);
      if (sid == null) continue;
      const bi = (s && s.basic_info) || {};
      const sp = { spaceId: cut(sid, 20), spaceType: cut(s.SPC_TP_CD || bi.SPC_TP_CD || s.spc_tp_cd || '', 12) || null,
        name: cut(s.SPC_NM || s.name || bi.SPC_NM || '', 60), products: [] };
      const pr = await api('GET', '/partner/spaces/' + encodeURIComponent(String(sid)) + '/manage_products', null);
      if (!okStatus(pr)) return { status: pr.status, error: errText(pr.json) || pr.net || '', login: pr.status === 401, failedSpace: sp.spaceId };
      const products = listOf(pr.json, 'products');
      if (!products) return { status: 0, error: '상품 목록 모양이 아니다', shape: true, failedSpace: sp.spaceId };
      for (const p of products.slice(0, 60)) {
        const pid = p && (p.id != null ? p.id : p.product_id);
        if (pid == null) continue;
        sp.products.push({
          productId: cut(pid, 20),
          exposed: p.exposed == null ? null : cut(p.exposed, 2),
          icalHash: await hash16(p.ical_url || p.icalUrl || p.ICAL_URL || ''),   // 주소는 여기서 버린다
          name: cut(p.name || p.PRD_NM || p.product_name || p.title || '', 60),
        });
      }
      out.push(sp);
    }
    return { status: r.status, spaces: out };
  }
  if (call.op === 'month') {
    const m = await month(call.productId, call.year, call.month);
    delete m.raw;   // 이름 · 연락처 · 메모가 든 원본은 페이지 밖으로 안 낸다
    return m;
  }
  if (call.op === 'add') {
    /* 화면은 이 응답을 안 본다(번호는 달력을 다시 읽어 안다). 200 에 success:false 가 오면 거절로 본다. */
    return wrote(await api('POST', '/partner/products/' + encodeURIComponent(String(call.productId)) + '/external_schedules', call.body));
  }
  if (call.op === 'update') {
    /* 시각 고치기(PUT, 화면의 「외부예약 수정」 과 같은 몸통). 우리 표식 줄만 · 이름 · 연락처 · 메모는 **있던 그대로** 둔다(페이지 안에서만 본다). */
    const one = await ourOne(String(call.marker || ''));
    if (one.stop) return one.stop;
    if (one.gone) return { status: 200, ok: false, gone: true };
    const body = Object.assign({}, call.body);
    for (const k of ['name', 'tel', 'memo']) {
      const v = one.raw[k];
      if (typeof v === 'string' && v) body[k.toUpperCase()] = v;
    }
    return wrote(await api('PUT', '/partner/products/' + encodeURIComponent(String(call.productId)) + '/external_schedules/' + encodeURIComponent(String(call.id)), body));
  }
  if (call.op === 'delete') {
    const one = await ourOne(String(call.marker || ''));
    if (one.stop) return one.stop;
    if (one.gone) return { status: 200, ok: true, gone: true };
    return wrote(await api('DELETE', '/partner/products/' + encodeURIComponent(String(call.productId)) + '/external_schedules/' + encodeURIComponent(String(call.id)), null));
  }
  return { status: 0, error: 'unknown op' };
}

/* 페이지가 도는 중에 다른 곳으로 넘어가면(로그인 화면으로 보냄 등) evaluate 가 "context was destroyed" 로 깨진다.
   그때만 한 번 더 해 본다 — 그래도 로그인 화면이면 로그인 풀림으로 본다. */
const NAV_RE = /context was destroyed|navigat|Target closed|Execution context/i;

async function call(page, desc, { ms = 60000 } = {}) {
  const arg = { api: API, timeoutMs: 25000, ...desc };
  for (let i = 0; i < 2; i++) {
    try {
      return await deadline(page.evaluate(inPage, arg), ms, `호스트센터 ${desc.op}`);
    } catch (e) {
      if (i === 0 && NAV_RE.test(String(e && e.message)) && !e.timedOut) {
        await soft(page.waitForLoadState?.('domcontentloaded', { timeout: 15000 }), 16000, null);
        if (isLoginUrl(page.url?.())) throw new HostError('호스트센터가 로그인 화면으로 보냈다', { status: 401, login: true });
        continue;
      }
      throw e;
    }
  }
  throw new HostError(`호스트센터 ${desc.op}: 두 번 다 페이지가 넘어갔다`);
}

function httpError(what, r) {
  const login = r.status === 401 || !!r.login;
  const msg = login ? `${what}: 로그인이 풀렸다(401)`
    : r.shape ? `${what}: ${r.error}`
      : r.refused ? `${what}: 거절(success:false)` : `${what}: ${r.status ? `HTTP ${r.status}` : '응답 없음'}`;
  return new HostError(msg, { status: r.status, login, said: r.shape ? '' : (r.error || '') });
}

/**
 * 호스트센터 달력 화면을 열고 로그인됐는지 본다. 로그인 = 토큰이 있고 GET /partner/spaces?all=true 가 200.
 * @returns {Promise<{loggedIn:boolean, why:string, transient?:boolean}>}  transient = 호스트센터가 흔들린 것(로그인 탓 아님)
 */
export async function openHost(page, { settleMs = 15000 } = {}) {
  try {
    await deadline(page.goto(CALENDAR_URL, { waitUntil: 'domcontentloaded', timeout: 45000 }), 50000, '호스트센터 열기');
  } catch (e) {
    return { loggedIn: false, transient: true, why: `호스트센터를 못 열었다 — ${String(e && e.message).split('\n')[0].slice(0, 120)}` };
  }
  /* 화면이 스스로 토큰을 바꾸는 중(401 → get_token)일 수 있다 — 조용해질 때까지 잠깐(길어도 settleMs). 같은 토큰을 둘이 동시에 바꾸지 않게. */
  if (settleMs > 0) await soft(page.waitForLoadState?.('networkidle', { timeout: settleMs }), settleMs + 1000, null);
  if (isLoginUrl(page.url?.())) return { loggedIn: false, why: '로그인 화면으로 넘어갔다' };
  return whoami(page);
}

/** 지금 페이지에서 로그인됐는지만 본다(화면을 다시 열지 않는다) — pair 가 3초마다 부른다. */
export async function whoami(page) {
  if (isLoginUrl(page.url?.())) return { loggedIn: false, why: '로그인 화면' };
  let r;
  try {
    r = await call(page, { op: 'whoami' }, { ms: 40000 });
  } catch (e) {
    if (e instanceof HostError && e.login) return { loggedIn: false, why: e.message };
    return { loggedIn: false, transient: true, why: String(e && e.message).split('\n')[0].slice(0, 120) };
  }
  if (r && r.loggedIn) return { loggedIn: true, why: '' };
  const why = !r ? '응답 없음'
    : r.why === 'no_token' ? '저장된 로그인이 없다'
      : r.why === 'refresh_failed' ? '로그인이 풀렸다(토큰 갱신 실패)'
        : r.why === 'http_401' ? '로그인이 풀렸다(401)' : String(r.why || '').slice(0, 80);
  return { loggedIn: false, why, ...(r && r.transient ? { transient: true } : {}) };
}

/** 공간 · 상품 목록. 달력 주소는 지문(icalHash)으로만 온다. */
export async function listProducts(page) {
  const r = await call(page, { op: 'products' }, { ms: 90000 });
  if (!r || !r.spaces) throw httpError(r && r.failedSpace ? `공간 ${r.failedSpace} 의 상품 목록` : '공간 목록', r || { status: 0 });
  return r.spaces.map((s) => ({ spaceId: s.spaceId, spaceType: s.spaceType, name: s.name, products: s.products || [] }));
}

/** 한 상품의 한 달 외부예약 — [{ id, symd, shour, ehour, marker|null }]. 이름 · 연락처 · 메모는 없다. */
export async function monthExternals(page, productId, year, month) {
  const r = await call(page, { op: 'month', productId: String(productId), year: Number(year), month: Number(month) });
  if (!r || !r.externals) throw httpError('달력 읽기', r || { status: 0 });
  return r.externals;
}

/* 쓰기 결과 → { status, ok, refused4xx(= 거절이 확실), error(= 스페이스클라우드가 한 말 — 로그에만), login, gone, refused(= 우리 표식 아님) }. */
const outOf = (r) => ({ status: r.status, ok: !!r.ok, refused4xx: !!r.refused4xx, error: r.error || '', login: !!r.login, gone: !!r.gone,
  refused: !!r.refused, shape: !!r.shape });

/** 「+예약추가」 한 줄. */
export async function addExternal(page, productId, { date, startHour, endHour, marker, memo }) {
  if (markerOf(marker) !== marker) throw new Error('표식이 MOTMOT-<번호> 모양이 아니다');
  const body = addBody({ date, startHour, endHour, marker, memo: memo || memoFor(marker) });
  return outOf(await call(page, { op: 'add', productId: String(productId), body }));
}

/**
 * 우리 표식 줄 하나의 시각을 고친다(PUT …/external_schedules/:id, 「+예약추가」 와 같은 몸통). 그 번호의 줄이 **정확히 이 표식**일 때만 —
 * 페이지 안에서 고치기 직전에 다시 본다. 이름 · 연락처 · 메모는 있던 것을 그대로 둔다(페이지 밖으로는 안 나온다).
 */
export async function updateExternal(page, productId, id, { date, startHour, endHour, marker, memo }) {
  if (!marker || markerOf(marker) !== marker) return { status: 0, ok: false, refused: true, error: '표식 없이 고치지 않는다' };
  const body = addBody({ date, startHour, endHour, marker, memo: memo || memoFor(marker) });
  const [y, m] = String(date).split('-').map(Number);
  const r = outOf(await call(page, { op: 'update', productId: String(productId), id: String(id), marker, year: y, month: m, body }));
  if (r.refused) r.error = '그 번호의 줄에 우리 표식이 없다';
  return r;
}

/**
 * 외부예약 하나를 지운다 — **그 번호의 줄이 정확히 이 표식을 달고 있을 때만**(페이지 안에서 지우기 직전에 다시 본다).
 * 계약서 모양(page, productId, id)에 { marker, date } 를 **반드시** 더 받는다 — 없으면 아무것도 안 지운다.
 * @returns {{status, ok, gone?, refused?, error}}
 */
export async function deleteExternal(page, productId, id, { marker, date } = {}) {
  if (!marker || markerOf(marker) !== marker || !/^\d{4}-\d{2}-\d{2}$/.test(String(date || ''))) {
    return { status: 0, ok: false, refused: true, error: '표식·날짜 없이 지우지 않는다' };
  }
  const [y, m] = String(date).split('-').map(Number);
  const r = outOf(await call(page, { op: 'delete', productId: String(productId), id: String(id), marker, year: y, month: m }));
  if (r.refused) r.error = '그 번호의 줄에 우리 표식이 없다';
  return r;
}
