#!/usr/bin/env node
/* 스페이스클라우드 호스트센터 — 사람이 부르는 명령(0.9.3, 홀 자동 막기).
     npm start -- --space pair      브라우저 창을 띄워 **사람이** 한 번 로그인한다(「로그인 기억하기」 체크 · 사람 확인은 직접). 10분 기다린다.
     npm start -- --space map       로그인 확인 + 공간 · 상품 목록 + 대시보드 홀과의 짝(아무것도 안 바꾼다)
     npm start -- --space preview   서버가 막으라는 줄마다 무엇을 할지(넣을 것 · 이미 있음 · 풀 것 · 없음) — 아무것도 안 바꾸고 보고도 안 한다
     npm start -- --space once      진짜 한 판(서버가 맡긴 줄을 넣고 · 풀고 · 보고한다)
   ★ 로그인은 사람이 한다. 사람 확인(Cloudflare Turnstile)을 풀거나 흉내 내지 않는다(D-001). 창은 기다리기만 한다 —
     Enter 같은 키보드 입력이 필요 없다(실행기 화면은 이 명령을 입력 없이 부른다). 3초마다 로그인이 끝났는지 본다.
   ★ 막는 것은 **스페이스클라우드 프로필을 지금 쓰는 쪽**뿐이다(state/spacecloud/profile.lock — worker.js PROFILE_LOCK).
     상주 실행기(여기어때)가 돌고 있어도 거절하지 않는다 — 실행기 화면은 실행기를 잠깐 끄고 부르지만, 로그인(10분까지) 도중에
     작업 스케줄러가 상주를 다시 띄울 수 있다. 그래도 괜찮다: pair · map 은 도는 내내 프로필 자물쇠를 쥐고, 상주 일꾼은 그것을 보면
     서버에 묻지도 않고(줄을 안 맡는다) 쉰다. 반대로 상주 일꾼이 한 판을 도는 중이면(길어야 몇십 초) 최대 1분 기다렸다가, 그래도 쓰고 있으면 까닭을 말하고 1 로 끝낸다.
     preview · once 는 한 판 안에서 일꾼이 같은 자물쇠를 쥔다. 끝 코드: 0 = 됐다 · 1 = 못 했다(까닭은 바로 위 줄).
   ★★ 손님 정보는 화면에 안 나온다 — 공간 · 상품 번호 · 이름(우리 홀 상품)과 표식 · 날짜 · 시각뿐이다. 달력 주소는 지문으로도 안 찍는다. */
import { loadEnvFile, loadConfig } from '../lib/config.js';
import { createLogger, scrubSecrets } from '../lib/log.js';
import { ChannelSession } from '../browser/session.js';
import { SingleInstanceLock } from '../lib/lock.js';
import { DashboardClient } from '../dashboard/client.js';
import { soft } from '../lib/deadline.js';
import { LOGIN_URL, openHost, whoami, listProducts } from '../space/hostcenter.js';
import { matchHalls } from '../space/plan.js';
import { SpaceWorker, CHANNEL, SPACE_VERSION, PROFILE_LOCK, clean, patchStatusFile } from '../space/worker.js';
import { heldByOther } from '../lib/lock.js';

export const POLL_MS = 3000;
export const PAIR_WAIT_MS = 10 * 60000;
/** 프로필을 다른 곳이 쓰고 있을 때 기다려 보는 시간 — 상주 일꾼의 한 판은 대개 몇십 초다. */
export const BUSY_WAIT_MS = 60000;
const CMDS = ['pair', 'map', 'preview', 'once'];

function usage(out) {
  out('스페이스클라우드 호스트센터:');
  out('  npm start -- --space pair      창에서 직접 로그인(처음 한 번 · 풀렸을 때)');
  out('  npm start -- --space map       로그인 확인 · 상품 목록 · 홀 짝 (아무것도 안 바꿈)');
  out('  npm start -- --space preview   무엇을 막고 풀지 보여만 줌 (아무것도 안 바꿈)');
  out('  npm start -- --space once      진짜 한 판');
}

/** 대시보드 홀 목록(달력 주소가 있는 홀) — space_pull 미리보기(줄을 안 맡긴다). 못 받으면 halls=null 과 까닭. */
async function hallsFrom(cfg, log, deps) {
  try {
    let d = deps.dashboard || null;
    if (!d) {
      if (!cfg.dashboard.email || !cfg.dashboard.password) return { halls: null, why: '.env 에 대시보드 계정이 없어 홀 짝은 못 본다' };
      d = await new DashboardClient(cfg.dashboard, { log: log.child('대시보드') }).init();
    }
    const r = await d.spacePull({ preview: true, limit: 1, version: SPACE_VERSION });
    if (!r || r.ok === false) {
      return { halls: null, why: r && r.code === 'no_table' ? '서버에 스페이스클라우드 표가 아직 없다(supabase-129 를 먼저)' : `서버가 홀 목록을 못 줬다 — ${clean(r && r.error) || '응답 없음'}` };
    }
    return { halls: Array.isArray(r.halls) ? r.halls : [] };
  } catch (e) {
    return { halls: null, why: `대시보드에 못 붙었다 — ${clean(e && e.message)}` };
  }
}

/** 공간 · 상품 목록과 홀 짝을 사람 말로. 손님 정보 · 주소 · 지문은 안 찍는다. */
export function describeProducts(list, halls, overrides) {
  const lines = [];
  const matched = halls ? matchHalls(halls, list, overrides) : [];
  const byProduct = new Map(matched.filter((m) => m.productId).map((m) => [String(m.productId), m]));
  lines.push('공간 · 상품 (호스트센터)');
  if (!list || !list.length) lines.push('  (공간이 없다 — 이 계정이 호스트 계정인지 확인)');
  for (const s of list || []) {
    lines.push(`  공간 ${s.spaceId} · ${s.spaceType || '종류 모름'}${s.name ? ` · 「${s.name}」` : ''}${s.error ? ` · ⚠ ${s.error}` : ''}`);
    if (s.spaceType && s.spaceType !== 'MEET') lines.push('    ⚠ 시간 단위 달력(외부예약)은 MEET 공간에서만 쓴다 — 이 공간의 홀은 자동으로 못 막을 수 있다');
    for (const p of s.products || []) {
      const m = byProduct.get(String(p.productId));
      lines.push(`    상품 ${p.productId} · 노출 ${p.exposed || '?'}${p.name ? ` · 「${p.name}」` : ''}${p.icalHash ? '' : ' · 달력 주소 없음'}` +
        (m ? `  ← 홀 ${m.resource_id}${m.name ? `(${m.name})` : ''}` : ''));
    }
  }
  if (halls) {
    lines.push('홀 짝 (대시보드 홀 ↔ 호스트센터 상품)');
    if (!matched.length) lines.push('  (대시보드에 스페이스클라우드 달력 주소를 넣은 홀이 없다)');
    for (const m of matched) {
      const nm = `${m.resource_id}${m.name ? ` 「${m.name}」` : ''}`;
      if (m.productId) lines.push(`  ✓ ${nm} → 상품 ${m.productId} (${m.how === 'override' ? '.env SPACECLOUD_PRODUCTS' : '달력 주소 지문이 같다'})`);
      else if (m.how === 'ambiguous') lines.push(`  ✗ ${nm} → 같은 달력 주소의 상품이 ${m.candidates}개 — 고르지 않는다. .env 에 SPACECLOUD_PRODUCTS=${m.resource_id}=<상품번호> 로 적을 것`);
      else lines.push(`  ✗ ${nm} → 못 찾음 — 대시보드에 넣은 달력 주소가 그 상품의 「캘린더 내보내기」 주소와 같은지 확인. 아니면 .env SPACECLOUD_PRODUCTS=${m.resource_id}=<상품번호>`);
    }
  }
  return lines;
}

/**
 * @param {string[]} argv
 * @param {object} deps 시험용: out, cfg, lock, makeSession, dashboard, sleep, now, pollMs, waitMs
 */
export async function spaceCli(argv = process.argv.slice(2), deps = {}) {
  const out = deps.out || ((s) => console.log(s));
  /* 실행기 화면은 이 출력을 그대로 보여 준다 — 뜻밖의 실패도 오류 더미 대신 한국어 한 줄과 끝 코드 1 로. */
  try {
    return await spaceCliInner(argv, deps, out);
  } catch (e) {
    out(`✗ 스페이스클라우드 명령을 끝내지 못했습니다 — ${clean(e && e.message, 300)}`);
    return 1;
  }
}

async function spaceCliInner(argv, deps, out) {
  const cmd = argv.find((a) => !a.startsWith('--')) || '';
  if (!CMDS.includes(cmd)) { usage(out); return 2; }
  if (!deps.cfg) loadEnvFile();
  const cfg = deps.cfg || loadConfig(process.env, { requireDashboard: cmd === 'preview' || cmd === 'once' });
  const log = deps.log || createLogger('스페이스클라우드', { level: cfg.logLevel });
  const sleep = deps.sleep || ((ms) => new Promise((r) => setTimeout(r, ms)));
  const now = deps.now || (() => Date.now());

  if (cfg.space && cfg.space.enabled === false) out('※ .env 에 SPACECLOUD=off — 상주 실행기는 홀 자동 막기를 안 돌린다(이 명령은 그대로 한다).');
  const ctx = { ...deps, sleep, now };
  /* preview · once — 일꾼이 한 판 안에서 자물쇠를 쥔다. 여기서는 비기를 잠깐 기다려만 본다. */
  if (cmd === 'preview' || cmd === 'once') {
    const busy = await waitProfileFree(cfg, out, ctx, () => heldByOther(cfg.paths.stateDir, { file: PROFILE_LOCK }));
    if (busy) return 1;
    return await runPass(cmd, cfg, log, out, ctx);
  }
  /* pair · map — 도는 내내 프로필 자물쇠를 쥔다(상주 일꾼이 그동안 쉰다). */
  const lock = deps.lock || new SingleInstanceLock(cfg.paths.stateDir, { file: PROFILE_LOCK });
  let got = null;
  const busy = await waitProfileFree(cfg, out, ctx, () => {
    got = lock.acquire();
    return got.ok ? { held: false } : { held: true, pid: got.pid };
  });
  if (busy) return 1;
  const touch = setInterval(() => lock.touch?.(), 60000);
  touch.unref?.();
  /* Ctrl+C 등으로 갑자기 끝나도 자물쇠를 놓는다(남겨 두면 그 pid 를 다른 프로그램이 물려받았을 때 상주 일꾼이 15분 동안 쉰다 — lock.js 머리말). */
  const onExit = () => lock.release();
  process.once('exit', onExit);
  try {
    if (cmd === 'pair') return await pair(cfg, log, out, ctx);
    return await map(cfg, log, out, ctx);
  } finally {
    clearInterval(touch);
    process.removeListener('exit', onExit);
    lock.release();
  }
}

/** 프로필이 빌 때까지 3초마다 본다(최대 BUSY_WAIT_MS). 비면 null, 끝내 안 비면 까닭을 말하고 { pid }. */
async function waitProfileFree(cfg, out, deps, check) {
  const until = deps.now() + (deps.busyWaitMs ?? BUSY_WAIT_MS);
  let said = false;
  for (;;) {
    let st;
    try { st = check(); } catch (e) { out(`※ 프로필 자물쇠를 못 봤다 — ${clean(e && e.message)} (그냥 한다)`); return null; }
    if (!st || !st.held) return null;
    if (deps.now() >= until) {
      out(`✗ 스페이스클라우드 브라우저 프로필(state/spacecloud/profile)을 지금 다른 곳(pid ${st.pid ?? '?'})이 쓰고 있다.`);
      out(st.pid === process.pid
        ? '  이 창 안에서 이미 쓰는 중이다 — 끝난 뒤 다시.'
        : '  실행기의 막기 판이면 곧 끝난다 — 1~2분 뒤 다시 눌러 주세요. 다른 「호스트센터 로그인」 창이 열려 있으면 그 창을 먼저 끝내 주세요.');
      return { pid: st.pid };
    }
    if (!said) { said = true; out(`… 스페이스클라우드 브라우저를 다른 곳(pid ${st.pid ?? '?'})이 쓰는 중 — 끝나기를 잠깐(최대 ${Math.round((deps.busyWaitMs ?? BUSY_WAIT_MS) / 1000)}초) 기다립니다.`); }
    await deps.sleep(deps.pollMs ?? POLL_MS);
  }
}

/** 브라우저를 못 열었을 때 한 줄 — 프로필을 다른 창이 쥐고 있으면 무엇을 하면 되는지도. */
function openFailed(out, e) {
  const msg = String(e && e.message || '');
  out(`✗ 브라우저를 못 열었다 — ${clean(msg, 300)}`);
  if (/다른 곳|ProcessSingleton|SingletonLock|already (?:in use|running)/i.test(msg)) {
    out('  스페이스클라우드 프로필을 다른 브라우저 창이 쥐고 있다 — 열려 있는 「호스트센터 로그인」 창을 닫거나 1~2분 뒤 다시 해 주세요.');
  }
  return 1;
}

function makeSession(cfg, log, deps, headless) {
  if (deps.makeSession) return deps.makeSession({ headless });
  /* busyLock = 프로필 자물쇠 — 상주 실행기 자물쇠(executor.lock)는 안 본다(머리말). */
  return new ChannelSession({ channel: CHANNEL, stateDir: cfg.paths.stateDir, secret: cfg.stateSecret, headless, browser: cfg.browser, log, busyLock: PROFILE_LOCK });
}

async function pair(cfg, log, out, deps) {
  const session = makeSession(cfg, log, deps, false);
  if (!cfg.stateSecret) out('※ STATE_SECRET 이 비어 있다 — 세션 백업(state/spacecloud/storage.json)이 평문으로 남는다.');
  const onSig = async () => { await soft(session.close(), 5000, null); process.exit(130); };
  if (!deps.makeSession) process.once('SIGINT', onSig);
  try {
    let page;
    try { page = await session.open({ headless: false }); } catch (e) { return openFailed(out, e); }
    let st = await openHost(page, { settleMs: deps.settleMs ?? 8000 });
    if (st.loggedIn) {
      out('✓ 이미 로그인돼 있다 — 그대로 저장한다.');
    } else {
      await soft(page.goto(LOGIN_URL, { waitUntil: 'domcontentloaded' }), 45000, null);
      out('');
      out('브라우저 창에서 스페이스클라우드 호스트센터에 로그인하세요.');
      out('  · 「로그인 기억하기」 를 꼭 체크하세요 — 안 하면 곧 풀려 다시 해야 합니다.');
      out('  · 사람 확인(체크 상자)이 나오면 직접 눌러 주세요. 실행기는 그것을 누르지 않습니다.');
      out(`  · 로그인이 끝나면 저절로 알아챕니다(키보드 입력 필요 없음) — ${Math.round((deps.waitMs ?? PAIR_WAIT_MS) / 60000)}분까지 기다립니다.`);
      out('');
      const until = deps.now() + (deps.waitMs ?? PAIR_WAIT_MS);
      let lastSaid = deps.now();
      while (deps.now() < until) {
        await deps.sleep(deps.pollMs ?? POLL_MS);
        if (page.isClosed?.()) { out('✗ 브라우저 창이 닫혔습니다 — 처음부터 다시 해 주세요.'); break; }
        st = await whoami(page);
        if (st.loggedIn) break;
        if (deps.now() - lastSaid >= 60000) {
          lastSaid = deps.now();
          out(`  …아직 기다리는 중(${Math.ceil((until - deps.now()) / 60000)}분 남음)`);
        }
      }
    }
    if (!st.loggedIn) {
      out('✗ 로그인을 확인하지 못했습니다 — 실행기 화면에서 「호스트센터 로그인」 을 다시 눌러 주세요.');
      return 1;
    }
    /* ★ 세션 백업(storage.json) 쓰기가 막혀도(15초 넘게 걸림 · 백신 · OneDrive 가 파일을 쥠) 겉보기 오류 더미로 끝내지 않는다(검토 [8]). */
    let saveErr = null;
    const saved = await soft(session.saveStorage().catch((e) => { saveErr = e; return false; }), 20000, false);
    /* 실행기 화면이 「로그인 필요」 를 계속 보이지 않게 상태 파일에 바로 적는다(검토 [5]) — 상주 일꾼도 이것을 받아 쓴다. */
    patchStatusFile(cfg.paths.stateDir, { login: true, ok: true, lastError: null, lastAction: saved ? '로그인 저장됨' : '로그인됨 · 세션 백업 못 함' },
      { now: deps.now(), enabled: cfg.space?.enabled !== false });
    if (!saved) {
      out('✗ 로그인은 됐지만 세션 백업(state/spacecloud/storage.json)을 저장하지 못했습니다' + (saveErr ? ` — ${clean(saveErr.message, 120)}` : ' — 시간 초과'));
      out('  브라우저 프로필에는 로그인이 남아 있어 실행기는 돌 수 있습니다. 백신 · OneDrive 가 그 파일을 쥐고 있을 수 있으니, 잠시 뒤 「호스트센터 로그인」 을 한 번 더 눌러 주세요.');
      return 1;
    }
    out('✓ 로그인 상태를 저장했습니다(이 PC 의 state/spacecloud 안에만 — 밖으로 안 나갑니다).');
    await showProducts(page, cfg, log, out, deps);
    out('');
    out('이제 실행기가 켜져 있으면 우리 홀 예약을 호스트센터 「+예약추가」 에 MOTMOT-번호로 막고, 취소되면 풉니다. 손님 정보는 가져오지 않습니다.');
    return 0;
  } finally {
    await soft(session.close(), 15000, null);
    if (!deps.makeSession) process.removeListener('SIGINT', onSig);
  }
}

async function showProducts(page, cfg, log, out, deps) {
  let list = null;
  try { list = await listProducts(page); } catch (e) { out(`⚠ 공간 · 상품 목록을 못 읽었다 — ${clean(e && e.message)}`); }
  if (!list) return null;
  const h = await hallsFrom(cfg, log, deps);
  if (!h.halls) out(`※ ${h.why}`);
  for (const line of describeProducts(list, h.halls, cfg.space?.products)) out(line);
  return list;
}

async function map(cfg, log, out, deps) {
  const session = makeSession(cfg, log, deps, cfg.space?.headless !== false);
  try {
    let page;
    try { page = await session.open(); } catch (e) { return openFailed(out, e); }
    const st = await openHost(page, { settleMs: deps.settleMs ?? 15000 });
    if (!st.loggedIn) {
      out(st.transient ? `✗ 호스트센터가 응답하지 않는다 — ${clean(st.why)}` : `✗ 호스트센터 로그인이 안 돼 있다(${clean(st.why)}) — npm start -- --space pair`);
      return 1;
    }
    out('✓ 호스트센터 로그인 됨');
    patchStatusFile(cfg.paths.stateDir, { login: true }, { now: (deps.now || Date.now)(), enabled: cfg.space?.enabled !== false });
    const list = await showProducts(page, cfg, log, out, deps);
    await soft(session.saveStorage(), 20000, false);
    return list ? 0 : 1;
  } finally {
    await soft(session.close(), 15000, null);
  }
}

async function runPass(cmd, cfg, log, out, deps) {
  const preview = cmd === 'preview';
  const dashboard = deps.dashboard || await new DashboardClient(cfg.dashboard, { log: log.child('대시보드') }).init();
  const worker = deps.worker || new SpaceWorker({ cfg, dashboard, log, ...(deps.makeSession ? { session: deps.makeSession({ headless: cfg.space?.headless !== false }) } : {}), ...(deps.settleMs != null ? { settleMs: deps.settleMs } : {}) });
  try {
    out(preview ? '미리보기 — 서버도 줄을 안 맡기고, 호스트센터 · 서버에 아무것도 안 씁니다.' : '한 판 — 서버가 맡긴 줄을 넣고 · 풀고 · 보고합니다.');
    const r = await worker.pass({ preview, force: true });
    for (const p of r.plans || []) {
      out(`  ${p.label} · ${p.op === 'add' ? '막기' : p.op === 'remove' ? '풀기' : String(p.op)} → ${p.plan}${p.why ? ` (${p.why})` : ''}`);
    }
    if (!(r.plans || []).length && r.ok !== false) out('  (지금 막거나 풀 줄이 없다)');
    out(worker.summarize(r));
    return r.ok === false || r.busy ? 1 : 0;
  } finally {
    await soft(worker.stop(), 15000, null);
  }
}

if (process.argv[1] && /cli[\\/]space\.js$/.test(process.argv[1])) {
  spaceCli().then((c) => process.exit(c), (e) => { console.error(scrubSecrets(e.stack || e.message)); process.exit(1); });
}
